package com.vocalink.runners;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;
/**
 * This class used to run the cucumber feature files
 * @author venkat
 *
 */
@RunWith(Cucumber.class)
@CucumberOptions(
        features = {
                "target/test-classes"
                
        },
        
        
        
        		plugin = {
        		        "pretty", "html:target/Ten10-Test-Report",
        		        "json:target/Vocalink-Test-Report/cucumber.json",
        		        "rerun:target/Vocalink-Test-Report/rerun.txt"},
        tags = {"@Test"},
        glue = {"com/vocalink/stepdefinations/"})
public class VocalinkTestRunner {
}
