package com.vocalink.stepdefinations;

import com.vocalink.Tub;
import com.vocalink.VendingMachine;
import com.vocalink.VendingMachineFactory;
import com.vocalink.enums.Coin;
import com.vocalink.enums.Products;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import org.apache.log4j.Logger;

import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;


/**
 * This class have the logic for programming exercise and expected outcome
 * @author venkat
 *
 */
public class VendingMachineStepDefinations {
	
	final static Logger logger = Logger.getLogger(VendingMachineStepDefinations.class);
	private static VendingMachine vendingMachine;

	@Before
	public static void setUp(){
		vendingMachine = VendingMachineFactory.createVendingMachine();
	}

	@Given("^User inserts coin of \"(.*?)\" in to machine$")
	public void user_inserts_coin_of_in_to_machine(String coins) throws Throwable {
		String collectonOfCoins[] =coins.split(",");
		for(String coin:collectonOfCoins)
		{
			vendingMachine.insertCoin(Coin.valueOf(coin));
		}

	}

	@When("^User select the product :\"(.*?)\"$")
	public void user_select_the_product(String product) throws Throwable {
		long price = vendingMachine.selectProductAndGetPrice(Products.valueOf(product));
		assertEquals(Products.valueOf(product).getPrice(), price);

	}

	@Then("^User collected the selected product \"(.*?)\" and remaining change \"(.*?)\"$")
	public void user_collected_the_selected_product_and_remaining_change(String selectedProduct, String returnChnage) throws Throwable {
		Tub<Products, List<Coin>> tub = vendingMachine.collectProductAndChange();
		Products product = tub.getFirst();
		List<Coin> change = tub.getSecond();
		assertEquals(Products.valueOf(selectedProduct), product);

		if(returnChnage!=null && !returnChnage.equals(""))
		{
			assertTrue(!change.isEmpty());
			assertEquals(Integer.parseInt(returnChnage) , getTotal(change));

		} else {
			assertTrue(change.isEmpty());
		}


	}

	@Then("^User cancel the request and Machine should refund the original amount \"(.*?)\"$")
	public void userCancelTheRequestAndMachineShouldRefundTheOriginalAmount(long amount) throws Throwable {
		assertEquals(amount, getTotal(vendingMachine.refund()));
	}

	@Then("^supplier reset the machine$")
	public void supplierResetTheMachine() throws Throwable {
		vendingMachine.reset();
	}

	@Then("^Total sales should return \"([^\"]*)\"$")
	public void totalSalesShouldReturn(String arg0) throws Throwable {
		assertEquals(0, vendingMachine.getTotalSales());
	}

	private long getTotal(List<Coin> change){
		long total = 0;
		for(Coin coin : change){
			total = total + coin.getDenomination();
		}
		return total;
	}

	@After
	public static void tearDown(){
		vendingMachine = null;
	}

}
