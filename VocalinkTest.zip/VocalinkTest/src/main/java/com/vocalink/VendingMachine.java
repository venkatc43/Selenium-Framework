package com.vocalink;

import com.vocalink.enums.Coin;
import com.vocalink.enums.Products;

import java.util.List;


/**
 * This class have the logic for programming exercise and expected outcome
 * @author venkat
 *
 */

public interface VendingMachine {
    public long selectProductAndGetPrice(Products products);
    public void insertCoin(Coin coin);
    public List<Coin> refund();
    public Tub<Products, List<Coin>> collectProductAndChange();
    public void reset();
    public long getTotalSales();
}
