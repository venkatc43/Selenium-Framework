package com.vocalink;

/**
 * This class have the logic for programming exercise and expected outcome
 * @author venkat
 *
 */

public class Tub<Products, Coin> {
    private Products first;
    private Coin second;

    public Tub(Products first, Coin second){
        this.first = first;
        this.second = second;
    }

    public Products getFirst(){
        return first;
    }

    public Coin getSecond(){
        return second;
    }
}
