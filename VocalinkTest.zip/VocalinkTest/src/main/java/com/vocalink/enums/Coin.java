package com.vocalink.enums;

/**
 * This class have the logic for programming exercise and expected outcome
 * @author venkat
 *
 */
public enum Coin {
    ONEPENNY(1), FIVEPENNY(5), TWENTYPENNY(20), FIVETYPENNY(50) ,POUND(100);

    private int denomination;

    private Coin(int denomination){
        this.denomination = denomination;
    }

    public int getDenomination(){
        return denomination;
    }
}
