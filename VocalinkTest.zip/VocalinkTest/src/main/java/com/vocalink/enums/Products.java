package com.vocalink.enums;

/**
 * This class have the logic for programming exercise and expected outcome
 * @author venkat
 *
 */
public enum Products {
    CANDY("Candy", 10), SNACK("Snack", 50), NUTS("Nuts", 75),COKE("Coke", 150),WATER("Water", 100);

    private String name;
    private int price;

    private Products(String name, int price){
        this.name = name;
        this.price = price;
    }

    public String getName(){
        return name;
    }

    public long getPrice(){
        return price;
    }
}
