package com.vocalink;

import com.vocalink.enums.Coin;
import com.vocalink.enums.Products;
import com.vocalink.exception.NotFullPaidException;
import com.vocalink.exception.NotSufficientChangeException;
import com.vocalink.exception.SoldOutException;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * This class have the logic for programming exercise and expected outcome
 * @author venkat
 *
 */

public class VendingMachineImpl implements VendingMachine {
    private Stock<Coin> cashAvailable = new Stock<Coin>();
    private Stock<Products> productsStock = new Stock<Products>();
    private long totalSales;
    private Products currentProducts;
    private long currentBalance;
    private List<Coin> changes;

    public VendingMachineImpl() {
        initialize();
    }

    private void initialize() {

        for (Coin coins : Coin.values()) {
            cashAvailable.put(coins, 10);
        }

        for (Products products : Products.values()) {
            productsStock.put(products, 10);
        }

    }

    @Override
    public long selectProductAndGetPrice(Products products) {
        if (productsStock.hasItem(products)) {
            currentProducts = products;
            return currentProducts.getPrice();
        }
        throw new SoldOutException("Products Sold Out, Please buy another products");
    }

    @Override
    public void insertCoin(Coin coin) {
        currentBalance = currentBalance + coin.getDenomination();
        cashAvailable.add(coin);
    }

    @Override
    public Tub<Products, List<Coin>> collectProductAndChange() {
        Products products = collectItem();
        totalSales = totalSales + currentProducts.getPrice();

        List<Coin> change = collectChange();

        return new Tub<Products, List<Coin>>(products, change);
    }

    private Products collectItem() throws NotSufficientChangeException,
            NotFullPaidException {
        if (isFullPaid()) {
            if (hasSufficientChange()) {
                productsStock.deduct(currentProducts);
                return currentProducts;
            }
            throw new NotSufficientChangeException("Not Sufficient change available");

        }
        long remainingBalance = currentProducts.getPrice() - currentBalance;
        throw new NotFullPaidException("Price not full paid, remaining : ",
                remainingBalance);
    }

    private List<Coin> collectChange() {
        long changeAmount = currentBalance - currentProducts.getPrice();
        List<Coin> change = getChange(changeAmount);
        updatecashAvailable(change);
        currentBalance = 0;
        currentProducts = null;
        return change;
    }

    @Override
    public List<Coin> refund() {
        List<Coin> refund = getChange(currentBalance);
        updatecashAvailable(refund);
        currentBalance = 0;
        currentProducts = null;
        return refund;
    }


    private boolean isFullPaid() {
        return currentBalance >= currentProducts.getPrice();
    }


    private List<Coin> getChange(long amount) throws NotSufficientChangeException {
        changes = Collections.EMPTY_LIST;
        if (amount > 0) {
            changes = new ArrayList<>();
            long balance = amount;
            while (balance > 0) {

                if (balance >= Coin.POUND.getDenomination()
                        && cashAvailable.hasItem(Coin.POUND)) {
                    changes.add(Coin.POUND);
                    balance = balance - Coin.POUND.getDenomination();
                    continue;

                } else if (balance >= Coin.FIVETYPENNY.getDenomination()
                        && cashAvailable.hasItem(Coin.FIVETYPENNY)) {
                    changes.add(Coin.FIVETYPENNY);
                    balance = balance - Coin.FIVETYPENNY.getDenomination();
                    continue;

                } else if (balance >= Coin.TWENTYPENNY.getDenomination()
                        && cashAvailable.hasItem(Coin.TWENTYPENNY)) {
                    changes.add(Coin.TWENTYPENNY);
                    balance = balance - Coin.TWENTYPENNY.getDenomination();
                    continue;

                } else if (balance >= Coin.FIVEPENNY.getDenomination()
                        && cashAvailable.hasItem(Coin.FIVEPENNY)) {
                    changes.add(Coin.FIVEPENNY);
                    balance = balance - Coin.FIVEPENNY.getDenomination();
                    continue;

                } else if (balance >= Coin.ONEPENNY.getDenomination()
                        && cashAvailable.hasItem(Coin.ONEPENNY)) {
                    changes.add(Coin.ONEPENNY);
                    balance = balance - Coin.ONEPENNY.getDenomination();
                    continue;

                } else {
                    throw new NotSufficientChangeException("NotSufficientChange,Please try another product");
                }
            }
        }

        return changes;
    }

    @Override
    public void reset() {
        cashAvailable.clear();
        productsStock.clear();
        totalSales = 0;
        currentProducts = null;
        currentBalance = 0;
    }

    private boolean hasSufficientChange() {
        return hasSufficientChangeForAmount(currentBalance - currentProducts.getPrice());
    }

    private boolean hasSufficientChangeForAmount(long amount) {
        boolean hasChange = true;
        try {
            getChange(amount);
        } catch (NotSufficientChangeException nsce) {
            return hasChange = false;
        }

        return hasChange;
    }

    private void updatecashAvailable(List<Coin> change) {
        for (Coin coin : change) {
            cashAvailable.deduct(coin);
        }
    }

    public long getTotalSales() {
        return totalSales;
    }

    private long getBalance(long balance,String coinName)
    {
        if (balance >= Coin.valueOf(coinName).getDenomination()
                && cashAvailable.hasItem(Coin.valueOf(coinName))) {
            changes.add(Coin.valueOf(coinName));
            balance = balance - Coin.valueOf(coinName).getDenomination();
        }else {
            throw new NotSufficientChangeException("NotSufficientChange,Please try another product");
        }
        return balance;
    }

}

