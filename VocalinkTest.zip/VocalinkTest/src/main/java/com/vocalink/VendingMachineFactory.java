package com.vocalink;

/**
 * This class have the logic for programming exercise and expected outcome
 * @author venkat
 *
 */

public class VendingMachineFactory {
    public static VendingMachine createVendingMachine() {
        return new VendingMachineImpl();
    }
}
