Ten10 Technical test
=================================

Scenarios:
1. Return selected product and remaining change if any
2. Allow user to take refund by cancelling the request
3. Allow reset operation for vending machine by supplier

To run,
1. you need to unzip and navigate to VocalinkTest folder
2. you will need to install maven if you don't have, then:
3. open the command prompt and navigate to VocalinkTest
4. Type the command :mvn clean test
5.Once finished a report will be generated at /target/Vocalink-Test-Report/index.html


1) High-level Design
Includes overview of the problem

    - Main interface, classes and Exceptions
          - VendingMachine - an interface which defines public API of VendingMachine
          - VendingMachineImpl - a general purpose implementation of VendingMachine interface
          - Stock - A type-safe Stock for holding objects, which is an ADAPTER or WRAPPER over java.util.Map
          - Products - type-safe Enum to represent products supported by vending machine.
          - Coin - type-safe Enum to represent coins, which is acceptable by vending machine.
          - Tub - A class for holding two types together.
          - SoldOutException - thrown when user selects a product which is sold out
          - NotSufficientChangeException - thrown when Vending machine doesn't have enough change to support the current transaction.

          - NotFullPaidException - thrown when the user tries to collect an products, without paying the full amount.

    - Data structures used
          - Map data structure is used to implement cash and products inventories.
          - The List is used to returning changes because it can contain duplicates, i.e. multiple coins of the same denomination.


    - Motivation behind design decisions
         - Factory design pattern is used to encapsulate creation logic of VendingMachine.
         - Adapter pattern is used to create Stock by wrapping java.util.Map
         - java.lang.Enum is used to represent Products and Coins, because of following benefits
                - compile time safety against entering an invalid products and invalid coin.
                - no need to write code for checking if selected products or entered coin is valid.
                - reusable and well encapsulated.
         - long is used to represent price and totalSales, which are the amount because we are dealing in cents.


