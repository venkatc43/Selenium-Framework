CheckCarRegistration Exercise
=================================

Scenarios:
1. Reads the input file and verify car registration details


To run,
1. Navigate to CheckCarRegistration folder
2. you will need to install maven if you don't have, then:
3. open the command prompt and navigate to CheckCarRegistration
4. Type the command :mvn clean test
5.Once finished a report will be generated at /target/Registration-Test-Report/index.html
