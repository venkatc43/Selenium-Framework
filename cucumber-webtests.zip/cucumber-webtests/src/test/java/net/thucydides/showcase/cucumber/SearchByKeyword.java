package net.thucydides.showcase.cucumber;

import cucumber.api.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import org.junit.runner.RunWith;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(
        features = {
                "target/test-classes"
                
        },
        		plugin = {
        		        "pretty", "html:target/cucumber-report/moj",
        		        "json:target/cucumber-report/moj/cucumber.json",
        		        "rerun:target/cucumber-report/moj/rerun.txt"},
        tags = {"@test"}
        )
public class SearchByKeyword  {}
