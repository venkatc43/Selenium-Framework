package com.marks.spencers.driver;

import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebDriverUtils {
	
	private WebDriver webDriver;
	private int WAIT_TIMEOUT = 60;

	public WebDriverUtils(SharedDriver webDriver) {
		this.webDriver = webDriver;
	}

	public void enterText(WebElement element, String charSequence) {
		element.clear();
		element.sendKeys(charSequence);
	}

	public void waitForVisibilityOfElement(WebElement element) {
		int count=0;
		while(count < 3)
		{
			try{
				new WebDriverWait(webDriver, WAIT_TIMEOUT).until(ExpectedConditions.visibilityOf(element));	
			} catch (StaleElementReferenceException e)
			{		
			}
			count++;
		}
	}

	public void waitForElementTobeClickable(WebElement element) {
		new WebDriverWait(webDriver, WAIT_TIMEOUT).until(ExpectedConditions.elementToBeClickable(element));
	}
	
	public void selectDropDown(WebElement element, String title) {
		new Select(element).selectByVisibleText(title);
	}
	
	public void goToHomeUrl(String homeUrl)
	{
		webDriver.get(homeUrl);
	}

}
