package com.marks.spencers.pageobjects;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;
import com.marks.spencers.driver.SharedDriver;
import com.marks.spencers.driver.WebDriverUtils;

public class SearchPageObject extends WebDriverUtils{
	
    public SearchPageObject(SharedDriver webDriver) {
    	super(webDriver);
		PageFactory.initElements(new AjaxElementLocatorFactory(webDriver, 20), this);
    }

    @FindBy(id = "global-search")
	private WebElement searchBox;
    
    @FindBy(id = "goButton")
	private WebElement searchButton;
    
    @FindBy(css = ".criteria>strong")
	private WebElement searchResultsTerm;
    
    @FindBy(css = ".model-view")
	private List<WebElement> searchResultProducts;
    
    @FindBy(css = ".criteria")
	private WebElement invalidSerchResultsText;
    
    @FindBy(id = "itemcount-top")
	private WebElement productsCountDropDown;
    
    public void enterSearchTerm(String searchTerm) {
       enterText(searchBox, searchTerm); 
    }

    public void submitSearch() {
        waitForElementTobeClickable(searchButton);
        searchButton.click();
    }

    public String getSearchTerm()
    {
    	waitForVisibilityOfElement(searchResultsTerm);
    	return searchResultsTerm.getText();
    }
    
    public boolean isSearchResultsViewDisplayed()
    {
    	waitForVisibilityOfElement(searchResultProducts.get(0));
    	return searchResultProducts.get(0).isDisplayed();
    }
    
    public String getInvalidResultsText()
    {
    	waitForVisibilityOfElement(invalidSerchResultsText);
    	return invalidSerchResultsText.getText();
    }
    
    public void selectShowProductsperPage(String title)
    {
    	waitForVisibilityOfElement(productsCountDropDown);
    	selectDropDown(productsCountDropDown, title);
    }
    
    public int getProductsDisplayed()
    {
    	waitForVisibilityOfElement(searchResultProducts.get(0));
    	return searchResultProducts.size();
    }
    
    
}
