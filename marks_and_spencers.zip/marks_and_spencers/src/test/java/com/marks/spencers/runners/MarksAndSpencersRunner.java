package com.marks.spencers.runners;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import net.serenitybdd.cucumber.CucumberWithSerenity;

import org.junit.runner.RunWith;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(
        features = {
                "target/test-classes"
                
        },
        
        
        
        		plugin = {
        		        "pretty", "html:target/Marks-Spencers-Repor",
        		        "json:target/Marks-Spencers-Repor/cucumber.json",
        		        "rerun:target/Marks-Spencers-Repor/rerun.txt"},
        tags = {"@search"},
        glue = {"com/marks/spencers/stepdefinations/"})
public class MarksAndSpencersRunner {
}
