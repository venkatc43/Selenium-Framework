package com.marks.spencers.stepdefinations;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import com.marks.spencers.driver.SharedDriver;
import com.marks.spencers.pageobjects.SearchPageObject;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SearchStepDefinations {
	
    private SearchPageObject searchPage;
    private String searchType =null;
    public SearchStepDefinations(SharedDriver webDriver) {
        searchPage = new SearchPageObject(webDriver);
    }

    @Given("^I am on Marks and spencers home page \"([^\"]*)\"$")
    public void I_am_on_Marks_and_spencers_home_page(String url) throws Throwable {
    	searchPage.goToHomeUrl(url); 
    }

    @When("^I enter \"([^\"]*)\" search product name: \"([^\"]*)\"$")
    public void I_enter_search_product_name(String productType, String searchTerm) throws Throwable {
    	searchType=productType;
    	searchPage.enterSearchTerm(searchTerm);
    }

    @When("^I click on go button$")
    public void I_click_on_go_button() throws Throwable {
    	searchPage.submitSearch();
    }

    @Then("^should see the serach term \"([^\"]*)\"$")
    public void should_see_the_serach_term(String resultsProductTerm) throws Throwable {
    	 switch(searchType)
         {
         case "Valid":
        	 assertEquals(resultsProductTerm, searchPage.getSearchTerm());
      	   break;
         case "Invalid":
        	 assertEquals(resultsProductTerm, searchPage.getInvalidResultsText());
      	   break;
         }
    	
    }

    @Then("^Should see the \"([^\"]*)\" view of the product results$")
    public void Should_see_the_view_of_the_product_results(String seearchResultsType) throws Throwable {
       if(seearchResultsType.equals("Valid"))
       {
    	   assertTrue("Search Results not displayed", searchPage.isSearchResultsViewDisplayed());
       } 	   
    }
    
    @When("^I select show products per page \"([^\"]*)\"$")
    public void I_select_show_products_per_page(String ShowProductsPerPage) throws Throwable {
    	searchPage.selectShowProductsperPage(ShowProductsPerPage);
    }

    @Then("^I Should see selected products per page \"([^\"]*)\"$")
    public void I_Should_see_selected_products_per_page(String resultsPerPage) throws Throwable {
    	assertEquals(resultsPerPage, String.valueOf(searchPage.getProductsDisplayed()));
    }
      
}
