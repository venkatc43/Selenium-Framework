Marks and Spencers screening test
=================================

project showing running of Marks and spencers global search results .

Scenarios:
1. Search with valid product
2. Search with invalid product
3. Search results showing items per page 24
4. Search results showing items per page 48


To run,
1. you need to unzip and navigate to marks_and_spencers
2. you will need to install maven if you don't have, then:
3. open the command prompt and navigate to marks_and_spencers
4. Type the command :mvn clean install 
5.Once finished a report will be generated at /target/Marks-Spencers-Report/index.html
