/**
 * 
 */
package com.rota.json;

/**
 * @author Venkat
 * All jsons need to get it from this interface
 */
public interface JsonAsString {
	
	public static String magAdhocSearch="{\"ljaId\":ljaValue,\"combinedPanelId\":null,\"availableDate\":null,"
			+ "\"amSession\":null,\"pmSession\":null,\"availableStartDate\":null,\"availableEndDate\":null,"
			+ "\"location\":\"locationValue\",\"panel\":\"panelValue\",\"adHocMagistrates\":adhocValue,\"panelStatus\":\"\","
			+ "\"specialistAuthority\":\"specialAuthValue\",\"appraiser\":null,\"mentor\":null,\"shortNoticeOption\":null,"
			+ "\"consecutiveDaysOption\":null,\"outOfHours\":null,\"bankHolidays\":null,"
			+ "\"sitSaturdays\":null,\"doCrossBenchAppraisals\":null,\"welshSpeaking\":null}";
	
	public static String updateRota="[{\"id\":\"IdValue\",\"panelType\":\"ADULT\",\"specialistBusinessType\":\"1\","
			+ "\"session\":\"AM\",\"day\":2,\"sessionDate\":\"01/12/2015\",\"welsh\":welshValue,\"dj\":false,\"singleJustice\":false,"
			+ "\"numberOfMagistrates\":3,\"outsideRotaPeriod\":false,\"districtJudge\":null,"
			+ "\"chair\":{\"id\":\"sessionsIdValue\",\"title\":null,\"lastName\":\"Green\","
			+ "\"firstName\":\"Richard\",\"gender\":1,\"specialRequirement\":false,\"specialRequirementText\":\"\","
			+ "\"localAuthorityEmployee\":false,\"localAuthorityEmployeeText\":\"\",\"welsh\":false,\"newWinger\":false,"
			+ "\"winger\":null,\"traineeChair\":false,\"chair\":true,\"mentor\":null,\"appraiser\":null,\"totalNumberOfAdultSittings\":0,"
			+ "\"totalNumberOfYouthSittings\":0,\"totalNumberOfFamilySittings\":0,\"adultSitter\":null,\"familySitter\":null,"
			+ "\"youthSitter\":null,\"justiceSitsAtJusticeAreaLocation\":true,\"justiceAdhocSitsAtLocation\":false,"
			+ "\"justiceIsAssignedToJusticeArea\":true,\"offerStatus\":null,\"offerDate\":null,\"email\":null,\"phoneNumber\":null},"
			+ "\"winger1\":{\"id\":\"sessionsIdValue\",\"title\":null,\"lastName\":\"Taylor\","
			+ "\"firstName\":\"Graham\",\"gender\":1,\"specialRequirement\":false,\"specialRequirementText\":null,"
			+ "\"localAuthorityEmployee\":false,\"localAuthorityEmployeeText\":\"\",\"welsh\":false,\"newWinger\":false,\"winger\":null,"
			+ "\"traineeChair\":false,\"chair\":false,\"mentor\":null,\"appraiser\":null,\"totalNumberOfAdultSittings\":0,"
			+ "\"totalNumberOfYouthSittings\":0,\"totalNumberOfFamilySittings\":0,\"adultSitter\":null,\"familySitter\":null,"
			+ "\"youthSitter\":null,\"justiceSitsAtJusticeAreaLocation\":true,\"justiceAdhocSitsAtLocation\":false,\"justiceIsAssignedToJusticeArea\":true,"
			+ "\"offerStatus\":null,\"offerDate\":null,\"email\":null,\"phoneNumber\":null},"
			+ "\"winger2\":{\"id\":\"sessionsIdValue\",\"title\":null,\"lastName\":\"Noble\","
			+ "\"firstName\":\"Kirsty\",\"gender\":2,\"specialRequirement\":false,\"specialRequirementText\":\"\","
			+ "\"localAuthorityEmployee\":false,\"localAuthorityEmployeeText\":\"\",\"welsh\":false,\"newWinger\":false,\"winger\":null,"
			+ "\"traineeChair\":false,\"chair\":true,\"mentor\":null,\"appraiser\":null,\"totalNumberOfAdultSittings\":0,"
			+ "\"totalNumberOfYouthSittings\":0,\"totalNumberOfFamilySittings\":0,\"adultSitter\":null,\"familySitter\":null,"
			+ "\"youthSitter\":null,\"justiceSitsAtJusticeAreaLocation\":true,\"justiceAdhocSitsAtLocation\":false,"
			+ "\"justiceIsAssignedToJusticeArea\":true,\"offerStatus\":null,\"offerDate\":null,\"email\":null,"
			+ "\"phoneNumber\":null},\"lastSittingDistrictJudge\":false,\"returningBenchDistrictJudge\":false,"
			+ "\"returningBenchDistrictJudgeReason\":null,\"lastSittingSingleJustice\":false,\"returningBenchSingleJustice\":false,"
			+ "\"returningBenchSingleJusticeReason\":null,\"applicationsSingleJustice\":false,\"lastSittingChair\":false,"
			+ "\"returningBenchChair\":false,\"returningBenchChairReason\":null,\"applicationsChair\":false,\"lastSittingWinger1\":false,"
			+ "\"returningBenchWinger1\":false,\"returningBenchWinger1Reason\":null,\"applicationsWinger1\":false,"
			+ "\"lastSittingWinger2\":false,\"returningBenchWinger2\":false,\"returningBenchWinger2Reason\":null,"
			+ "\"applicationsWinger2\":false,\"confirmed\":false,\"duration\":2,\"linked\":false,\"brokenLinked\":false,"
			+ "\"parentId\":null,\"sittingIdentifierChair\":null,\"sittingIdentifierWinger1\":null,\"sittingIdentifierWinger2\":null,"
			+ "\"version\":versionValue,\"deputyDj\":null,\"brokenRulesCount\":3}]";
	
	public static String create_Session_update="{\"id\":idValue,\"panelType\":\"panelValue\",\"specialistBusinessType\":\"businessTypeValue\",\"session\":\"PM\",\"day\":dayValue,\"sessionDate\":\"sessionDateValue\","
			+ "\"welsh\":welshValue,\"dj\":djValue,\"singleJustice\":sjValue,\"numberOfMagistrates\":magistratesVal,\"outsideRotaPeriod\":false,\"districtJudge\":null,\"chair\":null,\"winger1\":null,"
			+ "\"winger2\":null,\"lastSittingDistrictJudge\":false,\"returningBenchDistrictJudge\":false,\"returningBenchDistrictJudgeReason\":null,\"lastSittingSingleJustice\":false,"
			+ "\"returningBenchSingleJustice\":false,\"returningBenchSingleJusticeReason\":null,\"applicationsSingleJustice\":false,\"lastSittingChair\":false,\"returningBenchChair\":false,"
			+ "\"returningBenchChairReason\":null,\"applicationsChair\":false,\"lastSittingWinger1\":false,\"returningBenchWinger1\":false,\"returningBenchWinger1Reason\":null,"
			+ "\"applicationsWinger1\":false,\"lastSittingWinger2\":false,\"returningBenchWinger2\":false,\"returningBenchWinger2Reason\":null,\"applicationsWinger2\":false,"
			+ "\"confirmed\":false,\"duration\":1,\"linked\":false,\"brokenLinked\":false,\"parentId\":null,\"sittingIdentifierChair\":null,\"sittingIdentifierWinger1\":null,"
			+ "\"sittingIdentifierWinger2\":null,\"version\":versionValue,\"deputyDj\":null,\"brokenRulesCount\":0}";
	
	public static String existing_session_mag_update="{\"id\":\"idValue\",\"panelType\":\"ADULT\",\"specialistBusinessType\":\"6\",\"session\":\"PM\",\"day\":dayValue,"
			+ "\"sessionDate\":\"sessionDateValue\",\"welsh\":welshValue,\"dj\":false,\"singleJustice\":false,\"numberOfMagistrates\":2,\"outsideRotaPeriod\":false,"
			+ "\"districtJudge\":null,\"chair\":null,\"winger1\":{\"id\":\"sessionsIdValue\",\"title\":\"Reverend\",\"lastName\":\"Taylor\","
			+ "\"firstName\":\"Ian\",\"gender\":1,\"specialRequirement\":false,\"specialRequirementText\":null,\"localAuthorityEmployee\":false,"
			+ "\"localAuthorityEmployeeText\":null,\"welsh\":false,\"newWinger\":false,\"winger\":true,\"traineeChair\":false,\"chair\":false,\"mentor\":true,"
			+ "\"appraiser\":true,\"totalNumberOfAdultSittings\":12,\"totalNumberOfYouthSittings\":3,\"totalNumberOfFamilySittings\":0,\"adultSitter\":true,"
			+ "\"familySitter\":true,\"youthSitter\":true,\"justiceSitsAtJusticeAreaLocation\":true,\"justiceAdhocSitsAtLocation\":false,"
			+ "\"justiceIsAssignedToJusticeArea\":true,\"offerStatus\":\"NOT_OFFERED\",\"offerDate\":null,\"email\":\"ian.taylor@email9.com\","
			+ "\"phoneNumber\":\"07782 807625\"},\"winger2\":null,\"lastSittingDistrictJudge\":false,\"returningBenchDistrictJudge\":false,"
			+ "\"returningBenchDistrictJudgeReason\":null,\"lastSittingSingleJustice\":false,\"returningBenchSingleJustice\":false,\"returningBenchSingleJusticeReason\":null,"
			+ "\"applicationsSingleJustice\":false,\"lastSittingChair\":false,\"returningBenchChair\":false,\"returningBenchChairReason\":null,"
			+ "\"applicationsChair\":false,\"lastSittingWinger1\":false,\"returningBenchWinger1\":false,\"returningBenchWinger1Reason\":null,"
			+ "\"applicationsWinger1\":false,\"lastSittingWinger2\":false,\"returningBenchWinger2\":false,\"returningBenchWinger2Reason\":null,"
			+ "\"applicationsWinger2\":false,\"confirmed\":false,\"duration\":1,\"linked\":false,\"brokenLinked\":false,\"parentId\":null,"
			+ "\"sittingIdentifierChair\":null,\"sittingIdentifierWinger1\":null,\"sittingIdentifierWinger2\":null,\"version\":versionValue,\"deputyDj\":null,"
			+ "\"brokenRulesCount\":0}";

  public static String create_session="{\"id\":null,\"panelType\":\"panelValue\",\"specialistBusinessType\":\"businessTypeValue\",\"session\":\"sessionType\",\"day\":dayValue,\"sessionDate\":\"sessionDateValue\""
  		+ ",\"welsh\":false,\"dj\":false,\"singleJustice\":false,\"numberOfMagistrates\":3,\"outsideRotaPeriod\":false,\"districtJudge\":null,\"chair\":null,\"winger1\":null,\"winger2\":null,"
  		+ "\"lastSittingDistrictJudge\":false,\"returningBenchDistrictJudge\":false,\"returningBenchDistrictJudgeReason\":null,\"lastSittingSingleJustice\":false,\"returningBenchSingleJustice\":false,"
  		+ "\"returningBenchSingleJusticeReason\":null,\"applicationsSingleJustice\":false,\"lastSittingChair\":false,\"returningBenchChair\":false,\"returningBenchChairReason\":null,"
  		+ "\"applicationsChair\":false,\"lastSittingWinger1\":false,\"returningBenchWinger1\":false,\"returningBenchWinger1Reason\":null,\"applicationsWinger1\":false,\"lastSittingWinger2\":false,"
  		+ "\"returningBenchWinger2\":false,\"returningBenchWinger2Reason\":null,\"applicationsWinger2\":false,\"confirmed\":false,\"duration\":durationValue,\"linked\":false,\"brokenLinked\":false,\"parentId\":null,"
  		+ "\"sittingIdentifierChair\":null,\"sittingIdentifierWinger1\":null,\"sittingIdentifierWinger2\":null,\"version\":versionValue,\"deputyDj\":null,\"brokenRulesCount\":0}";
  
  public static String create_session_vacate_update="{\"id\":\"idValue\",\"panelType\":\"panelValue\",\"specialistBusinessType\":\"businessTypeValue\",\"session\":\"sessionType\",\"day\":dayValue,\"sessionDate\":\"sessionDateValue\",\"welsh\":false,"
  		+ "\"dj\":false,\"singleJustice\":false,\"numberOfMagistrates\":3,\"outsideRotaPeriod\":false,\"districtJudge\":null,\"chair\":null,\"winger1\":{\"id\":\"sessionsIdValue\","
  		+ "\"title\":\"Miss\",\"lastName\":\"Ives\",\"firstName\":\"Jean\",\"gender\":2,\"specialRequirement\":false,\"specialRequirementText\":null,\"localAuthorityEmployee\":false,\"localAuthorityEmployeeText\":null,"
  		+ "\"welsh\":false,\"newWinger\":false,\"winger\":true,\"traineeChair\":false,\"chair\":false,\"mentor\":true,\"appraiser\":true,\"totalNumberOfAdultSittings\":6,\"totalNumberOfYouthSittings\":14,\"totalNumberOfFamilySittings\":0,"
  		+ "\"adultSitter\":true,\"familySitter\":true,\"youthSitter\":true,\"justiceSitsAtJusticeAreaLocation\":true,\"justiceAdhocSitsAtLocation\":false,\"justiceIsAssignedToJusticeArea\":true,\"offerStatus\":\"NOT_OFFERED\","
  		+ "\"offerDate\":null,\"email\":\"jean.ives@email10.com\",\"phoneNumber\":\"70783 807625\"},\"winger2\":null,\"lastSittingDistrictJudge\":false,\"returningBenchDistrictJudge\":false,\"returningBenchDistrictJudgeReason\":null,"
  		+ "\"lastSittingSingleJustice\":false,\"returningBenchSingleJustice\":false,\"returningBenchSingleJusticeReason\":null,\"applicationsSingleJustice\":false,\"lastSittingChair\":false,\"returningBenchChair\":false,"
  		+ "\"returningBenchChairReason\":null,\"applicationsChair\":false,\"lastSittingWinger1\":false,\"returningBenchWinger1\":false,\"returningBenchWinger1Reason\":null,\"applicationsWinger1\":false,\"lastSittingWinger2\":false,"
  		+ "\"returningBenchWinger2\":false,\"returningBenchWinger2Reason\":null,\"applicationsWinger2\":false,\"confirmed\":false,\"duration\":durationValue,\"linked\":false,\"brokenLinked\":false,\"parentId\":null,\"sittingIdentifierChair\":null,"
  		+ "\"sittingIdentifierWinger1\":null,\"sittingIdentifierWinger2\":null,\"version\":versionValue,\"deputyDj\":null,\"brokenRulesCount\":0}";
  
  public static String vacate_session_vacate_update="{\"id\":\"idValue\",\"panelType\":\"panelValue\",\"specialistBusinessType\":\"businessTypeValue\",\"session\":\"sessionType\",\"day\":dayValue,"
  		+ "\"sessionDate\":\"sessionDateValue\",\"welsh\":false,\"dj\":false,\"singleJustice\":false,\"numberOfMagistrates\":3,\"outsideRotaPeriod\":false,\"districtJudge\":null,"
  		+ "\"chair\":null,\"winger1\":{\"id\":\"sessionsIdValue\",\"title\":\"Mrs\",\"lastName\":\"Blundenholme\",\"firstName\":\"Janette\","
  		+ "\"gender\":2,\"specialRequirement\":false,\"specialRequirementText\":null,\"localAuthorityEmployee\":false,\"localAuthorityEmployeeText\":null,\"welsh\":false,"
  		+ "\"newWinger\":false,\"winger\":false,\"traineeChair\":false,\"chair\":true,\"mentor\":false,\"appraiser\":false,\"totalNumberOfAdultSittings\":12,"
  		+ "\"totalNumberOfYouthSittings\":0,\"totalNumberOfFamilySittings\":0,\"adultSitter\":true,\"familySitter\":false,\"youthSitter\":false,"
  		+ "\"justiceSitsAtJusticeAreaLocation\":true,\"justiceAdhocSitsAtLocation\":false,\"justiceIsAssignedToJusticeArea\":true,\"offerStatus\":\"NOT_OFFERED\","
  		+ "\"offerDate\":null,\"email\":\"blundenholme@email10.com\",\"phoneNumber\":\"07773 192404\"},\"winger2\":null,\"lastSittingDistrictJudge\":false,"
  		+ "\"returningBenchDistrictJudge\":false,\"returningBenchDistrictJudgeReason\":null,\"lastSittingSingleJustice\":false,\"returningBenchSingleJustice\":false,"
  		+ "\"returningBenchSingleJusticeReason\":null,\"applicationsSingleJustice\":false,\"lastSittingChair\":false,\"returningBenchChair\":false,\"returningBenchChairReason\":null,"
  		+ "\"applicationsChair\":false,\"lastSittingWinger1\":false,\"returningBenchWinger1\":false,\"returningBenchWinger1Reason\":null,\"applicationsWinger1\":false,"
  		+ "\"lastSittingWinger2\":false,\"returningBenchWinger2\":false,\"returningBenchWinger2Reason\":null,\"applicationsWinger2\":false,\"confirmed\":false,\"duration\":1,"
  		+ "\"linked\":false,\"brokenLinked\":false,\"parentId\":null,\"sittingIdentifierChair\":null,\"sittingIdentifierWinger1\":null,\"sittingIdentifierWinger2\":null,"
  		+ "\"version\":versionValue,\"deputyDj\":null,\"brokenRulesCount\":0,\"linkedDuration\":0,\"linkedPosition\":0}";
  
  public static String vacate_schedule_sittings="{\"id\":\"idValue\",\"type\":\"vacatedType\",\"position\":\"WINGER_1\",\"reason\":\"Moving\",\"version\":versionValue,"
  		+ "\"brokenLinked\":false}";
  		
  public static String identifier_update="{\"id\":\"idValue\",\"panelType\":\"ADULT\",\"specialistBusinessType\":\"6\",\"session\":\"PM\",\"day\":dayValue,"
			+ "\"sessionDate\":\"sessionDateValue\",\"welsh\":welshValue,\"dj\":false,\"singleJustice\":false,\"numberOfMagistrates\":2,\"outsideRotaPeriod\":false,"
			+ "\"districtJudge\":null,\"chair\":null,\"winger1\":{\"id\":\"sessionsIdValue\",\"title\":\"Reverend\",\"lastName\":\"Taylor\","
			+ "\"firstName\":\"Ian\",\"gender\":1,\"specialRequirement\":false,\"specialRequirementText\":null,\"localAuthorityEmployee\":false,"
			+ "\"localAuthorityEmployeeText\":null,\"welsh\":false,\"newWinger\":false,\"winger\":true,\"traineeChair\":false,\"chair\":false,\"mentor\":true,"
			+ "\"appraiser\":true,\"totalNumberOfAdultSittings\":12,\"totalNumberOfYouthSittings\":3,\"totalNumberOfFamilySittings\":0,\"adultSitter\":true,"
			+ "\"familySitter\":true,\"youthSitter\":true,\"justiceSitsAtJusticeAreaLocation\":true,\"justiceAdhocSitsAtLocation\":false,"
			+ "\"justiceIsAssignedToJusticeArea\":true,\"offerStatus\":\"NOT_OFFERED\",\"offerDate\":null,\"email\":\"ian.taylor@email9.com\","
			+ "\"phoneNumber\":\"07782 807625\"},\"winger2\":null,\"lastSittingDistrictJudge\":false,\"returningBenchDistrictJudge\":false,"
			+ "\"returningBenchDistrictJudgeReason\":null,\"lastSittingSingleJustice\":false,\"returningBenchSingleJustice\":false,\"returningBenchSingleJusticeReason\":null,"
			+ "\"applicationsSingleJustice\":false,\"lastSittingChair\":false,\"returningBenchChair\":false,\"returningBenchChairReason\":null,"
			+ "\"applicationsChair\":false,\"lastSittingWinger1\":lsWingValue1,\"returningBenchWinger1\":rbWinger1,\"returningBenchWinger1Reason\":\"returningBenchReason\","
			+ "\"applicationsWinger1\":apsValue1,\"lastSittingWinger2\":false,\"returningBenchWinger2\":false,\"returningBenchWinger2Reason\":null,"
			+ "\"applicationsWinger2\":false,\"confirmed\":confirmedValue,\"duration\":1,\"linked\":false,\"brokenLinked\":false,\"parentId\":null,"
			+ "\"sittingIdentifierChair\":null,\"sittingIdentifierWinger1\":\"sittingIdentifierValue1\",\"sittingIdentifierWinger2\":null,\"version\":versionValue,\"deputyDj\":null,"
			+ "\"brokenRulesCount\":0}";	

}
