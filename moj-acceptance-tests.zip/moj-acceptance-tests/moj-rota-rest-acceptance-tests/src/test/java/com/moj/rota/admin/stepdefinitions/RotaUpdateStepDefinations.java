package com.moj.rota.admin.stepdefinitions;

import static com.jayway.restassured.RestAssured.given;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.jayway.restassured.path.json.JsonPath;
import com.moj.rota.base.stepdefs.BaseStepDefination;
import com.rota.json.JsonAsString;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RotaUpdateStepDefinations extends BaseStepDefination {

	private static String operationType = null;
	private static String locationID = null;
	private static String courtSessionIDValue = null;
	private static boolean isWelsh = false;
	private static int versionNumber = 0;
	private static boolean isEUpdate = false;

	@When("^I sent welsh language \"(.*?)\",\"(.*?)\",\"(.*?)\",\"(.*?)\" request to service$")
	public void i_sent_welsh_language_request_to_service(String language, String operationTypeVal, String location,
			String sessionID) throws Throwable {

		operationType = operationTypeVal;
		locationID = location;
		courtSessionIDValue = sessionID;
		// below method gets the version number and updated data
		getSessionsData("VersionNumber");

		String json = JsonAsString.updateRota.replace("sessionsIdValue", courtSessionID).replace("welshValue", language)
				.replace("IdValue", courtSessionIDValue).replace("versionValue", String.valueOf(versionNumber));
		response = given().spec(requestSpec).urlEncodingEnabled(true).body(json).log().all().when()
				.put("/RotaAdminREST/webresources/rota/session/" + courtSessionIDValue + "/" + optimisedUrlSessionId);
	}

	@When("^I sent another request too get updated data$")
	public void i_sent_another_request_too_get_updated_data() throws Throwable {
		response.then().spec(getResponseSpecification()).log().all();
		getSessionsData("Welsh");
	}

	@Then("^I should see the update welsh language \"(.*?)\"$")
	public void i_should_see_the_update_welsh_language(String language) throws Throwable {

		if (operationType.equals("Add")) {
			assertUtil.isTrue(isWelsh);
		} else {
			assertUtil.isFalse(isWelsh);
		}

	}

	@When("^I sent request with location \"(.*?)\" ,panel type \"(.*?)\" ,business type \"(.*?)\",\"(.*?)\" ,\"(.*?)\" ,\"(.*?)\",\"(.*?)\",\"(.*?)\",\"(.*?)\"$")
	public void i_sent_request_with_panel_type_business_type(String location, String panelType, String businessType,
			String venueID, String operationType, String sj, String dj, String noOfMagistrates, String language)
					throws Throwable {

		if (dj.equals("true")) {
			versionNumber = 1;
		} else if (operationType.equals("EUpdate")) {
			versionNumber = 4;
		} else {
			versionNumber = 0;
		}

		if (operationType.equals("EUpdate") && !isEUpdate) {
			isEUpdate = true;
			versionNumber = 2;
			String updatedjson = JsonAsString.existing_session_mag_update.replace("idValue", createdSessionID)
					.replace("sessionsIdValue", courtSessionID).replace("versionValue", String.valueOf(versionNumber))
					.replace("dayValue", String.valueOf(getDayNumber())).replace("sessionDateValue", getDate())
					.replace("welshValue", language);

			response = given().spec(requestSpec).urlEncodingEnabled(true).body(updatedjson).log().all().when()
					.put("/RotaAdminREST/webresources/rota/session/" + createdSessionID + "/" + optimisedUrlSessionId);
			response.then().spec(getResponseSpecification()).log().all();
			versionNumber = 3;

		}
		String json = JsonAsString.create_Session_update.replace("panelValue", panelType)
				.replace("businessTypeValue", businessType).replace("sjValue", sj).replace("djValue", dj)
				.replace("versionValue", String.valueOf(versionNumber)).replace("magistratesVal", noOfMagistrates)
				.replace("dayValue", String.valueOf(getDayNumber())).replace("sessionDateValue", getDate())
				.replace("idValue", "idValue").replace("welshValue", language);

		if (operationType.equals("Add")) {
			response = given().spec(requestSpec).urlEncodingEnabled(true).body(json.replace("idValue", "null")).log()
					.all().when().post("/RotaAdminREST/webresources/rota/session/" + getOptimisedVenueID(location)
							+ "/LJA/" + optimisedUrlSessionId);
		} else if (operationType.equals("Update") || operationType.equals("EUpdate")) {
			response = given().spec(requestSpec).urlEncodingEnabled(true)
					.body(json.replace("idValue", createdSessionID)).log().all().when()
					.put("/RotaAdminREST/webresources/rota/session/" + createdSessionID + "/" + optimisedUrlSessionId);
		} else {
			response = given().spec(requestSpec).urlEncodingEnabled(true).log().all().when().delete(
					"/RotaAdminREST/webresources/rota/session/" + createdSessionID + "/" + optimisedUrlSessionId);
		}
	}

	@Then("^I should recive the response$")
	public void i_should_recive_the_response() throws Throwable {
		response.then().spec(getResponseSpecification()).log().all();
	}

	@Then("^Should get the updated \"(.*?)\" ,panel type \"(.*?)\" ,business type \"(.*?)\" ,\"(.*?)\",\"(.*?)\",\"(.*?)\",\"(.*?)\"$")
	public void i_should_see_the_panel_type_business_type(String operationType, String panelType, String businessType,
			String sj, String dj, String noOfMagistrates, String language) throws Throwable {

		if (operationType.equals("Update") || operationType.equals("EUpdate")) {
			response = given().spec(requestSpec).urlEncodingEnabled(true).log().ifValidationFails().when()
					.get("/RotaAdminREST/webresources/rota/session/" + createdSessionID + "/" + optimisedUrlSessionId);
			response.then().spec(getResponseSpecification()).log().ifValidationFails();
		}

		if (!operationType.equals("Delete")) {
			JsonPath jsonPath = new JsonPath(response.body().asInputStream());
			Map<String, Object> listOfData = (HashMap<String, Object>) jsonPath.get();
			assertUtil.isEquals(panelType, listOfData.get("panelType"));
			assertUtil.isEquals(businessType, listOfData.get("specialistBusinessType"));
			assertUtil.isEquals(dj, listOfData.get("dj").toString());
			assertUtil.isEquals(sj, listOfData.get("singleJustice").toString());
			assertUtil.isEquals(noOfMagistrates, listOfData.get("numberOfMagistrates").toString());
			isWelsh = (boolean) listOfData.get("welsh");
			versionNumber = (int) listOfData.get("version");
			if (operationType.equals("Add")) {
				createdSessionID = (String) listOfData.get("id");
				assertUtil.isTrue(createdSessionID.length() > 1);
				assertUtil.isTrue(isWelsh);
			} else {
				assertUtil.isFalse(isWelsh);
			}

		}

	}

	@SuppressWarnings("unchecked")
	private void getSessionsData(String typeOfValue) {
		response = null;
		response = given().spec(requestSpec).urlEncodingEnabled(true).log().all().when()
				.get("/RotaAdminREST/webresources/rota/" + locationID + "/LJA/DRAFT_ROTA/" + optimisedUrlSessionId);
		response.then().spec(getResponseSpecification());
		JsonPath jsonPath = new JsonPath(response.getBody().asInputStream());
		List<Object> sessionData = jsonPath.getList("rotaLocations[1].rotaVenues[0].sessions");
		boolean idContains = false;
		for (int i = 0; i < sessionData.size(); i++) {
			Map<String, Object> listOfData = (HashMap<String, Object>) sessionData.get(i);
			idContains = listOfData.containsValue(courtSessionIDValue);
			if (idContains) {
				switch (typeOfValue) {
				case "Welsh":
					isWelsh = (boolean) listOfData.get("welsh");
					break;

				case "VersionNumber":
					versionNumber = (int) listOfData.get("version");
					break;
				default:

				}
				break;
			}

		}

	}

}
