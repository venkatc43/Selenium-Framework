package com.moj.rota.admin.stepdefinitions;

import static com.jayway.restassured.RestAssured.given;

import java.util.HashMap;
import java.util.Map;
import com.jayway.restassured.path.json.JsonPath;
import com.moj.rota.base.stepdefs.BaseStepDefination;
import com.rota.json.JsonAsString;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class PublishedRotaUpdateStepDefinations extends BaseStepDefination {
	private static String operationType = null;
	private static boolean isWelsh = false;
	private static int versionNumber = 0;
	private static boolean isEUpdate = false;

	@When("^I sent published rota request with location \"(.*?)\" ,panel type \"(.*?)\" ,business type \"(.*?)\",\"(.*?)\" ,\"(.*?)\" ,\"(.*?)\",\"(.*?)\",\"(.*?)\",\"(.*?)\"$")
	public void i_sent_request_with_panel_type_business_type(String location, String panelType, String businessType,
			String venueID, String operationType, String sj, String dj, String noOfMagistrates, String language)
					throws Throwable {

		if (dj.equals("true")) {
			versionNumber = 1;
		} else if (operationType.equals("EUpdate")) {
			versionNumber = 4;
		} else {
			versionNumber = 0;
		}

		if (operationType.equals("EUpdate") && !isEUpdate) {
			isEUpdate = true;
			versionNumber = 2;
			String updatedjson = JsonAsString.existing_session_mag_update.replace("idValue", createdSessionID)
					.replace("sessionsIdValue", publishCourtSessionID)
					.replace("versionValue", String.valueOf(versionNumber))
					.replace("dayValue", String.valueOf(getDayNumber())).replace("sessionDateValue", getDate())
					.replace("welshValue", language);

			response = given().spec(requestSpec).urlEncodingEnabled(true).body(updatedjson).log().all().when()
					.put("/RotaAdminREST/webresources/rota/session/" + createdSessionID + "/" + publishedUrlSessionId);
			response.then().spec(getResponseSpecification()).log().all();
			versionNumber = 3;

		}
		String json = JsonAsString.create_Session_update.replace("panelValue", panelType)
				.replace("businessTypeValue", businessType).replace("sjValue", sj).replace("djValue", dj)
				.replace("versionValue", String.valueOf(versionNumber)).replace("magistratesVal", noOfMagistrates)
				.replace("dayValue", String.valueOf(getDayNumber())).replace("sessionDateValue", getDate())
				.replace("idValue", "idValue").replace("welshValue", language);

		if (operationType.equals("Add")) {
			response = given().spec(requestSpec).urlEncodingEnabled(true).body(json.replace("idValue", "null")).log()
					.all().when().post("/RotaAdminREST/webresources/rota/session/" + getPublishedVenueID(location)
							+ "/LJA/" + publishedUrlSessionId);
		} else if (operationType.equals("Update") || operationType.equals("EUpdate")) {
			response = given().spec(requestSpec).urlEncodingEnabled(true)
					.body(json.replace("idValue", createdSessionID)).log().all().when()
					.put("/RotaAdminREST/webresources/rota/session/" + createdSessionID + "/" + publishedUrlSessionId);
		} else {
			response = given().spec(requestSpec).urlEncodingEnabled(true).log().all().when().delete(
					"/RotaAdminREST/webresources/rota/session/" + createdSessionID + "/" + publishedUrlSessionId);
		}
	}

	@Then("^Should get the updated published rota \"(.*?)\" ,panel type \"(.*?)\" ,business type \"(.*?)\" ,\"(.*?)\",\"(.*?)\",\"(.*?)\",\"(.*?)\"$")
	public void i_should_see_the_panel_type_business_type(String operationType, String panelType, String businessType,
			String sj, String dj, String noOfMagistrates, String language) throws Throwable {

		if (operationType.equals("Update") || operationType.equals("EUpdate")) {
			response = given().spec(requestSpec).urlEncodingEnabled(true).log().ifValidationFails().when()
					.get("/RotaAdminREST/webresources/rota/session/" + createdSessionID + "/" + publishedUrlSessionId);
			response.then().spec(getResponseSpecification()).log().ifValidationFails();
		}

		if (!operationType.equals("Delete")) {
			JsonPath jsonPath = new JsonPath(response.body().asInputStream());
			Map<String, Object> listOfData = (HashMap<String, Object>) jsonPath.get();
			assertUtil.isEquals(panelType, listOfData.get("panelType"));
			assertUtil.isEquals(businessType, listOfData.get("specialistBusinessType"));
			assertUtil.isEquals(dj, listOfData.get("dj").toString());
			assertUtil.isEquals(sj, listOfData.get("singleJustice").toString());
			assertUtil.isEquals(noOfMagistrates, listOfData.get("numberOfMagistrates").toString());
			isWelsh = (boolean) listOfData.get("welsh");
			versionNumber = (int) listOfData.get("version");
			if (operationType.equals("Add")) {
				createdSessionID = (String) listOfData.get("id");
				assertUtil.isTrue(createdSessionID.length() > 1);
				assertUtil.isTrue(isWelsh);
			} else {
				assertUtil.isFalse(isWelsh);
			}

		}

	}

	@When("^I sent request with \"(.*?)\" , Identifier type \"(.*?)\" ,\"(.*?)\" ,\"(.*?)\",\"(.*?)\",\"(.*?)\",\"(.*?)\"$")
	public void i_sent_request_with_Identifier_type(String location, String identifierType, String rbFlag,
			String operationTypeVal, String lsFlag, String appsFlag, String isConfirmedFlag) throws Throwable {
		operationType = operationTypeVal;
		switch (operationType) {
		case "AddUpdate":

			String json = JsonAsString.create_Session_update.replace("panelValue", "ADULT")
					.replace("businessTypeValue", "1").replace("sjValue", "false").replace("djValue", "false")
					.replace("versionValue", String.valueOf(versionNumber)).replace("magistratesVal", "3")
					.replace("dayValue", String.valueOf(getDayNumber())).replace("sessionDateValue", getDate())
					.replace("idValue", "idValue").replace("welshValue", "false");

			response = given().spec(requestSpec).urlEncodingEnabled(true).body(json.replace("idValue", "null")).log()
					.all().when().post("/RotaAdminREST/webresources/rota/session/" + getPublishedVenueID(location)
							+ "/LJA/" + publishedUrlSessionId);
			response.then().spec(getResponseSpecification()).log().all();

			JsonPath jsonPath = new JsonPath(response.body().asInputStream());
			Map<String, Object> listOfData = (HashMap<String, Object>) jsonPath.get();
			createdSessionID = (String) listOfData.get("id");

			String updatedjson = JsonAsString.existing_session_mag_update.replace("idValue", createdSessionID)
					.replace("sessionsIdValue", publishCourtSessionID)
					.replace("versionValue", String.valueOf(versionNumber))
					.replace("dayValue", String.valueOf(getDayNumber())).replace("sessionDateValue", getDate())
					.replace("welshValue", "false");

			response = given().spec(requestSpec).urlEncodingEnabled(true).body(updatedjson).log().all().when()
					.put("/RotaAdminREST/webresources/rota/session/" + createdSessionID + "/" + publishedUrlSessionId);
			response.then().spec(getResponseSpecification()).log().all();
			versionNumber = 1;

			break;
		case "Update":

			String idenfifierUpdateJson = JsonAsString.identifier_update.replace("idValue", createdSessionID)
					.replace("sessionsIdValue", publishCourtSessionID)
					.replace("versionValue", String.valueOf(versionNumber))
					.replace("dayValue", String.valueOf(getDayNumber())).replace("sessionDateValue", getDate())
					.replace("welshValue", "false").replace("lsWingValue1", lsFlag).replace("rbWinger1", rbFlag)
					.replace("returningBenchReason", "Too Long").replace("apsValue1", appsFlag)
					.replace("sittingIdentifierValue1", identifierType).replace("confirmedValue", isConfirmedFlag);

			response = given().spec(requestSpec).urlEncodingEnabled(true).body(idenfifierUpdateJson).log().all().when()
					.put("/RotaAdminREST/webresources/rota/session/" + createdSessionID + "/" + publishedUrlSessionId);

			break;

		case "Delete":
			response = given().spec(requestSpec).urlEncodingEnabled(true).log().all().when().delete(
					"/RotaAdminREST/webresources/rota/session/" + createdSessionID + "/" + publishedUrlSessionId);
			break;

		default:
		}
	}

	@Then("^I should see the updated Identifier type \"(.*?)\" ,\"(.*?)\",\"(.*?)\",\"(.*?)\",\"(.*?)\"$")
	public void i_should_see_the_updated_Identifier_type(String identifierType, String rbFlag, String lsFlag,
			String appsFlag, String Confirmed) throws Throwable {
		if (!operationType.equals("Delete") && !operationType.equals("AddUpdate")) {
			response = given().spec(requestSpec).urlEncodingEnabled(true).log().ifValidationFails().when()
					.get("/RotaAdminREST/webresources/rota/session/" + createdSessionID + "/" + publishedUrlSessionId);
			response.then().spec(getResponseSpecification()).log().ifValidationFails();

			JsonPath jsonPath = new JsonPath(response.body().asInputStream());
			Map<String, Object> listOfData = (HashMap<String, Object>) jsonPath.get();
			versionNumber = (int) listOfData.get("version");
			assertUtil.isEquals(identifierType, listOfData.get("sittingIdentifierWinger1"));
			assertUtil.isFalse(((Boolean) listOfData.get("confirmed")));
			if (rbFlag.equals("true")) {
				assertUtil.isTrue((Boolean) listOfData.get("returningBenchWinger1"));
				assertUtil.isTrue((listOfData.get("returningBenchWinger1Reason").toString().length() > 0));
				assertUtil.isTrue(((Boolean) listOfData.get("applicationsWinger1")));
			} else {
				assertUtil.isFalse((Boolean) listOfData.get("returningBenchWinger1"));
				assertUtil.isFalse(((Boolean) listOfData.get("applicationsWinger1")));
			}

		}
	}

}
