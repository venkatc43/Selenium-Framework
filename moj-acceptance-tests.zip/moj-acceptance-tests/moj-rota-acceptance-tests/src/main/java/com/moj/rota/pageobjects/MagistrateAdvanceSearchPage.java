package com.moj.rota.pageobjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.moj.common.pageobjects.MOJBasePage;

public class MagistrateAdvanceSearchPage extends MOJBasePage {

	@FindBy(xpath = "//a[@href='#advanced']")
	private WebElement advanceTab;

	@FindBy(css = "#search-results-advanced > div:nth-child(1) > div > span")
	private WebElement numberofMagistrates;

	@FindBy(id = "rotaAdminRole")
	private WebElement localJustAreaRadioBtn;

	@FindBy(id = "dfcRole")
	private WebElement combinedPanelRadioBtn;

	@FindBy(id = "advanced")
	private WebElement advancedContent;

	@FindBy(id = "ljaId")
	private WebElement localJusticeArea;

	@FindBy(id = "availableDate")
	private WebElement availableDate;

	@FindBy(id = "availableStartDate")
	private WebElement availableStartDate;

	@FindBy(id = "availableEndDate")
	private WebElement availableEndDate;

	@FindBy(id = "ljaLocation")
	private WebElement ljaLocation;

	@FindBy(id = "panel")
	private WebElement panel;

	@FindBy(id = "panelStatus")
	private WebElement panelStatus;

	@FindBy(id = "appraiser")
	private WebElement appraiser;

	@FindBy(id = "mentor")
	private WebElement mentor;

	@FindBy(id = "shortNoticeOption")
	private WebElement shortNoticeOption;

	@FindBy(id = "consecutiveDaysOption")
	private WebElement consecutiveDaysOption;

	@FindBy(id = "outOfHours")
	private WebElement outOfHours;

	@FindBy(id = "bankHolidays")
	private WebElement bankHolidays;

	@FindBy(id = "sitSaturdays")
	private WebElement sitSaturdays;

	@FindBy(id = "doCrossBenchAppraisals")
	private WebElement doCrossBenchAppraisals;

	@FindBy(id = "welshSpeaking")
	private WebElement welshSpeaking;

	@FindBy(id = "search-mags-advanced-btn")
	private WebElement searchAdvancedbtn;

	@FindBy(css = "#errorDialogHeading>h3")
	private WebElement errorMessage;

	@FindBy(id = "search-results-advanced")
	private WebElement noMatchfoundMsg;

	@FindBy(css = ".col-xs-12.col-sm-12.col-md-12.col-lg-12")
	private WebElement searchResultMsg;

	@FindBy(id = "adHocMagistrates")
	private WebElement adhocLJA;

	@FindBy(id = "combinedPanelLocation")
	private WebElement combinedLocation;

	@FindBy(id = "search-results-advanced")
	private WebElement advanceNoSearchResults;

	@FindBy(css = "#search-results-advanced > div:nth-child(1) > div > span")
	private WebElement magistratesCount;

	// judge related
	@FindBy(id = "authority")
	private WebElement authority;

	@FindBy(id = "search-djs-advanced-btn")
	private WebElement disJudgeSearch;

	@FindBy(id = "specialistAuthority")
	private WebElement specialAuthority;

	@FindBy(css = "#sat-bank-holl-range-message > div.col-xs-12.col-sm-7.col-md-7.col-lg-7.text-primary")
	private WebElement excludeWarningMessage;

	@FindBy(css = "#result.row.result-row div.col-xs-12.col-sm-3.col-md-12.col-lg-12")
	private List<WebElement> searchResults;

	@FindBy(css = "#result > div:nth-child(3) > a > span")
	private List<WebElement> searchResultsEligibility;

	@FindBy(id = "amSession")
	private WebElement selectAM;

	@FindBy(id = "pmSession")
	private WebElement selectPM;
	
	@FindBy(id = "combinedPanelId")
	private WebElement combinedPanelLocation;

	public MagistrateAdvanceSearchPage(WebDriver driver) {
		super(driver);
	}

	public void clickAdvanceTab() {
		//advanceTab.click();
		click(advanceTab);
	}

	public void displayAdvancedContent() {
		advancedContent.isDisplayed();

	}

	public String advanceNoresultsFound() {
		return getTextFromWebElement(advanceNoSearchResults);
	}

	public void localJusticeAreaRadiobtn() {
		localJustAreaRadioBtn.isSelected();
	}

	public void combinedPanelRadiobtn() {
		combinedPanelRadioBtn.isDisplayed();
	}

	public void selectCombinedPanelRadiobtn() {
		click(combinedPanelRadioBtn);
	}

	public void localJusticeAreaDropdown() {
		localJusticeArea.isDisplayed();
	}

	public void selectLocation(String location) {
		Select selectLocalLocation = new Select(getElement(ljaLocation));
		selectLocalLocation.deselectByVisibleText(location);
	}

	public void selectLJALocation(String location) {
		selectDropDown(ljaLocation, location);
	}

	public void selectComindLocation(String location) {
		selectDropDown(combinedLocation, location);
	}

	public int numberOfMags() {
		int num = Integer.parseInt(numberofMagistrates.getText());
		return num;
	}

	public MagistrateAdvanceSearchPage clickSearchButton() {
		getElement(searchAdvancedbtn).click();
		waitForPage();
		return getPage(MagistrateAdvanceSearchPage.class);
	}

	public MagistrateSearchPage clickOnSearchButton() {
		getElement(searchAdvancedbtn).click();
		waitForPage();
		return getPage(MagistrateSearchPage.class);
	}

	public void enterLocation(String location) {
		Select selLoc = new Select(getElement(localJusticeArea));
		selLoc.selectByVisibleText(location);
		getPage(MagistrateAdvanceSearchPage.class);
	}

	public void selectPanel(String pnl) {
		Select selPnl = new Select(getElement(panel));
		selPnl.selectByVisibleText(pnl);
	}

	public void enterPanelStatus(String pStatus) {
		Select selPnlStatus = new Select(getElement(panelStatus));
		selPnlStatus.selectByVisibleText(pStatus);
	}

	public void selectAppraiser() {
		getElement(appraiser).click();
	}

	public void selectMentor(String mntr) {
		getElement(mentor).click();
	}

	public void selectShortNoticeOption(String snOption) {
		Select sNoticeOption = new Select(getElement(shortNoticeOption));
		sNoticeOption.selectByVisibleText(snOption);
	}

	public void selectConsecutiveDaysOption(String cDayOption) {
		Select conDaysOption = new Select(getElement(consecutiveDaysOption));
		conDaysOption.selectByVisibleText(cDayOption);
	}

	public void selectOutOfHours() {
		getElement(outOfHours).click();
	}

	public void selectCheckBox(WebElement element) {
		getElement(element).click();
	}

	public void selectBankHolidays() {
		getElement(bankHolidays).click();
	}

	public void selectSitSaturdays() {
		getElement(sitSaturdays).click();
	}

	public void selectDoCrossBenchAppraisals() {
		getElement(doCrossBenchAppraisals).click();
	}

	public void selectWelshSpeaking() {
		getElement(welshSpeaking).click();
	}

	public void selectAdhocLJA() {
		click(adhocLJA);
	}

	public boolean getErrorMesssage() {
		return getElement(errorMessage).getText().contains("error");
	}

	public boolean noMatchfoundMsg() {
		return getElement(noMatchfoundMsg).getText().contains("No matches found");
	}

	public boolean MagistratesFoundMsg(String resultsMessage) {
		return getElement(searchResultMsg).getText().contains(resultsMessage);
	}

	public void clickCheckBox(String checkBoxType) {
		switch (checkBoxType) {
		case "Appraiser":
			selectCheckBox(appraiser);
			break;
		case "Mentor":
			selectCheckBox(mentor);
			break;
		case "Out of Hours":
			selectCheckBox(outOfHours);
			break;
		case "Bank Holidays":
			selectCheckBox(bankHolidays);
			break;
		case "Saturdays":
			selectCheckBox(sitSaturdays);
			break;
		case "Bench Appraisals":
			selectCheckBox(doCrossBenchAppraisals);
			break;
		case "Welsh Speaking cases":
			selectCheckBox(welshSpeaking);
			break;

		}
	}

	public void availabilityOptions(String availableOn, String availableFrom, String availableTo) {

		if (availableOn != null && !availableOn.equals("")) {
			enterText(availableDate, availableOn);
			pressTab();
		}

		if (availableFrom != null && !availableFrom.equals("")) {
			enterText(availableStartDate, availableFrom);
		}

		if (availableTo != null && !availableTo.equals("")) {
			enterText(availableEndDate, availableTo);
		}
	}

	public void selectSearchType(String searchType) {

		if (searchType.equalsIgnoreCase("Combined")) {
			selectCombinedPanelRadiobtn();
			waitForVisibilityOfElement(combinedPanelLocation);
			selectDropDown(combinedPanelLocation, "Designated Family Centre 8");
		}
	}

	public void selectShortAndConsecutiveDays(String shortPeriod, String consecutiveDays) {

		if (shortPeriod != null && !shortPeriod.equals("")) {
			selectShortNoticeOption(shortPeriod);
		}

		if (consecutiveDays != null && !consecutiveDays.equals("")) {
			selectConsecutiveDaysOption(consecutiveDays);
		}
	}

	public String getMagistratesCount() {
		return getTextFromWebElement(magistratesCount);
	}

	// judge related

	public void selectAuthority(String authorityVal) {
		selectDropDown(authority, authorityVal);
	}

	public void selectSpecialAuthority(String specialAuthVal) {
		selectDropDown(specialAuthority, specialAuthVal);
	}

	public MagistrateAdvanceSearchPage clickJudgeSearchButton() {
		click(disJudgeSearch);
		return getPage(MagistrateAdvanceSearchPage.class);
	}

	public boolean districtJudgesFoundMsg() {
		return getElement(searchResultMsg).getText().contains("District Judge found");
	}

	public void selectAdhoc() {
		getElement(mentor).click();
	}

	public String getExcludeWarningMessage() {
		pressTab();
		implicitWait(10);
		return getTextFromWebElement(excludeWarningMessage);
	}

	public boolean isBankSatShortNoticeDisplayed(String days) {
		boolean isElementDisplayed = false;
		switch (days) {
		case "ShortNotice":
			isElementDisplayed = isElementNotDisplayed(shortNoticeOption);
			break;
		case "Saturday":
			isElementDisplayed = isElementNotDisplayed(sitSaturdays);
			break;
		case "BankHoliday":
			isElementDisplayed = isElementNotDisplayed(bankHolidays);
			break;
		}

		return isElementDisplayed;

	}

	public MagistrateSittingEligibiltyPage clickBenchChairMagistrate(String magName) {
		for (int i = 0; i < searchResults.size(); i++) {
			if (getTextFromWebElement(searchResults.get(i)).contains(magName)) {
				click(searchResultsEligibility.get(i));
				break;

			}
		}
		return returnPageFactory(MagistrateSittingEligibiltyPage.class);
	}

	public void selectDayPattern(String dayPattern) {

		if (!dayPattern.equals("AM") && !dayPattern.equals("AMAndPM")) {
			waitForPageToLoad();
			click(selectAM);
		} else if (!dayPattern.equals("PM") && !dayPattern.equals("AMAndPM")) {
			waitForPageToLoad();
			click(selectPM);
		}

	}

}
