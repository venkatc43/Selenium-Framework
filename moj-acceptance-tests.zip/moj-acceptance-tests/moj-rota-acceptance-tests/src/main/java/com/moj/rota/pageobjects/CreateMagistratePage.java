package com.moj.rota.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.moj.common.pageobjects.MOJBasePage;

public class CreateMagistratePage extends MOJBasePage {

	@FindBy(id = "title")
	private WebElement nameTitle;

	@FindBy(id = "firstName")
	private WebElement fname;

	@FindBy(id = "lastName")
	private WebElement lname;

	@FindBy(id = "dob")
	private WebElement dateofBirth;

	@FindBy(id = "gender-1")
	private WebElement genderMale;

	@FindBy(id = "gender-2")
	private WebElement genderFemale;

	@FindBy(id = "addressLine1")
	private WebElement address1;

	@FindBy(id = "addressLine2")
	private WebElement address2;

	@FindBy(id = "addressLine3")
	private WebElement address3;

	@FindBy(id = "addressLine4")
	private WebElement address4;

	@FindBy(id = "addressLine5")
	private WebElement address5;

	@FindBy(id = "postCode")
	private WebElement postCode;

	@FindBy(id = "preferredNotificationMethod")
	private WebElement notificationMethod;

	@FindBy(id = "emailAddress")
	private WebElement email;

	@FindBy(id = "welsh")
	private WebElement welshLangPref;

	@FindBy(id = "personal-details-next-btn")
	protected WebElement nextButton;

	@FindBy(css = ".panel-title")
	private WebElement personalDetails;

	// Validation Messages

	@FindBy(css = "h3.panel-title")
	private WebElement title;

	@FindBy(id = "titleError")
	private WebElement titleError;

	@FindBy(id = "firstNameError")
	private WebElement firstNameError;

	@FindBy(id = "lastNameError")
	private WebElement lastNameError;

	@FindBy(id = "dobError")
	private WebElement dobError;

	@FindBy(id = "genderError")
	private WebElement genderError;

	@FindBy(id = "addressLine1Error")
	private WebElement addressLine1Error;

	@FindBy(id = "addressLine2Error")
	private WebElement addressLine2Error;

	@FindBy(id = "postCodeError")
	private WebElement postCodeError;

	@FindBy(id = "emailAddressError")
	private WebElement emailAddressError;

	public CreateMagistratePage(WebDriver driver) {
		super(driver);
	}

	public void selectTitle(String title) {
		Select selectTitle = new Select(getElement(nameTitle));
		selectTitle.selectByVisibleText(title);
	}

	public void enterFirstName(String firstName) {
		getElement(fname).sendKeys(firstName);
	}

	public void enterLastName(String lastName) {
		getElement(lname).sendKeys(lastName);
	}

	public void enterDateofBirth(String dob) {
		getElement(dateofBirth).sendKeys(dob);
	}

	public void selectGenderAsMale() {
		waitForElementTobeClickable(genderMale);
		getElement(genderMale).click();
	}

	public void selectGenderAsFemale() {
		getElement(genderFemale).click();
	}

	public void enterAddress1(String add1) {
		getElement(address1).sendKeys(add1);
	}

	public void enterAddress2(String add2) {
		getElement(address2).sendKeys(add2);
	}

	public void enterAddress3(String add3) {
		getElement(address3).sendKeys(add3);
	}

	public void enterAddress4(String add4) {
		getElement(address4).sendKeys(add4);
	}

	public void enterAddress5(String add5) {
		getElement(address5).sendKeys(add5);
	}

	public void enterPostCode(String pCode) {
		getElement(postCode).sendKeys(pCode);
	}

	public void selectNotificationMethod(String ntfMethod) {
		Select selectTitle = new Select(notificationMethod);
		selectTitle.selectByVisibleText(ntfMethod);
	}

	public void enterEmailAddress(String emailAddress) {
		getElement(email).sendKeys(emailAddress);
	}

	public void selectWelshLangPref() {
		getElement(welshLangPref).click();
	}

	public SittingMagistratePage clickNextButtonToSittingPage() {
		getElement(nextButton).click();
		return getPage(SittingMagistratePage.class);
	}

	public CreateMagistratePage clickNextWithInvalidData() {
		getElement(nextButton).click();
		return getPage(CreateMagistratePage.class);
	}

	// Validation errors

	public boolean errorWithNoData() {
		return getElement(title).getText().contains("Personal Details");
	}

	public String getErrorMsg(String fieldName) {
		String errorMsg = "";
		if (fieldName.equalsIgnoreCase("Title")) {
			errorMsg = clickNextWithInvalidData().getElement(titleError).getText();
		}
		if (fieldName.equalsIgnoreCase("First Name")) {
			selectTitle(TITLE);
			errorMsg = clickNextWithInvalidData().getElement(firstNameError).getText();
		}
		if (fieldName.equalsIgnoreCase("Last Name")) {
			selectTitle(TITLE);
			enterFirstName(FIRST_NAME);
			errorMsg = clickNextWithInvalidData().getElement(lastNameError).getText();
		}
		if (fieldName.equalsIgnoreCase("Date of birth")) {
			selectTitle(TITLE);
			enterFirstName(FIRST_NAME);
			enterLastName(LAST_NAME);
			errorMsg = clickNextWithInvalidData().getElement(dobError).getText();
		}

		if (fieldName.equalsIgnoreCase("Gender")) {
			selectTitle(TITLE);
			enterFirstName(FIRST_NAME);
			enterLastName(LAST_NAME);
			enterDateofBirth(DOB);
			errorMsg = clickNextWithInvalidData().getElement(genderError).getText();
		}

		if (fieldName.equalsIgnoreCase("Address line 1")) {
			selectTitle(TITLE);
			enterFirstName(FIRST_NAME);
			enterLastName(LAST_NAME);
			enterDateofBirth(DOB);
			pressTab();
			selectGenderAsMale();
			errorMsg = clickNextWithInvalidData().getElement(addressLine1Error).getText();
		}

		if (fieldName.equalsIgnoreCase("Address line 2")) {
			selectTitle(TITLE);
			enterFirstName(FIRST_NAME);
			enterLastName(LAST_NAME);
			enterDateofBirth(DOB);
			pressTab();
			selectGenderAsMale();
			enterAddress1(ADDRESS_LINE_1);
			errorMsg = clickNextWithInvalidData().getElement(addressLine2Error).getText();
		}

		if (fieldName.equalsIgnoreCase("Postcode")) {
			selectTitle(TITLE);
			enterFirstName(FIRST_NAME);
			enterLastName(LAST_NAME);
			enterDateofBirth(DOB);
			pressTab();
			selectGenderAsMale();
			enterAddress1(ADDRESS_LINE_1);
			enterAddress2(ADDRESS_LINE_2);
			errorMsg = clickNextWithInvalidData().getElement(postCodeError).getText();
		}

		if (fieldName.equalsIgnoreCase("Email")) {
			selectTitle(TITLE);
			enterFirstName(FIRST_NAME);
			enterLastName(LAST_NAME);
			enterDateofBirth(DOB);
			pressTab();
			selectGenderAsMale();
			enterAddress1(ADDRESS_LINE_1);
			enterAddress2(ADDRESS_LINE_2);
			enterPostCode(POSTCODE);
			errorMsg = clickNextWithInvalidData().getElement(emailAddressError).getText();
		}

		if (fieldName.equalsIgnoreCase("Date of appointment")) {
			selectTitle(TITLE);
			enterFirstName(FIRST_NAME);
			enterLastName(LAST_NAME);
			enterDateofBirth(DOB);
			pressTab();
			selectGenderAsMale();
			enterAddress1(ADDRESS_LINE_1);
			enterAddress2(ADDRESS_LINE_2);
			enterPostCode(POSTCODE);
			enterEmailAddress(EMAIL);
			SittingMagistratePage onSittingMagistratePage = clickNextButtonToSittingPage();
			onSittingMagistratePage.clickSaveButton();
			errorMsg = onSittingMagistratePage.appDateErrorMsg();
		}

		return errorMsg;

	}

	public ConfirmationPopUp createMagistrateWithValidData(String firstName, String lastName, String emailAddress,
			String location) {
		selectTitle(TITLE);
		enterFirstName(firstName);
		enterLastName(lastName);
		enterDateofBirth(DOB);
		pressTab();
		selectGenderAsMale();
		enterAddress1(ADDRESS_LINE_1);
		enterAddress2(ADDRESS_LINE_2);
		enterPostCode(POSTCODE);
		if (emailAddress != null && !emailAddress.equals("")) {
			enterEmailAddress(emailAddress);
		} else {
			enterEmailAddress(EMAIL);
		}

		SittingMagistratePage onSittingMagistratePage = clickNextButtonToSittingPage();
		onSittingMagistratePage.enterAppointmentDate(getDate(-1));
		pressTab();
		onSittingMagistratePage.selectJusticeArea(location);
		onSittingMagistratePage.clickSaveButton();
		waitForPage();
		return getPage(ConfirmationPopUp.class);
	}

	public ErrorCreatingMagistratePage createMagistrateWithInValidData(String location) {
		selectTitle(TITLE);
		enterFirstName(FIRST_NAME);
		enterLastName(LAST_NAME);
		enterDateofBirth(DOB);
		pressTab();
		selectGenderAsMale();
		enterAddress1(ADDRESS_LINE_1);
		enterAddress2(ADDRESS_LINE_2);
		enterPostCode(POSTCODE);
		pressTab();
		enterEmailAddress(INVALID_EMAIL);
		SittingMagistratePage onSittingMagistratePage = clickNextButtonToSittingPage();
		onSittingMagistratePage.enterAppointmentDate(APP_DATE);
		pressTab();
		onSittingMagistratePage.selectJusticeArea(location);
		onSittingMagistratePage.clickSaveButton();
		return getPage(ErrorCreatingMagistratePage.class);
	}

	public boolean isPersonalDetailsDisplayed() {
		return isWebElementDisplayed(personalDetails);
	}

	public boolean isPageFieldsDisplayed(String pageFields) {
		boolean isElemtDisplayed = false;
		switch (pageFields) {
		case "Title":
			isElemtDisplayed = isWebElementDisplayed(nameTitle);
			break;
		case "First_name":
			isElemtDisplayed = isWebElementDisplayed(fname);
			break;
		case "Last_name":
			isElemtDisplayed = isWebElementDisplayed(lname);
			break;
		case "Date_of_birth":
			isElemtDisplayed = isWebElementDisplayed(dateofBirth);
			break;
		case "Address_line1":
			isElemtDisplayed = isWebElementDisplayed(address1);
			break;
		case "Address_line2":
			isElemtDisplayed = isWebElementDisplayed(address2);
			break;
		case "Address_line3":
			isElemtDisplayed = isWebElementDisplayed(address3);
			break;
		case "Address_line4":
			isElemtDisplayed = isWebElementDisplayed(address4);
			break;
		case "Address_line5":
			isElemtDisplayed = isWebElementDisplayed(address5);
			break;
		case "PostCode":
			isElemtDisplayed = isWebElementDisplayed(postCode);
			break;
		case "Notification_method":
			isElemtDisplayed = isWebElementDisplayed(notificationMethod);
			break;
		case "Email":
			isElemtDisplayed = isWebElementDisplayed(email);
			break;
		case "Welsh_language":
			isElemtDisplayed = isWebElementDisplayed(welshLangPref);
			break;
		default:
			System.out.println("Not elements displyed");

		}

		return isElemtDisplayed;
	}

}
