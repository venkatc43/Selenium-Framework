package com.moj.rota.magistrate.pageobjects;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.moj.common.pageobjects.MOJBasePage;
import com.moj.rota.pageobjects.MagistrateNonAvailabilityPage;
import com.moj.rota.pageobjects.MagistratePersonalDetailsPage;
import com.moj.rota.pageobjects.MagistrateSittingEligibiltyPage;
import com.moj.rota.pageobjects.MagistrateSittingLocationsPage;
import com.moj.rota.pageobjects.MagistrateSittingPrefecencesPage;
import com.moj.rota.pageobjects.MagistrateSittingsPage;

public class MagistrateHomePage extends MOJBasePage {

	@FindBy(css = "h6.text-right")
	private WebElement loggedInName;

	@FindBy(css = ".btn-xs.dropdown-toggle")
	private WebElement myAccounDropdown;

	@FindBy(css = ".btn.btn-info.btn-xs")
	private WebElement logoutLink;

	@FindBy(xpath = ".//*[@href='completePersonalDetails.html']")
	private WebElement step1Link;

	@FindBy(id = "edit-magistrate-btn")
	private WebElement personalDetailButton;

	@FindBy(xpath = ".//*[@href='sittingRequirements.html']")
	private WebElement step2Link;

	@FindBy(id = "edit-sitting-btn")
	private WebElement editSittingButton;

	@FindBy(xpath = ".//*[@href='calendar.html']")
	private WebElement step3Link;

	@FindBy(id = "non-availability-btn")
	private WebElement nonAvailablityButton;

	@FindBy(css = "p.text-danger")
	private WebElement completionMsg;

	@FindBy(css = "#broadcastMessagesSection.col-xs-12.col-sm-12.col-md-12.col-lg-12 div.row div p")
	private WebElement welcomeMessage;

	@FindBy(css = "#content div.jumbotron > div > div > div > div:nth-child(1) > div:nth-child(1)")
	private WebElement myRotaPrifle;

	@FindBy(css = "#content div:nth-child(1) > h5")
	private WebElement magistrateAccount;

	@FindBy(css = "#content div:nth-child(3) > ul > li > a")
	private WebElement yourMessages;

	@FindBy(css = "#your-tasks > ul > li > a")
	private WebElement yourTaks;

	@FindBy(id = "sitting-eligibility-btn")
	private WebElement sittingEligibility;

	@FindBy(id = "locations-btn")
	private WebElement sittingLocations;

	@FindBy(id = "sittings-btn")
	private WebElement sittings;

	public MagistrateHomePage(WebDriver driver) {
		super(driver);
	}

	public void clickMyAccount() {
		getElement(myAccounDropdown).click();
	}

	public boolean loggedInName(String name) {
		return loggedInName.getText().contains(name);
	}

	public MagistrateLoginPage clickLogoutLink() {
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("window.scrollBy(0,-500)", "");
		getElement(logoutLink).click();
		return getPage(MagistrateLoginPage.class);
	}

	public MagistratePersonalDetailsPage clickStep1Link() {
		getElement(step1Link).click();
		return getPage(MagistratePersonalDetailsPage.class);
	}

	public MagistratePersonalDetailsPage clickPersonalDetailLink() {
		getElement(personalDetailButton).click();
		return getPage(MagistratePersonalDetailsPage.class);
	}

	public MagistrateSittingPrefecencesPage clickStep2Link() {
		getElement(step2Link).click();
		return getPage(MagistrateSittingPrefecencesPage.class);
	}

	public MagistrateNonAvailabilityPage clickStep3Link() {
		getElement(step3Link).click();
		waitForPageToLoad();
		return getPage(MagistrateNonAvailabilityPage.class);
	}

	public boolean showSuccessMessage() {

		return getElement(completionMsg).getText().contains("All the required information is complete");
	}

	public boolean isMagistreateUI() {
		return isElementDisplayed(step1Link);
	}

	public String getWelcomeMessage() {
		return getTextFromWebElement(welcomeMessage);
	}

	public String getHomePageFields(String field) {
		String fieldText = null;
		switch (field) {
		case "My Rota Profile":
			fieldText = getTextFromWebElement(myRotaPrifle);
			break;
		case "Magistrate Account":
			fieldText = getTextFromWebElement(magistrateAccount);
			break;
		case "Your messages":
			fieldText = getTextFromWebElement(yourMessages);
			break;
		case "Your tasks":
			fieldText = getTextFromWebElement(yourTaks);
			break;
		case "Personal Details":
			fieldText = getTextFromWebElement(personalDetailButton);
			break;
		case "Sitting Preferences":
			fieldText = getTextFromWebElement(step2Link);
			break;
		case "Non-availability":
			fieldText = getTextFromWebElement(step3Link);
			break;
		case "Sitting Eligibility":
			fieldText = getTextFromWebElement(sittingEligibility);
			break;

		case "Sitting Locations":
			fieldText = getTextFromWebElement(sittingLocations);
			break;
		case "Sittings":
			fieldText = getTextFromWebElement(sittings);
			break;
		default:
		}

		return fieldText;
	}

	public MagistrateSittingEligibiltyPage clickMagSittingEligibility() {
		click(sittingEligibility);
		return returnPageFactory(MagistrateSittingEligibiltyPage.class);
	}

	public MagistrateSittingLocationsPage clickMagSittingLocation() {
		click(sittingLocations);
		return returnPageFactory(MagistrateSittingLocationsPage.class);
	}

	public MagistrateSittingsPage clickOnSittings() {
		click(sittings);
		return returnPageFactory(MagistrateSittingsPage.class);
	}
}
