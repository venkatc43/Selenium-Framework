package com.moj.rota.parameters.pageobjects;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.moj.common.pageobjects.MOJBasePage;

public class CombinedYouthPanelsPage extends MOJBasePage {

	public CombinedYouthPanelsPage(WebDriver driver) {
		super(driver);
		
	}
	
	private static int count=0;
		
	@FindBy(id = "combinedYouthPanelsTab")
	private WebElement combinedYouthPanel;
		
	@FindBy(css = "div[id*='lja-youth-panel-'] > div > h3 > a > strong")
	private List<WebElement> ljaNorth;
	
	@FindBy(css = "div[id*='lja-youth-panel-'] > div > h3 > a > strong")
	private List<WebElement> ljaSouth;
	
	@FindBy(css = "input[id*='combinedYouthPanelLjaSearch']")
	private List<WebElement> ljaName;
	
	@FindBy(id = "combined-youth-panel-add-btn")
	private List<WebElement> addButton;
	
	@FindBy(css = "label[id*='currentCombinedYouthPanelErrorLabel']")
	private List<WebElement> ownCombinedPanelError;
	
	@FindBy(css = "div[id*='combined-Youth-collapsable-'] > div > div:nth-child(2) > div:nth-child(1) > span")
	private List<WebElement> addedLjaName;
	
	@FindBy(css = "label[id*='combinedYouthPanelDuplicateErrorLabel']")
	private List<WebElement> alreadyAddedError;
	
	@FindBy(css = "label[id*='combinedYouthPanelAlreadyOwnerUseErrorLabel']")
	private List<WebElement> alreadyUsedError;
		
	@FindBy(css = "div[id*='combined-Youth-collapsable-'] > div > div:nth-child(2) > div:nth-child(1) > span > span")
	private List<WebElement> removedCombinedPanel1;
	
	@FindBy(css = "div[id*='combined-Youth-collapsable-'] > div > div:nth-child(2) > div:nth-child(2) > span > span")
	private WebElement removedCombinedPanel2;
	
	@FindBy(css = "div[id*='combined-Youth-collapsable-'] > div > div:nth-child(2) > div:nth-child(3) > span > span")
	private WebElement removedCombinedPanel3;
	
	@FindBy(css = ".text-muted")
	private List<WebElement> noCombinePanelMessage;
	
			
	public boolean isCombinedYouthPanelDisplayed()
	{
		return isElementDisplayed(combinedYouthPanel);
	}
	
		
	public String getLocationsTitle(String location)
	{
		String locationTitle=null;
		switch(location)
		{
		case "Local Justice Area 20 North":
			//locationTitle=getTextFromWebElement(ljaNorth.get(0));
           // waitForPage();
            implicitWait(10);
            waitForVisibilityOfAllElement(ljaNorth);
			for(WebElement element:ljaNorth)
			{   
				waitForVisibilityOfElement(element);
				locationTitle=getTextFromWebElement(element);
				System.out.println("Location title :"+locationTitle);
				if(locationTitle.contains(location))
				{
					break;	
				}
			}
			break;
		case "Local Justice Area 20 South":
			//locationTitle=getTextFromWebElement(ljaSouth.get(1));
			waitForPage();
			for(WebElement southElement:ljaSouth)
			{   
				locationTitle=getTextFromWebElement(southElement);
				if(locationTitle.equals(location))
				{
					break;	
				}
			}
			break;
		}
		return locationTitle;
	}
	
	public void clickLJALocation(String location)
	{
		waitForPage();
		switch(location)
		{
		case "Local Justice Area 20 North":
			//click(ljaNorth.get(0));
			for(WebElement element:ljaNorth)
			{   
				count++;
				if(getTextFromWebElement(element).equals(location))
				{
					waitForVisibilityOfElement(element);
					click(element);	
					break;
				}
			}
			break;
		case "Local Justice Area 20 South":
			//click(ljaSouth.get(1));
			for(WebElement southElement:ljaSouth)
			{   
				count++;
				if(getTextFromWebElement(southElement).equals(location))
				{
					waitForVisibilityOfElement(southElement);
					click(southElement);
					break;
				}
				
			}
			break;
		case "Local Justice Area 2 South":
			//click(ljaSouth.get(1));
			for(WebElement southElement:ljaSouth)
			{   
				count++;
				if(getTextFromWebElement(southElement).equals(location))
				{
					waitForVisibilityOfElement(southElement);
					click(southElement);
					break;
				}
				
			}
			break;
		
		}
		
	}
		
	
	public void clickOnAddButton()
	{
		click(addButton.get(count-1));
	}
	
	public void clickonRemoveButton()
	{
		waitForPage();
		click(removedCombinedPanel1.get(1));
		waitForPage();
		//waitForPage();
		//click(removedCombinedPanel1);
		//waitForPage();
		//waitForPage();
		//click(removedCombinedPanel1);
		//waitForPage();
	}
		
	public void enterLJAName(String ljaNameVal) {
		waitForPage();
		enterText(ljaName.get(count-1), ljaNameVal);
		enterText(ljaName.get(count-1), Keys.ARROW_DOWN.toString());
		enterText(ljaName.get(count-1), Keys.ENTER.toString());	
	}
	
	public String getSucessOrVadidationMessage(String operationType)
	{
		String messageDetails=null;
		waitForPageToLoad();
		switch(operationType)
		{
		case "Own":
			messageDetails=getTextFromWebElement(ownCombinedPanelError.get(count-1));
			break;
		case "Add":
			waitForPage();
			messageDetails=getTextFromWebElement(addedLjaName.get(2));
			break;
		case "Duplicate":
			messageDetails=getTextFromWebElement(alreadyAddedError.get(count-1));
			break;
		case "AlreadyInUse":
			//messageDetails=getTextFromWebElement(alreadyUsedError);
			messageDetails=getTextFromWebElement(alreadyUsedError.get(count-1));
			break;
		}
		return messageDetails;
	}
	
	public boolean isCombinedYouthLJAExist()
	{
		waitForPage();
		return isElementNotDisplayed(addedLjaName.get(count-1));
	}
	
	public String getNoCombinedYouthPanelMessage()
	{
		waitForPage();
		System.out.println("Count size:"+count);
		return getTextFromWebElement(noCombinePanelMessage.get(count-3));
	}
	
}
