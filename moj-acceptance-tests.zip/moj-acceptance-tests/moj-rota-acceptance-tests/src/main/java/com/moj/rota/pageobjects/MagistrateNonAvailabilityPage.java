package com.moj.rota.pageobjects;

import java.util.Calendar;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.moj.common.pageobjects.MOJBasePage;
import com.moj.rota.magistrate.pageobjects.MagistrateHomePage;

public class MagistrateNonAvailabilityPage extends MOJBasePage {

	private static String winHandleBefore = null;

	public MagistrateNonAvailabilityPage(WebDriver driver) {
		super(driver);
		winHandleBefore = driver.getWindowHandle();
		waitForPage();
		//switchToNewWindow();
		if(isElementNotDisplayed(switchFrame))
		{
		switchToIFrame(switchFrame);
		}
	}

	@FindBy(css = ".btn.btn-info.btn-xs")
	private WebElement logOut;

	@FindBy(id = "loggedInName")
	private WebElement loginName;

	@FindBy(css = ".breadcrumb>li>a")
	private WebElement homePage;

	@FindBy(css = ".container>h1")
	private WebElement calenderTitle;

	@FindBy(css = ".container>h3")
	private WebElement calenderSubTitle;

	@FindBy(css = "#help-heading > div > div > h3")
	private WebElement helpTitle;

	@FindBy(id = "help-panel-close-btn")
	private WebElement show;

	@FindBy(css = ".col-xs-12.col-sm-6.col-md-6.col-lg-6")
	private WebElement helpInformation;

	@FindBy(id = "btnPreviousRota")
	private WebElement presentPeriod;
	
	@FindBy(css = ".btnNextRota")
	private WebElement magNextPeriod;

	@FindBy(css = "#btnCurrentRota.btn.active")
	private WebElement presentPeriodColor;

	@FindBy(id = "btnNextRota")
	private WebElement plusSixMonths;

	@FindBy(id = "btnFutureRota")
	private WebElement plusTwellMonths;

	@FindBy(id = "magistrate-name-heading")
	private WebElement magistrateInformation;

	@FindBy(css = "#calendar1 td.fc-header-left > span > h2")
	private WebElement monthHeading;

	@FindBy(css = "#calendar2 > table > tbody > tr > td.fc-header-right > span")
	private WebElement currentPeriod;

	@FindBy(css = "#calendar2 > table > tbody > tr > td.fc-header-right > span")
	private WebElement sixmonthPeriod;

	@FindBy(css = "#calendar1 > table > tbody > tr > td.fc-header-right > span")
	private WebElement PrevCurrentPeriod;

	@FindBy(css = "#calendar1 tr > th")
	private WebElement weekNames;

	@FindBy(id = "#calendar1 tr > th:nth-child(1)")
	private WebElement weekNumber;

	@FindBy(css = "#calendar1 .fc-non-selectable")
	private WebElement holidaysColor;

	@FindBy(css = "#calendar1 tr td.fc-day.fc-mon.fc-widget-content.fc-past > div")
	private WebElement workingDaysSelection;

	@FindBy(css = "#calendar1 tr:nth-child(4) > td.fc-day.fc-wed.fc-widget-content")
	private WebElement daySelection;

	@FindBy(css = "#calendar2 tr:nth-child(2) > td.fc-week-number.fc-widget-content.fc-first > div")
	private WebElement weekNumberSelection;

	@FindBy(css = "#calendar2 .fc-selected")
	private WebElement selectedWeekNumber;

	@FindBy(css = "#calendar3  tr > th.fc-day-header.fc-fri.fc-widget-header")
	private WebElement repeatingDayOfTheWeek;

	@FindBy(css = "#calendar3 .fc-selected")
	private WebElement selectedRepeatingDayOfTheWeek;

	@FindBy(css = "#calendar4  tr > th.fc-day-header.fc-sat.fc-widget-header")
	private WebElement selectSaturdays;

	@FindBy(css = "#calendar4 .fc-selected")
	private WebElement selectedSaturdays;

	@FindBy(css = "#calendar4 .fc-day.fc-sat.fc-non-selectable")
	private WebElement nonSelectableSaturdays;

	@FindBy(css = "#calendar3  tr > th.fc-day-header.fc-fri.fc-widget-header")
	private WebElement selectBankHolidays;

	@FindBy(css = "#calendar4 tr > td.fc-header-left > span > h2")
	private WebElement selectMonthHeaing;

	@FindBy(id = "saveDetailsBtn")
	private WebElement save;

	@FindBy(css = ".btn.btn-small.btn-success.saveDetailsBtn")
	private WebElement magSave;

	@FindBy(css = ".fc-header-title.badge.badge-info>h2")
	private List<WebElement> defaultPeriod;

	@FindBy(id = "nextMonthView")
	private WebElement nextMonthView;

	@FindBy(id = "prevMonthView")
	private WebElement previousMonthView;

	@FindBy(id = "sixMonthView")
	private WebElement sixMonthsView;

	@FindBy(id = "month-view-6")
	private WebElement sixMonthsViewDisplay;

	// magistrate
	@FindBy(css = "a.btn.btn-info.btn-small.active.btnCurrentView")
	private WebElement magPresentPeriod;

	@FindBy(css = ".btnNextRota")
	private WebElement magplussixMonthsPerioed;

	@FindBy(css = ".btnPreviousRota")
	private WebElement magPrevioussentPeriod;

	@FindBy(css = ".fc-sitting")
	private List<WebElement> notConfirmedSittingStatus;

	@FindBy(css = ".fc-selected")
	private List<WebElement> notAvailableToSit;

	public boolean isNonAvailabilityDisplayed() {
		return isElementDisplayed(calenderTitle);
	}

	public boolean isPageFieldsDisplayed(String pageFields) {
		boolean isElemtDisplayed = false;
		switch (pageFields) {
		case "Home_link":
			isElemtDisplayed = isWebElementDisplayed(homePage);
			break;
		case "LogOut":
		case "MyAccount":
			isElemtDisplayed = isWebElementDisplayed(logOut);
			break;
		case "Calender_Title":
			isElemtDisplayed = isWebElementDisplayed(calenderTitle);
			break;
		case "Magistrate_Name":
			isElemtDisplayed = isWebElementDisplayed(magistrateInformation);
			break;
		case "Help":
			isElemtDisplayed = isWebElementDisplayed(helpTitle);
			break;
		case "Show":
			isElemtDisplayed = isWebElementDisplayed(show);
			break;
		case "MagNext":
			isElemtDisplayed = isWebElementDisplayed(magNextPeriod);
			break;
		case "+6Months":
		case "Next":
			isElemtDisplayed = isWebElementDisplayed(plusSixMonths);
			break;
		case "+12Months":
			isElemtDisplayed = isWebElementDisplayed(plusTwellMonths);
			break;
		case "DefaultPeriod":
			isElemtDisplayed = isWebElementDisplayed(defaultPeriod.get(0));
			break;
		case "Save_Button":
			isElemtDisplayed = isWebElementDisplayed(save);
			break;
		case "Mag_Save_Button":
			isElemtDisplayed = isWebElementDisplayed(magSave);
			break;
		case "DistrictJudge_Name":
			isElemtDisplayed = isWebElementDisplayed(magistrateInformation);
			break;
		default:
			System.out.println("Not elements displyed");

		}

		return isElemtDisplayed;
	}

	public void clickHelpButton(String buttonType) {

		if (buttonType != null && !buttonType.equals("")) {
			waitForPage();
			waitForElementTobeClickable(show);
			click(show);

		}

	}

	public void clickRotaPeriod(String rotaPeriod) {
		switch (rotaPeriod) {
		case "present":
			//click(presentPeriod);
			break;
		case "+6Months":
			click(plusSixMonths);
			break;
		case "+12Months":
			click(plusSixMonths);
			waitForPage();
			waitForElementTobeClickable(plusSixMonths);
			waitForPage();
			click(plusSixMonths);
			break;
		default:
		}

		waitForPageToLoad();

	}

	public MagistrateSearchPage clickonSave() {
		click(save);
		driver.switchTo().window(winHandleBefore);
		return returnPageFactory(MagistrateSearchPage.class);
	}

	public String getHelpPanelButtonLabel() {
		return getTextFromWebElement(show);
	}

	public boolean isHelpPanelInfoDisplayed(String buttonType) {
		return isElementDisplayed(helpInformation);
	}

	public String getRotaPeriodColors(String rotaPeriod) {
		String buttonName = null;
		switch (rotaPeriod) {
		case "present":
			buttonName = getTextFromWebElement(plusSixMonths);
			break;
		case "+6Months":
		case "+12Months":
			buttonName = getTextFromWebElement(presentPeriod);
			break;
		default:
		}

		return buttonName;
	}

	public void seleactNonAvalability(String rotaPeriod) {

		switch (rotaPeriod) {
		case "Day":
			click(daySelection);
			break;
		case "WeekNumber":
			click(weekNumberSelection);
			break;
		case "RepeatingDayInTheMonth":
			click(repeatingDayOfTheWeek);
			break;
		case "BankHolidays":
			Calendar now = Calendar.getInstance();
			int month = now.get(Calendar.MONTH);

			if (month >= 1) {
				clickRotaPeriod("+12Months");
			} else if (month >= 6) {
				clickRotaPeriod("+6Months");
			} else if (month >= 12) {
				clickRotaPeriod("present");
			}

			click(selectBankHolidays);
			break;
		case "Saturdays":
			click(selectSaturdays);
			break;
		default:
		}

	}

	public String getSelectedNonAvaliability(String rotaPeriod) {

		String blackCrossMark = null;
		waitForPage();
		switch (rotaPeriod) {
		case "Day":
			blackCrossMark = daySelection.getCssValue("background-image");
			break;
		case "WeekNumber":
			blackCrossMark = selectedWeekNumber.getCssValue("background-image");
			break;
		case "RepeatingDayInTheMonth":
			blackCrossMark = selectedRepeatingDayOfTheWeek.getCssValue("background-image");
			break;
		case "BankHolidays":
			blackCrossMark = selectBankHolidays.getCssValue("background-image");
			break;
		case "Saturdays":
			blackCrossMark = selectedSaturdays.getCssValue("background-image");
			break;
		default:
		}

		return blackCrossMark;

	}

	public String getNonSelectedNonAvaliability(String rotaPeriod) {

		String blackCrossMark = null;
		switch (rotaPeriod) {
		case "Day":
			blackCrossMark = daySelection.getCssValue("background-image");
			break;
		case "WeekNumber":
			blackCrossMark = weekNumberSelection.getCssValue("background-image");
			break;
		case "RepeatingDayInTheMonth":
			blackCrossMark = repeatingDayOfTheWeek.getCssValue("background-image");
			break;
		case "BankHolidays":
			blackCrossMark = selectBankHolidays.getCssValue("background-image");
			break;
		case "Saturdays":
			blackCrossMark = selectSaturdays.getCssValue("background-image");
			break;
		default:
		}

		return blackCrossMark;

	}

	public void clickOnMonthHeading() {
		waitForPage();
		click(monthHeading);
	}

	public void clickArrowButtons(String arrowButtons) {
		switch (arrowButtons) {
		case "Right":
			click(nextMonthView);
			break;
		case "Left":
			click(previousMonthView);
			break;
		case "6Months":
			click(sixMonthsView);
			break;
		default:
		}
	}

	public boolean isNextMonthViewDisplayed() {
		return isElementDisplayed(nextMonthView);
	}

	public boolean isNextAndPrevViewsdisplayed(String monthViewsButton) {
		boolean isMonthViewsDisplayed = false;
		switch (monthViewsButton) {
		case "Right":
			isMonthViewsDisplayed = isElementDisplayed(nextMonthView);
			break;
		case "Left":
			isMonthViewsDisplayed = isElementDisplayed(previousMonthView);
			break;
		case "6Months":
			isMonthViewsDisplayed = isElementDisplayed(sixMonthsView);
			break;
		default:
		}
		return isMonthViewsDisplayed;
	}

	public boolean getMonthsCurrentPeriod() {
		return currentPeriod.isDisplayed();

	}

	public boolean getMonthsCurrentPeriod(String monthViewsButton) {
		boolean isMonthViewsDisplayed = false;
		switch (monthViewsButton) {
		case "Right":
			isMonthViewsDisplayed = currentPeriod.isDisplayed();
			break;
		case "6Months":
			isMonthViewsDisplayed = sixmonthPeriod.isDisplayed();
			break;
		case "Left":
			isMonthViewsDisplayed = PrevCurrentPeriod.isDisplayed();
			break;
		default:
		}
		return isMonthViewsDisplayed;
	}

	public boolean isSixMonthViewDisplayed() {
		return isElementDisplayed(sixMonthsViewDisplay);
	}

	public boolean isPresentDisplayed() {
		return isElementDisplayed(sixMonthsViewDisplay);
	}

	// magistrate

	public void clickMagRotaPeriod(String rotaPeriod) {
		switch (rotaPeriod) {
		case "present":
			//click(magPresentPeriod);
			break;
		case "+6Months":
			click(magplussixMonthsPerioed);
			break;
		case "+12Months":
			click(magplussixMonthsPerioed);
			waitForPage();
			click(magplussixMonthsPerioed);
			//click(magPlusTwellMonths);
			break;
		default:
		}

		waitForPageToLoad();

	}

	public MagistrateHomePage clickOnMagSave() {
		waitForElementTobeClickable(magSave);
		click(magSave);
		return returnPageFactory(MagistrateHomePage.class);
	}

	public String getMagRotaPeriodColors(String rotaPeriod) {
		String buttonName = null;
		switch (rotaPeriod) {
		case "present":
			buttonName = getTextFromWebElement(magNextPeriod);
			break;
		case "+12Months":
		case "+6Months":
			buttonName = getTextFromWebElement(magPrevioussentPeriod);
			break;
		default:
		}

		return buttonName;
	}

	public boolean isMagPresentDisplayed() {
		return isElementDisplayed(magplussixMonthsPerioed);
	}

	public boolean isDayselectionEditable() {
		click(daySelection);
		return daySelection.getCssValue("background-image").contains("cross-small.png");
	}

	public boolean getMagistrateStatus(String status) {
		boolean isSittingStatus = false;
		switch (status) {
		case "S":
			waitForPage();
			isSittingStatus = notConfirmedSittingStatus.get(0).getCssValue("background-image").contains("s-small.png");
			break;
		case "X":
			waitForPage();
			isSittingStatus = notAvailableToSit.get(0).getCssValue("background-image").contains("cross-small.png");
			break;
		}

		return isSittingStatus;
	}

	public void changeToAvailable() {
		for (WebElement element : notAvailableToSit) {
			click(element);
		}
	}

	public boolean isNonSeletableDay(String rotaPeriod) {

		boolean isNonSelectable = false;
		waitForPage();
		switch (rotaPeriod) {
		case "Saturdays":
			isNonSelectable = isElementNotDisplayed(nonSelectableSaturdays);
			break;
		}
		return isNonSelectable;

	}
}
