package com.moj.rota.pageobjects;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.moj.common.pageobjects.MOJBasePage;

public class CreateDistrictJudgePage extends MOJBasePage {

	@FindBy(id = "firstName")
	private WebElement fname;

	@FindBy(id = "lastName")
	private WebElement lname;

	@FindBy(id = "gender-1")
	private WebElement genderMale;

	@FindBy(id = "gender-2")
	private WebElement genderFemale;

	@FindBy(id = "emailAddress")
	private WebElement email;

	@FindBy(id = "phone1")
	private WebElement contactPhone1;

	@FindBy(id = "phoneType1")
	private WebElement phoneType1;

	@FindBy(id = "phone2")
	private WebElement contactPhone2;

	@FindBy(id = "phoneType2")
	private WebElement phoneType2;

	@FindBy(id = "phone3")
	private WebElement contactPhone3;

	@FindBy(id = "phoneType3")
	private WebElement phoneType3;

	@FindBy(id = "welsh")
	private WebElement welshLangPref;

	@FindBy(id = "personal-details-save-btn")
	private WebElement saveButton;

	@FindBy(id = "lastNameError")
	private WebElement lastNameError;

	@FindBy(id = "genderError")
	private WebElement genderError;

	@FindBy(id = "personal-details-save-btn")
	protected WebElement nextButton;

	public CreateDistrictJudgePage(WebDriver driver) {
		super(driver);
	}

	public void enterFirstName(String firstName) {
		getElement(fname).sendKeys(firstName);
	}

	public void enterLastName(String lastName) {
		getElement(lname).sendKeys(lastName);
	}

	public void selectGenderAsMale() {
		getElement(genderMale).click();
	}

	public void selectGenderAsFemale() {
		getElement(genderFemale).click();
	}

	public void enterEmailAddress(String emailAddress) {
		getElement(email).sendKeys(emailAddress);
	}

	public void enterPhoneNo1(String phone1) {
		getElement(contactPhone1).sendKeys(phone1);
	}

	public void selectPhoneType1(String pType1) {
		Select phoSelect1 = new Select(getElement(phoneType1));
		phoSelect1.selectByVisibleText(pType1);
	}

	public void enterPhoneNo2(String phone2) {
		getElement(contactPhone2).sendKeys(phone2);
	}

	public void selectPhoneType2(String pType2) {
		Select phoSelect2 = new Select(getElement(phoneType2));
		phoSelect2.selectByVisibleText(pType2);
	}

	public void enterPhoneNo3(String phone3) {
		getElement(contactPhone3).sendKeys(phone3);
	}

	public void selectPhoneType3(String pType3) {
		Select phoSelect3 = new Select(getElement(phoneType3));
		phoSelect3.selectByVisibleText(pType3);
	}

	public void selectWelshLangPref() {
		getElement(welshLangPref).click();
	}

	public RotaAdminHomePage clickSaveButton() {
		getElement(saveButton).click();
		return getPage(RotaAdminHomePage.class);
	}

	public void verifyErrors() {
		Assert.assertTrue(getElement(lastNameError).isDisplayed());
		Assert.assertTrue(getElement(genderError).isDisplayed());
	}

	public ConfirmationPopUp completeDJFormWithValidData() {

		completeNonMandatoryFields();
		enterFirstName(faker.name().firstName());
		enterLastName(faker.name().lastName());
		selectGenderAsMale();
		selectGenderAsFemale();

		clickSaveButton();

		return getPage(ConfirmationPopUp.class);

	}

	public ConfirmationPopUp completeDJFormWithValidData(String firstName, String lastName) {

		enterFirstName(firstName);
		completeNonMandatoryFields();

		enterLastName(lastName);
		selectGenderAsMale();
		selectGenderAsFemale();

		clickSaveButton();

		return getPage(ConfirmationPopUp.class);

	}

	public CreateDistrictJudgePage completeDJFormWithNoData() {
		clickSaveButton();
		return getPage(CreateDistrictJudgePage.class);
	}

	public void completeNonMandatoryFields() {

		enterEmailAddress(faker.internet().emailAddress());

		enterPhoneNo1(faker.numerify("44#########"));
		selectPhoneType1("Home");

		enterPhoneNo2(faker.numerify("020########"));
		selectPhoneType2("Office");

		enterPhoneNo3(faker.numerify("07#########"));
		selectPhoneType3("Mobile");

		selectWelshLangPref();
	}

	public void leaveMandatoryFieldsIncomplete() {
		completeNonMandatoryFields();
		clickSaveButton();
	}

	public CreateDistrictJudgePage clickNextWithInvalidData() {
		getElement(nextButton).click();
		return getPage(CreateDistrictJudgePage.class);
	}

	public String getErrorMsg(String fieldName) {
		String errorMsg = "";

		if (fieldName.equalsIgnoreCase("Last Name")) {

			enterFirstName(FIRST_NAME);
			errorMsg = clickNextWithInvalidData().getElement(lastNameError).getText();
		}

		if (fieldName.equalsIgnoreCase("Gender")) {

			enterFirstName(FIRST_NAME);
			enterLastName(LAST_NAME);

			errorMsg = clickNextWithInvalidData().getElement(genderError).getText();
		}
		return errorMsg;

	}
}
