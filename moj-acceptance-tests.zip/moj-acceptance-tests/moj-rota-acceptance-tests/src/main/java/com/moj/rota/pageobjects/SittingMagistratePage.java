
package com.moj.rota.pageobjects;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.moj.common.pageobjects.MOJBasePage;

public class SittingMagistratePage extends MOJBasePage {

	@FindBy(id = "appointmentDate")
	private WebElement appDate;

	@FindBy(id = "panelType")
	private WebElement appStatus;

	@FindBy(id = "ljaId")
	private WebElement localJusticeArea;

	@FindBy(id = "sitting-eligibility-back-btn")
	private WebElement backbuttElement;

	@FindBy(id = "sitting-eligibility-next-btn")
	private WebElement saveButton;

	@FindBy(id = "appointmentDateError")
	private WebElement appointmentDateError;

	public SittingMagistratePage(WebDriver driver) {
		super(driver);
	}

	public void enterAppointmentDate(String appointmentDate) {
		getElement(appDate).sendKeys(appointmentDate);
	}

	public void selectAppointmentStatus(String appointmentStatus) {
		Select appSelect = new Select(appStatus);
		appSelect.selectByVisibleText(appointmentStatus);
	}

	public void selectJusticeArea(String justiceArea) {
		Select appSelect = new Select(localJusticeArea);
		appSelect.selectByVisibleText(justiceArea);
	}

	public void clickBackButton() {
		getElement(backbuttElement).click();
	}

	public void clickSaveButton() {
		//getElement(saveButton).click();
		saveButton.sendKeys(Keys.ENTER);
		
	}

	public String appDateErrorMsg() {
		return getElement(appointmentDateError).getText();
	}

}
