package com.moj.rota.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.moj.common.pageobjects.MOJBasePage;

public class StandardReportsPage extends MOJBasePage {

	public StandardReportsPage(WebDriver driver) {
		super(driver);
	}

	@FindBy(css = "#criteria-content>div>h1")
	private WebElement reportsTitle;

	@FindBy(css = ".panel-title")
	private WebElement pageTitle;

	@FindBy(id = "reportId")
	private WebElement reportName;

	@FindBy(id = "lja")
	private WebElement ljaLocation;

	@FindBy(css = ".btn.btn-success")
	private WebElement viewReportButton;

	@FindBy(css = ".textLayer>div:nth-child(1)")
	private WebElement pdfReportTitle;

	@FindBy(css = ".textLayer>div:nth-child(2)")
	private WebElement nameHeader;

	@FindBy(css = ".textLayer>div:nth-child(3)")
	private WebElement homeLocationHeader;

	@FindBy(css = ".textLayer>div:nth-child(4)")
	private WebElement percentageAssignedHeader;

	@FindBy(css = ".textLayer>div:nth-child(3)")
	private WebElement specialRequirementsHeader;

	@FindBy(css = ".textLayer>div:nth-child(3)")
	private WebElement halfDayOnlyHeader;

	@FindBy(css = ".textLayer>div:nth-child(5)")
	private WebElement youthOnlyHeader;

	@FindBy(css = ".textLayer>div:nth-child(7)")
	private WebElement familyOnlyHeader;

	@FindBy(css = ".textLayer>div:nth-child(4)")
	private WebElement weeklyPatternHeader;

	@FindBy(css = ".textLayer>div:nth-child(6)")
	private WebElement monthlySittingHeader;

	@FindBy(css = ".textLayer>div:nth-child(4)")
	private WebElement specialRequirementsNameVal;

	@FindBy(css = ".textLayer>div:nth-child(5)")
	private WebElement specialRequirementsVal;

	@FindBy(css = ".textLayer>div:nth-child(5)")
	private WebElement homeLocationsNameVal;

	@FindBy(css = ".textLayer>div:nth-child(6)")
	private WebElement homeLocationsVal;

	@FindBy(css = ".textLayer>div:nth-child(7)")
	private WebElement homeLocationPercentageVal;

	@FindBy(css = ".textLayer>div:nth-child(8)")
	private WebElement expectionDefaultNameVal;

	public boolean isReportsPageDisplayed() {
		return isElementDisplayed(pageTitle);
	}

	public String getReportLables(String typeOfLable) {
		String reportLabels = null;
		switch (typeOfLable) {
		case "Standard Reports":
			reportLabels = getTextFromWebElement(reportsTitle);
			break;
		case "Standard Report Criteria":
			reportLabels = getTextFromWebElement(pageTitle);
			break;
		case "View Report":
			reportLabels = getTextFromWebElement(viewReportButton);
			break;
		default:
		}
		return reportLabels;
	}

	public void selectReportName(String reportNameVal) {
		selectDropDown(reportName, reportNameVal);
	}

	public void selectLJALocation(String locationName) {
		selectDropDown(ljaLocation, locationName);
	}

	public void clickViewReport() {
		click(viewReportButton);
	}

	public String getPDFPageTitle() {
		switchToNewWindow();
		return getTextFromWebElement(pdfReportTitle);
	}

	public String getReportContentHeaders(String typeOfLable) {
		String reportContent = null;
		switch (typeOfLable) {
		case "Name":
			reportContent = getTextFromWebElement(nameHeader);
			break;
		case "Home Location":
			reportContent = getTextFromWebElement(homeLocationHeader);
			break;
		case "% Assigned":
			reportContent = getTextFromWebElement(percentageAssignedHeader);
			break;
		case "Special Requirement":
			reportContent = getTextFromWebElement(specialRequirementsHeader);
			break;
		case "Half Day Only":
			reportContent = getTextFromWebElement(halfDayOnlyHeader);
			break;
		case "Youth Only":
			reportContent = getTextFromWebElement(youthOnlyHeader);
			break;
		case "Family Only":
			reportContent = getTextFromWebElement(familyOnlyHeader);
			break;
		case "Weekly Pattern":
			reportContent = getTextFromWebElement(weeklyPatternHeader);
			break;
		case "Monthly Sitting":
			reportContent = getTextFromWebElement(monthlySittingHeader);
			break;
		default:
		}
		return reportContent;
	}

	public String getReportNameValues(String reportType) {
		String name = null;
		switch (reportType) {
		case "Home Locations":
			name = getTextFromWebElement(homeLocationsNameVal);
			break;
		case "Special Requirements":
			name = getTextFromWebElement(specialRequirementsNameVal);
			break;
		case "Exceptions to Default Settings Report":
			name = getTextFromWebElement(expectionDefaultNameVal);
			break;
		default:
		}
		return name;
	}

	public String getReportContentValues(String reportType) {
		String reportContent = null;
		switch (reportType) {
		case "Home Location":
			reportContent = getTextFromWebElement(homeLocationsVal);
			break;
		case "% Assigned":
			reportContent = getTextFromWebElement(homeLocationPercentageVal);
			break;

		case "Special Requirement":
			reportContent = getTextFromWebElement(specialRequirementsVal);
			break;
		default:
		}
		return reportContent;
	}
	
	public void switchToPreviousWindow(String windowName)
	{
		driver.switchTo().window(windowName);
	}
	public String getCurrentWindowName()
	{
		return driver.getWindowHandle();
	}

}
