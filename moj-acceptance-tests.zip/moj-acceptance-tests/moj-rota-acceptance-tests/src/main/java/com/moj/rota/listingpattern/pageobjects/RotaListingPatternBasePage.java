package com.moj.rota.listingpattern.pageobjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.moj.common.pageobjects.MOJBasePage;

public class RotaListingPatternBasePage extends MOJBasePage {
		
	public RotaListingPatternBasePage(WebDriver driver) {
		super(driver);
		
	}
	
	@FindBy(id = "justiceAreaIdType")
	public WebElement selectJusticeArea;
	
	@FindBy(css = ".btn.btn-primary.btn-lg.jumbo-btn-wide")
	public WebElement listingPatternButton;
	
	@FindBy(css = ".btn.btn-info.btn-xs.dropdown-toggle")
	public WebElement myAccount;
	
	@FindBy(id = "loggedInName")
	public WebElement loginName;
	
	@FindBy(css = ".breadcrumb>li>a")
	public WebElement homePage;
	
	@FindBy(css = ".container.wide>h1")
	public WebElement pageTitle;
	
	@FindBy(css = ".panel-title>strong")
	public WebElement boxTitle;
		
	@FindBy(css = ".col-xs-12.col-sm-3.col-md-3.col-lg-3.control-label")
	public WebElement patternSizeTitle;
	
	@FindBy(id = "weeks-1")
	public WebElement oneWeekPattern;
	
	@FindBy(id = "weeks-2")
	public WebElement twoWeekPattern;
	
	@FindBy(id = "weeks-3")
	public WebElement threeweekPattern;
	
	@FindBy(id = "weeks-4")
	public WebElement fourWeekPattern;
	
	@FindBy(css = "div[id*='justice-area-location-'] > div.panel-heading > h3 > a")
	public List<WebElement> dfjaLocation;
	
	@FindBy(css = "div[id*='justice-area-location-'] > div.panel-heading > h3 > a")
	public List<WebElement> crownCourt;
	
	@FindBy(css = "div[id*='justice-area-location-'] > div.panel-heading > h3 > a")
	public List<WebElement> magistrateCourt1;
	
	@FindBy(css = "div[id*='justice-area-location-'] > div.panel-heading > h3 > a")
	public List<WebElement> magistrateCourt2;
	
	@FindBy(css = "#content-venues-70 > ul > li:nth-child(1) > a")
	public WebElement week1;
	
	@FindBy(css = "#justice-area-location-78 > div.panel-heading > h3 > a")
	public WebElement week2Optimised;
	
	@FindBy(css = "input[id*='venue-name-']")
	public List<WebElement> week1Venue;
	
	@FindBy(css = "button[id*='add-venue-']")
	public List<WebElement> addEvenueWeek1;
	
	@FindBy(css = "#content-venues-67 > ul > li:nth-child(2) > a")
	public WebElement week2;
			
	@FindBy(css = "input[id*='venue-name-']")
	public List<WebElement> week2Venue;
		
	@FindBy(css = "button[id*='add-venue-']")
	public List<WebElement> addEvenueWeek2;
	
	@FindBy(css = "#content-venues-68 > ul > li:nth-child(3) > a")
	public WebElement week3;
	
	@FindBy(css = "input[id*='venue-name-']")
	public List<WebElement> week3Venue;
	
	@FindBy(css = "button[id*='add-venue-']")
	public List<WebElement> addEvenueWeek3;
	
	@FindBy(id = "#content-venues-69 > ul > li:nth-child(4) > a")
	public WebElement week4;
	
	@FindBy(css = "input[id*='venue-name-']")
	public List<WebElement> week4Venue;
		
	@FindBy(css = "button[id*='add-venue-']")
	public List<WebElement> addEvenueWeek4;
	
	@FindBy(id = "generate-rota-btn")
	public WebElement generateRotaButton;
	
	@FindBy(css = "#weeks div:nth-child(1) > label")
	public WebElement weekOneLabel;
	
	@FindBy(css = "#weeks div:nth-child(2) > label")
	public WebElement weekTwoLabel;
	
	@FindBy(css = "#weeks div:nth-child(3) > label")
	public WebElement weekThreeLabel;
	
	@FindBy(css = "#weeks div:nth-child(4) > label")
	public WebElement weekFourLabel;
	
	@FindBy(css = "div[id*='content-venues-'] > ul > li.active > a")
	public WebElement week1UnderLocation;
	
	@FindBy(css = "div[id*='content-venues-'] > ul > li:nth-child(2) > a")
	public WebElement week2UnderLocation;
	
	@FindBy(css = "div[id*='content-venues-'] > ul > li:nth-child(3) > a")
	public List<WebElement> week3UnderLocation;
	
	@FindBy(css = "div[id*='content-venues-'] > ul > li:nth-child(4) > a")
	public List<WebElement> week4UnderLocation;
	
	@FindBy(css = "tr.am-row > td:nth-child(2) > strong")
	public WebElement sessionAM;
	
	@FindBy(css = "tr.pm-row > td:nth-child(1) > strong")
	public WebElement sessionPM;
	
	@FindBy(css = "Span[id*='session-closed-badge']")
	public WebElement closeSaAMSession;
	
	@FindBy(css = "Span[id*='session-closed-badge']")
	public WebElement closeSunPMSession;
	
	@FindBy(css = "Span[id$='-1-AM']")
	public WebElement clickMonAM;
		
	@FindBy(css = "Span[id$='-1-PM']")
	public WebElement clickMonPM;
	
	@FindBy(css = "Span[id$='-9-AM']")
	public List<WebElement> clickTueAM;
		
	@FindBy(css = "Span[id$='-9-PM']")
	public List<WebElement> clickTuePM;
	
	@FindBy(css = "Span[id$='-2-PM']")
	public List<WebElement> draftClickTuePM;
	
	@FindBy(css = "Span[id$='-17-AM']")
	public List<WebElement> clickWedAM;
	
	@FindBy(css = "Span[id$='-3-PM']")
	public List<WebElement> draftClickWedPM;
		
	@FindBy(css = "Span[id$='-17-PM']")
	public List<WebElement> clickWedPM;
	
	@FindBy(css = "Span[id$='-4-PM']")
	public List<WebElement> draftClickThuPM;
	
	@FindBy(css = "Span[id$='-25-AM']")
	public List<WebElement> clickThuAM;
		
	@FindBy(css = "Span[id$='-25-PM']")
	public List<WebElement> clickThuPM;
	
	@FindBy(css = "Span[id$='-5-AM']")
	public WebElement clickFriAM;
		
	@FindBy(css = "Span[id$='-5-PM']")
	public WebElement clickFriPM;
	
	@FindBy(css = "Span[id$='-6-AM']")
	public WebElement clickSatAM;
		
	@FindBy(css = "Span[id$='-6-PM']")
	public WebElement clickSatPM;
	
	@FindBy(css = "Span[id$='-7-AM']")
	public WebElement clickSunAM;
		
	@FindBy(css = "Span[id$='-7-PM']")
	public WebElement clickSunPM;
	
	@FindBy(css = "Select[id^='panel-type']")
	public WebElement panelType;
		
	@FindBy(css = "Select[id^='business-type']")
	public WebElement businessType;
	
	@FindBy(css = "Select[id^='duration-select']")
	public WebElement numberOfSessions;
	
	@FindBy(css = "Span[id^='session-popup-tick-btn']")
	public WebElement saveSession;
	
	@FindBy(css = "a[id$='-1-AM'] > span.badge.badge-primary")
	public WebElement monAMSavedPanel;
	
	@FindBy(css = "a[id$='-1-PM'] > span.badge.badge-primary")
	public WebElement monPMSavedPanel;
	
	@FindBy(css = "a[id$='-1-AM'] > span.badge.badge-info")
	public WebElement monAMSavedBusinessType;
		
	@FindBy(css = "a[id$='-1-PM'] > span.badge.badge-info")
	public WebElement monPMSavedBusinessType;
	
	
	@FindBy(css = "a[id$='-9-AM'] > span.badge.badge-primary")
	public WebElement tueAMSavedPanel;
	
	@FindBy(css = "a[id$='-9-PM'] > span.badge.badge-primary")
	public WebElement tuePMSavedPanel;
	
	@FindBy(css = "a[id$='-9-AM'] > span.badge.badge-info")
	public WebElement tueAMSavedBusinessType;
		
	@FindBy(css = "a[id$='-9-PM'] > span.badge.badge-info")
	public WebElement tuePMSavedBusinessType;
	
	@FindBy(css = "a[id$='-2-PM'] > span.badge.badge-primary")
	public WebElement draftTuePMSavedPanel;
		
	@FindBy(css = "a[id$='-17-AM'] > span.badge.badge-primary")
	public WebElement wedAMSavedPanel;
	
	@FindBy(css = "a[id$='-3-PM'] > span.badge.badge-primary")
	public WebElement draftWedPMSavedPanel;
	
	@FindBy(css = "a[id$='-17-PM'] > span.badge.badge-primary")
	public WebElement wedPMSavedPanel;
	
	@FindBy(css = "a[id$='-17-AM'] > span.badge.badge-info")
	public WebElement wedAMSavedBusinessType;
		
	@FindBy(css = "a[id$='-17-PM'] > span.badge.badge-info")
	public WebElement wedPMSavedBusinessType;
	
	
	@FindBy(css = "a[id$='-25-AM'] > span.badge.badge-primary")
	public WebElement thuAMSavedPanel;
	
	@FindBy(css = "a[id$='-25-PM'] > span.badge.badge-primary")
	public WebElement thuPMSavedPanel;
	
	@FindBy(css = "a[id$='-4-PM'] > span.badge.badge-primary")
	public WebElement draftThuPMSavedPanel;
	
	@FindBy(css = "a[id$='-25-AM'] > span.badge.badge-info")
	public WebElement thuAMSavedBusinessType;
		
	@FindBy(css = "a[id$='-25-PM'] > span.badge.badge-info")
	public WebElement thuPMSavedBusinessType;
	
	@FindBy(css = "a[id$='-5-AM'] > span.badge.badge-primary")
	public WebElement friAMSavedPanel;
	
	@FindBy(css = "a[id$='-5-PM'] > span.badge.badge-primary")
	public WebElement friPMSavedPanel;
	
	@FindBy(css = "a[id$='-5-AM'] > span.badge.badge-info")
	public WebElement friAMSavedBusinessType;
		
	@FindBy(css = "a[id$='-5-PM'] > span.badge.badge-info")
	public WebElement friPMSavedBusinessType;
	
	@FindBy(css = "a[id$='-6-AM'] > span.badge.badge-primary")
	public WebElement satAMSavedPanel;
	
	@FindBy(css = "a[id$='-6-PM'] > span.badge.badge-primary")
	public WebElement satPMSavedPanel;
	
	@FindBy(css = "a[id$='-6-AM'] > span.badge.badge-info")
	public WebElement satAMSavedBusinessType;
		
	@FindBy(css = "a[id$='-6-PM'] > span.badge.badge-info")
	public WebElement satPMSavedBusinessType;
	
	@FindBy(css = "a[id$='-7-AM'] > span.badge.badge-primary")
	public WebElement sunAMSavedPanel;
	
	@FindBy(css = "a[id$='-7-PM'] > span.badge.badge-primary")
	public WebElement sunPMSavedPanel;
	
	@FindBy(css = "a[id$='-7-AM'] > span.badge.badge-info")
	public WebElement sunAMSavedBusinessType;
		
	@FindBy(css = "a[id$='-7-PM'] > span.badge.badge-info")
	public WebElement sunPMSavedBusinessType;
	
	@FindBy(css = "div[id$='-PM'] > span.glyphicon.glyphicon-link")
	public List<WebElement> linkedSessionInfo;
	
	@FindBy(css = "div[id$='-PM'] > span.glyphicon.glyphicon-link")
	public List<WebElement> monSatSunLinkedSessionInfo;
	
	@FindBy(css = "div[id$='-7-AM'] > span.session-close-x")
	public WebElement deletSessionSun;
	
	@FindBy(css = "div[id$='-AM'] span.session-close-x")
	public List<WebElement> deletSession;
	
	@FindBy(css = "div[id$='-PM'] span.session-close-x")
	public List<WebElement> deletLinkedPMSession;
	
	@FindBy(css = "#dismissConfirmModel")
	public WebElement confirmButton;
			
	@FindBy(css = "#header>h1")
	public WebElement rotaProfileTitle;
	
	@FindBy(css = ".text-muted>span")
	public WebElement rotaPeriod;
	
	@FindBy(id = "abort-rota-btn")
	public WebElement rotaAbortButton;
	
	@FindBy(css = ".btn.btn-info.btn-small.nextWeek-button")
	public List<WebElement> nextWeekButton;
		
	@FindBy(css = "a[id$='-2-AM'] > span.badge.badge-primary")
	public WebElement tueRotaSavedPanel;
	
	@FindBy(css = "a[id$='-2-AM'] > span.badge.badge-info")
	public WebElement tueRotaSavedBusinessType;
	
	@FindBy(css = "a[id$='-3-AM'] > span.badge.badge-primary")
	public WebElement wedRotaSavedPanel;
	
	@FindBy(css = "a[id$='-3-AM'] > span.badge.badge-info")
	public WebElement wedRotaSavedBusinessType;
	
	@FindBy(css = "a[id$='-4-AM'] > span.badge.badge-primary")
	public WebElement thuRotaSavedPanel;
	
	@FindBy(css = "a[id$='-4-AM'] > span.badge.badge-info")
	public WebElement thuRotaSavedBusinessType;
	
	@FindBy(id = "abortRotaCancel")
	public WebElement abortRotaCancel;
	
	@FindBy(id = "abortRotaContinue")
	public WebElement abortRotaConfirm;
	
	@FindBy(css = "#content > div > div.jumbotron > div > div:nth-child(1) > div > div")
	public WebElement createRotaLabel;
	
	@FindBy(css = "span[id^='remove-venue']")
	public List<WebElement> removeVenue;
	
	@FindBy(css = "div[id$='-AM'] > label:nth-child(2) > span")
	public List<WebElement> walesLanguage;
	
	@FindBy(css = "div[id$='-AM'] > label:nth-child(3) > span")
	public List<WebElement> districtJudge;
	
	@FindBy(css = "div[id$='-PM'] > label:nth-child(8) > span")
	public List<WebElement> singleJustice;
	
	@FindBy(css = "div[id*='session'] > span:nth-child(1) > span:nth-child(2) > label > span > span.week-view")
	public WebElement rotaProfileLanguage;
	
	@FindBy(css = "div[id*='session'] > span:nth-child(3) > label > span > span.week-view")
	public WebElement rotaProfileDJ;
	
	@FindBy(css = "div[id*='session'] > span:nth-child(3) > label:nth-child(1) > span > span.week-view")
	public List<WebElement> selectRotaProfileSJDJ;
	
	@FindBy(css = "div[id*='session-'] > span:nth-child(3) > label:nth-child(4) > span > span.week-view")
	public List<WebElement> rotaProfileSJ;
	
	@FindBy(css = "div[id*='session-'] > span:nth-child(3) > label:nth-child(3) > span > span.week-view")
	public WebElement selectRotaProfileSJ;
	
	@FindBy(css = "div[id*='session-'] > span:nth-child(3) > label:nth-child(7) > span > span.week-view")
	public WebElement selectRotaProfileDJSJ;
	
	@FindBy(css = ".badge.badge-warning.secondCrownCourtMagistrateIcon > span.week-view")
	public WebElement rotaProfileMJ1;
	
	@FindBy(css = ".badge.badge-inactive.secondCrownCourtMagistrateIcon > span.week-view")
	public WebElement rotaProfileMJ2;
	
	@FindBy(css = "th[id*='toggle-day'] .badge-danger")
	public List<WebElement> bankHoliday;
	
	@FindBy(css = "Span[class*='session-control-CHAIR-'] > span.badge.badge-danger > span.week-view")
	public List<WebElement> chairCount;

	@FindBy(css = "Span[class*='session-control-WINGER'] > span.badge.badge-warning > span.week-view")
	public List<WebElement> wingerCount;
	
	@FindBy(css = "Div[id$='9-AM'] > span[class*='glyphicon glyphicon-user icon-primary']")
	public List<WebElement> selectMagistrate;
	
	@FindBy(css = "Div[id$='6-AM'] > span[class*='glyphicon glyphicon-user icon-primary']")
	public List<WebElement> dfjaMagCount;
	
	@FindBy(css = "Div[id$='-17-AM'] > span.glyphicon.glyphicon-user.icon-primary")
	public List<WebElement> DJMagCount;
	
	@FindBy(css = "Div[id$='-17-PM'] > span.glyphicon.glyphicon-user.icon-primary")
	public List<WebElement> SJMagCount;
	
	//rota profile
	@FindBy(css = "Span[id$='-2-AM']")
	public List<WebElement> clickCloseDraftRotaAM;
	
	@FindBy(css = "Span[id$='-3-AM']")
	public List<WebElement> clickWedCloseDraftRotaAM;
	
	@FindBy(css = "Span[id$='-4-AM']")
	public List<WebElement> clickThuCloseDraftRotaAM;
	
	@FindBy(css = "Span[class*='badge badge-inactive welsh-badge welsh-badge']")
	public List<WebElement> dRotaWalesLanguage;
	
	@FindBy(css = "div[id$='-AM'] > label:nth-child(3) > span")
	public List<WebElement> dRotaDistrictJudge;
	
	@FindBy(css = "div[id$='-PM'] > label:nth-child(8) > span")
	public List<WebElement> dRotaSingleJustice;
	
	@FindBy(css = "Button[id*='add-venue-']")
	public List<WebElement> draftAddVenue;
	
	//Identify flags
	@FindBy(css = ".glyphicon.glyphicon-pencil.edit-winger1")
	public WebElement searchMagTypeWinger;
	
	@FindBy(css = ".glyphicon.glyphicon-pencil.edit-winger1")
	public List<WebElement> searchMagTypeWingerForMatching;
	
	@FindBy(css = "a[id$='-chair'] > span")
	public WebElement searchChairTypeMag;
	
	@FindBy(css = ".badge.badge-success .week-view.profile-tooltip")
	public WebElement specilaRequirements;
	
	@FindBy(css = "Span[class*='session-control-WINGER1-'] > span:nth-child(12)")
	public WebElement specilaRequirementsMouseOverText;
	
	@FindBy(css = "Span[class*='session-control-WINGER1-'] span.badge.badge-warning > span.week-view")
	public WebElement newWingerFlag;
	
	@FindBy(css = "Span[class*='session-control-CHAIR-'] > span.badge.badge-danger > span.week-view")
	public WebElement traineeChairFlag;
	
	@FindBy(css = ".glyphicon.glyphicon-pencil.edit-winger2")
	public WebElement searchMagTypeLocalAuthorityr;
	
	@FindBy(css = ".glyphicon.glyphicon-pencil.edit-winger2")
	public List<WebElement> searchMagTypeLocalAuthorityrForMatching;
	
	@FindBy(css = "Span[class*='session-control-WINGER2-'] > span:nth-child(8) > span.badge.badge-info > span.week-view.profile-tooltip")
	public WebElement LocalAuthorityFlag;
	
	@FindBy(css = "span.badge.badge-danger > span.week-view")
	public WebElement welshSpeakingFlag;
	
	@FindBy(css = "a[id*='returningBenchWinger1-']> span.week-view")
	public WebElement returningBenchFlag;
	
	@FindBy(css = "input[id*='returningBenchWinger1-reason-text-']")
	public WebElement returnBenchReason;

	@FindBy(css = "span[id*='returningBenchWinger1-popup-tick-btn']")
	public WebElement returnBenchSave;
	
	@FindBy(css = ".glyphicon.glyphicon-remove.remove-returningBenchWinger1")
	public WebElement deleteReturningBench;
	
	@FindBy(css = "Span[class*='badge badge-inactive lastSittingWinger1-badge']")
	public WebElement lastSittingFlag;
	
	@FindBy(css = "span[class*='badge badge-info returningBenchWinger1-badge returningBenchWinger1-badge-']")
	public WebElement colorOfReturningBench;
	
	@FindBy(css = "span[class*='badge badge-inactive returningBenchWinger1-badge returningBenchWinger1-badge-']")
	public WebElement colorOfInactiveReturningBench;
	
	@FindBy(css = "span[class*='badge badge-success lastSittingWinger1-badge lastSittingWinger1-badge-']")
	public WebElement colorOflastSitting;
	
	@FindBy(css = "span[class*='badge badge-inactive lastSittingWinger1-badge lastSittingWinger1-badge-']")
	public WebElement colorOfInactivelastSitting;
	
	@FindBy(css = "span[class*='session-control-WINGER1'] > div:nth-child(7) > a > span")
	public WebElement sittingIdentifier;
	
	@FindBy(css = "span[class*='session-control-WINGER1'] > div:nth-child(7) > a > span")
	public List<WebElement> sittingIdentifierWinger1;

	
	@FindBy(css = "span[class*='session-control-WINGER2'] > div:nth-child(7) > a > span")
	public List<WebElement> sittingIdentifier2;
	
	@FindBy(css = "a[id*='sittingIdentifier-winger1']")
	public List<WebElement> listOfSittingIdentifiers;
	
	@FindBy(css = ".btn-group.dropup.open a[id*='sittingIdentifier-winger1']")
	public List<WebElement> listOfSittingIdentifiersWinger1;
	
	@FindBy(css = ".btn-group.dropup.open a[id*='sittingIdentifier-winger2']")
	public List<WebElement> listOfSittingIdentifiersWinger2;
	
	
	@FindBy(css = "span[class*='session-control-WINGER1'] > div:nth-child(7) > a > span.week-view > span")
	public WebElement sittingIdentifiersText;
	
	@FindBy(css = "#sittingIdentifier-winger1-x>b")
	public WebElement closeSittingIdentifier;
	
	@FindBy(css = "div[id*='session-'] .glyphicon.glyphicon-link")
	public List<WebElement> dfLinkedCourtSessions;
	
	@FindBy(css = "span[id$='-PM']")
	public List<WebElement> closedSessionsCount;
	
	//swap functionality
	@FindBy(id = "swap-tab")
	public WebElement swapOpen;
	
	@FindBy(id = "swap-chair")
	public List<WebElement> swapChair;
	
	@FindBy(id = "swap-chair")
	public WebElement swapChair1;
	
	@FindBy(id = "swap-winger2")
	public List<WebElement> swapwinger2;
	
	@FindBy(id = "swap-winger1")
	public List<WebElement> swapwinger1;
	
	@FindBy(id = "swap-singleJustice")
	public List<WebElement> swapSingleJustice;
	
	@FindBy(id = "swap-btn")
	public WebElement swapButton;
	
	@FindBy(css = "Span[class*='session-control-CHAIR-'] > span.profile-tooltip.week-view.control-label.magistrate-initials")
	public List<WebElement> chairName;
	
	@FindBy(css = "Span[class*='session-control-WINGER2-'] > span.profile-tooltip.week-view.control-label.magistrate-initials")
	public List<WebElement> wingerName;
	
	@FindBy(css = ".glyphicon.glyphicon-tags")
	public WebElement pairingIcon;
	
	//Matching pair search results
	@FindBy(css = ".panel-title>strong")
	public WebElement titleBar;
	
	@FindBy(css = "span[id*='matching-session-link-']")
	public List<WebElement> date;
	
	@FindBy(css = "tr[id*='matching-session-template'] > td:nth-child(3) > div > span")
	public List<WebElement> searchBusinessType;
	
	@FindBy(css = "tr[id*='matching-session-template'] > td:nth-child(4) > div")
	public List<WebElement> locationAndVenue;
	
	@FindBy(css = "tr[id*='matching-session-template'] > td:nth-child(5) > div:nth-child(1)")
	public WebElement sittersRole;
	
	@FindBy(css = "tr[id*='matching-session-template'] > td:nth-child(5) > div:nth-child(2)")
	public WebElement sittersFlags;
	
	@FindBy(css = "div[id*='session-'] > span:nth-child(3) > label:nth-child(3) > span > span.week-view")
	public List<WebElement> magTypeSJ;

	@FindBy(css = "div[id*='session-'] > span:nth-child(3) > label:nth-child(1) > span > span.week-view")
	public List<WebElement> magTypeDJ;
	
	@FindBy(css = "tr[id*='matching-session-template-']")
	public List<WebElement> searchResultsCount;
	
	@FindBy(css = "div[id*='session-'] > span:nth-child(3) > label:nth-child(4) > span > span.week-view")
	public List<WebElement> removeSJ;
	
	@FindBy(css = "div[id*='session-'] > span:nth-child(3) > label:nth-child(1) > span > span.week-view")
	public List<WebElement> removeDJ;
	
	@FindBy(css = "tr[id*='matching-session-template-'] > td.success.valid")
	public List<WebElement> sucessTickMark;
	
	@FindBy(css = "a[id*='dj-fix-'] > span")
	public List<WebElement> djSitting;
	
	@FindBy(css = ".ui-datepicker-trigger")
	public List<WebElement> dateImage;
	
	@FindBy(css = ".ui-datepicker-trigger")
	public WebElement selectedDate;
	
	@FindBy(css = "#ui-datepicker-div div.ui-datepicker-group.ui-datepicker-group-first tr:nth-child(4) > td:nth-child(5) > a")
	public WebElement bankHolidayDate;
	
	@FindBy(css = ".glyphicon.glyphicon-plus.expand-all.hand-hover")
	public List<WebElement> plusSign;
	
	@FindBy(css = ".glyphicon.glyphicon-minus")
	public List<WebElement> minusSign;
	
	@FindBy(css = ".btn.btn-info.btn-small.prevWeek-button")
	public List<WebElement> previuosButton;
	
	//swap related
	@FindBy(css = "li[id*='swap-container-']")
	public List<WebElement> swapMessage;
	
	@FindBy(id = "swap-slot1-validation-failures")
	public WebElement slot1ValidationMessage;
	
	@FindBy(id = "swap-slot2-validation-failures")
	public WebElement slot2ValidationMessage;
	
	@FindBy(css = "span[class*='session-control-WINGER1-'] > div:nth-child(5) > a > b")
	public List<WebElement> magistrate1;
	
	@FindBy(css = ".btn-group.dropup.open > ul > li:nth-child(3) > a")
	public WebElement selectEligibility;
	
	@FindBy(css = "#mag-search-form > div > div > table > thead > tr:nth-child(2) > th.col-day-2")
	public List<WebElement> locationStartDate;
	
	@FindBy(id = "swap-dj")
	public List<WebElement> swapDJ;
	
	@FindBy(css = "#swap-bench > span")
	public List<WebElement> swapBench;
	
	@FindBy(css = "div[id*='session-'] > span > span.week-view.control-label.magistrate-initials.profile-tooltip")
	public List<WebElement> swapDJName;
	
	@FindBy(css = ".glyphicon.glyphicon-star-empty.edit-deputy-dj")
	public List<WebElement> deputyDJ;
	
	@FindBy(css = "input[id*='deputyDj-name-']")
	public WebElement deputyDJName;

	@FindBy(css = "span[id*='deputyDj-popup-tick-btn-']")
	public WebElement deputyDJSave;
	
	@FindBy(css = "span.glyphicon-star-empty")
	public WebElement deputyDJStar;
	
	@FindBy(css = "div[id*='session-'] > span > span.glyphicon.glyphicon-remove")
	public List<WebElement> removeDeputyDJ;
	
	@FindBy(css = "div[id*='session-'] > span > label > span > span.week-view")
	public List<WebElement> djAndSJLabels;
	
	@FindBy(css = "div[id*='session-'] > span:nth-child(3) > span.profile-tooltip")
	public List<WebElement> allDJSJMagNames;
	
	//Broken Rules related
	@FindBy(id = "broken-rules-link")
	public WebElement brokenRulesLink;
	
	@FindBy(id = "broken-rules-count")
	public WebElement brokenRulesCount;
		
	@FindBy(id = "start-optimisation-btn")
	public WebElement startOptimisation;
	
	@FindBy(id = "optimisationValidationLabel")
	public WebElement validationLabel;
	
	@FindBy(css = "#optimisationValidationModal > div > div > div.modal-body > div")
	public WebElement validationText;
	
	@FindBy(id = "optimisationValidationCancel")
	public WebElement optimisationCancel;
	
	@FindBy(id = "optimisationValidationContinue")
	public WebElement optimisationContinue;
	
	@FindBy(id = "swap-clear-1")
	public WebElement swapClear1;
	
	@FindBy(css = ".matching-sessions-close-x.close")
	public WebElement closeMatchingPairButton;
	
	//Prevent duplicate sessions
	
	@FindBy(css = "#myModalLabel2")
	public WebElement popupBox;
	
	@FindBy(css = "#dismissStaleDataModal")
	public WebElement continuePopUpButton;
			
	}
