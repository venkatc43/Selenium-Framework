package com.moj.rota.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.moj.common.pageobjects.MOJBasePage;

public class ConfirmationPopUp extends MOJBasePage {

	@FindBy(id = "dismissConfirmModel")
	private WebElement continueButton;

	public ConfirmationPopUp(WebDriver driver) {
		super(driver);
	}

	public RotaAdminHomePage clickContinueButton() {
		getElement(continueButton).click();
		return getPage(RotaAdminHomePage.class);
	}

}
