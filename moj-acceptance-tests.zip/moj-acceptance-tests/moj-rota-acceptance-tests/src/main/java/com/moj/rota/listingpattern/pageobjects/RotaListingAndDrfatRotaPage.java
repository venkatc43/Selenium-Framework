package com.moj.rota.listingpattern.pageobjects;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.moj.rota.pageobjects.MagistrateSittingEligibiltyPage;

public class RotaListingAndDrfatRotaPage extends RotaListingAndDrfatRotaBasePage {
	int clickSearchCount=0;
	public RotaListingAndDrfatRotaPage(WebDriver driver) {
		super(driver);
		waitForPageToLoad();

	}

	public DraftRotaMagistrateListPopupPage clickMagistrateSearch(String requirements, String dayPattern) {
		waitForPage();
		requirementsVal = requirements;
		if (requirements.equals("Trainee Chair")) {
			waitForElementTobeClickable(searchChairTypeMag);
			click(searchChairTypeMag);

		} else if (requirements.equals("Local Authority")) {
			waitForElementTobeClickable(searchMagTypeLocalAuthorityr);
			click(searchMagTypeLocalAuthorityr);

		} else if (requirements.equals("Winger1")) {
			clickSearchCount=clickSearchCount+1;
			if (clickSearchCount < 2) {
				int size = searchMagTypeWingerForMatching.size();
				if (dayPattern.equals("PM")) {
					waitForElementTobeClickable(searchMagTypeWingerForMatching.get(size - 1));
					click(searchMagTypeWingerForMatching.get(size - 1));
				} else {
					waitForElementTobeClickable(searchMagTypeWingerForMatching.get(1));
					click(searchMagTypeWingerForMatching.get(1));
				}
			}

		} else if (requirements.equals("Winger2")) {
			clickSearchCount = clickSearchCount + 1;
			if (clickSearchCount < 2) {
				int size = searchMagTypeLocalAuthorityrForMatching.size();
				if (dayPattern.equals("PM")) {
					waitForElementTobeClickable(searchMagTypeLocalAuthorityrForMatching.get(size - 1));
					click(searchMagTypeLocalAuthorityrForMatching.get(size - 1));
				} else {
					waitForElementTobeClickable(searchMagTypeLocalAuthorityrForMatching.get(1));
					click(searchMagTypeLocalAuthorityrForMatching.get(1));
				}
			}
		} else if (requirements.equals("Winger1Winger2") || requirements.equals("DJ1")
				|| requirements.equals("SameVenuePM") || requirements.equals("DifferentVenueAM")) {

		} else {
			waitForElementTobeClickable(searchMagTypeWinger);
			click(searchMagTypeWinger);
		}
		return returnPageFactory(DraftRotaMagistrateListPopupPage.class);
	}

	public String getSpecialRequirementFlag() {
		waitForVisibilityOfElement(specilaRequirements);
		return getTextFromWebElement(specilaRequirements);
	}

	public void mouseOverOnSpecialRequirements() {
		mouseHover(specilaRequirements);
	}

	public boolean isMouseOverDisplayed() {
		waitForPage();
		return specilaRequirementsMouseOverText.isEnabled();
	}

	public String getSpecialNewWingerFlag() {
		return getTextFromWebElement(specilaRequirements);
	}

	public String getNewWingerFlag() {
		waitForVisibilityOfElement(newWingerFlag);
		return getTextFromWebElement(newWingerFlag);
	}

	public String getTraineeChairFlag() {
		waitForVisibilityOfElement(traineeChairFlag);
		return getTextFromWebElement(traineeChairFlag);
	}

	public String getWelshSpeakingLnagFlag() {
		waitForVisibilityOfElement(welshSpeakingFlag);
		return getTextFromWebElement(welshSpeakingFlag);
	}

	public String getLocalAuthorityFlag() {
		waitForVisibilityOfElement(LocalAuthorityFlag);
		return getTextFromWebElement(LocalAuthorityFlag);
	}

	public void clickRBAndLA(String operationType) {

		waitForPage();
		if (operationType.equals("DAdd")) {
			click(returningBenchFlag);
			waitForPageToLoad();
			enterText(returnBenchReason, "TooFar");
			click(returnBenchSave);
			waitForPageToLoad();
			waitForPage();
			click(lastSittingFlag);
		} else {
			click(deleteReturningBench);
			waitForPageToLoad();
			waitForPage();
			waitForElementTobeClickable(returningBenchFlag);
			click(colorOflastSitting);
		}
	}

	public String getColorOfReturningBench(String oprationType) {
		waitForPage();
		waitForPageToLoad();
		String colorOftheRB = null;
		String actualColor = null;
		if (oprationType.equals("DAdd")) {
			colorOftheRB = getElement(colorOfReturningBench).getCssValue("background-color");
			actualColor = getActualColorFromRGB(colorOftheRB);
		} else {
			colorOftheRB = getElement(colorOfInactivelastSitting).getCssValue("background-color");
			actualColor = getActualColorFromRGB(colorOftheRB);
		}
		return actualColor;

	}

	public String getColorOfLastSitting(String operationType) {
		waitForPageToLoad();
		String colorOftheRB = null;
		String actualColor = null;
		if (operationType.equals("DAdd")) {
			colorOftheRB = getElement(colorOflastSitting).getCssValue("background-color");
			actualColor = getActualColorFromRGB(colorOftheRB);
		} else {
			colorOftheRB = getElement(colorOfInactivelastSitting).getCssValue("background-color");
			actualColor = getActualColorFromRGB(colorOftheRB);
		}
		return actualColor;

	}

	public void clickSitiingIdentifier() {
		waitForPage();
		click(sittingIdentifier);
	}

	public void clickSitiingIdentifier(String winger) {
		if (winger.equals("Winger1")) {
			waitForPageToLoad();
			waitForPage();
			waitForElementTobeClickable(sittingIdentifier);
			click(sittingIdentifier);

		} else if (winger.equals("Winger1PM")) {
			waitForPageToLoad();
			waitForPage();
			waitForElementTobeClickable(sittingIdentifierWinger1.get(2));
			click(sittingIdentifierWinger1.get(2));

		} else if (winger.equals("Winger2PM")) {
			waitForPageToLoad();
			waitForPage();
			waitForElementTobeClickable(sittingIdentifier2.get(2));
			click(sittingIdentifier2.get(2));

		} else if (winger.equals("Winger1Winger2")) {
			waitForPage();
			waitForElementTobeClickable(sittingIdentifier);
			click(sittingIdentifier);
			waitForPageToLoad();
			waitForVisibilityOfElement(listOfSittingIdentifiersWinger1.get(6));
			waitForElementTobeClickable(listOfSittingIdentifiersWinger1.get(6));
			click(listOfSittingIdentifiersWinger1.get(6));
			waitForPage();
			waitForVisibilityOfElement(sittingIdentifier2.get(0));
			waitForElementTobeClickable(sittingIdentifier2.get(0));
			click(sittingIdentifier2.get(0));
			waitForElementTobeClickable(listOfSittingIdentifiersWinger2.get(7));
			click(listOfSittingIdentifiersWinger2.get(7));
		} else {
			waitForPageToLoad();
			click(sittingIdentifier2.get(0));
		}
	}

	public String getIdentifierLabel(int index) {
		waitForPageToLoad();
		return getTextFromWebElement(listOfSittingIdentifiers.get(index));
	}

	public boolean isSucessTickMarkDisplayed() {
		return isElementDisplayed(sucessTickMark.get(0));
	}

	public void selectSittingIdentifier(String sittingIdentifier) {
		waitForPageToLoad();
		switch (sittingIdentifier) {
		case "AS":
			click(listOfSittingIdentifiers.get(0));
			break;
		case "TAS":
			click(listOfSittingIdentifiers.get(1));
			break;
		case "Apr":
			click(listOfSittingIdentifiers.get(2));
			break;
		case "XApr":
			click(listOfSittingIdentifiers.get(3));
			break;
		case "MS":
			click(listOfSittingIdentifiers.get(4));
			break;
		case "Men":
			click(listOfSittingIdentifiers.get(5));
			break;
		case "SS":
			click(listOfSittingIdentifiers.get(6));
			break;
		case "Sup":
			click(listOfSittingIdentifiers.get(7));
			break;
		case "DDelete":
			click(closeSittingIdentifier);
			break;
		}
	}

	public void selectMatchingIdentifier(String sittingIdentifier, String wingerType) {
		waitForPageToLoad();
		waitForPage();
		switch (sittingIdentifier) {
		case "AS":
			if (wingerType.equals("Winger1") || wingerType.equals("Winger1PM")) {
				click(listOfSittingIdentifiersWinger1.get(0));
			} else {
				click(listOfSittingIdentifiersWinger2.get(0));
			}

			break;
		case "TAS":
			if (wingerType.equals("Winger1") || wingerType.equals("Winger1PM")) {
				click(listOfSittingIdentifiersWinger1.get(1));
			} else {
				click(listOfSittingIdentifiersWinger2.get(1));
			}
			break;
		case "Apr":
			if (wingerType.equals("Winger1") || wingerType.equals("Winger1PM")) {
				click(listOfSittingIdentifiersWinger1.get(2));
			} else {
				click(listOfSittingIdentifiersWinger2.get(2));
			}
			break;
		case "XApr":
			if (wingerType.equals("Winger1") || wingerType.equals("Winger1PM")) {
				click(listOfSittingIdentifiersWinger1.get(3));
			} else {
				click(listOfSittingIdentifiersWinger2.get(3));
			}
			break;
		case "MS":
			if (wingerType.equals("Winger1") || wingerType.equals("Winger1PM")) {
				click(listOfSittingIdentifiersWinger1.get(4));
			} else {
				click(listOfSittingIdentifiersWinger2.get(4));
			}
			break;
		case "Men":
			if (wingerType.equals("Winger1") || wingerType.equals("Winger1PM")) {
				click(listOfSittingIdentifiersWinger1.get(5));
			} else {
				click(listOfSittingIdentifiersWinger2.get(5));
			}
			break;
		case "SS":
			if (wingerType.equals("Winger1") || wingerType.equals("Winger1PM")) {
				click(listOfSittingIdentifiersWinger1.get(6));
			} else {
				click(listOfSittingIdentifiersWinger2.get(6));
			}
			break;
		case "Sup":
			if (wingerType.equals("Winger1") || wingerType.equals("Winger1PM")) {
				click(listOfSittingIdentifiersWinger1.get(7));
			} else {
				click(listOfSittingIdentifiersWinger2.get(7));
			}
			break;
		default:
		}
	}

	public boolean isMatchingPair() {
		waitForPageToLoad();
		return isElementDisplayed(pairingIcon);
	}

	public void clickOnMatchingPair() {
		waitForPage();
		click(pairingIcon);
	}

	public boolean isSearchResultsPanel() {
		waitForPageToLoad();
		return isElementDisplayed(titleBar);
	}

	public String getSearchPanelTitle() {
		waitForPageToLoad();
		return getTextFromWebElement(titleBar);
	}

	public String getSelectedSittingIdentifier(String sittingIdentifierType) {
		waitForPageToLoad();
		waitForPage();
		return getTextFromWebElement(sittingIdentifiersText);
	}

	public boolean isSittingIdentifierIcon(String sittingIdentifierType) {
		waitForPageToLoad();
		waitForPage();
		return isElementDisplayed(sittingIdentifier);
	}

	public boolean isLinkedSessionsDisplayed() {
		waitForPage();
		if (dfLinkedCourtSessions.size() > 0) {
			return isElementNotDisplayed(dfLinkedCourtSessions.get(0));
		} else {
			return false;
		}
	}

	public int linkedSessionCount() {
		return dfLinkedCourtSessions.size();
	}

	public int closedSessionsCount() {
		return closedSessionsCount.size();
	}

	public void clickSwapTabToOpen() {
		click(swapOpen);
	}

	public void selectSwapMagistrate(String swapType) {
		switch (swapType) {
		case "2sessions with same venue":
			click(swapwinger2.get(0));
			waitForPageToLoad();
			click(swapChair.get(3));
			waitForPageToLoad();
			break;
		case "2Magistrates with same session":
			click(swapChair.get(3));
			waitForPageToLoad();
			click(swapwinger2.get(4));
			waitForPageToLoad();
			break;
		case "WednesdayToFriday":
			click(swapwinger2.get(3));
			waitForPageToLoad();
			click(swapChair.get(3));
			waitForPageToLoad();
			break;
		case "1 Vacant Slot":
			click(swapChair.get(0));
			waitForPageToLoad();
			click(swapwinger2.get(0));
			break;
		case "DOES_NOT_HAVE_ROLE":
		case "HAS_LEAVE_OF_ABSENCE":
			click(swapwinger1.get(0));
			waitForPageToLoad();
			click(swapChair.get(0));
			break;
		case "NO_PANEL_ELIGIBILITY":
			click(swapChair.get(0));
			waitForPageToLoad();
			click(swapwinger2.get(1));
			break;
		case "DOES_NOT_SIT_AT_LOCATION":
		case "Resigned":
			click(swapwinger1.get(0));
			waitForPageToLoad();
			click(swapChair.get(1));
			break;
		case "DJ TO BENCH":
			click(swapDJ.get(0));
			waitForPageToLoad();
			break;
		case "BENCH TO DJ":
			click(swapBench.get(0));
			waitForPageToLoad();
			break;
		case "MAGISTRATE TO DJ":
			click(swapwinger1.get(0));
			waitForPageToLoad();
			break;
		case "DJ TO BENCH SWAP":
		case "NO_PANEL_ELIGIBILITY_DJ_BENCH":
		case "HAS_LEAVE_OF_ABSENCE_DJ_BENCH":
		case "Resigned_DJ_BENCH":
			click(swapDJ.get(0));
			waitForPageToLoad();
			click(swapBench.get(0));
			waitForPageToLoad();
			break;
		case "BENCH TO DJ SWAP":
			click(swapBench.get(0));
			waitForPageToLoad();
			click(swapDJ.get(0));
			waitForPageToLoad();
			break;
		case "SWAP DJ1 TO DJ2":
		case "SWAP DJ WITH DEPUTY DJ":
		case "HAS_NON_AVAILABILITY_DJ":
		case "NO_PANEL_ELIGIBILITY_DJ":
		case "HAS_LEAVE_OF_ABSENCE_DJ":
		case "Resigned_DJ":
			click(swapDJ.get(0));
			waitForPageToLoad();
			click(swapDJ.get(1));
			break;
		case "SWAP DEPUTY DJ TO DJ":
			click(swapDJ.get(1));
			waitForPageToLoad();
			click(swapDJ.get(0));
			break;
		default:

		}
	}

	public String getSearchResultsContent(String contentsType) {
		String content = null;
		switch (contentsType) {
		case "date":
			content = getTextFromWebElement(date.get(0));
			break;
		case "businessType":
			content = getTextFromWebElement(searchBusinessType.get(0));
			break;
		case "location":
			content = getTextFromWebElement(locationAndVenue.get(0));
			break;
		case "sittersRole":
			content = getTextFromWebElement(sittersRole);
			break;
		case "sittersFlag":
			content = getTextFromWebElement(sittersFlags);
			break;
		default:

		}
		return content;
	}

	public void clickSwapButton() {
		waitForPage();
		//click(swapButton);
		swapButton.sendKeys(Keys.ENTER);
		waitForPage();
	}

	public void clickSearchResultsDate() {
		waitForPage();
		click(date.get(0));
	}

	public void clickMatchMagistrateType(String magType) {
		switch (magType) {
		case "removeSJ":
			waitForElementTobeClickable(magTypeSJ.get(0));
			click(magTypeSJ.get(0));
			break;
		case "removeSJAfter":
			if (removeSJ.size() >= 1) {
				waitForElementTobeClickable(removeSJ.get(1));
				click(removeSJ.get(1));
			} else {
				waitForElementTobeClickable(removeSJ.get(0));
				click(removeSJ.get(0));
			}
			break;
		case "removeDJ":
			waitForPage();
			JavascriptExecutor jse = (JavascriptExecutor)driver;
			jse.executeScript("window.scrollBy(0,-500)", "");
			waitForPage();
			waitForElementTobeClickable(magTypeDJ.get(1));
			click(magTypeDJ.get(1));
			break;
		case "removeDJAfter":

			if (removeDJ.size() >= 1) {
				waitForElementTobeClickable(removeDJ.get(1));
				click(removeDJ.get(1));
			} else {
				waitForElementTobeClickable(removeDJ.get(0));
				click(removeDJ.get(0));
			}
			break;
		}
		waitForPage();
	}

	public int getSearchResultsCount() {
		waitForPageToLoad();
		return searchResultsCount.size();
	}

	public String getSwappedMagistrateName(String swapType, String magType) {
		waitForPage();
		String magName = null;
		switch (swapType) {
		case "2sessions with same venue":
			magName = getTextFromWebElement(chairName.get(0));
			break;
		case "2Magistrates with same session":
			if (magType.equals("Chair")) {
				magName = getTextFromWebElement(chairName.get(3));
			} else {
				magName = getTextFromWebElement(wingerName.get(3));
			}

			break;
		case "WednesdayToFriday":
			magName = getTextFromWebElement(wingerName.get(0));
			break;
		case "1 Vacant Slot":
			if (magType.equals("Winger")) {
				magName = getTextFromWebElement(wingerName.get(0));
			} else {
				magName = getTextFromWebElement(chairName.get(0));
			}
			break;
		case "DJ TO BENCH SWAP":
		case "BENCH TO DJ SWAP":
			magName = getTextFromWebElement(wingerName.get(0));
			break;
		case "SWAP DJ1 TO DJ2":
		case "SWAP DJ WITH DEPUTY DJ":
		case "SWAP DEPUTY DJ TO DJ":
			magName = getTextFromWebElement(swapDJName.get(0));
			break;
		default:

		}

		return magName;
	}

	public String getSwapValidationMessage(String validationType) {
		String validationMessage = null;
		switch (validationType) {
		case "DOES_NOT_HAVE_ROLE":
		case "NO_PANEL_ELIGIBILITY":
		case "HAS_LEAVE_OF_ABSENCE":
		case "DOES_NOT_SIT_AT_LOCATION":
		case "Resigned":
			waitForPage();
			validationMessage = getValidationMessage();

			break;
			
		case "HAS_NON_AVAILABILITY_DJ":
		case "NO_PANEL_ELIGIBILITY_DJ":
		case "HAS_LEAVE_OF_ABSENCE_DJ":
		case "Resigned_DJ":
			waitForPage();
			validationMessage = getValidationMessage();
			
			if(validationMessage==null)
			{
				mouseHover(swapMessage.get(1));
				waitForPage();
				validationMessage = slot2ValidationMessage.getAttribute("data-content");	
			}

			break;
		
		case "NO_PANEL_ELIGIBILITY_DJ_BENCH":
		case "HAS_LEAVE_OF_ABSENCE_DJ_BENCH":
		case "Resigned_DJ_BENCH":
			waitForPage();
			validationMessage = getValidationMessage();
			
			if(validationMessage==null)
			{
				waitForPage();
				click(swapClear1);
				waitForPageToLoad();
				click(swapDJ.get(1));
				waitForPageToLoad();
				click(swapBench.get(0));
				waitForPageToLoad();
				validationMessage = getValidationMessage();	
			}

			break;
		}
		return validationMessage;
	}

	private String getValidationMessage() {
		String validationMessage;
		mouseHover(swapMessage.get(0));
		waitForPage();
		validationMessage = slot1ValidationMessage.getAttribute("data-content");
		return validationMessage;
	}

	public MagistrateSittingEligibiltyPage selectEligibilty() {
		click(magistrate1.get(0));
		waitForPage();
		click(selectEligibility);
		waitForPage();
		return returnPageFactory(MagistrateSittingEligibiltyPage.class);
	}

	public String getCurrentLocationStartDate() {
		return getTextFromWebElement(locationStartDate.get(1));
	}

	public boolean isMagistrateSwapOptionDisabled() {
		// if swapping contains means it's disabled
		return swapwinger1.get(0).getAttribute("class").contains("swapping");
	}

	public boolean isDistrictJudgeSwapOptionDisabled() {
		return swapDJ.get(1).getAttribute("class").contains("swapping");
	}

	public void clickDJ() {
		click(deputyDJ.get(0));
	}

	public void enterDeputyDJName(String deputyDJNameVal) {
		waitForPage();
		enterText(deputyDJName, deputyDJNameVal);
	}

	public void saveDeputy() {
		click(deputyDJSave);
	}

	public void removeDeputyDJ() {
		WebElement element = null;
		for (int i = 0; i < allDJSJMagNames.size(); i++) {
			element = findElement(djAndSJLabels.get(i), By.cssSelector("span.glyphicon-star-empty"));

			if (element != null) {
				click(removeDeputyDJ.get(i - 1));
				break;
			}
		}

	}
	
	public void closeMatchingPair()
	{
		click(closeMatchingPairButton);
	}
	
	public RotaListingPatternPage switchToPreviousScreen(){
	   List<String> tabs = new ArrayList<String> (driver.getWindowHandles());
	   driver.switchTo().window(tabs.get(0));
	   return getPage(RotaListingPatternPage.class);
	}

}
