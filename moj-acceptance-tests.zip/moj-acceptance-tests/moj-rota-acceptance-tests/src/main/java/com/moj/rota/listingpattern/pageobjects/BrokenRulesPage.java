package com.moj.rota.listingpattern.pageobjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class BrokenRulesPage extends RotaListingAndDrfatRotaPage {

	public BrokenRulesPage(WebDriver driver) {
		super(driver);

	}
		
	@FindBy(css = "#broken-rules-content > div > div.panel-heading > h3")
	public WebElement brokenRulesTitle;
	
	@FindBy(css = "span[id*='broken-rule-session-link-']")
	public List<WebElement> brokenRuleDate;
	
	@FindBy(css = "tr[id*='broken-rule-template-'] > td:nth-child(3) > div")
	public List<WebElement> brokenRuleSitter;
	
	@FindBy(css = "tr[id*='broken-rule-template-'] > td:nth-child(5) > div")
	public List<WebElement> brokenRuleDescription;
	
	@FindBy(css = ".delete-broken-rule-checkbox")
	public List<WebElement> brokenRuleRemoveButon;
	
	@FindBy(css = "#broken-rules-content > div > div.panel-heading > h3 > span")
	public WebElement brokenRuleCloseButton;
	
	@FindBy(css = "a[id*='session-broken-rules-'] > img")
	public List<WebElement> brokenRuleImages;
	
	@FindBy(css = ".broken-rules-close-x.close")
	public WebElement brokenRulePopUpClose;
	
	@FindBy(css = ".active>a")
	public WebElement detailTab;
	
	@FindBy(css = ".nav.nav-tabs.hidden-print>li:nth-child(2)>a")
	public WebElement summaryByRule;
	
	@FindBy(css = ".nav.nav-tabs.hidden-print>li:nth-child(3)>a")
	public WebElement summaryBySitter;
	
	@FindBy(css = "#detail > span:nth-child(1) > span")
	public WebElement hardRule;
	
	@FindBy(css = "#detail > span:nth-child(2) > span")
	public WebElement softRule;
	
	@FindBy(css = "#summary-by-broken-rule > div:nth-child(1) > span:nth-child(1) > span")
	public WebElement summaryByHardRule;
	
	@FindBy(css = "#summary-by-broken-rule > div:nth-child(1) > span:nth-child(2) > span")
	public WebElement summaryBySoftRule;
	
	@FindBy(css = "#broken-rule-filter")
	public WebElement filter;
	
	@FindBy(css = ".active>th:nth-child(2)")
	public WebElement date;
	
	@FindBy(css = ".active>th:nth-child(3)")
	public WebElement sitter;
	
	@FindBy(css = ".active>th:nth-child(4)")
	public WebElement location;
	
	@FindBy(css = ".active>th:nth-child(5)")
	public WebElement ruleDescription;
	
	@FindBy(css = ".active>th:nth-child(6)")
	public WebElement selectAll;
	
	@FindBy(css = ".glyphicon.glyphicon-trash.hand-hover.hidden-print")
	public WebElement deleteButton;
	
	@FindBy(css = ".delete-broken-rules-of-type.hand-hover.glyphicon.glyphicon-trash")
	public WebElement summaryByDeleteButton;
	
	@FindBy(css = "#broken-rules-summary-by-justice-delete-popover-0 > span")
	public WebElement sitterByDeleteButton;
	
	@FindBy(css = ".glyphicon.glyphicon-print.hand-hover.hidden-print.broken-rules-print")
	public WebElement printButton;
	
	@FindBy(css = ".glyphicon.glyphicon-print.hand-hover.pull-right.hidden-print.broken-rules-print")
	public WebElement summaryByPrintButton;
	
	@FindBy(css = "#broken-rules-summary-by-justice-content th:nth-child(2) > span")
	public WebElement sitterByPrintButton;
	
	@FindBy(css = ".delete-broken-rule-checkbox")
	public List<WebElement> deleteCheckBox;
	
	@FindBy(css = "#broken-rules-summary-content th:nth-child(1)")
	public WebElement brokenRule;
	
	@FindBy(css = "#broken-rules-summary-by-justice-content th:nth-child(1)")
	public WebElement summaryBySitterTitle;
	
	@FindBy(css = "#broken-rules-summary-by-justice-content th:nth-child(2)")
	public WebElement noOfBrokenRules;
	
	@FindBy(css = "#broken-rules-summary-content th:nth-child(2)")
	public WebElement occurences;
	
	@FindBy(css = ".broken-rules-summary-body > tr:nth-child(1) > td:nth-child(1)")
	public WebElement brokenRuleContent;
	
	@FindBy(css = ".broken-rules-summary-body > tr:nth-child(1) > td:nth-child(2)")
	public WebElement occurencesContent;
	
	@FindBy(css = "#broken-rules-summary-by-justice-content tr:nth-child(1) > td:nth-child(1) > span")
	public WebElement SitterContent;
	
	@FindBy(css = "#broken-rules-summary-by-justice-content tr:nth-child(1) > td:nth-child(2)")
	public WebElement noOfBrokenRulesContent;
	
	@FindBy(id = "hard-rule-filter")
	public WebElement hardRuleFilter;
	
	@FindBy(id = "soft-rule-filter")
	public WebElement softRuleFilter;
	
	@FindBy(id = "hard-rule-filter")
	public WebElement sitterFilter;
	
	@FindBy(id = "broken-rule-fixedByFilter")
	public WebElement fixedSittingsFilter;
	
	@FindBy(css = "tr[id*='broken-rule-template-'].bs-warning")
	public List<WebElement> brokenSoftRuleColor;
	
	@FindBy(css = "tr[id*='broken-rule-template-'].bs-danger")
	public List<WebElement> brokenHardRuleColor;
	
	@FindBy(css = "tr[id*='broken-rule-template-'].bs-danger td:nth-child(3) div span")
	public List<WebElement> brokenHardRuleSitterName;
	
	@FindBy(css = "tr[id*='broken-rule-template-'].bs-danger td:nth-child(5)")
	public List<WebElement> brokenHardRuleDescription;
	
	@FindBy(css = "tr[id*='broken-rule-template-'].bs-warning td:nth-child(3) div span")
	public List<WebElement> brokenSoftRuleSitterName;
	
	@FindBy(css = "tr[id*='broken-rule-template-'].bs-warning td:nth-child(5)")
	public List<WebElement> brokenSoftRuleDescription;
	
	@FindBy(id = "broken-rule-filter-text")
	public WebElement brokenRuleFilterText;
	
	@FindBy(css = "tr[id*='broken-rule-template-']")
	public WebElement fixedSittingResult;
	
	@FindBy(css = "#magistrate-details-panel > div.panel-heading.draggable-hover > h3 > span:nth-child(2)")
	public WebElement sitterMagistrateName;
	
	@FindBy(css = "#magistrate-details-panel > div:nth-child(2) > div > div > small:nth-child(2)")
	public WebElement sittingFrequencyValue;
	
	@FindBy(css = "#magistrate-details-panel > div:nth-child(2) > div > div > small:nth-child(5)")
	public WebElement consecutiveDyasValue;
	
	@FindBy(css = "#magistrate-details-panel > div:nth-child(2) > div > div > small:nth-child(8)")
	public WebElement shortNoticeValue;
	
	@FindBy(css = "#magistrate-details-panel > div:nth-child(2) > div > div > small:nth-child(11)")
	public WebElement sittingPatternValue;
	
	@FindBy(css = "#magistrate-details-panel > div:nth-child(2) > div > div > small:nth-child(14) > span > span.badge.badge-primary")
	public WebElement sittingsValue;
	
	@FindBy(css = "tr[id*='broken-rule-template-'] > td:nth-child(3) > div span")
	public List<WebElement> sitterName;
		
	@FindBy(css = "tr[id*='broken-rule-template-'] > td:nth-child(6) > div > input")
	public List<WebElement> selectSingleRule;
	
	@FindBy(css = ".popover-title")
	public WebElement deletePopTitle;
	
	@FindBy(css = ".popover-content>div")
	public WebElement deleteDescription;
	
	@FindBy(css = ".glyphicon.glyphicon-ok")
	public List<WebElement> deleteOk;
	
	@FindBy(id = "delete-broken-rule-close")
	public WebElement deleteCancel;
	
	@FindBy(css = ".delete-broken-rules-by-type-close")
	public WebElement deleteByRuleCancel;
	
	@FindBy(css = ".delete-sitters-broken-rules-close")
	public WebElement deleteBySitterCancel;
	
	@FindBy(css = "#broken-rules-summary-delete-popover-0 > span")
	public WebElement summaryByRuleDelete;
	
	@FindBy(css = "#broken-rules-summary-by-justice-delete-popover-0 > span")
	public WebElement summaryBySitterDelete;
			
	public String getBrokenRuleContent(String contentType) {
		String content = null;
		switch (contentType) {
		case "Sitter":
			content = getTextFromWebElement(brokenRuleSitter.get(0));
			break;
		case "Rule description":
			content = getTextFromWebElement(brokenRuleDescription.get(0));
			break;
		case "Broken Rule":
			content = getTextFromWebElement(brokenRuleContent);
			break;
		case "Occurences":
			content = getTextFromWebElement(occurencesContent);
			break;	
		case "Sitter Content":
			content = getTextFromWebElement(SitterContent);
			break;
		case "No. of broken rules":
			content = getTextFromWebElement(noOfBrokenRulesContent);
			break;
		
		default:
		}
		return content;
	}

	public boolean isBrokenRuleContentDisplayed() {
		return isElementDisplayed(brokenRulesTitle);
	}

	public String clickOnBrokenRuleDate() {
		waitForElementTobeClickable(brokenRuleDate.get(0));
		String date = getTextFromWebElement(brokenRuleDate.get(0));
		click(brokenRuleDate.get(0));
		click(brokenRuleCloseButton);
		return date;

	}

	public boolean isBrokenRuleSessionDisplayed() {
		waitForPage();
		return isElementDisplayed(brokenRuleImages.get(0));
	}
	
	public void closeBrokenRulePopUp() {
		waitForElementTobeClickable(brokenRulePopUpClose);
		click(brokenRulePopUpClose);
	}
	
	public void clickSummaryByRule() {
		waitForElementTobeClickable(summaryByRule);
		click(summaryByRule);
	}
	
	public void clickSummaryBySitter() {
		waitForElementTobeClickable(summaryBySitter);
		click(summaryBySitter);
	}
	
	public String getDetailTabSummary(String contentType) {
		
		String content = null;
		switch (contentType) {
		case "Hard Rule":
			content = getTextFromWebElement(hardRule);
			break;
		case "Soft Rule":
			content = getTextFromWebElement(softRule);
			break;
		case "Filter":
			content = getTextFromWebElement(filter);
			break;
		case "Date":
			content = getTextFromWebElement(date);
			break;
		case "Sitter":
			content = getTextFromWebElement(sitter);
			break;
		case "Location / Venue":
			content = getTextFromWebElement(location);
			break;
		case "Rule Description":
			content = getTextFromWebElement(ruleDescription);
			break;
		case "All":
			content = getTextFromWebElement(selectAll);
			break;
		default:
		}
		return content;
	}
	
public String getSummaryByRuleTabTitles(String contentType) {
		
		String content = null;
		switch (contentType) {
		case "Hard Rule":
			content = getTextFromWebElement(summaryByHardRule);
			break;
		case "Soft Rule":
			content = getTextFromWebElement(summaryBySoftRule);
			break;
		case "Broken Rule":
			content = getTextFromWebElement(brokenRule);
			break;
		case "Occurences":
			content = getTextFromWebElement(occurences);
			break;
		case "Sitter":
			content = getTextFromWebElement(summaryBySitterTitle);
			break;
		case "No. of broken rules":
			content = getTextFromWebElement(noOfBrokenRules);
			break;
		default:
		}
		return content;
	}
	
	public String getTabName(String tabType)
	{
		String tabName=null;
		switch(tabType)
		{
		case "Detail":
			tabName=getTextFromWebElement(detailTab);
			break;
		case "Summary by broken rule":
			tabName=getTextFromWebElement(summaryByRule);
			break;
		case "Summary by sitter":
			tabName=getTextFromWebElement(summaryBySitter);
			break;
			
		}
		return tabName;
	}
	
public boolean isBrokenRuleButtonDisplayed(String contentType) {
		boolean isButtonDisplayed=false;
		switch (contentType) {
		case "Delete button":
			isButtonDisplayed= isElementDisplayed(deleteButton);
			break;	
		case "Print Button":
			isButtonDisplayed= isElementDisplayed(printButton);
			break;
		case "Summary Print Button":
			isButtonDisplayed= isElementDisplayed(summaryByPrintButton);
			break;
		case "Sitter Print Button":
			isButtonDisplayed= isElementDisplayed(sitterByPrintButton);
			break;
		case "Delete checkbox":
			isButtonDisplayed= isElementDisplayed(deleteCheckBox.get(0));
			break;
		case "Summary Delete button":
			isButtonDisplayed= isElementDisplayed(summaryByDeleteButton);
			break;
		case "Sitter Delete Button":
			isButtonDisplayed= isElementDisplayed(sitterByDeleteButton);
			break;
		default:
		}
		return isButtonDisplayed;
	}

public void clickFilterType(String filterType) {
	switch (filterType) {
	case "Hard Rule":
		click(hardRuleFilter);
		break;
	case "Soft Rule":
		click(softRuleFilter);
		break;
	case "Sitter":
		click(sitterName.get(0));
		break;
	case "Rule description":
		enterText(brokenRuleFilterText, "Weekly");
		break;
	case "Fixed Sittings":
		click(fixedSittingsFilter);
		break;
	default:
	}
}

public String getSoftAndHardRulesColor(String hardOrSoftRule) {
	String colorOftheRB=null;
	String actualColor=null;
	waitForPage();
	switch (hardOrSoftRule) {
	case "Hard Rule":
		colorOftheRB = getElement(brokenSoftRuleColor.get(0)).getCssValue("background-color");
		actualColor = getActualColorFromRGB(colorOftheRB);
		break;
	case "Soft Rule":
		colorOftheRB = getElement(brokenHardRuleColor.get(0)).getCssValue("background-color");
		actualColor = getActualColorFromRGB(colorOftheRB);
		break;
	default:
	}
	return actualColor;

}

public String getSitterAndRuleDescription(String sitterOrRuleDescription,String filterType) {
	String description=null;
	switch (sitterOrRuleDescription) {
	case "Sitter":
		if(filterType.equals("Soft Rule"))
		{
			description = getTextFromWebElement(brokenHardRuleSitterName.get(0));
		} else {
			description = getTextFromWebElement(brokenSoftRuleSitterName.get(0));
		}
		
		break;
	case "Rule description":
		if(filterType.equals("Soft Rule"))
		{
			description = getTextFromWebElement(brokenHardRuleDescription.get(0));
		} else {
			description = getTextFromWebElement(brokenSoftRuleDescription.get(0));
		}
		break;
	default:
	}
	return description;

}

public boolean getFilterResultCount(String sitterOrRuleDescription,String filterType) {
	boolean isResultsDisplayed=false;
	switch (sitterOrRuleDescription) {
	case "Sitter":
			isResultsDisplayed = brokenSoftRuleSitterName.size()>0;
		break;
	case "Rule description":
		isResultsDisplayed = brokenSoftRuleDescription.size()>0;
		break;
	default:
	}
	return isResultsDisplayed;

}

public boolean isFixedSittingsResultsDisplayed()
{
	return isElementNotDisplayed(fixedSittingResult);
}

public String getSitterInformation(String contentType) {
	String content = null;
	switch (contentType) {
	case "Sitting freq":
		content = getTextFromWebElement(sittingFrequencyValue);
		break;
	case "Consec.days":
		content = getTextFromWebElement(consecutiveDyasValue);
		break;
	case "Short notice":
		content = getTextFromWebElement(shortNoticeValue);
		break;
	case "pattern":
		content = getTextFromWebElement(sittingPatternValue);
		break;	
	case "Sittings":
		content = getTextFromWebElement(sittingsValue);
		break;	
	default:
	}
	return content;
}

public boolean isSittingpanelBoxDisplayed()
{
	return isElementNotDisplayed(sitterMagistrateName);
}

public void selectDeleteType(String filterType) {
	switch (filterType) {
	case "Select All":
		click(selectAll);
		break;
	case "Select Single Rule":
		click(selectSingleRule.get(0));
		break;
	default:
	}
}

public void clickDelete()
{
	click(deleteButton);
}

public boolean isDeletePopUpDisplayed()
{
	return isElementDisplayed(deletePopTitle);
}

public boolean isDeletePopUpDescription()
{
	return isElementDisplayed(deleteDescription);
}

public boolean isDeletePopUpOkButton(int type)
{
	return isElementDisplayed(deleteOk.get(type));
}

public boolean isDeletePopUpCancel()
{
	return isElementDisplayed(deleteCancel);
}

public boolean isDeletePopUpByRuleCancel()
{
	return isElementDisplayed(deleteByRuleCancel);
}

public boolean isDeletePopUpBySitterCancel()
{
	return isElementDisplayed(deleteBySitterCancel);
}

public void clickTabName(String tabType)
{
	switch(tabType)
	{
	case "Detail":
		click(detailTab);
		break;
	case "Summary By Rule":
		click(summaryByRule);
		click(summaryByRuleDelete);
		break;
	case "Summary By Sitter":
		click(summaryBySitter);
		click(summaryBySitterDelete);
		break;
		
	}
}

public void deleteBrokenRule()
{
	click(deleteOk.get(1));
}

public int getBrokesRulesCount()
{
	return selectSingleRule.size();
}

}
