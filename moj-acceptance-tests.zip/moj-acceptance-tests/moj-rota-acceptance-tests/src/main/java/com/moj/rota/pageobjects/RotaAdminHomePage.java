package com.moj.rota.pageobjects;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.moj.common.pageobjects.MOJBasePage;
import com.moj.rota.listingpattern.pageobjects.RotaListingPatternPage;
import com.moj.rota.parameters.pageobjects.RotaParametersLocationPage;

public class RotaAdminHomePage extends MOJBasePage {

	@FindBy(id = "loggedInName")
	private WebElement loggedInName;
	
	@FindBy(id = "error-dialog-close")
	private WebElement errorDialogHeading;

	@FindBy(xpath = "//a[contains(text(),'Create District Judge')]")
	private WebElement createDistrictJudge;

	@FindBy(css = ".btn-xs.dropdown-toggle")
	private WebElement myAccounDropdown;

	@FindBy(css = ".btn.btn-info.btn-xs")
	private WebElement logoutLink;

	@FindBy(linkText = "Create Magistrate")
	private WebElement createMagistrateLink;

	@FindBy(linkText = "Magistrate Search")
	private WebElement searchMagistrateLink;

	@FindBy(xpath = "//a[contains(text(),'District Judge Search')]")
	private WebElement searchDistrictJudge;

	@FindBy(linkText = "Create Rota")
	private WebElement createRotaLink;

	@FindBy(linkText = "Rota Parameters")
	private WebElement rotaPamrameters;

	@FindBy(partialLinkText = "Messages")
	private WebElement messagesLink;

	@FindBy(partialLinkText = "Maintain Rota")
	private WebElement maintainRota;

	@FindBy(linkText = "Optimisation Status")
	private WebElement optimisationStatus;

	@FindBy(linkText = "Standard Reports")
	private WebElement reportsLink;

	public RotaAdminHomePage(WebDriver driver) {
		super(driver);
	}

	public void clickMyAccount() {
		getElement(myAccounDropdown).click();
	}

	public boolean loggedInName(String name) {
		return getElement(loggedInName).getText().contains(name);
	}

	public RotaLoginPage clickLogoutLink() {
		JavascriptExecutor jse = (JavascriptExecutor)driver;
		jse.executeScript("window.scrollBy(0,-500)", "");
		waitForElementTobeClickable(logoutLink);
		getElement(logoutLink).click();
		return getPage(RotaLoginPage.class);
	}

	public CreateDistrictJudgePage clickCreateDistrictJudge() {
		createDistrictJudge.click();
		return getPage(CreateDistrictJudgePage.class);
	}

	public DistrictJudgeSearchPage clickSearchDistrictJudge() {
		searchDistrictJudge.click();
		return getPage(DistrictJudgeSearchPage.class);
	}

	public MagistrateSearchPage clickSearchDistrictJudgeForCommon() {
		searchDistrictJudge.click();
		return getPage(MagistrateSearchPage.class);
	}

	public boolean verifyAdminHomePageisDisplayed() {
		try {
			return getElement(createDistrictJudge).isDisplayed();

		} catch (NoSuchElementException e) {
			e.printStackTrace();
			return false;
		}
	}

	public CreateMagistratePage clickOnCreateMagistrateLink() {
		getElement(createMagistrateLink).click();
		return getPage(CreateMagistratePage.class);
	}

	public MagistrateSearchPage clickOnSearchMagistrateLink() {
		getElement(searchMagistrateLink).click();
		return getPage(MagistrateSearchPage.class);
	}

	public MagistrateAdvanceSearchPage clickOnAdvanceSearch() {
		getElement(searchMagistrateLink).click();
		return getPage(MagistrateAdvanceSearchPage.class);
	}

	public MagistrateAdvanceSearchPage clickOnJudgeAdvanceSearch() {
		getElement(searchDistrictJudge).click();
		return getPage(MagistrateAdvanceSearchPage.class);
	}

	public RotaListingPatternPage clickOnCreateRota() {
		getElement(createRotaLink).click();
		return getPage(RotaListingPatternPage.class);
	}

	public MagistrateAlertMessagePage clickOnMessageLink() {
		waitForPage();
		waitForElementTobeClickable(messagesLink);
		getElement(messagesLink).click();
		return getPage(MagistrateAlertMessagePage.class);
	}

	public RotaParametersLocationPage clickOnRotaParametrs() {
		click(rotaPamrameters);
		return getPage(RotaParametersLocationPage.class);
	}

	public RotaListingPatternPage clickOnMaintainRota() {
		getElement(maintainRota).click();
		return getPage(RotaListingPatternPage.class);
	}

	public OptimisationStatusPage clickOnOptimisationStatus() {
		getElement(optimisationStatus).click();
		return getPage(OptimisationStatusPage.class);
	}

	public StandardReportsPage clickOnReports() {
		getElement(reportsLink).click();
		return getPage(StandardReportsPage.class);
	}
	
	public boolean isErrorDialog()
	{
		return isElementNotDisplayed(errorDialogHeading);
	}
	
	public RotaAdminHomePage clickCloseToErrorDialog()
	{
		click(errorDialogHeading);
		return returnPageFactory(RotaAdminHomePage.class);
	}

}
