package com.moj.rota.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.moj.common.pageobjects.MOJBasePage;

public class DistrictJudgeAdvanceSearchPage extends MOJBasePage {

	@FindBy(xpath = "//a[@href='#advanced']")
	private WebElement advanceTab;

	@FindBy(id = "ljaId")
	private WebElement localJusticeArea;

	@FindBy(id = "availableDate")
	private WebElement availableDate;

	@FindBy(id = "availableStartDate")
	private WebElement availableStartDate;

	@FindBy(id = "availableEndDate")
	private WebElement availableEndDate;

	@FindBy(id = "locationId")
	private WebElement djLocation;

	@FindBy(id = "authority")
	private WebElement authority;

	@FindBy(id = "specialistAuthority")
	private WebElement specialistAuthority;

	@FindBy(id = "bankHolidays")
	private WebElement bankHolidays;

	@FindBy(id = "sitSaturdays")
	private WebElement sitSaturdays;

	@FindBy(id = "doCrossBenchAppraisals")
	private WebElement doCrossBenchAppraisals;

	@FindBy(id = "welshSpeaking")
	private WebElement welshSpeaking;

	@FindBy(id = "search-mags-advanced-btn")
	private WebElement searchAdvancedbtn;

	@FindBy(css = "#errorDialogHeading>h3")
	private WebElement errorMessage;

	@FindBy(id = "search-results-advanced")
	private WebElement noMatchfoundMsg;

	public DistrictJudgeAdvanceSearchPage(WebDriver driver) {
		super(driver);
	}

	public void clickAdvanceTab() {
		getElement(advanceTab).click();
	}

	public void enterLocation(String location) {
		Select selLoc = new Select(getElement(djLocation));
		selLoc.selectByVisibleText(location);
	}

	public void selectPanel(String auth) {
		Select selPnl = new Select(getElement(authority));
		selPnl.selectByVisibleText(auth);
	}

	public void enterPanelStatus(String specialistAuth) {
		Select selPnlStatus = new Select(getElement(specialistAuthority));
		selPnlStatus.selectByVisibleText(specialistAuth);
	}

	public void selectBankHolidays() {
		getElement(bankHolidays).click();
	}

	public void selectSitSaturdays() {
		getElement(sitSaturdays).click();
	}

	public void selectDoCrossBenchAppraisals() {
		getElement(doCrossBenchAppraisals).click();
	}

	public void selectWelshSpeaking() {
		getElement(welshSpeaking).click();
	}

	public boolean getErrorMesssage() {
		return getElement(errorMessage).getText().contains("error");
	}

	public boolean noMatchfoundMsg() {
		return getElement(noMatchfoundMsg).getText().contains("No matches found");
	}

}
