package com.moj.rota.pageobjects;

import org.openqa.selenium.WebDriver;

import com.moj.rota.listingpattern.pageobjects.DraftRotaMagistrateListPopupPage;
import com.moj.rota.magistrate.pageobjects.MagistrateHomePage;

public class MagistrateSittingEligibiltyPage extends MagistrateSittingEligibiltyBasePage {

	private static String winHandleBefore = null;
	private static String inActivebuttonType = null;

	public MagistrateSittingEligibiltyPage(WebDriver driver) {
		super(driver);
		winHandleBefore = driver.getWindowHandle();
		//switchToNewWindow();
		if(isElementNotDisplayed(switchFrame))
		{
		switchToIFrame(switchFrame);
		}
		waitForVisibilityOfElement(pageTitle);
		waitForPage();
	}

	public boolean isSittingEligiblePageDisplayed() {
		//switchToNewWindow();
		return isWebElementDisplayed(pageTitle);
	}

	public boolean getSittingEligibilityPanels(String resultsSectionText, int index) {

		if (index == 0) {
			index = index + 0;
		} else {
			index = index + 1;
		}
		return getTextFromWebElement(allPanel.get(index)).contains(resultsSectionText);
	}

	public String getPageTitle() {
		return getTextFromWebElement(pageTitle);
	}

	public boolean getDisabledFieldStatus(String disabledField) {
		boolean fieldStatus = false;

		switch (disabledField) {
		case "date_of_appointment":
			fieldStatus = getStatusOfElement(dateOfAppointment);
			break;
		case "local_justice_area":
			fieldStatus = getStatusOfElement(currentJusticeArea);
			break;
		case "justice_area_history":
			fieldStatus = getStatusOfElement(localJusticeAreaHistory);
			break;
		case "current_bench":
			fieldStatus = getStatusOfElement(currentBenchChair);
			break;
		case "justice_area_history_from":
			fieldStatus = getStatusOfElement(ljaHistoryFrom);
			break;
		default:
		}

		return fieldStatus;
	}

	public void enteLeavingDate(String leavingDateVal) {
		waitForPage();
		waitForElementTobeClickable(leavingDate);
		enterText(leavingDate, leavingDateVal);
		waitForPage();
		click(save);
	}

	public void selectLeavingReason(String leavingReasonVal) {
		waitForVisibilityOfElement(leavingReason);
		selectDropDown(leavingReason, leavingReasonVal);
		pressEnter();
	}

	public void selectOutOfHours() {
		waitForVisibilityOfElement(outOfHours);
		click(outOfHours);
	}

	public MagistrateSearchPage clicSaveButton() {
		click(save);
		driver.switchTo().window(winHandleBefore);
		return returnPageFactory(MagistrateSearchPage.class);

	}

	public String getLeavingDate() {
		return getTextFromWebElement(leavingDate);
	}

	public String getSelectedLeavingReason() {
		waitForVisibilityOfElement(leavingReason);
		waitForPage();
		return getSelectedDropDownOption(leavingReason);
	}

	public void clickInActivity() {
		click(periodsOfAbsence);
	}

	public void clickOnButtonType(String buttonType) {
		inActivebuttonType = buttonType;
		switch (buttonType) {
		case "Add":
			click(inActiveAdd);
			break;
		case "Edit":
			click(inActiveEdit);
			break;
		case "Remove":
			click(inActiveEdit);
			click(inActiveRemove);
			break;

		}
	}

	public void enterStartDate(String startDateVal) {
		switch (inActivebuttonType) {
		case "Add":
			enterText(startDate, startDateVal);
			break;
		case "Edit":
			enterText(inActiveEditStartDate, startDateVal);
			break;
		case "Remove":
			break;
		}

	}

	public void enterEndDate(String endDateVal) {

		switch (inActivebuttonType) {
		case "Add":
			enterText(endDate, endDateVal);
			break;
		case "Edit":
			enterText(inActiveEndDate, endDateVal);
			break;
		case "Remove":
			break;
		}

	}

	public void selectAuthority(String authorityVal) {

		switch (inActivebuttonType) {
		case "Add":
			selectDropDown(authority, authorityVal);
			break;
		case "Edit":
			selectDropDown(inActiveEditAuthority, authorityVal);
			break;
		case "Remove":
			break;
		}

	}

	public void enterReason(String reasonVal) {
		switch (inActivebuttonType) {
		case "Add":
			enterText(reason, reasonVal);
			break;
		case "Edit":
			enterText(inActiveEditReason, reasonVal);
			break;
		case "Remove":
			break;
		}

	}

	public void clickConfirmButton() {
		click(confirmChanges);
	}

	public String getCurrentStatus() {
		return getTextFromWebElement(currentStatus);
	}

	public void selectNewWinger(String panelType, String newWinger, String date) {
		switch (panelType) {
		case "Adult_Panel":
			waitForElementTobeClickable(adultPanelClick);
			click(adultPanelClick);
			enterText(adultPanelDate, date);
			break;
		case "Youth_Panel":
			waitForElementTobeClickable(YouthPanelClick);
			click(YouthPanelClick);
			enterText(YouthPanelDate, date);
			break;
		case "Family_Panel":
			waitForElementTobeClickable(familyPanelClick);
			click(familyPanelClick);
			enterText(familyPanelDate, date);
			break;
		default:
		}
	}

	public void selectWinger(String panelType, String winger, String date) {
		switch (panelType) {
		case "Adult_Panel":
			waitForElementTobeClickable(selectAdultWinger);
			click(selectAdultWinger);
			enterText(adultWingerDate, getDate(1));
			break;
		case "Youth_Panel":
			waitForElementTobeClickable(selectYouthPanelWinger);
			click(selectYouthPanelWinger);
			enterText(YouthWingerDate, getDate(1));
			break;
		case "Family_Panel":
			waitForElementTobeClickable(selectfamilyPanelWinger);
			click(selectfamilyPanelWinger);
			enterText(familyhWingerDate, getDate(1));
			break;
		default:
		}
	}

	public void selectTraineeChair(String panelType, String traineeChair, String date) {
		switch (panelType) {
		case "Adult_Panel":
			waitForElementTobeClickable(selectTraineeChair);
			click(selectTraineeChair);
			enterText(TraineeChairDate, getDate(1));
			break;
		case "Youth_Panel":
			waitForElementTobeClickable(youthTraineeChair);
			click(youthTraineeChair);
			enterText(youthTraineeChairDate, getDate(1));
			break;

		default:
		}
	}

	public void selectChair(String panelType, String chair, String date) {
		switch (panelType) {
		case "Adult_Panel":
			waitForElementTobeClickable(selectAdultChair);
			click(selectAdultChair);
			enterText(adultChairDate, getDate(1));
			break;

		default:
		}
	}

	public boolean selectedRole(String panelType, String role) {
		boolean isPanelSelected = false;
		switch (panelType) {
		case "Adult_Panel":
			waitForVisibilityOfElement(adultPanelClick);
			isPanelSelected = getStatusOfCheckBox(adultPanelClick);
			break;
		case "Youth_Panel":
			waitForVisibilityOfElement(youthTraineeChair);
			isPanelSelected = getStatusOfCheckBox(youthTraineeChair);
			break;
		case "Family_Panel":
			waitForVisibilityOfElement(selectfamilyPanelWinger);
			isPanelSelected = getStatusOfCheckBox(selectfamilyPanelWinger);
			break;
		default:
		}

		return isPanelSelected;
	}

	public boolean panelCheckBoxStatus(String panelType, String role) {
		boolean isEnabled = false;
		switch (panelType) {
		case "Adult_Panel":
			waitForVisibilityOfElement(adultPanelClick);
			isEnabled = getStatusOfElement(adultPanelClick);
			break;
		case "Youth_Panel":
			waitForVisibilityOfElement(youthTraineeChair);
			isEnabled = getStatusOfElement(youthTraineeChair);
			break;
		case "Family_Panel":
			waitForVisibilityOfElement(selectfamilyPanelWinger);
			isEnabled = getStatusOfElement(selectfamilyPanelWinger);
			break;
		default:
		}

		return isEnabled;
	}

	public void selectSpecialAuthorities(String authorityName, String date) {
		switch (authorityName) {
		case "Community Justice":
			waitForElementTobeClickable(communityJustice);
			mouseHover(communityJustice);
			click(communityJustice);
			enterText(communityJustDate, getDate(2));
			break;
		case "Domestic Violence":
			waitForElementTobeClickable(domesticViolence);
			click(domesticViolence);
			enterText(domesticVioDate, getDate(2));
			break;
		case "Drug rehabilitation":
			waitForElementTobeClickable(drugRehabitation);
			click(drugRehabitation);
			enterText(drugDate, getDate(2));
			break;
		case "Education":
			waitForElementTobeClickable(education);
			click(education);
			enterText(educationdate, getDate(2));
			break;
		case "Enforcement":
			waitForElementTobeClickable(enforceMent);
			click(enforceMent);
			enterText(enforcementDate, getDate(2));
			break;
		case "Licencing":
			waitForElementTobeClickable(licencing);
			click(licencing);
			enterText(licencingDate, getDate(2));
			break;
		case "Problem Solving":
			waitForElementTobeClickable(probelSolving);
			click(probelSolving);
			enterText(problemSolvingDate, getDate(2));
			break;
		case "Regulatory Cases":
			waitForElementTobeClickable(regulatoryCases);
			click(regulatoryCases);
			enterText(regulatoryCasesDate, getDate(2));
			break;
		case "Appriaser":
			waitForElementTobeClickable(selectAppraiser);
			click(selectAppraiser);
			enterText(appraiserDate, getDate(2));
			break;
		case "Mentor":
			waitForElementTobeClickable(selectMentor);
			click(selectMentor);
			enterText(mentorDate, getDate(2));
			break;
		case "Crown court":
			waitForElementTobeClickable(selectCrownCourt);
			click(selectCrownCourt);
			enterText(crownCourtDate, getDate(2));
			break;

		default:

		}

	}

	public boolean getSelectedAuthoritiesStatus(String authorityName) {
		boolean isSelected = false;
		switch (authorityName) {
		case "Community Justice":
			waitForVisibilityOfElement(communityJustice);
			isSelected = getStatusOfCheckBox(communityJustice);

			break;
		case "Domestic Violence":
			waitForVisibilityOfElement(domesticViolence);
			isSelected = getStatusOfCheckBox(domesticViolence);
			break;
		case "Drug rehabilitation":
			waitForVisibilityOfElement(communityJustice);
			isSelected = getStatusOfCheckBox(drugRehabitation);
			break;
		case "Education":
			waitForVisibilityOfElement(education);
			isSelected = getStatusOfCheckBox(education);
			break;
		case "Enforcement":
			waitForVisibilityOfElement(enforceMent);
			isSelected = getStatusOfCheckBox(enforceMent);
			break;
		case "Licencing":
			waitForVisibilityOfElement(licencing);
			isSelected = getStatusOfCheckBox(licencing);
			break;
		case "Problem Solving":
			waitForVisibilityOfElement(probelSolving);
			isSelected = getStatusOfCheckBox(probelSolving);
			break;
		case "Regulatory Cases":
			waitForVisibilityOfElement(regulatoryCases);
			isSelected = getStatusOfCheckBox(regulatoryCases);
			break;
		case "Appriaser":
			waitForVisibilityOfElement(selectAppraiser);
			isSelected = getStatusOfCheckBox(selectAppraiser);
			break;
		case "Mentor":
			waitForVisibilityOfElement(selectMentor);
			isSelected = getStatusOfCheckBox(selectMentor);
			break;
		case "Crown court":
			waitForVisibilityOfElement(selectCrownCourt);
			isSelected = getStatusOfCheckBox(selectCrownCourt);
			break;

		default:

		}

		return isSelected;

	}

	public void clickTransferMgistrate() {
		waitForVisibilityOfElement(ljaTransfer);
		click(ljaTransfer);
	}

	public void selectNewLJA(String newLJA) {
		waitForVisibilityOfElement(newlja);
		selectDropDown(newlja, newLJA);
	}

	public void newLJAEffectiveDate(String newLjaEffectiveDateVal) {
		waitForVisibilityOfElement(newLjaEffectiveDate);
		enterText(newLjaEffectiveDate, newLjaEffectiveDateVal);
	}

	public String getNewLJA() {
		return getSelectedDropDownOption(newlja);
	}

	public String getNewLJAEffectiveDate() {
		return getTextFromWebElement(newLjaEffectiveDate);
	}

	public boolean isCancelButtonDisplayed() {
		return isElementDisplayed(removeLJATransfer);
	}

	public void clickOnTransferRemoveButton() {
		click(removeLJATransfer);
	}

	// Magistrate related

	public String getMagLeavingDate() {
		return getReadOnlyTextData(leavingDate);
	}

	public String getMagCurrentJusticeArea() {
		return getReadOnlyTextData(magistrateLJA);
	}

	public boolean getSelectedEligibilityFields(String fieldName) {
		boolean isSelected = false;
		switch (fieldName) {
		case "Date Of Appointment":
			isSelected = getReadOnlyTextData(dateOfAppointment).length() > 0;

			break;
		case "Leaving date":
			isSelected = getReadOnlyTextData(leavingDate).length() > 0;
			break;
		case "Active":
			isSelected = getTextFromWebElement(currentStatus).contains(fieldName);
			break;
		case "LJA history":
			isSelected = getReadOnlyTextData(ljaHistoryFrom).length() > 0;
			break;
		case "Transfer button":
			isSelected = isElementDisplayed(ljaTransfer);
			break;
		case "Out of hour duties":
			isSelected = isElementDisplayed(outOfHours);
			break;

		default:

		}

		return isSelected;

	}

	public MagistrateHomePage clickOnMagClose() {
		click(magistrateCloseButton);
		return returnPageFactory(MagistrateHomePage.class);
	}

	// DJ related

	public boolean getDJSittingEligibilityPanels(String resultsSectionText, int index) {

		return getTextFromWebElement(allPanel.get(index)).contains(resultsSectionText);
	}

	public boolean getDJFieldStatus(String DJFields) {
		boolean fieldStatus = false;

		switch (DJFields) {
		case "date_of_appointment":
			fieldStatus = isElementDisplayed(djDateOfAppointment);
			break;
		case "leaving_date":
			fieldStatus = isElementDisplayed(leavingDate);
			break;
		case "Adult Panel":
			fieldStatus = isElementDisplayed(djAdultPanel);
			break;
		case "Youth Panel":
			fieldStatus = isElementDisplayed(djYouthPanel);
			break;
		case "Family Panel":
			fieldStatus = isElementDisplayed(djFamilyPanel);
			break;
		case "Extradition":
			fieldStatus = isElementDisplayed(djExtradition);
			break;
		case "Terrorism":
			fieldStatus = isElementDisplayed(djTerrorism);
			break;
		case "Serious Sexual Offences":
			fieldStatus = isElementDisplayed(djsexualOffences);
			break;
		case "Recorder and Independent Adjudicator":
			fieldStatus = isElementDisplayed(djIndependentAdjuctor);
			break;
		case "Peiod of Absence":
			fieldStatus = isElementDisplayed(periodsOfAbsence);
			break;

		default:
		}

		return fieldStatus;
	}

	public String getDJCurrentStatus() {
		return getTextFromWebElement(djCurrentStatus);
	}

	public void selectDJSpecialAuthorities(String authorityName) {
		switch (authorityName) {
		case "Adult Panel":
			click(djAdultPanel);
			enterText(djAdultPanelDate, getDate(2));
			break;
		case "Youth Panel":
			click(djYouthPanel);
			enterText(djYouthPanelDate, getDate(2));
			break;
		case "Family Panel":
			click(djFamilyPanel);
			enterText(djFamilyPanelDate, getDate(2));
			break;
		case "Extradition":
			click(djExtradition);
			enterText(djExtraditionDate, getDate(2));
			break;
		case "Terrorism":
			click(djTerrorism);
			enterText(djTerrorismDate, getDate(2));
			break;
		case "Serious Sexual Offences":
			click(djsexualOffences);
			enterText(djsexualOffencesDate, getDate(2));
			break;
		case "Recorder":
			click(djrecorder);
			enterText(djrecorderDate, getDate(2));
			break;
		case "Independent Adjudicator":
			click(djIndependentAdjuctor);
			enterText(djIndependentAdjuctorDate, getDate(2));
			break;
		default:

		}

	}

	public boolean getDJSelectedAuthoAndSpecialAuthorities(String authorityName) {
		boolean isCheckBoxSelected = false;
		switch (authorityName) {
		case "Adult Panel":
			isCheckBoxSelected = getStatusOfCheckBox(djAdultPanel);
			break;
		case "Youth Panel":
			isCheckBoxSelected = getStatusOfCheckBox(djYouthPanel);
			break;
		case "Family Panel":
			isCheckBoxSelected = getStatusOfCheckBox(djFamilyPanel);
			break;
		case "Extradition":
			isCheckBoxSelected = getStatusOfCheckBox(djExtradition);
			break;
		case "Terrorism":
			isCheckBoxSelected = getStatusOfCheckBox(djTerrorism);
			break;
		case "Serious Sexual Offences":
			isCheckBoxSelected = getStatusOfCheckBox(djsexualOffences);
			break;
		case "Recorder":
			isCheckBoxSelected = getStatusOfCheckBox(djrecorder);
			break;
		case "Independent Adjudicator":
			isCheckBoxSelected = getStatusOfCheckBox(djIndependentAdjuctor);
			break;
		default:

		}
		return isCheckBoxSelected;

	}

	public void identifyNewWingerInAdultPanel(String date) {
		if (getStatusOfCheckBox(selectAdultChair)) {
			waitForPage();
			click(selectAdultChair);
			waitForPageToLoad();
			click(confirmPopUp);
			waitForPageToLoad();
		}

		if (getStatusOfCheckBox(selectTraineeChair)) {
			click(selectTraineeChair);
			waitForPageToLoad();
			click(confirmPopUp);
			waitForPageToLoad();
		}

		if (getStatusOfCheckBox(selectAdultWinger)) {
			click(selectAdultWinger);
			waitForPageToLoad();
			click(confirmPopUp);
			waitForPageToLoad();
		}

		if (getStatusOfCheckBox(adultPanelClick)) {
			click(adultPanelClick);
			enterText(adultPanelDate, date);
		}
	}

	public void identifyTraineeChairFamilyPanel(String date) {
		if (getStatusOfCheckBox(familyChair) == true) {
			click(familyChair);
			waitForPageToLoad();
			click(confirmPopUp);
			waitForPageToLoad();
		}

		if (getStatusOfCheckBox(familyTraineeChair) == false) {
			click(familyTraineeChair);
		}

	}

	public DraftRotaMagistrateListPopupPage clickOnDraftRotaSaveButton() {
		click(save);
		driver.switchTo().window(winHandleBefore);
		return returnPageFactory(DraftRotaMagistrateListPopupPage.class);

	}

	public boolean isDateOfAppointmentEditable() {
		return getStatusOfElement(dateOfAppointment);
	}

	public boolean isBenchChairAppointsmentDisplayed() {
		return isElementDisplayed(benchChairTitle);
	}

	public String getLJALocationForBenchChair() {
		return getTextFromWebElement(benchChairLocation);
	}

	public String getAppDateForBenchChair() {
		return getReadOnlyTextData(benchChairAppDate);
	}
}
