package com.moj.rota.pageobjects;

import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.moj.common.pageobjects.MOJBasePage;

public class MagistrateSittingLocationsPage extends MOJBasePage {

	public MagistrateSittingLocationsPage(WebDriver driver) {
		super(driver);
		winHandleBefore = driver.getWindowHandle();
		//switchToNewWindow();
		if(isElementNotDisplayed(switchFrame))
		{
		switchToIFrame(switchFrame);
		}
	}

	private static String winHandleBefore = null;

	@FindBy(css = ".container>h1")
	private WebElement pageTitle;

	@FindBy(css = "#location-details > div.panel-heading > h3")
	private WebElement boxTitle;

	@FindBy(css = "#content > div > div.panel.panel-default h3")
	private WebElement homeCourt;

	@FindBy(css = "#family-panel h3")
	private WebElement familyPanel;

	@FindBy(css = "#youth-panel h3")
	private WebElement youthPanel;

	@FindBy(css = "#adult-panel h3")
	private WebElement adultPanel;

	@FindBy(css = "#crownCourt-panel h3")
	private WebElement crownCourtPanel;

	@FindBy(css = "div#adhoc-locations-content div.panel.panel-default div.panel-heading h3.panel-title")
	private WebElement adhocLocationPanel;

	@FindBy(id = "homeCourtLocationId")
	private WebElement homeCourtLocation;

	@FindBy(id = "homeCourtPercentage")
	private WebElement homeCourtPercentage;

	@FindBy(css = "input[id*='primary-location-adult']")
	private List<WebElement> adultPrimaryLocation;

	@FindBy(css = "input[id*='primary-location-youth-']")
	private List<WebElement> youthLocation;

	@FindBy(css = "input[id*='primary-location-family-']")
	private WebElement familyLocation;

	@FindBy(css = "input[id*='primary-location-crownCourt-']")
	private WebElement crownCourtLocation;

	@FindBy(css = "#locationSearch")
	private WebElement adhocLocation;

	@FindBy(id = "ad-hoc-location-add-btn")
	private WebElement adhocAddButton;

	@FindBy(id = "finish-btn")
	private WebElement saveButton;

	// error validations
	@FindBy(id = "homeCourtPercentageError")
	private WebElement percentageError;

	@FindBy(id = "adultPanelError")
	private WebElement adultPanelError;

	@FindBy(id = "youthPanelError")
	private WebElement youthPanelError;

	@FindBy(id = "familyPanelError")
	private WebElement familyPanelError;

	@FindBy(id = "crownCourtPanelError")
	private WebElement crownCourtPanelError;

	@FindBy(css = ".label.label-default.hand-hover")
	private WebElement adhocLocationLabel;

	@FindBy(css = "#adHocLocationErrorLabel")
	private WebElement adhocLocationLabelError;

	@FindBy(css = "span[id*='ad-hoc-location-remove-']")
	private WebElement deleteAdhoc;

	// Magistrate

	@FindBy(css = "span[id*='primary-location-badge-adult-']")
	private List<WebElement> magAdultPrimaryLocation;

	@FindBy(css = "span[id*='primary-location-badge-youth-']")
	private List<WebElement> magYouthLocation;

	@FindBy(css = "span[id*='primary-location-badge-family-']")
	private List<WebElement> MajFamilyLocation;

	@FindBy(css = "span[id*='primary-location-badge-crownCourt-']")
	private List<WebElement> majCrownCourtLocation;

	// DJ Related
	@FindBy(css = "#wrap > div > div.panel.panel-default > div.panel-heading > h3")
	private WebElement djBoxTitle;

	@FindBy(id = "locationError")
	private WebElement djErroLocation;

	@FindBy(css = "#location-remove-1:nth-child(2)")
	private WebElement deleteLocation;

	@FindBy(id = "ljaSearch")
	private WebElement ljaSearch;

	@FindBy(id = "locationSearch")
	private WebElement djLocation;

	@FindBy(id = "location-add-btn")
	private WebElement addLocationButton;

	@FindBy(css = "#location-remove-2:nth-child(2)")
	private WebElement deleteDJLocation;

	@FindBy(css = "input[id*='checkbox-sitting-pattern']")
	private List<WebElement> selectDays;

	public boolean isPageFieldsDisplayed(String pageFields) {
		boolean isElemtDisplayed = false;
		switch (pageFields) {
		case "Home Court":
			isElemtDisplayed = getTextFromWebElement(homeCourt).contains(pageFields);
			break;
		case "Family Panel":
			isElemtDisplayed = getTextFromWebElement(familyPanel).contains(pageFields);
			break;
		case "Youth Panel":
			isElemtDisplayed = getTextFromWebElement(youthPanel).contains(pageFields);
			break;
		case "Adult Panel":
			isElemtDisplayed = getTextFromWebElement(adultPanel).contains(pageFields);
			break;
		case "Crown Court Panel":
			isElemtDisplayed = getTextFromWebElement(crownCourtPanel).contains(pageFields);
			break;
		case "Ad-hoc Locations":
			isElemtDisplayed = getTextFromWebElement(adhocLocationPanel).contains(pageFields);
			break;

		default:
			System.out.println("Not elements displyed");

		}

		return isElemtDisplayed;
	}

	public void selectHomeCourtLocation(String homeCourtLocationVal) {
		selectDropDown(homeCourtLocation, homeCourtLocationVal);
	}

	public void selectHomeCourtPercentage(String percentage) {
		selectDropDown(homeCourtPercentage, percentage);
	}

	public void checkOrUncheckLocation(String location) {
		switch (location) {
		case "Adult_uncheck":
			if (adultPrimaryLocation.size() > 1) {
				click(adultPrimaryLocation.get(0));
				waitForPage();
				click(adultPrimaryLocation.get(1));
			} else {
				click(adultPrimaryLocation.get(0));
			}

			break;
		case "Youth_uncheck":
			if (youthLocation.size() > 1) {
				click(youthLocation.get(0));
				waitForPage();
				click(youthLocation.get(1));
			} else {
				click(youthLocation.get(0));
			}
			break;
		case "Family_uncheck":
			click(familyLocation);
			break;
		case "CrownCourt_uncheck":
			click(crownCourtLocation);
			break;
		default:

		}
	}

	public void enterAdHocLocation(String location) {
		// click(adhocLocation);
		enterText(adhocLocation, location);
		enterText(adhocLocation, Keys.ARROW_DOWN.toString());
		enterText(adhocLocation, Keys.ENTER.toString());
		clickAddButton();
	}

	public void clickAddButton() {
		click(adhocAddButton);
	}

	public void deleteAdhoc() {
		click(deleteAdhoc);
	}

	public MagistrateSearchPage clickSaveButton() {
		click(saveButton);
		driver.switchTo().window(winHandleBefore);
		return returnPageFactory(MagistrateSearchPage.class);
	}

	public MagistrateSittingLocationsPage clickErrorSaveButton() {
		click(saveButton);
		return returnPageFactory(MagistrateSittingLocationsPage.class);
	}

	public boolean isSittingLocationPageDisplayed() {
		//switchToNewWindow();
		return isWebElementDisplayed(pageTitle);
	}

	public String getPageBoxTitle() {
		waitForVisibilityOfElement(boxTitle);
		waitForPage();
		return getTextFromWebElement(boxTitle);
	}

	public String getAdhocLocationLable() {
		return getTextFromWebElement(adhocLocationLabel);
	}

	public String getPageTitle() {
		return getTextFromWebElement(pageTitle);
	}

	public String getAdhocLocationErrorLable() {
		return getTextFromWebElement(adhocLocationLabelError);
	}

	public void enterValidData(String location, String percentage, String locationUnclick) {
		// Home court location
		selectHomeCourtLocation(location);
		if (percentage != null && !percentage.equals("")) {
			selectHomeCourtPercentage(percentage);
		} else {
			selectHomeCourtPercentage("Select...");
		}

		if (locationUnclick != null && !locationUnclick.equals("")) {
			checkOrUncheckLocation(locationUnclick);
		}

	}

	public String getErrorMessage(String errorType) {
		String error_message = null;
		switch (errorType) {
		case "Adult_uncheck":
			error_message = getTextFromWebElement(adultPanelError);
			break;
		case "Youth_uncheck":
			error_message = getTextFromWebElement(youthPanelError);
			break;
		case "Family_uncheck":
			error_message = getTextFromWebElement(familyPanelError);
			break;
		case "CrownCourt_uncheck":
			error_message = getTextFromWebElement(crownCourtPanelError);
			break;
		case "percentage_blank":
			error_message = getTextFromWebElement(percentageError);
			break;
		default:

		}

		return error_message;

	}

	public String getSelectedHomeCourtLocation() {
		return getSelectedDropDownOption(homeCourtLocation);
	}

	public String getSelectedHomeCourtPercentage() {
		return getSelectedDropDownOption(homeCourtPercentage);
	}

	public String getSelectedPanels(String panelType) {
		String selectedPanel = null;
		switch (panelType) {
		case "Adulat panel":
			waitForVisibilityOfElement(magAdultPrimaryLocation.get(0));
			selectedPanel = getTextFromWebElement(magAdultPrimaryLocation.get(0));
			break;
		case "Youth panel":
			waitForVisibilityOfElement(magYouthLocation.get(0));
			selectedPanel = getTextFromWebElement(magYouthLocation.get(0));
			break;
		case "Family panel":
			waitForVisibilityOfElement(MajFamilyLocation.get(0));
			selectedPanel = getTextFromWebElement(MajFamilyLocation.get(0));
			break;
		case "Crown court panel":
			waitForVisibilityOfElement(majCrownCourtLocation.get(0));
			selectedPanel = getTextFromWebElement(majCrownCourtLocation.get(0));
			break;

		default:

		}

		return selectedPanel;

	}

	// DJ related

	public String getDJPageBoxTitle() {
		waitForVisibilityOfElement(djBoxTitle);
		return getTextFromWebElement(djBoxTitle);
	}

	public String getDJErrorDetails() {
		return getTextFromWebElement(djErroLocation);
	}

	public void clickOnDelete() {
		click(deleteLocation);
	}

	public void clickOnDJDelete() {
		click(deleteDJLocation);
	}

	public void addLJALocation(String location) {
		enterText(ljaSearch, location);
		enterTextWithClick(ljaSearch, Keys.ARROW_DOWN.toString());
		enterTextWithClick(ljaSearch, Keys.TAB.toString());
		waitForPage();
		enterTextWithClick(ljaSearch, Keys.ENTER.toString());
		waitForPage();

	}

	public void selectLocation(String location) {
		selectDropDown(djLocation, location);
		click(addLocationButton);
		waitForPageToLoad();
	}

	public void selectDays() {
		for (WebElement element : selectDays) {
			click(element);
		}
	}

	public boolean isHomeCourtLocationEditable() {
		return getStatusOfElement(homeCourtLocation);
	}

}
