
package com.moj.rota.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.moj.common.pageobjects.MOJBasePage;

public class ErrorCreatingMagistratePage extends MOJBasePage {

	@FindBy(css = "#errorDialogHeading>h3")
	private WebElement errorDialogHeading;
	
	@FindBy(id = "error-dialog-close")
	private WebElement closeErrorDialog;

	public ErrorCreatingMagistratePage(WebDriver driver) {
		super(driver);
	}

	public boolean errorHeading() {
		return getElement(errorDialogHeading).getText().contains("error");
	}
	
	public RotaAdminHomePage closeErrorDialog()
	{
		click(closeErrorDialog);
		return returnPageFactory(RotaAdminHomePage.class);
	}

}
