package com.moj.rota.parameters.pageobjects;

import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.moj.common.pageobjects.MOJBasePage;

public class BenchChairPage extends MOJBasePage {

	public BenchChairPage(WebDriver driver) {
		super(driver);
	}
	
	@FindBy(id = "benchChairsTab")
	private WebElement benchChairTab;
		
	@FindBy(css = "div[id*='bench-chair-panel-'] > div > h3 > a > strong")
	private List<WebElement> ljaNorth;
	
	@FindBy(css = "div[id*='bench-chair-panel-'] > div > h3 > a > strong")
	private List<WebElement> ljaSouth;
	
	@FindBy(css = "input[id*='benchChairSearch-']")
	private WebElement magName;
	
	@FindBy(css = "input[id*='benchChairAddDate-']")
	private WebElement magDate;
	
	@FindBy(id = "benchChair-add-btn")
	private WebElement allocateButton;
	
	@FindBy(css = "span[id*='allocatedBenchChair-']")
	private WebElement addedMagName;
	
	@FindBy(id = "deleteBenchChair")
	private WebElement deleteBenchChair;
	
	@FindBy(css = ".col-xs-12.col-sm-3.col-md-2.col-lg-2.text-align-with-label.text-muted")
	private WebElement benchChairTba;
	
	public boolean isBenchChairTabDisplayed()
	{
		return isElementDisplayed(benchChairTab);
	}
	
	public String getLocationsTitle(String location)
	{
		String locationTitle=null;
		waitForPage();
		switch(location)
		{
		case "Local Justice Area 5 North":
			//waitForVisibilityOfElement(ljaNorth.get(0));
			for(WebElement element:ljaNorth)
			{   
				locationTitle=getTextFromWebElement(element);
				if(locationTitle.equals(location))
				{
					break;	
				}
			}
			
			break;
		case "Local Justice Area 5 South":
			/*waitForVisibilityOfElement(ljaSouth.get(1));
			locationTitle=getTextFromWebElement(ljaSouth.get(1));*/
			for(WebElement southElement:ljaSouth)
			{   
				locationTitle=getTextFromWebElement(southElement);
				if(locationTitle.equals(location))
				{
					break;	
				}
			}
			break;
		}
		return locationTitle;
	}
	
	public void clickLJALocation(String location)
	{
		switch(location)
		{
		case "Local Justice Area 5 North":
			/*waitForElementTobeClickable(ljaNorth.get(0));
			click(ljaNorth.get(0));*/
			for(WebElement element:ljaNorth)
			{   
				if(getTextFromWebElement(element).equals(location))
				{
					click(element);	
				}
			}
			
			break;
		case "Local Justice Area 5 South":
			/*waitForElementTobeClickable(ljaSouth.get(1));
			click(ljaSouth.get(1));*/
			for(WebElement southElement:ljaSouth)
			{   
				if(getTextFromWebElement(southElement).equals(location))
				{
					click(southElement);	
				}
			}
			break;
		
		}
		
	}
		
	public void enterMagistrateData(String MagNameVal)
	{
		enterText(magDate, getDate(1));
		enterText(magName, MagNameVal);
		enterText(magName, Keys.ARROW_DOWN.toString());
		enterText(magName, Keys.ENTER.toString());
		waitForPageToLoad();
		
	}
	
	public void clickAllocateButton()
	{
		waitForElementTobeClickable(allocateButton);
		click(allocateButton);
	}
	
	public void clickonRemoveButton()
	{
		waitForElementTobeClickable(deleteBenchChair);
		click(deleteBenchChair);
	}
	
	public String getMagName()
	{
		waitForPage();
		return getTextFromWebElement(addedMagName);
	}
	
	public String getBechChairTBA()
	{
		waitForPage();
		return getTextFromWebElement(benchChairTba);
	}
}
