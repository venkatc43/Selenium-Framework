
package com.moj.rota.pageobjects;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.moj.common.pageobjects.MOJBasePage;

public class RotaLoginPage extends MOJBasePage {

	@FindBy(id = "username")
	private WebElement uname;

	@FindBy(id = "password")
	private WebElement pass;

	@FindBy(css = ".btn.btn-success.btn-wide-1")
	private WebElement loginBtn;

	@FindBy(className = "error")
	private WebElement errorMsg;
	
	@FindBy(id = "IDToken1")
	private WebElement sitUname;

	@FindBy(id = "IDToken2")
	private WebElement sitPass;

	@FindBy(css = ".button.primary")
	private WebElement sitLoginBtn;

	public RotaLoginPage(WebDriver driver) {
		super(driver);
	}

	public void enterUsername(String username) {
		getElement(uname).sendKeys(username);
	}

	public void enterPassword(String password) {
		getElement(pass).sendKeys(password);
	}

	public RotaAdminHomePage clickLoginButton() {
		getElement(loginBtn).click();
		return getPage(RotaAdminHomePage.class);
	}
	
	/*public RotaAdminHomePage sitLogin(List<String> loginCredentials) {
		enterText(sitUname, loginCredentials.get(0));
		enterText(sitPass, loginCredentials.get(1));
		click(sitLoginBtn);
		return getPage(RotaAdminHomePage.class);
	}*/
	
	public RotaAdminHomePage sitLogin(String userName,String password) {
		enterText(sitUname, userName);
		enterText(sitPass, password);
		click(sitLoginBtn);
		return getPage(RotaAdminHomePage.class);
	}

	public boolean errorMessage() {
		getElement(loginBtn).click();
		return getElement(errorMsg).getText().contains("Invalid");
	}

	public boolean isUserLogedIn(RotaAdminHomePage onRotaAdminHomePage, String userName) {
		return onRotaAdminHomePage.loggedInName(userName);
	}

	public RotaLoginPage navigateToSite(String website) {
		driver.get(website);
		return getPage(RotaLoginPage.class);
	}
	
	public RotaAdminHomePage navigateToSiteWithouLogin(String website) {
		driver.get(website);
		return getPage(RotaAdminHomePage.class);
	}
	
	public void switchToSecondScreen(){
	   driver.findElement(By.cssSelector("#breadcrumb1 > ol > li:nth-child(1) > a")).sendKeys(Keys.CONTROL +"t");
	   List<String> tabs = new ArrayList<String> (driver.getWindowHandles());
	   driver.switchTo().window(tabs.get(1));
	}
	
}
