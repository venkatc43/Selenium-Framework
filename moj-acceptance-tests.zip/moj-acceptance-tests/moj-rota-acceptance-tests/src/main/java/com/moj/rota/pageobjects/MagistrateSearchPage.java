package com.moj.rota.pageobjects;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.moj.common.pageobjects.MOJBasePage;

public class MagistrateSearchPage extends MOJBasePage {

	private final String VALID_FIRST_NAME = "test";

	@FindBy(id = "firstName")
	private WebElement fname;

	@FindBy(id = "lastName")
	private WebElement lname;

	@FindBy(id = "jeanNumber")
	private WebElement jeanNumber;

	@FindBy(id = "search-mags-btn")
	private WebElement searchBtn;

	@FindBy(id = "error-dialog-close")
	private WebElement errorDialogClose;

	@FindBy(css = "#searchResultsError>label")
	private WebElement searchResultsError;

	@FindBy(id = "search-results")
	private WebElement searchResult;

	@FindBy(id = "search-results-advanced")
	private WebElement searchResultAdvanced;

	@FindBy(id = "firstNameError")
	private WebElement firstNameError;

	@FindBy(id = "lastNameError")
	private WebElement lastNameError;

	@FindBy(id = "jeanNumberError")
	private WebElement jeanNumberError;

	@FindBy(css = ".col-xs-12.col-sm-12.col-md-12.col-lg-12")
	private WebElement searchResultMsg;

	@FindBy(css = "#result > div:nth-child(2) > a")
	private WebElement sittingLocation;

	@FindBy(css = ".col-xs-12.col-sm-3.col-md-12.col-lg-12")
	private WebElement searchResultName;

	@FindBy(css = ".label.label-primary")
	private List<WebElement> searchResultSection;

	@FindBy(css = "#result > div:nth-child(3) > a > span")
	private WebElement sittingEligibility;

	@FindBy(css = "#result > div.col-xs-12.col-sm-2.col-md-2.col-lg-2 > a > span")
	private WebElement personalDetails;

	@FindBy(css = "#result > div:nth-child(5) > a > span")
	private WebElement nonAvailability;

	@FindBy(css = "#result > div:nth-child(6) > a > span")
	private WebElement sittingPreferences;

	@FindBy(css = "#result > div:nth-child(7) > a > span")
	private WebElement sittings;
	
	@FindBy(css = ".breadcrumb>li>a")
	private WebElement homePage;

	public MagistrateSearchPage(WebDriver driver) {
		super(driver);
	}

	public MagistrateSearchPage enterFirstName(String firstName) {
		getElement(fname).sendKeys(firstName);
		return getPage(MagistrateSearchPage.class);
	}

	public MagistrateSearchPage enterLastName(String lastName) {
		getElement(lname).sendKeys(lastName);
		return getPage(MagistrateSearchPage.class);
	}

	public MagistrateSearchPage enterJeanNumber(String jNumber) {
		getElement(jeanNumber).sendKeys(jNumber);
		return getPage(MagistrateSearchPage.class);
	}

	public MagistrateSearchPage clickSearchButton() {
		getElement(searchBtn).click();
		waitForPage();
		return getPage(MagistrateSearchPage.class);
	}

	// when no data entered
	public String getErrorMsgWithNoData() {
		return getElement(searchResultsError).getText();
	}

	public MagistrateSearchPage enterValidData() {
		enterFirstName(VALID_FIRST_NAME);
		clickSearchButton();
		return getPage(MagistrateSearchPage.class);
	}

	public MagistrateSearchPage enterSearchData(String firstName, String lastName) {
		enterFirstName(firstName);
		enterLastName(lastName);
		clickSearchButton();
		return getPage(MagistrateSearchPage.class);
	}

	public MagistrateSearchPage enterSearchData(String firstName, String lastName, String jeanNumber) {
		if (firstName != null && !firstName.equals("")) {
			enterFirstName(firstName);
		}

		if (lastName != null && !lastName.equals("")) {
			enterLastName(lastName);
		}

		if (jeanNumber != null && !jeanNumber.equals("")) {
			enterJeanNumber(jeanNumber);
		}

		clickSearchButton();
		return getPage(MagistrateSearchPage.class);
	}

	public boolean MagistratesFoundMsg() {
		waitForVisibilityOfElement(searchResultMsg);
		return getElement(searchResultMsg).getText().contains("Magistrates found");
	}

	public boolean inValidJeanNumber() {
		return getElement(jeanNumberError).getText().contains("Please enter a valid jean number");
	}

	public String noResultFoundMsg() {
		return getElement(searchResult).getText();
	}

	public MagistrateSittingLocationsPage clickSittingLocation() {
		click(sittingLocation);
		waitForPage();
		return returnPageFactory(MagistrateSittingLocationsPage.class);
	}

	public boolean isMagistrateSearchPage() {
		return isWebElementDisplayed(sittingLocation);

	}

	public boolean getSearchResultsName(String name) {
		return getTextFromWebElement(searchResultName).contains(name);
	}

	public boolean getSearchResultsSection(String resultsSectionText, int index) {
		return getTextFromWebElement(searchResultSection.get(index)).contains(resultsSectionText);
	}

	public MagistrateSittingEligibiltyPage clickSittingEligibility() {
		waitForPage();
		click(sittingEligibility);
		waitForPage();
		return returnPageFactory(MagistrateSittingEligibiltyPage.class);
	}

	public MagistratePersonalDetailsPage clickPersonalDetails() {
		waitForPage();
		click(personalDetails);
		waitForPage();
		return returnPageFactory(MagistratePersonalDetailsPage.class);
	}

	public MagistrateNonAvailabilityPage clickNonAvailability() {
		waitForPage();
		click(nonAvailability);
		waitForPage();
		return returnPageFactory(MagistrateNonAvailabilityPage.class);
	}

	public MagistrateSittingPrefecencesPage clickOnSittingPreferences() {
		waitForPage();
		click(sittingPreferences);
		waitForPage();
		return returnPageFactory(MagistrateSittingPrefecencesPage.class);
	}

	public MagistrateSittingsPage clickOnSittings() {
		waitForPage();
		click(sittings);
		waitForPage();
		return returnPageFactory(MagistrateSittingsPage.class);
	}
	
	public RotaAdminHomePage clickHomePage()
	{
	 List<String> tabs = new ArrayList<String> (driver.getWindowHandles());
	 driver.switchTo().window(tabs.get(0));
	 waitForPage();
	 click(homePage);
	 return getPage(RotaAdminHomePage.class);
	}

}
