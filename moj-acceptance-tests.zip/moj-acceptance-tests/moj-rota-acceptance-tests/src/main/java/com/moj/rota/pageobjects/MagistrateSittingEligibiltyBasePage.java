package com.moj.rota.pageobjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.moj.common.pageobjects.MOJBasePage;

public class MagistrateSittingEligibiltyBasePage extends MOJBasePage {

	public MagistrateSittingEligibiltyBasePage(WebDriver driver) {
		super(driver);
	}

	@FindBy(css = "#content>div>h1")
	public WebElement pageTitle;

	@FindBy(css = "#sitting-eligibility > div.panel-heading")
	public WebElement boxTitle;

	@FindBy(id = "noviceAppointmentDate")
	public WebElement dateOfAppointment;

	@FindBy(id = "leavingDate")
	public WebElement leavingDate;

	@FindBy(id = "leavingReason")
	public WebElement leavingReason;

	@FindBy(id = "openInactivityModal")
	public WebElement periodsOfAbsence;

	@FindBy(id = "myModalLabel2")
	public WebElement summaryOfInactivePeriods;

	@FindBy(id = "btn-add-inactivity")
	public WebElement inActiveAdd;

	@FindBy(css = ".col-xs-2.col-sm-1.col-md-1.col-lg-1 .btn.btn-primary")
	public WebElement inActiveEdit;

	@FindBy(css = ".col-xs-3.col-sm-2.col-md-2.col-lg-2 .form-control.mandatory.hasDatepicker")
	public WebElement inActiveEditStartDate;

	@FindBy(css = ".col-xs-2.col-sm-2.col-md-2.col-lg-2 .form-control.hasDatepicker")
	public WebElement inActiveEndDate;

	@FindBy(css = ".col-xs-2.col-sm-2.col-md-2.col-lg-2 .form-control.mandatory")
	public WebElement inActiveEditAuthority;

	@FindBy(css = ".col-xs-2.col-sm-3.col-md-3.col-lg-3 .form-control.mandatory")
	public WebElement inActiveEditReason;

	@FindBy(id = "remove-inactivity-btn")
	public WebElement inActiveRemove;

	@FindBy(id = "addInactiveStartDate")
	public WebElement startDate;

	@FindBy(id = "addInactiveEndDate")
	public WebElement endDate;

	@FindBy(id = "addInactiveAuthority")
	public WebElement authority;

	@FindBy(id = "addInactiveReason")
	public WebElement reason;

	@FindBy(id = "clear-add-inactivity-row")
	public WebElement clear;

	@FindBy(id = "btn-confirm-changes")
	public WebElement confirmChanges;

	@FindBy(id = "magistrateStatus")
	public WebElement currentStatus;

	@FindBy(id = "currentLjaName")
	public WebElement currentJusticeArea;

	@FindBy(id = "lja-transfer-btn")
	public WebElement ljaTransfer;

	@FindBy(id = "transferLjaId")
	public WebElement newlja;

	@FindBy(id = "transferLjaEffectiveDate")
	public WebElement newLjaEffectiveDate;

	@FindBy(id = "removeLjaTransferButton")
	public WebElement removeLJATransfer;

	@FindBy(css = "#ljaAssignmentHistory .col-xs-12.col-sm-4.col-md-4.col-lg-4 > input")
	public WebElement localJusticeAreaHistory;

	@FindBy(css = "#ljaAssignmentHistory .col-xs-8.col-sm-3.col-md-3.col-lg-3 > input")
	public WebElement ljaHistoryFrom;

	@FindBy(id = "benchChair")
	public WebElement currentBenchChair;

	@FindBy(id = "outOfHours")
	public WebElement outOfHours;

	@FindBy(id = "adultNoviceWinger")
	public WebElement adultPanelClick;

	@FindBy(id = "adultNoviceWingerDate")
	public WebElement adultPanelDate;

	@FindBy(id = "adultWinger")
	public WebElement selectAdultWinger;

	@FindBy(id = "adultWingerDate")
	public WebElement adultWingerDate;

	@FindBy(id = "adultTraineeChair")
	public WebElement selectTraineeChair;

	@FindBy(id = "adultTraineeChairDate")
	public WebElement TraineeChairDate;

	@FindBy(id = "adultChair")
	public WebElement selectAdultChair;

	@FindBy(id = "adultChairDate")
	public WebElement adultChairDate;

	@FindBy(id = "youthNoviceWinger")
	public WebElement YouthPanelClick;

	@FindBy(id = "youthNoviceWingerDate")
	public WebElement YouthPanelDate;

	@FindBy(id = "youthWinger")
	public WebElement selectYouthPanelWinger;

	@FindBy(id = "youthWingerDate")
	public WebElement YouthWingerDate;

	@FindBy(id = "youthTraineeChair")
	public WebElement youthTraineeChair;

	@FindBy(id = "youthTraineeChairDate")
	public WebElement youthTraineeChairDate;

	@FindBy(id = "familyNoviceWinger")
	public WebElement familyPanelClick;

	@FindBy(id = "familyNoviceWingerDate")
	public WebElement familyPanelDate;

	@FindBy(id = "familyWinger")
	public WebElement selectfamilyPanelWinger;

	@FindBy(id = "familyWingerDate")
	public WebElement familyhWingerDate;

	@FindBy(css = ".panel-title")
	public List<WebElement> allPanel;

	@FindBy(id = "specialistCrownCourt")
	public WebElement selectCrownCourt;

	@FindBy(id = "specialistCrownCourtDate")
	public WebElement crownCourtDate;

	@FindBy(id = "specialistCommunityJustice")
	public WebElement communityJustice;

	@FindBy(id = "specialistRegulatoryCases")
	public WebElement regulatoryCases;

	@FindBy(id = "specialistDomesticViolence")
	public WebElement domesticViolence;

	@FindBy(id = "specialistDrugRehab")
	public WebElement drugRehabitation;

	@FindBy(id = "specialistEducation")
	public WebElement education;

	@FindBy(id = "specialistEnforcement")
	public WebElement enforceMent;

	@FindBy(id = "specialistLicensing")
	public WebElement licencing;

	@FindBy(id = "specialistProblemSolving")
	public WebElement probelSolving;

	@FindBy(id = "mentor")
	public WebElement selectMentor;

	@FindBy(id = "appraiser")
	public WebElement selectAppraiser;

	@FindBy(id = "sitting-eligibility-save-btn")
	public WebElement save;

	@FindBy(id = "specialistCommunityJusticeDate")
	public WebElement communityJustDate;

	@FindBy(id = "specialistDomesticViolenceDate")
	public WebElement domesticVioDate;

	@FindBy(id = "specialistDrugRehabDate")
	public WebElement drugDate;

	@FindBy(id = "specialistEducationDate")
	public WebElement educationdate;

	@FindBy(id = "specialistEnforcementDate")
	public WebElement enforcementDate;

	@FindBy(id = "specialistLicensingDate")
	public WebElement licencingDate;

	@FindBy(id = "specialistProblemSolvingDate")
	public WebElement problemSolvingDate;

	@FindBy(id = "specialistRegulatoryCasesDate")
	public WebElement regulatoryCasesDate;

	@FindBy(id = "appraiserDate")
	public WebElement appraiserDate;

	@FindBy(id = "mentorDate")
	public WebElement mentorDate;

	@FindBy(id = "magistrateLJA")
	public WebElement magistrateLJA;

	@FindBy(id = "sitting-eligibility-close-btn")
	public WebElement magistrateCloseButton;

	// Dj related

	@FindBy(id = "appointmentDate")
	public WebElement djDateOfAppointment;

	@FindBy(id = "adultAuthority")
	public WebElement djAdultPanel;

	@FindBy(id = "familyAuthority")
	public WebElement djFamilyPanel;

	@FindBy(id = "youthAuthority")
	public WebElement djYouthPanel;

	@FindBy(id = "specialistExtraditionAuthority")
	public WebElement djExtradition;

	@FindBy(id = "specialistTerrorismAuthority")
	public WebElement djTerrorism;

	@FindBy(id = "specialistSeriousSexualOffencesAuthority")
	public WebElement djsexualOffences;

	@FindBy(id = "specialistIndependentAdjudicatorsAuthority")
	public WebElement djIndependentAdjuctor;

	@FindBy(id = "specialistRecorderAuthority")
	public WebElement djrecorder;

	@FindBy(id = "adultAuthorityDate")
	public WebElement djAdultPanelDate;

	@FindBy(id = "familyAuthorityDate")
	public WebElement djFamilyPanelDate;

	@FindBy(id = "youthAuthorityDate")
	public WebElement djYouthPanelDate;

	@FindBy(id = "specialistExtraditionAuthorityDate")
	public WebElement djExtraditionDate;

	@FindBy(id = "specialistTerrorismAuthorityDate")
	public WebElement djTerrorismDate;

	@FindBy(id = "specialistSeriousSexualOffencesAuthorityDate")
	public WebElement djsexualOffencesDate;

	@FindBy(id = "specialistIndependentAdjudicatorsAuthorityDate")
	public WebElement djIndependentAdjuctorDate;

	@FindBy(id = "specialistRecorderAuthorityDate")
	public WebElement djrecorderDate;

	@FindBy(id = "districtJudgeStatus")
	public WebElement djCurrentStatus;

	@FindBy(css = ".ui-dialog-buttonset>button:nth-child(2)")
	public WebElement confirmPopUp;

	@FindBy(id = "familyChair")
	public WebElement familyChair;

	@FindBy(id = "familyTraineeChair")
	public WebElement familyTraineeChair;

	@FindBy(css = "#benchChairHistory > div > div > div.panel-heading > h3")
	public WebElement benchChairTitle;

	@FindBy(css = "#benchChairHistory .col-xs-12.col-sm-4.col-md-4.col-lg-4.control-label")
	public WebElement benchChairLocation;

	@FindBy(id = "bench-chair-history-start-0")
	public WebElement benchChairAppDate;

}
