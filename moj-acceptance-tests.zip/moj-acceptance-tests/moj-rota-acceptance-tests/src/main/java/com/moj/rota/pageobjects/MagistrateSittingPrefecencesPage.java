package com.moj.rota.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.moj.common.pageobjects.MOJBasePage;
import com.moj.rota.listingpattern.pageobjects.DraftRotaMagistrateListPopupPage;
import com.moj.rota.magistrate.pageobjects.MagistrateHomePage;

public class MagistrateSittingPrefecencesPage extends MOJBasePage {
	private static String winHandleBefore = null;
	public MagistrateSittingPrefecencesPage(WebDriver driver) {
		super(driver);
		winHandleBefore = driver.getWindowHandle();
		waitForPage();
		//switchToNewWindow();
		if(isElementNotDisplayed(switchFrame))
		{
		switchToIFrame(switchFrame);
		}
		waitForVisibilityOfElement(pageTitle);
	}

	@FindBy(css = ".btn.btn-info.btn-xs.dropdown-toggle")
	private WebElement myAccount;
	
	@FindBy(className = "text-left")
	private WebElement logoutLink;

	@FindBy(id = "loggedInName")
	private WebElement loginName;

	@FindBy(css = ".breadcrumb>li>a")
	private WebElement homePage;

	@FindBy(css = "#content>div>h1")
	private WebElement pageTitle;

	@FindBy(css = "#mag-sitting-pattern-panel > div.panel-heading > h2 > strong")
	private WebElement nameTitle;

	@FindBy(css = "#mag-sitting-pattern-panel div:nth-child(1) > div.panel-heading > h3")
	private WebElement sittingPreferencesByMagistrate;

	@FindBy(id = "sittingFrequencyType")
	private WebElement sittingFrequency;

	@FindBy(id = "sitSaturdays")
	private WebElement sitOnStaurDay;

	@FindBy(id = "bankHolidays")
	private WebElement sitOnBankHoliday;

	@FindBy(id = "isAvailableConsecutiveDays")
	private WebElement sitOnConsecutiveDays;

	@FindBy(id = "consecutiveDaysOption")
	private WebElement selectConsecutiveDays;

	@FindBy(id = "isAvailableShortNotice")
	private WebElement availableShortNotice;

	@FindBy(id = "shortNoticeOption")
	private WebElement selectShortNotice;

	@FindBy(id = "sitOnWelshLanguageCases")
	private WebElement sitOnWeilshSpeakingCases;

	@FindBy(css = "#mag-sitting-pattern-panel div:nth-child(2) > div.panel-heading > h3")
	private WebElement exceptionToDefaultSittingReq;

	@FindBy(id = "youthSittingsOnly")
	private WebElement youthSittingOnly;

	@FindBy(id = "familySittingsOnly")
	private WebElement familySittingOnly;

	@FindBy(id = "weeklySittingMonAm")
	private WebElement weeklyPattenOfAvaiAM;

	@FindBy(id = "weeklySittingTueAm")
	private WebElement tueWeeklyPattenOfAvaiAM;

	@FindBy(id = "weeklySittingWedAm")
	private WebElement WedWeeklyPattenOfAvaiAM;

	@FindBy(id = "weeklySittingThuAm")
	private WebElement ThuWeeklyPattenOfAvaiAM;

	@FindBy(id = "weeklySittingFriAm")
	private WebElement FriWeeklyPattenOfAvaiAM;

	@FindBy(id = "weeklySittingMonPm")
	private WebElement weeklyPattenOfAvaiPM;

	@FindBy(id = "weeklySittingTuePm")
	private WebElement tueWeeklyPattenOfAvaiPM;

	@FindBy(id = "weeklySittingWedPm")
	private WebElement WedWeeklyPattenOfAvaiPM;

	@FindBy(id = "weeklySittingThuPm")
	private WebElement ThuWeeklyPattenOfAvaiPM;

	@FindBy(id = "weeklySittingFriPm")
	private WebElement FriWeeklyPattenOfAvaiPM;

	@FindBy(id = "halfDaySitting")
	private WebElement halfDaySittingOnly;

	@FindBy(id = "halfDay")
	private WebElement halfDaySittingPreference;

	@FindBy(id = "specialRequirements")
	private WebElement specialRequirements;

	@FindBy(id = "specialRequirementsText")
	private WebElement specialRequirementComments;

	@FindBy(id = "mag-sitting-requirements-finish-btn")
	private WebElement saveButton;

	@FindBy(id = "sittingPatternCrossError")
	private WebElement weeklyAndHalfDayWarning;

	@FindBy(id = "sittingPatternFullError")
	private WebElement selectAllWeekDaysWarning;
	
	@FindBy(css = ".close")
	private WebElement closeWarningMessage;
	
	

	public void selectTitle(String title) {
		Select selectTitle = new Select(getElement(nameTitle));
		selectTitle.selectByVisibleText(title);
	}

	public boolean isPageFieldsDisplayed(String pageFields, boolean isMagistrateUI) {
		boolean isElemtDisplayed = false;
		switch (pageFields) {
		case "sitting_preferences_completed":
			isElemtDisplayed = isWebElementDisplayed(sittingPreferencesByMagistrate);
			break;
		case "Sitting_Frequency":
			isElemtDisplayed = isWebElementDisplayed(sittingFrequency);
			break;
		case "Able_to_siton_Saturdays":
			isElemtDisplayed = isWebElementDisplayed(sitOnStaurDay);
			break;
		case "Able_to_siton_BankHolidays":
			isElemtDisplayed = isWebElementDisplayed(sitOnBankHoliday);
			break;
		case "Available_at_short_notice":
			isElemtDisplayed = isWebElementDisplayed(availableShortNotice);
			break;
		case "Able_to_Weilsh_Speaking_cases":
			isElemtDisplayed = isWebElementDisplayed(sitOnWeilshSpeakingCases);
			break;
		case "Weekly_pattern_AM":
			isElemtDisplayed = isWebElementDisplayed(weeklyPattenOfAvaiAM);
			break;
		case "Weekly_pattern_PM":
			isElemtDisplayed = isWebElementDisplayed(weeklyPattenOfAvaiPM);
			break;
		case "Half_day_Sitting":
			isElemtDisplayed = isWebElementDisplayed(halfDaySittingOnly);
			break;
		case "Special_Requirements":
			if (isMagistrateUI == true) {
				isElemtDisplayed = isWebElementDisplayed(specialRequirementComments);
			} else {
				isElemtDisplayed = isWebElementDisplayed(specialRequirements);
			}

			break;
		case "Save":
			isElemtDisplayed = isWebElementDisplayed(saveButton);
			break;

		default:
			System.out.println("Not elements displyed");

		}

		return isElemtDisplayed;
	}

	public boolean isDisabledPageFieldsDisplayed(String pageFields) {
		boolean isElemtDisplayed = false;
		switch (pageFields) {
		case "Youth_Sittings_Only":
			isElemtDisplayed = isWebElementDisplayed(youthSittingOnly);
			break;
		case "Family_Sittings_Only":
			isElemtDisplayed = isWebElementDisplayed(familySittingOnly);
			break;
		default:
			System.out.println("Not elements displyed");

		}

		return isElemtDisplayed;
	}

	public boolean isSittingPreferencesPageDisplayed() {
		return isElementDisplayed(pageTitle);
	}

	public String getMyAccountLabel() {
		return getTextFromWebElement(myAccount);
	}

	public boolean isLoginNameDisplayed() {
		return isElementDisplayed(loginName);
	}

	public String getHomeBreadCumLabel() {
		return getTextFromWebElement(homePage);
	}

	public String getPageTitle() {
		return getTextFromWebElement(pageTitle);
	}

	public void selectWeeklyPattern(String weeklyPattern) {
		switch (weeklyPattern) {
		case "selectAM":
			if (getStatusOfCheckBox(weeklyPattenOfAvaiAM)) {
				click(weeklyPattenOfAvaiAM);
				click(weeklyPattenOfAvaiAM);
			} else {
				click(weeklyPattenOfAvaiAM);
			}
			break;
		case "selectPM":
			if (getStatusOfCheckBox(weeklyPattenOfAvaiPM)) {
				click(weeklyPattenOfAvaiPM);
				click(weeklyPattenOfAvaiPM);
			} else {
				click(weeklyPattenOfAvaiPM);
			}
			break;
		case "AllDayOfTheWeek":
			click(weeklyPattenOfAvaiAM);
			if(isWebElementDisplayed(closeWarningMessage))
			{
				click(closeWarningMessage);
			}
			waitForPage();
			click(tueWeeklyPattenOfAvaiAM);
			click(WedWeeklyPattenOfAvaiAM);
			click(ThuWeeklyPattenOfAvaiAM);
			click(FriWeeklyPattenOfAvaiAM);
			click(weeklyPattenOfAvaiPM);
			click(tueWeeklyPattenOfAvaiPM);
			click(WedWeeklyPattenOfAvaiPM);
			click(ThuWeeklyPattenOfAvaiPM);
			click(FriWeeklyPattenOfAvaiPM);

			break;
		default:
		}
		if(isWebElementDisplayed(closeWarningMessage))
		{
			click(closeWarningMessage);
		}
	}

	public boolean getSelectedWeeklyPattern(String weekLyPattern) {
		boolean isWeeklyPattern = false;
		switch (weekLyPattern) {
		case "selectAM":
			isWeeklyPattern = getStatusOfCheckBox(weeklyPattenOfAvaiAM);
			break;
		case "selectPM":
			isWeeklyPattern = getStatusOfCheckBox(weeklyPattenOfAvaiPM);
			break;
		default:
		}
		return isWeeklyPattern;
	}

	public void selectHalfDayPattern(String halfDayPattern) {
		click(halfDaySittingOnly);
		selectDropDown(halfDaySittingPreference, halfDayPattern);
		if(halfDayPattern.equalsIgnoreCase("Morning OR afternoon"))
		{
		if(isWebElementDisplayed(closeWarningMessage))
		{
			click(closeWarningMessage);
		}
		}
	}

	public String getSelectedHalfDayPattern() {
		return getSelectedDropDownOption(halfDaySittingPreference);
	}

	public void selectYouthMemberShip() {
		if (getStatusOfCheckBox(familySittingOnly) == true) {
			click(familySittingOnly);
		}

		click(youthSittingOnly);
	}

	public void selectFaliyMemberShip() {
		if (getStatusOfCheckBox(youthSittingOnly) == true) {
			click(youthSittingOnly);
		}
		click(familySittingOnly);
	}

	public boolean getSelectedFamilyMember() {
		return getStatusOfCheckBox(familySittingOnly);
	}

	public boolean isWarningMessageDisplayed(String warningMessage) {
		boolean iswarningMessage = false;

		switch (warningMessage) {
		case "Cannot select pattern and half day":
			iswarningMessage = getTextFromWebElement(weeklyAndHalfDayWarning).contains(warningMessage);
			break;
		case "Cannot select all":
			iswarningMessage = getTextFromWebElement(selectAllWeekDaysWarning).contains(warningMessage);
			break;
		case "ShouldNotdisplay-Consecutivedays":
			iswarningMessage = isElementNotDisplayed(selectConsecutiveDays);
			break;
		case "Family Should be disabled":
			iswarningMessage = getStatusOfElement(familySittingOnly);
			break;

		case "Youth Should be disabled":
			iswarningMessage = getStatusOfElement(youthSittingOnly);
			break;
		}
		
		return iswarningMessage;
	}

	public void selectFrequency(String frequencyVal) {
		selectDropDown(sittingFrequency, frequencyVal);
	}

	public String getSelectedFrequency() {
		return getSelectedDropDownOption(sittingFrequency);
	}

	public void selectSitOnDays(String sitOnDays) {
		switch (sitOnDays) {
		case "Saturday":
			if (getStatusOfCheckBox(sitOnStaurDay) == true) {
				click(sitOnStaurDay);
				click(sitOnStaurDay);
			} else {
				click(sitOnStaurDay);
			}

			break;
		case "BankHoliday":
			if (getStatusOfCheckBox(sitOnBankHoliday) == true) {
				click(sitOnBankHoliday);
				click(sitOnBankHoliday);
			} else {
				click(sitOnBankHoliday);
			}
			break;

		case "Consecutive":
			if (getStatusOfCheckBox(sitOnConsecutiveDays) == true) {
				click(sitOnConsecutiveDays);
				click(sitOnConsecutiveDays);
			} else {
				click(sitOnConsecutiveDays);
			}
			selectDropDown(selectConsecutiveDays, "2 days");
			break;
		case "Weilsh Speaking":
			if (getStatusOfCheckBox(sitOnWeilshSpeakingCases) == true) {
				click(sitOnWeilshSpeakingCases);
				click(sitOnWeilshSpeakingCases);
			} else {
				click(sitOnWeilshSpeakingCases);
			}

			break;
		default:
		}
	}

	public boolean selectedSitOnDays(String sitOnDays) {
		boolean isSelectedDays = false;
		switch (sitOnDays) {
		case "Saturday":
			isSelectedDays = getStatusOfCheckBox(sitOnStaurDay);
			break;
		case "BankHoliday":
			isSelectedDays = getStatusOfCheckBox(sitOnBankHoliday);
			break;

		case "Consecutive":
			isSelectedDays = getStatusOfCheckBox(sitOnConsecutiveDays);
			break;
		case "Weilsh Speaking":
			isSelectedDays = getStatusOfCheckBox(sitOnWeilshSpeakingCases);
			break;
		case "Short Notice":
			isSelectedDays = getStatusOfCheckBox(availableShortNotice);
			break;
		default:
		}
		return isSelectedDays;
	}

	public void selectAvailableAtShortNotice(String shortNotice) {
		if (getStatusOfCheckBox(availableShortNotice) == true) {
			click(availableShortNotice);
			click(availableShortNotice);
		} else {
			click(availableShortNotice);
		}
		waitForPageToLoad();
		selectDropDown(selectShortNotice, shortNotice);
	}

	public String getSelectedShortNotice() {
		return getSelectedDropDownOption(selectShortNotice);
	}

	public MagistrateSearchPage clickonSave() {
		click(saveButton);
		driver.switchTo().window(winHandleBefore);
		return returnPageFactory(MagistrateSearchPage.class);
	}

	public void enterSpecialRequirements(String specialRequirementsVal) {
		if (getStatusOfCheckBox(specialRequirements) == true) {
			click(specialRequirements);
			click(specialRequirements);
		} else {
			click(specialRequirements);
		}
		enterText(specialRequirementComments, specialRequirementsVal);
	}

	public boolean getenteredSpecialRequirements() {
		return getStatusOfCheckBox(specialRequirements);
	}

	public MagistrateHomePage clickonMagSave() {
		click(saveButton);
		return returnPageFactory(MagistrateHomePage.class);
	}

	public DraftRotaMagistrateListPopupPage clickonDraftSave() {
		click(saveButton);
		driver.switchTo().window(winHandleBefore);
		return returnPageFactory(DraftRotaMagistrateListPopupPage.class);
	}

	public boolean isSittingPreferenceEditable() {
		return getStatusOfElement(sittingFrequency);
	}
	
	public RotaAdminHomePage clickLogoutLink() {
		click(myAccount);
		click(logoutLink);
		return getPage(RotaAdminHomePage.class);
	}

}
