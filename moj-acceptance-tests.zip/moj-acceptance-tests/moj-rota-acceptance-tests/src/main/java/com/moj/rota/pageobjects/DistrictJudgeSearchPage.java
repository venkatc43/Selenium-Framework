package com.moj.rota.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.moj.common.pageobjects.MOJBasePage;

public class DistrictJudgeSearchPage extends MOJBasePage {

	private final String VALID_FIRST_NAME = "test";
	private final String INVALID_FIRST_NAME = "1";
	private final String NO_RESULT_FIRST_NAME = "Some random text";

	@FindBy(id = "firstName")
	private WebElement fname;

	@FindBy(id = "firstNameError")
	private WebElement fname_error;

	@FindBy(id = "lastName")
	private WebElement lname;

	@FindBy(id = "lastNameError")
	private WebElement lname_error;

	@FindBy(id = "search-djs-btn")
	private WebElement searchBtn;

	@FindBy(id = "search-results")
	private WebElement searchResult;

	@FindBy(css = "#searchResultsError>label")
	private WebElement searchResultsError;

	@FindBy(css = "#result > div:nth-child(3) > a > span")
	private WebElement sittingEligibility;

	@FindBy(css = "#result > div:nth-child(2) > a > span")
	private WebElement personalDetails;

	@FindBy(css = "#result > div:nth-child(6) > a > span")
	private WebElement nonAvailability;

	@FindBy(css = "#result > div:nth-child(4) > a > span")
	private WebElement sittingPreferences;

	@FindBy(css = ".col-xs-12.col-sm-12.col-md-12.col-lg-12")
	private WebElement searchResultMsg;

	@FindBy(css = ".col-xs-12.col-sm-3.col-md-12.col-lg-12")
	private WebElement searchResultName;

	@FindBy(css = "#result > div:nth-child(5) > a")
	private WebElement sittingLocation;

	@FindBy(css = "#result > div:nth-child(7) > a > span")
	private WebElement sittings;

	public DistrictJudgeSearchPage(WebDriver driver) {
		super(driver);
	}

	public void completeDJFormWithValidData() {
		enterFirstName(VALID_FIRST_NAME);
		clickSearchButton();

	}

	public MagistrateSearchPage completeDJFormWithValidData(String firstName, String lastName) {
		enterFirstName(firstName);
		enterLastName(lastName);
		clickSearchButton();
		return returnPageFactory(MagistrateSearchPage.class);

	}

	public void completeDJFormWithInvalidData() {
		enterFirstName(INVALID_FIRST_NAME);
		clickSearchButton();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void completeDJFormWithZeroData() {
		enterFirstName(NO_RESULT_FIRST_NAME);
		clickSearchButton();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

	public boolean districtJudgeFoundMsg() {
		return getElement(searchResultMsg).getText().contains("District Judge found");
	}

	public void enterFirstName(String firstName) {
		getElement(fname).sendKeys(firstName);
	}

	public void enterLastName(String lastName) {
		getElement(lname).sendKeys(lastName);
	}

	public void clickSearchButton() {
		getElement(searchBtn).click();
	}

	public String getErrorMsgWithNoData() {
		return getElement(searchResultsError).getText();
	}

	public String getErrorMsgWithInvalidData() {
		return getElement(fname_error).getText();
	}

	public String getNoResultsMessage() {
		return getElement(searchResult).getText();
	}

	public void completeDJFormWithNoData() {
		clickSearchButton();
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public String getSearchResultsName() {
		return getTextFromWebElement(searchResultName);
	}

	public boolean disJudgeFoundMsg() {
		return getElement(searchResultMsg).getText().contains("District Judge found");
	}

	public MagistratePersonalDetailsPage clickPersonalDetails() {
		waitForPage();
		click(personalDetails);
		return returnPageFactory(MagistratePersonalDetailsPage.class);
	}

	public MagistrateSittingEligibiltyPage clickSittingEligibility() {
		waitForPage();
		click(sittingEligibility);
		return returnPageFactory(MagistrateSittingEligibiltyPage.class);
	}

	public MagistrateSittingPrefecencesPage clickOnSittingPreferences() {
		waitForPage();
		click(sittingPreferences);
		return returnPageFactory(MagistrateSittingPrefecencesPage.class);
	}

	public MagistrateSittingLocationsPage clickSittingLocation() {
		waitForPage();
		click(sittingLocation);
		return returnPageFactory(MagistrateSittingLocationsPage.class);
	}

	public MagistrateNonAvailabilityPage clickNonAvailability() {
		waitForPage();
		click(nonAvailability);
		return returnPageFactory(MagistrateNonAvailabilityPage.class);
	}

	public MagistrateSittingsPage clickOnSittings() {
		click(sittings);
		return returnPageFactory(MagistrateSittingsPage.class);
	}

}
