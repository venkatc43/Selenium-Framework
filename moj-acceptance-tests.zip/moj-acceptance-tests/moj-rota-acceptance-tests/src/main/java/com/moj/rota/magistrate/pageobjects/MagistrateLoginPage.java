
package com.moj.rota.magistrate.pageobjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import com.moj.common.pageobjects.MOJBasePage;
import com.moj.rota.pageobjects.RotaAdminHomePage;

public class MagistrateLoginPage extends MOJBasePage {

	@FindBy(id = "username")
	private WebElement uname;

	@FindBy(id = "password")
	private WebElement pass;

	@FindBy(css = ".btn.btn-success.btn-wide-1")
	private WebElement loginBtn;

	@FindBy(className = "error")
	private WebElement errorMsg;
	
	@FindBy(id = "IDToken1")
	private WebElement sitUname;

	@FindBy(id = "IDToken2")
	private WebElement sitPass;

	@FindBy(css = ".button.primary")
	private WebElement sitLoginBtn;

	public MagistrateLoginPage(WebDriver driver) {
		super(driver);
	}

	public void enterUsername(String username) {
		getElement(uname).sendKeys(username);
	}

	public void enterPassword(String password) {
		getElement(pass).sendKeys(password);
	}

	public MagistrateHomePage clickLoginButton() {
		getElement(loginBtn).click();
		return getPage(MagistrateHomePage.class);
	}

	public String errorMessage() {
		getElement(loginBtn).click();
		return getElement(errorMsg).getText();
	}

	public boolean isUserLogedIn(MagistrateHomePage onMagistratePage, String userName) {
		return onMagistratePage.loggedInName(userName);
	}
	
	public MagistrateHomePage sitLogin(String userName,String password) {
		enterText(sitUname, userName);
		enterText(sitPass, password);
		click(sitLoginBtn);
		return getPage(MagistrateHomePage.class);
	}

}
