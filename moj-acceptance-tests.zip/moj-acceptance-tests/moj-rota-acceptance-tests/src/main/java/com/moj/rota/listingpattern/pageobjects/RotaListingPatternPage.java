package com.moj.rota.listingpattern.pageobjects;

import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class RotaListingPatternPage extends RotaListingAndDrfatRotaPage {

	public RotaListingPatternPage(WebDriver driver) {
		super(driver);

	}

	public void selectJusticeArea(String justiceAreaVal) {
		waitForVisibilityOfElement(selectJusticeArea);
		selectDropDown(selectJusticeArea, justiceAreaVal);
	}

	public void clickLisitngPattern() {
		waitForElementTobeClickable(listingPatternButton);
		click(listingPatternButton);

	}

	public boolean isRotaListingDisplayed() {
		return isElementDisplayed(pageTitle);
	}

	public String getPageTitle() {
		return getTextFromWebElement(pageTitle);
	}

	public String getJusticeAreaTitle() {
		waitForPageToLoad();
		return getTextFromWebElement(boxTitle);
	}

	public String getPatternsTitle(String title) {
		String patternTitle = null;

		switch (title) {
		case "1 week":
			patternTitle = getTextFromWebElement(weekOneLabel);
			break;
		case "2 weeks":
			patternTitle = getTextFromWebElement(weekTwoLabel);
			break;
		case "3 weeks":
			patternTitle = getTextFromWebElement(weekThreeLabel);
			break;
		case "4 weeks":
			patternTitle = getTextFromWebElement(weekFourLabel);
			break;
		default:
		}

		return patternTitle;
	}

	public String getLocationsTitle(String title) {
		String locationTitle = null;

		switch (title) {
		case "DFJA":
			locationTitle = getTextFromWebElement(dfjaLocation.get(0));
			break;
		case "Crown Court":
			locationTitle = getTextFromWebElement(crownCourt.get(0));
			break;
		case "Magistrates Court":
			locationTitle = getTextFromWebElement(magistrateCourt1.get(1));
			break;

		default:
		}

		return locationTitle;
	}

	public boolean isGenerateRotaDisplayed() {
		return isElementDisplayed(generateRotaButton);
	}

	public void selectPatternType(String patternType) {
		switch (patternType) {
		case "1 week":
			click(oneWeekPattern);
			break;
		case "2 weeks":
			click(twoWeekPattern);
			break;
		case "3 weeks":
			click(threeweekPattern);
			break;
		case "4 weeks":
			click(fourWeekPattern);
			break;
		}
	}

	public void clickOnAddVenue(String patternType) {
		switch (patternType) {
		case "1 week":
			click(addEvenueWeek1.get(0));
			break;
		case "2 weeks":
			click(addEvenueWeek2.get(1));
			break;
		case "3 weeks":
			click(addEvenueWeek3.get(5));
			break;
		case "4 weeks":
			click(addEvenueWeek4.get(11));
			break;
		}
	}

	public void draftRotaAddVenue(String patternType) {
		waitForPage();
		switch (patternType) {
		case "1 week":
			click(draftAddVenue.get(0));
			break;
		case "2 weeks":
			click(draftAddVenue.get(0));
			break;
		case "3 weeks":
			click(draftAddVenue.get(1));
			break;
		case "4 weeks":
			click(draftAddVenue.get(2));
			break;
		}
	}

	public void clickOnLocation(String location) {
		waitForPage();
		switch (location) {
		case "1 week":
			waitForVisibilityOfElement(dfjaLocation.get(0));
			click(dfjaLocation.get(0));
			break;
		case "2 weeks":
			waitForVisibilityOfElement(crownCourt.get(0));
			click(crownCourt.get(0));
			break;
		case "3 weeks":
		case "2 weeks-Swap":
			waitForVisibilityOfElement(magistrateCourt1.get(1));
			click(magistrateCourt1.get(1));
			break;
		case "4 weeks":
			waitForVisibilityOfElement(magistrateCourt2.get(2));
			click(magistrateCourt2.get(2));
			break;
		case "optimised":
			waitForVisibilityOfElement(magistrateCourt1.get(1));
			click(magistrateCourt1.get(1));
			break;

		}
	}

	public void clickOnWeekNumberUnderLocation(String location) {
		switch (location) {
		case "1 week":
			waitForElementTobeClickable(week1UnderLocation);
			click(week1UnderLocation);
			break;
		case "2 weeks":
			waitForElementTobeClickable(week2UnderLocation);
			click(week2UnderLocation);
			break;
		case "3 weeks":
			waitForElementTobeClickable(week3UnderLocation.get(1));
			click(week3UnderLocation.get(1));
			break;
		case "4 weeks":
			waitForElementTobeClickable(week4UnderLocation.get(2));
			click(week4UnderLocation.get(2));
			break;
		}
	}

	public void enterVenueName(String patternType, String venueName, int venue) {
		// 0=Listing pattern venue
		// 1=Draft rota venue
		waitForPage();
		switch (patternType) {
		case "1 week":
			waitForVisibilityOfElement(week1Venue.get(venue));
			week1Venue.get(venue).clear();
			week1Venue.get(venue).sendKeys(venueName);
			week1Venue.get(venue).sendKeys(Keys.TAB);
			break;
		case "2 weeks":
			waitForVisibilityOfElement(week2Venue.get(venue));
			week2Venue.get(venue).clear();
			waitForPageToLoad();
			week2Venue.get(venue).sendKeys(venueName);
			week2Venue.get(venue).sendKeys(Keys.TAB);
			break;
		case "3 weeks":
			waitForPage();
			waitForVisibilityOfElement(week3Venue.get(3));
			waitForPageToLoad();
			week3Venue.get(3).clear();
			week3Venue.get(3).sendKeys(venueName);
			week3Venue.get(3).sendKeys(Keys.TAB);
			break;
		case "4 weeks":
			waitForPage();
			waitForVisibilityOfElement(week4Venue.get(4));
			waitForPage();
			week4Venue.get(4).clear();
			week4Venue.get(4).sendKeys(venueName);
			week4Venue.get(4).sendKeys(Keys.TAB);
			break;
		}

		waitForPageToLoad();
	}

	public String getenteredVenueName(String weekType, int venue) {
		String venueName = null;
		waitForPage();
		waitForPageToLoad();
		switch (weekType) {
		case "1 week":
			venueName = getReadOnlyTextData(week1Venue.get(venue));
			break;
		case "2 weeks":
			venueName = getReadOnlyTextData(week2Venue.get(venue));
			break;
		case "3 weeks":
			venueName = getReadOnlyTextData(week3Venue.get(3));
			break;
		case "4 weeks":
			venueName = getReadOnlyTextData(week4Venue.get(6));
			break;
		}
		return venueName;
	}

	public boolean getSelectedPatternRadioStatus(String patternType) {
		boolean radioButtonstatus = false;
		switch (patternType) {
		case "1 week":
			radioButtonstatus = getStatusOfElement(oneWeekPattern);
			break;
		case "2 weeks":
			radioButtonstatus = getStatusOfElement(twoWeekPattern);
			break;
		case "3 weeks":
			radioButtonstatus = getStatusOfElement(threeweekPattern);
			break;
		case "4 weeks":
			radioButtonstatus = getStatusOfElement(fourWeekPattern);
			break;
		}
		return radioButtonstatus;
	}

	public String getAMLabel() {
		return getTextFromWebElement(sessionAM);
	}

	public String getPMLabel() {
		return getTextFromWebElement(sessionPM);
	}

	public boolean getSATClosedLabel() {
		return getTextFromWebElement(closeSaAMSession).contains("Closed");
	}

	public boolean getSunClosedLabel() {
		return getTextFromWebElement(closeSunPMSession).contains("Closed");
	}

	public boolean getPMClosedLabel() {
		return getTextFromWebElement(clickThuPM.get(3)).contains("Closed");
	}

	public void clickCloseSession(String dayPatternType, String dayName, String operationType) {
		waitForPage();
		switch (dayName) {
		case "Monday":
			if (dayPatternType.equals("AM")) {

				if (operationType.equals("Add")) {
					click(clickMonAM);
				} else {
					click(monAMSavedPanel);
				}

			} else {
				if (operationType.equals("Add")) {
					click(clickMonPM);
				} else {
					click(monPMSavedPanel);
				}
			}
			break;
		case "TuesDay":
			if (dayPatternType.equals("AM")) {
				if (operationType.equals("Add")) {
					click(clickTueAM.get(0));
				} else if (operationType.equals("DAdd")) {
					click(clickCloseDraftRotaAM.get(0));
				} else if (operationType.equals("DUpdate")) {
					click(tueRotaSavedPanel);
				} else if (operationType.equals("Delete")) {
					waitForVisibilityOfAllElement(deletSession);
					draftRotaSessionDelete(deletSession);
				} else {
					click(tueAMSavedPanel);
				}

			} else {
				if (operationType.equals("Add")) {
					click(clickTuePM.get(0));
				} else if (operationType.equals("Delete")) {
					waitForVisibilityOfAllElement(deletLinkedPMSession);
					draftRotaSessionDelete(deletLinkedPMSession);
				} else {
					click(tuePMSavedPanel);
				}
			}
			break;
		case "Wednesday":
			if (dayPatternType.equals("AM")) {

				if (operationType.equals("Add")) {
					click(clickWedAM.get(1));
				} else if (operationType.equals("DAdd")) {
					click(clickWedCloseDraftRotaAM.get(0));
				} else if (operationType.equals("DUpdate")) {
					click(wedRotaSavedPanel);
				} else if (operationType.equals("Delete")) {
					waitForVisibilityOfAllElement(deletSession);
					draftRotaSessionDelete(deletSession);
				} else {
					click(wedAMSavedPanel);
				}

			} else {
				if (operationType.equals("Add")) {
					click(clickWedPM.get(1));
				} else if (operationType.equals("Delete")) {
					waitForVisibilityOfAllElement(deletLinkedPMSession);
					draftRotaSessionDelete(deletLinkedPMSession);
				} else if (dayPatternType.equals("SecondVenuePM")) {
					click(clickWedCloseDraftRotaAM.get(0));
				} else {
					click(wedPMSavedPanel);
				}
			}
			break;
		case "Thursday":
			waitForPage();
			if (dayPatternType.equals("AM")) {

				if (operationType.equals("Add")) {
					click(clickThuAM.get(2));
				} else if (operationType.equals("DAdd")) {
					click(clickThuCloseDraftRotaAM.get(0));
				} else if (operationType.equals("DUpdate")) {
					click(thuRotaSavedPanel);
				} else if (operationType.equals("Delete")) {
					waitForVisibilityOfAllElement(deletSession);
					draftRotaSessionDelete(deletSession);
				} else {
					click(thuAMSavedPanel);
				}

			} else {
				if (operationType.equals("Add")) {
					click(clickThuPM.get(2));
				} else if (operationType.equals("Delete")) {
					waitForVisibilityOfAllElement(deletLinkedPMSession);
					draftRotaSessionDelete(deletLinkedPMSession);
				} else {
					click(thuPMSavedPanel);
				}
			}
			break;
		case "Friday":
			if (dayPatternType.equals("AM")) {

				if (operationType.equals("Add")) {
					click(clickFriAM);
				} else {
					click(friAMSavedPanel);
				}

			} else {
				click(clickFriPM);
			}
			break;
		case "Saturday":
			if (dayPatternType.equals("AM")) {

				if (operationType.equals("Add")) {
					click(clickSatAM);
				} else if (operationType.equals("Delete")) {
					waitForVisibilityOfAllElement(deletSession);
					draftRotaSessionDelete(deletSession);
				} else {
					click(satAMSavedPanel);
				}
			} else {
				click(clickSatPM);
			}
			break;
		case "Sunday":
			if (dayPatternType.equals("AM")) {
				if (operationType.equals("Add") || operationType.equals("Add-Sun")) {
					click(clickSunAM);

				} else if (operationType.equals("Delete")) {
					waitForVisibilityOfElement(deletSessionSun);
					click(deletSessionSun);
					waitForPage();
				} else {
					click(sunAMSavedPanel);
				}
			} else {
				click(clickSunPM);
			}
			break;
		default:
		}

	}

	private void draftRotaSessionDelete(List<WebElement> deleteSesion) {
		int deleteElementSize = deleteSesion.size();
		if (deleteElementSize > 1) {
			waitForVisibilityOfElement(deleteSesion.get(deleteElementSize - 1));
			waitForElementTobeClickable(deleteSesion.get(deleteElementSize - 1));
			click(deleteSesion.get(deleteElementSize - 1));
			waitForPage();
		} else {
			waitForVisibilityOfElement(deleteSesion.get(0));
			waitForElementTobeClickable(deleteSesion.get(0));
			click(deleteSesion.get(0));
			waitForPage();
		}
	}

	public void clickDraftLinkesSessionUpdate(String dayPatternType, String dayName, String operationType) {
		waitForPage();
		waitForPageToLoad();
		switch (dayName) {
		case "TuesDay":
			if (operationType.equals("DLAdd")) {
				click(draftClickTuePM.get(0));
			} else {
				click(draftTuePMSavedPanel);
			}

			break;
		case "Wednesday":
			if (operationType.equals("DLAdd")) {
				click(draftClickWedPM.get(0));
			} else {
				click(draftWedPMSavedPanel);
			}
			break;
		case "Thursday":
			if (operationType.equals("DLAdd")) {
				click(draftClickThuPM.get(0));
			} else {
				click(draftThuPMSavedPanel);
			}
			break;
		default:
		}

	}

	public boolean getPanelBusinessNameByAMAndPM(String dayPatternType, String dayName, String panelType,
			String businesType, String operationType) {
		boolean isPanelAndBusineeType = false;
		waitForPage();
		waitForPage();
		switch (dayName) {
		case "Monday":
			if (dayPatternType.equals("AM")) {
				waitForVisibilityOfElement(monAMSavedPanel);
				waitForVisibilityOfElement(monAMSavedBusinessType);
				isPanelAndBusineeType = getTextFromWebElement(monAMSavedPanel).contains(panelType);
				isPanelAndBusineeType = getTextFromWebElement(monAMSavedBusinessType).contains(businesType);
			} else {
				waitForVisibilityOfElement(monPMSavedPanel);
				waitForVisibilityOfElement(monPMSavedBusinessType);
				isPanelAndBusineeType = getTextFromWebElement(monPMSavedPanel).contains(panelType);
				isPanelAndBusineeType = getTextFromWebElement(monPMSavedBusinessType).contains(businesType);
			}
			break;
		case "TuesDay":
			if ((dayPatternType.equals("AM") && operationType.equals("Add"))
					|| (dayPatternType.equals("AM") && operationType.equals("Update"))) {
				waitForVisibilityOfElement(tueAMSavedPanel);
				waitForVisibilityOfElement(tueAMSavedBusinessType);
				isPanelAndBusineeType = getTextFromWebElement(tueAMSavedPanel).contains(panelType);
				isPanelAndBusineeType = getTextFromWebElement(tueAMSavedBusinessType).contains(businesType);
			} else if ((dayPatternType.equals("AM") && operationType.equals("DUpdate"))
					|| operationType.equals("DAdd")) {
				waitForVisibilityOfElement(tueRotaSavedPanel);
				waitForVisibilityOfElement(tueRotaSavedBusinessType);
				isPanelAndBusineeType = getTextFromWebElement(tueRotaSavedPanel).contains(panelType);
				isPanelAndBusineeType = getTextFromWebElement(tueRotaSavedBusinessType).contains(businesType);
			} else {
				waitForVisibilityOfElement(tuePMSavedPanel);
				waitForVisibilityOfElement(tuePMSavedBusinessType);
				isPanelAndBusineeType = getTextFromWebElement(tuePMSavedPanel).contains(panelType);
				isPanelAndBusineeType = getTextFromWebElement(tuePMSavedBusinessType).contains(businesType);
			}
			break;
		case "Wednesday":
			if ((dayPatternType.equals("AM") && operationType.equals("Add"))
					|| (dayPatternType.equals("AM") && operationType.equals("Update"))) {
				waitForVisibilityOfElement(wedAMSavedPanel);
				waitForVisibilityOfElement(wedAMSavedBusinessType);
				isPanelAndBusineeType = getTextFromWebElement(wedAMSavedPanel).contains(panelType);
				isPanelAndBusineeType = getTextFromWebElement(wedAMSavedBusinessType).contains(businesType);

			} else if ((dayPatternType.equals("AM") && operationType.equals("DUpdate"))
					|| operationType.equals("DAdd")) {
				waitForVisibilityOfElement(wedRotaSavedPanel);
				waitForVisibilityOfElement(wedRotaSavedBusinessType);
				isPanelAndBusineeType = getTextFromWebElement(wedRotaSavedPanel).contains(panelType);
				isPanelAndBusineeType = getTextFromWebElement(wedRotaSavedBusinessType).contains(businesType);

			} else {
				waitForVisibilityOfElement(wedPMSavedPanel);
				waitForVisibilityOfElement(wedPMSavedBusinessType);
				isPanelAndBusineeType = getTextFromWebElement(wedPMSavedPanel).contains(panelType);
				isPanelAndBusineeType = getTextFromWebElement(wedPMSavedBusinessType).contains(businesType);
			}
			break;
		case "Thursday":
			if ((dayPatternType.equals("AM") && operationType.equals("Add"))
					|| (dayPatternType.equals("AM") && operationType.equals("Update"))) {
				waitForVisibilityOfElement(thuAMSavedPanel);
				waitForVisibilityOfElement(thuAMSavedBusinessType);
				isPanelAndBusineeType = getTextFromWebElement(thuAMSavedPanel).contains(panelType);
				isPanelAndBusineeType = getTextFromWebElement(thuAMSavedBusinessType).contains(businesType);

			} else if ((dayPatternType.equals("AM") && operationType.equals("DUpdate"))
					|| operationType.equals("DAdd")) {
				waitForVisibilityOfElement(thuRotaSavedPanel);
				waitForVisibilityOfElement(thuRotaSavedBusinessType);
				isPanelAndBusineeType = getTextFromWebElement(thuRotaSavedPanel).contains(panelType);
				isPanelAndBusineeType = getTextFromWebElement(thuRotaSavedBusinessType).contains(businesType);

			} else {
				waitForVisibilityOfElement(thuPMSavedPanel);
				waitForVisibilityOfElement(thuPMSavedBusinessType);
				isPanelAndBusineeType = getTextFromWebElement(thuPMSavedPanel).contains(panelType);
				isPanelAndBusineeType = getTextFromWebElement(thuPMSavedBusinessType).contains(businesType);
			}
			break;
		case "Friday":
			if (dayPatternType.equals("AM")) {
				waitForVisibilityOfElement(friAMSavedPanel);
				waitForVisibilityOfElement(friAMSavedBusinessType);
				isPanelAndBusineeType = getTextFromWebElement(friAMSavedPanel).contains(panelType);
				isPanelAndBusineeType = getTextFromWebElement(friAMSavedBusinessType).contains(businesType);
			} else {
				waitForVisibilityOfElement(friPMSavedPanel);
				waitForVisibilityOfElement(friPMSavedBusinessType);
				isPanelAndBusineeType = getTextFromWebElement(friPMSavedPanel).contains(panelType);
				isPanelAndBusineeType = getTextFromWebElement(friPMSavedBusinessType).contains(businesType);
			}
			break;
		case "Saturday":
			if (dayPatternType.equals("AM")) {
				waitForVisibilityOfElement(satAMSavedPanel);
				waitForVisibilityOfElement(satAMSavedBusinessType);
				isPanelAndBusineeType = getTextFromWebElement(satAMSavedPanel).contains(panelType);
				isPanelAndBusineeType = getTextFromWebElement(satAMSavedBusinessType).contains(businesType);
			} else {
				waitForVisibilityOfElement(satPMSavedPanel);
				waitForVisibilityOfElement(satPMSavedBusinessType);
				isPanelAndBusineeType = getTextFromWebElement(satPMSavedPanel).contains(panelType);
				isPanelAndBusineeType = getTextFromWebElement(satPMSavedBusinessType).contains(businesType);
			}
			break;
		case "Sunday":
			if (dayPatternType.equals("AM")) {
				waitForVisibilityOfElement(sunAMSavedPanel);
				waitForVisibilityOfElement(sunAMSavedBusinessType);
				isPanelAndBusineeType = getTextFromWebElement(sunAMSavedPanel).contains(panelType);
				isPanelAndBusineeType = getTextFromWebElement(sunAMSavedBusinessType).contains(businesType);
			} else {
				waitForVisibilityOfElement(sunPMSavedPanel);
				waitForVisibilityOfElement(sunPMSavedBusinessType);
				isPanelAndBusineeType = getTextFromWebElement(sunPMSavedPanel).contains(panelType);
				isPanelAndBusineeType = getTextFromWebElement(sunPMSavedBusinessType).contains(businesType);
			}
			break;
		default:
		}

		return isPanelAndBusineeType;
	}

	public boolean isVenueRemoveDisplayed() {
		return isElementNotDisplayed(removeVenue.get(0));
	}

	public void enterBankHoldayDate(String patternType) {
		waitForPage();
		if (patternType.equals("optimised")) {
			click(dateImage.get(1));
		} else {
			click(dateImage.get(1));
		}
		waitForPage();
		waitForPageToLoad();
		click(bankHolidayDate);
	}

	public boolean isBankHoliday(String patternType) {
		if (patternType.equals("optimised")) {
			return isElementDisplayed(bankHoliday.get(1));
		} else {
			return isElementDisplayed(bankHoliday.get(1));
		}
	}

	// Broken Rules related
	public BrokenRulesPage clickonBrokenRules() {
		waitForElementTobeClickable(brokenRulesLink);
		click(brokenRulesLink);
		return returnPageFactory(BrokenRulesPage.class);
	}
	
	public String getBrokenRulesCount() {
		return getTextFromWebElement(brokenRulesCount);
	}

	public void clickStartOptimisation() {
		waitForElementTobeClickable(startOptimisation);
		click(startOptimisation);
	}

	public boolean isValidationPupupDisplayed() {
		return isElementDisplayed(validationLabel);
	}

	public String getValidationContent(String contentType) {
		String validationContent = null;
		switch (contentType) {
		case "Cancel":
			validationContent = getTextFromWebElement(optimisationCancel);
			break;
		case "Continue":
			validationContent = getTextFromWebElement(optimisationContinue);
			break;
		default:
			validationContent = getTextFromWebElement(validationText);

		}
		return validationContent;
	}

	public void clickCancelPopUp() {
		click(optimisationCancel);
	}

	public boolean isDeleteSession() {
		return deletSession.size() > 0;
	}
		
}
