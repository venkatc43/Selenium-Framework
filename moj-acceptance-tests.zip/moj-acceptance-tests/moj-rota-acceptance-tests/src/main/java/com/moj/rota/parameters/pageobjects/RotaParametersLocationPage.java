package com.moj.rota.parameters.pageobjects;

import java.util.List;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.moj.common.pageobjects.MOJBasePage;

public class RotaParametersLocationPage extends MOJBasePage {

	private static int isDeleteCount=0;
	public RotaParametersLocationPage(WebDriver driver) {
		super(driver);
		
	}
	
	@FindBy(id = "locationsTab")
	private WebElement locationTab;
	
	@FindBy(id = "rotaPeriodsTab")
	private WebElement rotaPeriods;
	
	@FindBy(id = "benchChairsTab")
	private WebElement bechAndChair;
	
	@FindBy(id = "localBenchCompositionTab")
	private WebElement localBenchChair;
	
	@FindBy(id = "combinedYouthPanelsTab")
	private WebElement combinedYouthPanels;
	
	@FindBy(css = ".container>h1")
	private WebElement rotaparametsTitle;
	
	@FindBy(css = "div[id*='lja-panel-'] > div > h3 > a > strong")
	private List<WebElement> ljaNorth;
	
	@FindBy(css = "div[id*='lja-panel-'] > div > h3 > a > strong")
	private List<WebElement> ljaSouth;
	
	@FindBy(css = "div[id*='combinedPanel-panel-'] > div > h3 > a > strong")
	private List<WebElement> dfja;
	
	@FindBy(css = "input[id*='locationSearch']")
	private WebElement ljaNorthLocation;
	
	@FindBy(css = "input[id*='locationSearch']")
	private WebElement ljaSouthLocation;
	
	@FindBy(css = "input[id*='combinedPanelLocationSearch']")
	private WebElement dfjaLocation;
	
	@FindBy(id = "primary-location-add-btn")
	private WebElement ljaNorthAndSouthAddButton;
		
	@FindBy(id = "combinedPanelLocation-add-btn")
	private WebElement dfjaAddButton;
	
	@FindBy(css = "tr:nth-child(1) .label.label-default.hand-hover")
	private WebElement ljaNorthLocationName;
	
	@FindBy(css = "tr:nth-child(1) .label.label-default.hand-hover")
	private WebElement ljaSouthLocationName;
	
	@FindBy(css = "div[id*='combinedPanelLocation-line-'] > div > span")
	private WebElement dfjaLocationName;
	
	@FindBy(css = "input[id*='checkbox-locationPanel-']")
	private List<WebElement> ljaNorthAdult;
	
	@FindBy(css = "input[id*='checkbox-locationPanel-']")
	private List<WebElement> ljaSouthYouth;
	
	@FindBy(css = "label[id*='primaryLocationDuplicateErrorLabel']")
	private WebElement locationAlreadyAdded;
	
	@FindBy(css = "label[id*='combinedPanelInUseErrorLabel']")
	private WebElement dfjaAlreadyAdded;
	
	@FindBy(css = "span[id*='primary-location-remove-']")
	private List<WebElement> ljaNorthDelete;
	
	@FindBy(css = "span[id*='primary-location-remove-']")
	private List<WebElement> ljaSouthDelete;
	
	@FindBy(css = ".btn.btn-success.btn-sm.primary-location-remove")
	private WebElement deleteYes;
	
	@FindBy(css = ".btn.btn-default.btn-sm.primary-location-cancel-remove")
	private WebElement deleteNo;
	
	@FindBy(css = ".label.label-default.hand-hover")
	private List<WebElement> courtText;
	
	public void clickTabs(String tabName)
	{
		switch(tabName)
		{
		case"Location":
			click(locationTab);
			break;
		default:
			
		}
	}
	
	public BenchChairPage clickBenchChairTab()
	{
		waitForPage();
		waitForElementTobeClickable(bechAndChair);
		click(bechAndChair);
		return returnPageFactory(BenchChairPage.class);
	}
	
	public LocalBenchCompositionPage clickLocalBenchCompositionTab()
	{
		waitForPage();
		waitForElementTobeClickable(localBenchChair);
		click(localBenchChair);
		 return returnPageFactory(LocalBenchCompositionPage.class);
	}
	
	public CombinedYouthPanelsPage clickOnCombineYouthPanelTab()
	{
		waitForPage();
		waitForElementTobeClickable(combinedYouthPanels);
		click(combinedYouthPanels);
		 return returnPageFactory(CombinedYouthPanelsPage.class);
	}
	
	public String getRotaparametrsTitle()
	{
		return getTextFromWebElement(rotaparametsTitle);
	}
	
	public boolean isLocationsTabDisplayed()
	{
		return isElementDisplayed(locationTab);
	}
	
	public String getLocationsTitle(String location)
	{
		String locationTitle=null;
		switch(location)
		{
		case "Local Justice Area 5 North":
			locationTitle=getTextFromWebElement(ljaNorth.get(0));
			for(WebElement element:ljaNorth)
			{   
				locationTitle=getTextFromWebElement(element);
				if(locationTitle.equals(location))
				{
					break;	
				}
			}
			break;
		case "Local Justice Area 5 South":
			locationTitle=getTextFromWebElement(ljaSouth.get(1));
			for(WebElement element:ljaSouth)
			{   
				locationTitle=getTextFromWebElement(element);
				if(locationTitle.equals(location))
				{
					break;	
				}
			}
			break;
		case "Designated Family Centre 5":
			//locationTitle=getTextFromWebElement(dfja);
			for(WebElement element:dfja)
			{   
				locationTitle=getTextFromWebElement(element);
				if(locationTitle.equals(location))
				{
					break;	
				}
			}
			break;
		}
		return locationTitle;
	}
	
	public void clickLocation(String location)
	{
		waitForPage();
		switch(location)
		{
		case "Local Justice Area 5 North":
			//click(ljaNorth.get(0));
			for(WebElement southElement:ljaNorth)
			{   
				if(getTextFromWebElement(southElement).equals(location))
				{
					click(southElement);	
				}
			}
			break;
		case "Local Justice Area 5 South":
			//click(ljaSouth.get(1));
			for(WebElement southElement:ljaSouth)
			{   
				if(getTextFromWebElement(southElement).equals(location))
				{
					click(southElement);	
				}
			}
			break;
		case "Designated Family Centre 5":
			//click(dfja);
			for(WebElement southElement:dfja)
			{   
				if(getTextFromWebElement(southElement).equals(location))
				{
					click(southElement);	
				}
			}
			break;
		}
		
	}
	
	public void addNewLocation(String location,String operationType)
	{
		switch(location)
		{
		case "LJA 1 North Magistrates Court 1":
			addLocation(ljaNorthLocation,location);
			click(ljaNorthAndSouthAddButton);
			if(operationType.equals("Add"))
			{
			waitForPage();
			click(ljaNorthAdult.get(0));
			}
			break;
		case "LJA 1 South Magistrates Court 2":
			addLocation(ljaSouthLocation,location);
			click(ljaNorthAndSouthAddButton);
			if(operationType.equals("Add"))
			{
				waitForPage();
			click(ljaSouthYouth.get(0));
			}
			break;
		case "DFJA5 Location":
			addLocation(dfjaLocation,location);
			click(dfjaAddButton);
			
			break;
		}
				
	}

	private void addLocation(WebElement element,String location) {
		enterText(element, location);
		enterText(element, Keys.ARROW_DOWN.toString());
		enterText(element, Keys.ENTER.toString());
	}
	
	public String getNewlyAddedLocationName(String location)
	{
		String locationName=null;
		waitForPage();
		switch(location)
		{
		case "LJA 1 North Magistrates Court 1":
			waitForVisibilityOfElement(ljaNorthLocationName);
			locationName=getTextFromWebElement(ljaNorthLocationName);
			break;
		case "LJA 1 South Magistrates Court 2":
			waitForVisibilityOfElement(ljaSouthLocationName);
			locationName=getTextFromWebElement(ljaSouthLocationName);
			break;
		case "DFJA5 Location":
			waitForVisibilityOfElement(dfjaLocationName);
			locationName=getTextFromWebElement(dfjaLocationName);
			break;
		}
		return locationName;
				
	}
	
	public boolean getErrorLabel(String location)
	{
		boolean isErrorLable=false;
		waitForPageToLoad();
		switch(location)
		{
		case "LJA 1 North Magistrates Court 1":
		case "LJA 1 South Magistrates Court 2":
			isErrorLable=getTextFromWebElement(locationAlreadyAdded).contains("Location already added");
			break;
		case "DFJA1 Location":
			isErrorLable=getTextFromWebElement(dfjaAlreadyAdded).contains("Location already in use by another combined family panel");
			break;
		}
		return isErrorLable;
				
	}
	
	public void deleteLocation(String location) {
		waitForPageToLoad();
		switch (location) {
		case "LJA 1 North Magistrates Court 1":
			waitForPage();
			isDeleteCount=courtText.size();
			for(int i=0;i<courtText.size();i++)
			{
				if(getTextFromWebElement(courtText.get(i)).contains(location))
				{
					click(ljaNorthDelete.get(i));
					isDeleteCount=isDeleteCount+i;
				}
			}
			
			break;
		case "LJA 1 South Magistrates Court 2":
			waitForPage();
			isDeleteCount=courtText.size();
			for(int i=0;i<courtText.size();i++)
			{
				if(getTextFromWebElement(courtText.get(i)).contains(location))
				{
					click(ljaSouthDelete.get(i));
					
				}
			}
			break;

		}

	}
	
	public void confirmDeleteLocation(String location) {
		waitForPageToLoad();
		switch (location) {
		case "Yes":
			click(deleteYes);
			break;
		case "No":
			isDeleteCount=isDeleteCount-1;
			click(deleteNo);
			break;

		}

	}
	
	public boolean isLocationDisplayed(String location) {
		waitForPage();
		boolean isLocationDisplayed=false;
		switch (location) {
		case "LJA 1 North Magistrates Court 1":
			isLocationDisplayed=ljaNorthDelete.size()==isDeleteCount;
			break;
		case "LJA 1 South Magistrates Court 2":
			isLocationDisplayed=ljaSouthDelete.size()==isDeleteCount;
			break;

		}
		return isLocationDisplayed;

	}
}
