package com.moj.rota.parameters.pageobjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.moj.common.pageobjects.MOJBasePage;

public class LocalBenchCompositionPage extends MOJBasePage {

	public LocalBenchCompositionPage(WebDriver driver) {
		super(driver);
		
	}
		
	@FindBy(id = "localBenchCompositionTab")
	private WebElement localBenchChairCompositionTab;
		
	@FindBy(css = "div[id*='bench-composition-panel-'] > div.panel-heading > h3 > a > strong")
	private List<WebElement> ljaNorth;
	
	@FindBy(css = "div[id*='bench-composition-panel-'] > div.panel-heading > h3 > a > strong")
	private List<WebElement> ljaSouth;
	
	@FindBy(id = "add-bench-composition-btn")
	private WebElement addButton;
	
	@FindBy(css = "div[id*='bench-composition-collapsable-'] > div > div:nth-child(3) > div:nth-child(1) > select")
	private WebElement panelType;
	
	@FindBy(css = "div[id*='bench-composition-collapsable-'] > div > div:nth-child(3) > div:nth-child(2) > select")
	private WebElement specialAuthority;
	
	@FindBy(css = "input[type*='checkbox']")
	private List<WebElement> roleCheckboxes;
	
	@FindBy(id = "remove-bench-composition")
	private WebElement removeComposition;
	
			
	public boolean isLocalBenchCompositionDisplayed()
	{
		return isElementDisplayed(localBenchChairCompositionTab);
	}
	
	public boolean isPanelTypeExist()
	{
		waitForPage();
		return isElementNotDisplayed(panelType);
	}
	
	public String getLocationsTitle(String location)
	{
		String locationTitle=null;
		switch(location)
		{
		case "Local Justice Area 5 North":
			//locationTitle=getTextFromWebElement(ljaNorth.get(0));
			for(WebElement element:ljaNorth)
			{   
				locationTitle=getTextFromWebElement(element);
				if(locationTitle.equals(location))
				{
					break;	
				}
			}
			break;
		case "Local Justice Area 5 South":
			//locationTitle=getTextFromWebElement(ljaSouth.get(1));
			for(WebElement element:ljaSouth)
			{   
				locationTitle=getTextFromWebElement(element);
				if(locationTitle.equals(location))
				{
					break;	
				}
			}
			break;
		}
		return locationTitle;
	}
	
	public void clickLJALocation(String location)
	{
		switch(location)
		{
		case "Local Justice Area 5 North":
			//click(ljaNorth.get(0));
			for(WebElement element:ljaNorth)
			{   
				if(getTextFromWebElement(element).equals(location))
				{
					click(element);	
				}
			}
			break;
		case "Local Justice Area 5 South":
			//click(ljaSouth.get(1));
			for(WebElement southElemnt:ljaSouth)
			{   
				if(getTextFromWebElement(southElemnt).equals(location))
				{
					click(southElemnt);	
				}
			}
			break;
		
		}
		
	}
		
	
	public void clickOnAddButton()
	{
		click(addButton);
	}
	
	public void clickonRemoveButton()
	{
		waitForPageToLoad();
		click(removeComposition);
	}
	
	public void selectPanelType(String panelTypeToSelect)
	{
		waitForPageToLoad();
		selectDropDown(panelType, panelTypeToSelect);
	}
	
	public void selectSpecialRequirements(String specialReqToSelect)
	{
		waitForPageToLoad();
		selectDropDown(specialAuthority, specialReqToSelect);
	}
	
	public void clickRoleCheckBoxes()
	{
		waitForPage();
		for(int i=0;i<roleCheckboxes.size();i++)
		{
			waitForPage();
			waitForElementTobeClickable(roleCheckboxes.get(i));
			click(roleCheckboxes.get(i));
		}
	}
	
	public String getSelectedPanelType()
	{
		return getSelectedDropDownOption(panelType);
	}
	
	public String getSpecialAuthorityType()
	{
		return getSelectedDropDownOption(specialAuthority);
	}
	
	public boolean getStatusOfRoleCheckBoxes()
	{
		boolean isCheckBoxStatus=false;
		boolean status=false;
		for(int i=0;i<roleCheckboxes.size();i++)
		{
			isCheckBoxStatus=getStatusOfCheckBox(roleCheckboxes.get(i));
			if(!isCheckBoxStatus)
			{
				status=true;
			}
		}
		
		//checking any check box contains false the setting checkbox status to false;
		if(status)
		{
			isCheckBoxStatus=false;
		}
		
		return isCheckBoxStatus;
		
	}
	
}
