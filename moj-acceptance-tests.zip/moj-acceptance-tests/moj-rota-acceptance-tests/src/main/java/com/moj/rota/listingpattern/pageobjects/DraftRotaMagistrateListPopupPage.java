package com.moj.rota.listingpattern.pageobjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.moj.rota.pageobjects.MagistratePersonalDetailsPage;
import com.moj.rota.pageobjects.MagistrateSittingEligibiltyPage;
import com.moj.rota.pageobjects.MagistrateSittingPrefecencesPage;

public class DraftRotaMagistrateListPopupPage extends RotaListingPatternBasePage {

	private static int popUpDJCount = 0;

	public DraftRotaMagistrateListPopupPage(WebDriver driver) {
		super(driver);
		if (!requirementsVal.equals("Winger1Winger2") && !requirementsVal.equals("DJ1")
				&& !requirementsVal.equals("SameVenuePM") && !requirementsVal.equals("DifferentVenueAM")) {
			waitForVisibilityOfElement(magSearchOnPopUp);
		}
		waitForPageToLoad();
	}

	@FindBy(css = "#magistrateList tr:nth-child(1) > td:nth-child(1) > div > a > b")
	private WebElement searchMagTypeWinger;

	@FindBy(css = "#magistrateList tr:nth-child(2) > td:nth-child(1) > div > a > b")
	private WebElement searchMagEligibilityWinger;

	@FindBy(css = "#magistrateList tr:nth-child(1) > td:nth-child(1) > div > ul > li:nth-child(2) > a")
	private WebElement selectPreferences;

	@FindBy(css = "#magistrateList tr:nth-child(2) > td:nth-child(1) > div > ul > li:nth-child(1) > a")
	private WebElement selectPersonaDetails;

	@FindBy(css = "#magistrateList tr:nth-child(2) > td:nth-child(1) > div > ul > li:nth-child(3) > a")
	private WebElement selectEligibility;

	@FindBy(css = "#magistrateList tr:nth-child(1) > td:nth-child(1) > div > ul > li:nth-child(3) > a")
	private WebElement selectChairEligibility;

	@FindBy(id = "fix-close-btn-chair")
	private WebElement closeChairMagistrateList;

	@FindBy(id = "fix-close-btn-winger1")
	private WebElement closeMagistrateList;

	@FindBy(id = "fix-close-btn-winger2")
	private WebElement closeMagistrateList2;

	@FindBy(css = "Button[id*='select-magistrate-btn-']")
	private List<WebElement> selectMagistrate;

	@FindBy(css = "#magistrateList tr > td:nth-child(1) > span.badge.badge-warning")
	public List<WebElement> listOfMagistratesForNW;

	@FindBy(css = "#magistrateList tr > td:nth-child(1) > span.badge.badge-success.profile-tooltip")
	public List<WebElement> listOfSpecialRequirements;

	@FindBy(css = "#magistrateList tr > td:nth-child(1) > span.badge.badge-danger")
	public List<WebElement> listOfTraineeChairs;

	@FindBy(css = "#magistrateList tr:nth-child(2) > td:nth-child(1) > span.badge.badge-danger")
	public WebElement welshLanguage;

	@FindBy(css = "div[id*='magistrate-select-districtJudge-content-']")
	public WebElement djSearchResultsText;

	@FindBy(id = "slot-search-filter-mentor")
	public WebElement mentofrFilter;
	
	@FindBy(id = "slot-search-filter-appraiser")
	public WebElement appriaserFilter;
	
	@FindBy(id = "magNameFilter")
	public WebElement magSearchOnPopUp;
	
	@FindBy(css = "tr[id*='magistrate-row-'] > td:nth-child(1) > span:nth-child(4)")
	public List<WebElement> filterAprResult;
	
	@FindBy(css = "tr[id*='magistrate-row-'] > td:nth-child(1) > span:nth-child(5)")
	public List<WebElement> filterMenResult;
	
	@FindBy(css = "tr[id*='magistrate-row-'] > td:nth-child(1) > span:nth-child(1)")
	public List<WebElement> firstFilterResult;
	
	@FindBy(id = "magNameFilter")
	public WebElement searchMag;

	public void clickMagistrate(String requirements) {
		switch (requirements) {
		case "Special Requirements":
		case "Trainee Chair":
			click(searchMagTypeWinger);
			break;
		case "New Winger":
		case "Local Authority":
			click(searchMagEligibilityWinger);
			break;
		default:

		}

	}

	public MagistrateSittingPrefecencesPage selectMagistratePreferences() {
		waitForPageToLoad();
		click(selectPreferences);
		return returnPageFactory(MagistrateSittingPrefecencesPage.class);
	}

	public MagistratePersonalDetailsPage selectMagistratePersonalDetails() {
		waitForPageToLoad();
		click(selectPersonaDetails);
		return returnPageFactory(MagistratePersonalDetailsPage.class);
	}

	public RotaListingPatternPage closeMagistrateList(String requirements) {
		if (requirements.equals("Trainee Chair")) {
			click(closeChairMagistrateList);
		} else if (requirements.equals("Local Authority")) {

			click(closeMagistrateList2);
		} else {
			click(closeMagistrateList);
		}

		return returnPageFactory(RotaListingPatternPage.class);
	}

	public RotaListingPatternPage selectMagistrate(String requirementType) {
		// waitForVisibilityOfElement(magSearchOnPopUp);
		switch (requirementType) {
		case "Special Requirements":

			for (int index = 0; index < listOfSpecialRequirements.size(); index++) {
				if (getTextFromWebElement(listOfSpecialRequirements.get(index)).equals("S")) {
					click(selectMagistrate.get(index));
					break;
				}
			}
			break;
		case "New Winger":
			waitForPage();
			for (int index = 0; index < listOfMagistratesForNW.size(); index++) {
				if (getTextFromWebElement(listOfMagistratesForNW.get(index)).equals("NW")) {
					click(selectMagistrate.get(index));
					break;
				}
			}

			break;
		case "Trainee Chair":
			waitForPage();
			for (int index = 0; index < listOfTraineeChairs.size(); index++) {
				if (getTextFromWebElement(listOfTraineeChairs.get(index)).equals("TC")) {
					click(selectMagistrate.get(index));
					break;
				}
			}

			break;
		case "Local Authority":
			waitForPage();
			click(selectMagistrate.get(1));
			break;
		case "Winger1":
		case "Winger2":
			waitForPage();
			click(selectMagistrate.get(0));
			waitForPage();
			break;
		case "Winger1Winger2":
			waitForPageToLoad();
			implicitWait(5);
			if (searchMagTypeWingerForMatching.size() > 1) {
				waitForElementTobeClickable(searchMagTypeWingerForMatching.get(1));
				click(searchMagTypeWingerForMatching.get(1));
			} else {
				waitForElementTobeClickable(searchMagTypeWingerForMatching.get(0));
				click(searchMagTypeWingerForMatching.get(0));
			}
			waitForVisibilityOfElement(magSearchOnPopUp);
			waitForPageToLoad();

			implicitWait(5);
			click(selectMagistrate.get(0));
			waitForPageToLoad();
			waitForVisibilityOfAllElement(searchMagTypeLocalAuthorityrForMatching);
			if (searchMagTypeLocalAuthorityrForMatching.size() > 1) {
				waitForPage();
				waitForElementTobeClickable(searchMagTypeLocalAuthorityrForMatching.get(1));
				click(searchMagTypeLocalAuthorityrForMatching.get(1));

			} else {
				waitForPage();
				waitForElementTobeClickable(searchMagTypeLocalAuthorityrForMatching.get(0));
				click(searchMagTypeLocalAuthorityrForMatching.get(0));
			}
			waitForVisibilityOfElement(magSearchOnPopUp);
			waitForElementTobeClickable(selectMagistrate.get(0));
			click(selectMagistrate.get(0));
			break;
		case "DJ1":
			waitForPageToLoad();
			click(djSitting.get(0));
			waitForPageToLoad();
			click(selectMagistrate.get(0));
			break;
		case "SameVenuePM":
			waitForPageToLoad();
			waitForPage();
			click(djSitting.get(1));
			break;
		case "DifferentVenueAM":
			waitForPage();
			waitForPageToLoad();
			click(djSitting.get(3));
			break;
		default:
		}
		waitForPageToLoad();
		return returnPageFactory(RotaListingPatternPage.class);
	}

	public MagistrateSittingEligibiltyPage selectMagistrateEligibility(String requirements) {
		waitForPageToLoad();
		if (requirements.equals("Trainee Chair")) {
			click(selectChairEligibility);
		} else {
			click(selectEligibility);
		}

		return returnPageFactory(MagistrateSittingEligibiltyPage.class);
	}

	public boolean isNewWingerExists() {
		boolean isNewWingerExists = false;
		for (WebElement element : listOfMagistratesForNW) {
			if (getTextFromWebElement(element).equals("NW")) {
				isNewWingerExists = true;
				break;
			}
		}
		return isNewWingerExists;
	}

	public boolean isSpecialRequirements() {
		boolean isSpecialReqirementsExists = false;
		for (WebElement element : listOfSpecialRequirements) {
			if (getTextFromWebElement(element).equals("S")) {
				isSpecialReqirementsExists = true;
				break;
			}
		}
		return isSpecialReqirementsExists;
	}

	public boolean isTraineeChain() {
		boolean isTraineeChairExists = false;
		for (WebElement element : listOfTraineeChairs) {
			if (getTextFromWebElement(element).equals("TC")) {
				isTraineeChairExists = true;
				break;
			}
		}
		return isTraineeChairExists;
	}

	public boolean isDistrictJudgeSearchResultsDisplayed() {
		// getting DJ count to compare DJ in getDJSearchResultsNotDisplayed()
		popUpDJCount = selectMagistrate.size();
		return selectMagistrate.size() > 0;
	}

	public boolean getDJSearchResultsNotDisplayed() {
		// comparing with earlier dj count .Making sure count should be lesser
		// than earlier search
		waitForVisibilityOfElement(magSearchOnPopUp);
		return popUpDJCount > selectMagistrate.size();
	}
	
	//pen icon search
	
	public void clickFilter(String filterType)
	{
		switch(filterType)
		{
		case "Appriaser":
			click(appriaserFilter);
			break;
		case "Mentor":
			click(mentofrFilter);
			break;
			
		}
	}
	
	public String getFilterTypeResult(String filterType)
	{
		String filterResult=null;
		switch(filterType)
		{
		case "Apr":
			filterResult=getTextFromWebElement(filterAprResult.get(0));
			break;
		case "Men":
			filterResult=getTextFromWebElement(filterAprResult.get(0));
			break;
			
		}
		return filterResult;
	}
	
	public void enterMagistrateName()
	{
		String magName=getTextFromWebElement(firstFilterResult.get(0));
		enterText(searchMag, magName);
	}
	
	public String getSearchResultMagName()
	{
		waitForPage();
		return getTextFromWebElement(firstFilterResult.get(0));
	}

}
