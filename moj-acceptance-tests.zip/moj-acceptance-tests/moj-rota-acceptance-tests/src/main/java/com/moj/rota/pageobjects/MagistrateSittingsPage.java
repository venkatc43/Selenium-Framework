package com.moj.rota.pageobjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.moj.common.pageobjects.MOJBasePage;

public class MagistrateSittingsPage extends MOJBasePage {
	private static String winHandleBefore = null;
	private static int vacatedMagSize = 0;

	public MagistrateSittingsPage(WebDriver driver) {
		super(driver);
		winHandleBefore = driver.getWindowHandle();
		//switchToNewWindow();
		if(isElementNotDisplayed(switchFrame))
		{
		switchToIFrame(switchFrame);
		}
	}

	@FindBy(css = "#sittingRow-0 > td:nth-child(3)")
	private WebElement location;

	@FindBy(css = "#sittingRow-0 > td:nth-child(4)")
	private WebElement panelType;

	@FindBy(css = "#sittingRow-4>td:nth-child(4)")
	private WebElement filterPanelType;

	@FindBy(css = "#sittingRow-1 > td:nth-child(5)")
	private WebElement businessType;

	@FindBy(css = "#sittingRow-0 > td:nth-child(6)")
	private WebElement role;

	@FindBy(css = "#sittingRow-0 > td:nth-child(7)")
	private WebElement sittingsType;

	@FindBy(css = "#sittingRow-0 > td:nth-child(8)")
	private WebElement sittingsIdentifier;

	@FindBy(css = "#sittingRow-0 > td:nth-child(2)")
	private WebElement date;

	@FindBy(css = "#sittingRow-0 > td:nth-child(1)")
	private WebElement districtJudgedate;

	@FindBy(css = ".col-xs-12.col-sm-12.col-md-12.col-lg-12.key")
	private WebElement filters;

	@FindBy(css = "#wrap > div > h1")
	private WebElement pageTitle;

	@FindBy(id = "singleJustice-filterToggle")
	private WebElement singleJustice;

	@FindBy(id = "welsh-filterToggle")
	private WebElement welsh;

	@FindBy(id = "returningBench-filterToggle")
	private WebElement returningBench;

	@FindBy(id = "lastSitting-filterToggle")
	private WebElement lastSitting;

	@FindBy(id = "applications-filterToggle")
	private WebElement applications;

	@FindBy(id = "chair-filterToggle")
	private WebElement chair;

	@FindBy(id = "winger-filterToggle")
	private WebElement winger;

	@FindBy(id = "adult-filterToggle")
	private WebElement adult;

	@FindBy(id = "family-filterToggle")
	private WebElement family;

	@FindBy(id = "youth-filterToggle")
	private WebElement youth;

	@FindBy(id = "AS-filterToggle")
	private WebElement appraisedSitting;

	@FindBy(id = "TAS-filterToggle")
	private WebElement thresholdSitting;

	@FindBy(id = "APR-filterToggle")
	private WebElement apparaiser;

	@FindBy(id = "XAPR-filterToggle")
	private WebElement crossBechAppraiser;

	@FindBy(id = "MS-filterToggle")
	private WebElement mentorSitting;

	@FindBy(id = "MEN-filterToggle")
	private WebElement mentor;

	@FindBy(id = "SS-filterToggle")
	private WebElement suppoertedSitting;

	@FindBy(id = "SUP-filterToggle")
	private WebElement supportingMagistrate;

	@FindBy(id = "vacated-filterToggle")
	private WebElement vacated;

	@FindBy(id = "cancelled-filterToggle")
	private WebElement cancelled;

	@FindBy(id = "confirmed-filterToggle")
	private WebElement confirmed;

	@FindBy(id = "scheduled-filterToggle")
	private WebElement scheduled;

	@FindBy(id = "specialRequirementsText")
	private WebElement specialRequirementComments;

	@FindBy(id = "mag-sitting-requirements-finish-btn")
	private WebElement saveButton;

	@FindBy(id = "sittingPatternCrossError")
	private WebElement weeklyAndHalfDayWarning;

	@FindBy(id = "sittingPatternFullError")
	private WebElement selectAllWeekDaysWarning;

	@FindBy(id = "total-sittings")
	private WebElement totalSittings;

	@FindBy(css = "#content > div > h1")
	private WebElement djPageTitle;

	@FindBy(css = ".glyphicon.glyphicon-share.text-muted.profile-tooltip")
	private List<WebElement> tolateToCancel;

	@FindBy(css = "span[id^='vacateLink-']")
	private List<WebElement> cancelLink;

	@FindBy(id = "vacateSittingReason")
	private WebElement vacateSittingReason;

	@FindBy(id = "vacate-sitting-btn")
	private WebElement vacateConfirm;

	@FindBy(id = "cancel-vacate-sitting-btn")
	private WebElement vacateCancel;

	@FindBy(css = "#sittingRow-0 > td:nth-child(7) > span")
	private List<WebElement> vacatedMessage;

	@FindBy(css = "span[class*='glyphicon-link']")
	private List<WebElement> linkedCourtSessions;

	@FindBy(css = "tr[id*='sittingRow-'] > td:nth-child(2)")
	private List<WebElement> dateOfSession;

	@FindBy(css = "tr[id*='sittingRow-'] > td:nth-child(1)")
	private List<WebElement> scheduledSession;
	
	@FindBy(id = "dateRangeStartDate")
	private WebElement sittingFrom;
	
	@FindBy(id = "dateRangeEndDate")
	private WebElement sittingsTo;
	
	@FindBy(id = "search-btn")
	private WebElement searchButton;
	
	@FindBy(css = ".col-xs-12.col-sm-12.col-md-12.col-lg-12")
	private WebElement errorMessage;
	
	@FindBy(id = "dateRangeStartDateError")
	private WebElement dateRangeStartError;

	public boolean isPageFieldsDisplayed(String pageFields, boolean isDistrictJudge) {
		boolean isElemtDisplayed = false;
		waitForPage();
		switch (pageFields) {
		case "location":
			if (isDistrictJudge) {
				// trying to use same locator dont confuse ,we are checking
				// location displayed or not
				isElemtDisplayed = isWebElementDisplayed(date);
			} else {
				isElemtDisplayed = isWebElementDisplayed(location);
			}

			break;
		case "panel_type":
			if (isDistrictJudge) {
				isElemtDisplayed = isWebElementDisplayed(location);
			} else {
				isElemtDisplayed = isWebElementDisplayed(panelType);
			}

			break;
		case "Role":
			isElemtDisplayed = isWebElementDisplayed(role);
			break;
		case "Sitting Type":
			if (isDistrictJudge) {
				isElemtDisplayed = isWebElementDisplayed(businessType);
			} else {
				isElemtDisplayed = isWebElementDisplayed(sittingsType);
			}
			break;
		case "business type":
			if (isDistrictJudge) {
				isElemtDisplayed = isWebElementDisplayed(panelType);
			} else {
				isElemtDisplayed = isWebElementDisplayed(businessType);
			}

			break;
		case "filters":
			isElemtDisplayed = isWebElementDisplayed(filters);
			break;
		case "date":
			if (isDistrictJudge) {
				isElemtDisplayed = isWebElementDisplayed(districtJudgedate);
			} else {
				isElemtDisplayed = isWebElementDisplayed(date);
			}
			break;
		case "Sittings From":
			if (isDistrictJudge) {
				isElemtDisplayed = isWebElementDisplayed(sittingFrom);
			} 
			break;
		case "Sittings To":
			if (isDistrictJudge) {
				isElemtDisplayed = isWebElementDisplayed(sittingsTo);
			} 
			break;

		default:
			System.out.println("No elements displyed");

		}

		return isElemtDisplayed;
	}

	public boolean isSittingsPageDisplayed() {
		return isElementDisplayed(pageTitle);
	}

	public boolean isDJSittingsPageDisplayed() {
		return isElementDisplayed(djPageTitle);
	}

	public boolean clickFilterColumns(String pageFields, boolean isDistrictJudge) {
		boolean isresultsDisplayed = false;
		switch (pageFields) {
		case "Welsh":
			isresultsDisplayed = getFilterResults(welsh, sittingsType);
			click(welsh);
			waitForPage();
			break;
		case "Returning Bench":
			if (isDistrictJudge) {
				waitForPage();
				isresultsDisplayed = getFilterResults(returningBench, businessType);
			} else {
				isresultsDisplayed = getFilterResults(returningBench, sittingsType);
			}
			click(returningBench);
			waitForPage();
			break;
		case "Last Sitting":
			if (isDistrictJudge) {
				isresultsDisplayed = getFilterResults(lastSitting, businessType);
			} else {
				isresultsDisplayed = getFilterResults(lastSitting, sittingsType);
			}

			click(lastSitting);
			waitForPage();
			break;
		case "Applications":
			isresultsDisplayed = getFilterResults(applications, sittingsType);
			click(applications);
			waitForPage();
			break;
		case "Winger":
			isresultsDisplayed = getFilterResults(winger, role);
			click(winger);
			waitForPage();
			break;
		case "Adult":
			if (isDistrictJudge) {
				isresultsDisplayed = getFilterResults(adult, location);
			} else {
				isresultsDisplayed = getFilterResults(adult, panelType);
			}

			click(adult);
			waitForPage();
			break;
		case "Youth":
			isresultsDisplayed = getFilterResults(youth, filterPanelType);
			click(youth);
			waitForPage();
			break;
		case "Appraiser":
			isresultsDisplayed = getFilterResults(apparaiser, sittingsIdentifier);
			click(apparaiser);
			waitForPage();
			break;
		case "Scheduled":
			isresultsDisplayed = getFilterResults(scheduled, location);
			click(scheduled);
			waitForPage();
			break;
		default:
			System.out.println("No elements displyed");

		}

		return isresultsDisplayed;
	}

	public void clickOnFilterFlagColumns(String pageFields) {
		switch (pageFields) {
		case "Supporting a Magistrate":
			click(supportingMagistrate);
			waitForPageToLoad();
			break;
		case "Supported sitting":
			click(suppoertedSitting);
			waitForPageToLoad();
			break;
		case "Chair":
			click(chair);
			waitForPageToLoad();
			break;
		case "Confirmed":
			click(confirmed);
			waitForPageToLoad();
			break;
		case "Mentor":
			click(mentor);
			waitForPageToLoad();
			break;
		case "Mentored sitting":
			click(mentorSitting);
			waitForPageToLoad();
			break;
		case "Threshold Appraised Sitting":
			click(thresholdSitting);
			waitForPageToLoad();
			break;
		case "Family":
			click(family);
			waitForPageToLoad();
			break;
		case "Single Justice":
			click(singleJustice);
			waitForPageToLoad();
			break;
		case "Cross-Bench Appraiser":
			click(crossBechAppraiser);
			waitForPageToLoad();
			break;
		case "Vacated":
			click(vacated);
			waitForPageToLoad();
			break;
		case "Cancelled":
			click(cancelled);
			waitForPageToLoad();
			break;

		default:
			System.out.println("No elements displyed");

		}

	}

	private boolean getFilterResults(WebElement filterElement, WebElement filterResults) {
		boolean isResults;
		click(filterElement);
		waitForVisibilityOfElement(filterResults);
		waitForPage();
		isResults = getTextFromWebElement(filterResults).length() > 0;
		return isResults;
	}

	public boolean getNotConfirmedMagistrate() {
		boolean isResults = false;
		waitForVisibilityOfElement(totalSittings);
		isResults = getTextFromWebElement(totalSittings).equals("0");
		return isResults;
	}

	public void clickToLateToCancel() {
		waitForPage();
		mouseHover(tolateToCancel.get(0));
		waitForPage();
	}

	public String getValidationMessage() {
		String toolTipText = tolateToCancel.get(0).getAttribute("data-original-title");
		return toolTipText;
	}

	public String getVacatedMessage() {
		String toolTipText = tolateToCancel.get(0).getAttribute("data-original-title");
		return toolTipText;
	}

	public void enterReason(String vacateReasonVal) {
		enterText(vacateSittingReason, vacateReasonVal);
	}

	public void clickVacated(String status) {
		switch (status) {
		case "Cancel":
			click(vacateCancel);
			break;
		case "Confirm":
			click(vacateConfirm);
			break;
		}
	}

	public void clickVacated() {
		vacatedMagSize = cancelLink.size();
		click(cancelLink.get(0));

		String date = "";

	}

	public boolean isVacated(String status) {
		boolean isVacateLinks = false;
		waitForPage();
		switch (status) {
		case "Cancel":
			isVacateLinks = vacatedMagSize == cancelLink.size();
			break;
		case "Confirm":
			isVacateLinks = vacatedMagSize != cancelLink.size();
			break;
		}

		return isVacateLinks;

	}

	public boolean isVacatedMessageDisplayed() {
		waitForPage();
		mouseHover(vacatedMessage.get(0));
		waitForPage();

		return vacatedMessage.get(0).getAttribute("data-original-title").length() > 0;

	}
	
	public void enterDateRange(String from,String to)
	{
		if(from!=null)
		{
			enterText(sittingFrom, from);	
		}
		
		if(to!=null)
		{
		enterText(sittingsTo, to);
		pressTab();
		}
	}
	
	public void clickOnSearch()
	{
		click(searchButton);
	}
	
	public String getErrorMessage()
	{
		return getTextFromWebElement(errorMessage);
	}
	
	public String getErrorMessage(String message) {

		if (message.equals("No scheduled sittings.")) {
			return getTextFromWebElement(errorMessage);
		} else {
			return getTextFromWebElement(dateRangeStartError);
		}

	}
	
	
}
