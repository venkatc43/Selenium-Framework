package com.moj.rota.listingpattern.pageobjects;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class RotaListingAndDrfatRotaBasePage extends RotaListingPatternBasePage {

	public RotaListingAndDrfatRotaBasePage(WebDriver driver) {
		super(driver);
		waitForPageToLoad();

	}

	// all the elements are coming from base page

	public void selectPanelBusinessBasedOnDay(String dayName, String panel, String businessTypeVal, String sessions) {
		waitForPage();
		waitForVisibilityOfElement(panelType);
		selectDropDown(panelType, panel);
		waitForPage();
		pressTab();
		waitForVisibilityOfElement(businessType);
		selectDropDown(businessType, businessTypeVal);
		waitForPage();
		pressTab();
		waitForVisibilityOfElement(numberOfSessions);
		selectDropDown(numberOfSessions, sessions);
		waitForPage();
		waitForElementTobeClickable(saveSession);
		waitForPage();
		click(saveSession);
		waitForPage();
	}

	public void selectLanguageAndJustice(String justiceType, String dayName, String dayPattern) {
		waitForPage();
		waitForPage();
		switch (dayName) {
		case "Monday":
			if (dayPattern.equals("AM")) {
				click(walesLanguage.get(0));
				waitForPage();
				click(districtJudge.get(0));
			} else {
				click(singleJustice.get(0));
			}

			break;
		case "TuesDay":
			if (dayPattern.equals("AM")) {
				click(walesLanguage.get(0));

			} else {
				click(singleJustice.get(0));

			}
			break;
		case "Wednesday":
			if (dayPattern.equals("AM")) {
				click(walesLanguage.get(1));
				waitForPage();
				click(districtJudge.get(0));
			} else {
				click(singleJustice.get(1));
			}

			break;
		case "Thursday":
			if (dayPattern.equals("AM")) {
				click(walesLanguage.get(2));
				waitForPage();
				click(districtJudge.get(1));
			} else {
				click(singleJustice.get(2));
			}
			break;
		case "Saturday":
			if (dayPattern.equals("AM")) {
				click(walesLanguage.get(5));
			} else {
				click(singleJustice.get(3));
			}

			break;

		}
		waitForPage();

	}

	public boolean isLinkedSessionDisplayed(String dayName, String operationType, String dayPattern) {
		boolean isLinkSessionDisplayed = false;
		switch (dayName) {
		case "Monday":
			if (dayPattern.equals("AM") && operationType.equals("Add")) {
				isLinkSessionDisplayed = monSatSunLinkedSessionInfo.size() > 0;
			} else {
				isLinkSessionDisplayed = isElementNotDisplayed(linkedSessionInfo.get(0));
			}

			break;
		case "TuesDay":
			if (dayPattern.equals("AM") && operationType.equals("Add")) {
				if (linkedSessionInfo.size() > 0) {
					isLinkSessionDisplayed = isElementNotDisplayed(linkedSessionInfo.get(0));
				}
			} else {
				isLinkSessionDisplayed = isElementNotDisplayed(linkedSessionInfo.get(3));
			}
			break;
		case "Wednesday":
			if (dayPattern.equals("AM") && operationType.equals("Add")) {
				isLinkSessionDisplayed = isElementNotDisplayed(linkedSessionInfo.get(0));
			} else {
				isLinkSessionDisplayed = isElementNotDisplayed(linkedSessionInfo.get(6));
			}

			break;
		case "Thursday":
			if (dayPattern.equals("AM") && operationType.equals("Add")) {
				isLinkSessionDisplayed = isElementNotDisplayed(linkedSessionInfo.get(0));
			} else {
				isLinkSessionDisplayed = isElementNotDisplayed(linkedSessionInfo.get(8));
			}

			break;
		case "Friday":
			isLinkSessionDisplayed = isElementNotDisplayed(monSatSunLinkedSessionInfo.get(0));
			break;
		case "Saturday":
			// looking for linked image ,if it is not available then it is
			// single session
			isLinkSessionDisplayed = monSatSunLinkedSessionInfo.size() > 0;
			break;
		case "Sunday":
			if (dayPattern.equals("AM") && operationType.equals("Delete")) {
				isLinkSessionDisplayed = isElementNotDisplayed(linkedSessionInfo.get(0));
			} else {
				isLinkSessionDisplayed = monSatSunLinkedSessionInfo.size() > 0;
			}

			break;
		}

		return isLinkSessionDisplayed;
	}

	// Rota Profile

	public void clickOnGenerateButton() {
		generateRotaButton.sendKeys(Keys.ENTER);
		//click(generateRotaButton);
	}

	public void clickOnConfirmButton() {
		waitForPageToLoad();
		click(confirmButton);
	}

	public String getRotaProfileTitle() {
		return getTextFromWebElement(rotaProfileTitle);
	}

	public boolean isRotaPeriod() {
		return isElementDisplayed(rotaPeriod);
	}

	public boolean isRotaAbortButton() {
		return isElementDisplayed(rotaAbortButton);
	}

	public void clcickNextWeekButton(String weekNumber) {
		boolean isBankHoliday = false;
		waitForPageToLoad();
		switch (weekNumber) {
		case "1 week":
			waitForPage();
			waitForElementTobeClickable(nextWeekButton.get(0));
			waitForElementTobeClickable(plusSign.get(0));
			click(plusSign.get(0));
			waitForElementTobeClickable(minusSign.get(0));
			break;
		case "2 weeks":
			waitForPage();
			waitForElementTobeClickable(nextWeekButton.get(0));
			waitForElementTobeClickable(plusSign.get(0));
			click(nextWeekButton.get(0));
			waitForPage();
			waitForElementTobeClickable(previuosButton.get(0));
			waitForElementTobeClickable(plusSign.get(0));
			click(plusSign.get(0));
			waitForPage();
			waitForElementTobeClickable(minusSign.get(1));
			break;
		case "3 weeks":
			waitForPage();
			waitForElementTobeClickable(nextWeekButton.get(1));
			waitForElementTobeClickable(plusSign.get(1));
			click(nextWeekButton.get(1));
			waitForPage();
			waitForElementTobeClickable(previuosButton.get(1));
			waitForElementTobeClickable(plusSign.get(1));
			click(nextWeekButton.get(1));
			waitForPage();
			waitForElementTobeClickable(previuosButton.get(1));
			waitForElementTobeClickable(plusSign.get(1));
			click(plusSign.get(1));
			waitForPage();
			waitForElementTobeClickable(minusSign.get(1));
			break;
		case "4 weeks":
			waitForPage();
			waitForElementTobeClickable(nextWeekButton.get(2));
			waitForElementTobeClickable(plusSign.get(2));
			click(nextWeekButton.get(2));
			waitForPage();
			waitForElementTobeClickable(previuosButton.get(2));
			waitForElementTobeClickable(plusSign.get(2));
			click(nextWeekButton.get(2));
			waitForPage();
			waitForElementTobeClickable(previuosButton.get(2));
			waitForElementTobeClickable(plusSign.get(2));
			click(nextWeekButton.get(2));
			waitForPage();
			waitForElementTobeClickable(previuosButton.get(2));
			waitForElementTobeClickable(plusSign.get(2));
			click(plusSign.get(2));
			waitForElementTobeClickable(minusSign.get(2));
			waitForPage();
			break;

		case "2 weeks-Swap":
			waitForPage();
			waitForElementTobeClickable(nextWeekButton.get(1));
			waitForElementTobeClickable(plusSign.get(1));
			click(nextWeekButton.get(1));
			waitForPage();
			waitForElementTobeClickable(previuosButton.get(1));
			waitForElementTobeClickable(plusSign.get(1));
			click(plusSign.get(1));
			waitForPage();
			waitForElementTobeClickable(minusSign.get(1));
			break;
		}
		waitForPage();

		// if it is bank holiday moving forward to next 4 weeks
		if (isBankHoliday == true) {
			clcickNext4Weeks(weekNumber);
		}

	}

	public void clcickNext4Weeks(String weekNumber) {
		waitForPageToLoad();
		switch (weekNumber) {
		case "1 week":
			clickBankHolidayweek(0);
			break;
		case "2 weeks":
			clickBankHolidayweek(1);
			break;
		case "3 weeks":
			clickBankHolidayweek(2);
			break;
		case "4 weeks":
			clickBankHolidayweek(3);
			break;
		}
		waitForPageToLoad();
	}

	private void clickBankHolidayweek(int elementNumber) {
		click(nextWeekButton.get(elementNumber));
		waitForPageToLoad();
		waitForPage();
		click(nextWeekButton.get(elementNumber));
		waitForPageToLoad();
		waitForPage();
		click(nextWeekButton.get(elementNumber));
		waitForPage();
		click(nextWeekButton.get(elementNumber));
	}

	public boolean getRotaPfofilePanelBusinessNameByAMAndPM(String dayPatternType, String dayName, String panelType,
			String businesType) {
		boolean isPanelAndBusineeType = false;
		waitForPageToLoad();
		waitForPage();
		switch (dayName) {
		case "Monday":
			isPanelAndBusineeType = getTextFromWebElement(monAMSavedPanel).contains(panelType);
			isPanelAndBusineeType = getTextFromWebElement(monAMSavedBusinessType).contains(businesType);
			break;
		case "TuesDay":
			isPanelAndBusineeType = getTextFromWebElement(tueRotaSavedPanel).contains(panelType);
			isPanelAndBusineeType = getTextFromWebElement(tueRotaSavedBusinessType).contains(businesType);
			break;
		case "Wednesday":
			isPanelAndBusineeType = getTextFromWebElement(wedRotaSavedPanel).contains(panelType);
			isPanelAndBusineeType = getTextFromWebElement(wedRotaSavedBusinessType).contains(businesType);
			break;
		case "Thursday":
			isPanelAndBusineeType = getTextFromWebElement(thuRotaSavedPanel).contains(panelType);
			isPanelAndBusineeType = getTextFromWebElement(thuRotaSavedBusinessType).contains(businesType);
			break;
		case "Friday":
			isPanelAndBusineeType = getTextFromWebElement(friAMSavedPanel).contains(panelType);
			isPanelAndBusineeType = getTextFromWebElement(friAMSavedBusinessType).contains(businesType);
			break;
		case "Saturday":
			isPanelAndBusineeType = getTextFromWebElement(satAMSavedPanel).contains(panelType);
			isPanelAndBusineeType = getTextFromWebElement(satAMSavedBusinessType).contains(businesType);
			break;
		case "Sunday":
			isPanelAndBusineeType = getTextFromWebElement(sunAMSavedPanel).contains(panelType);
			isPanelAndBusineeType = getTextFromWebElement(sunAMSavedBusinessType).contains(businesType);
			break;
		default:
		}
		return isPanelAndBusineeType;
	}

	public void clickOnAbortRota() {
		click(rotaAbortButton);
	}

	public void clickConfirmOrCancelRota(String rotaType) {
		waitForPageToLoad();
		switch (rotaType) {
		case "Canel":
			click(abortRotaCancel);
			break;
		case "Refresh":
			driver.navigate().refresh();
			waitForPageToLoad();
			break;
		case "Confirm":
			click(abortRotaConfirm);
			break;
		}
		waitForPageToLoad();
	}

	public String getCreateRotalLable() {
		return getTextFromWebElement(createRotaLabel);
	}

	public void removeVenue(String patternType) {
		waitForPage();
		switch (patternType) {
		case "1 week":
			click(removeVenue.get(0));
			waitForPageToLoad();
			break;
		case "2 weeks":
			click(removeVenue.get(1));
			waitForPageToLoad();
			break;
		case "3 weeks":
			click(removeVenue.get(2));
			waitForPageToLoad();
			break;
		case "4 weeks":
			click(removeVenue.get(3));
			waitForPageToLoad();
			break;
		}

	}

	public boolean isAMSessionDisplayed(String patternType) {
		boolean isRemoveSize = false;
		switch (patternType) {
		case "1 week":
			isRemoveSize = removeVenue.size() >= 0;
			break;
		case "2 weeks":
			isRemoveSize = removeVenue.size() >= 2;
			waitForPageToLoad();
			break;
		case "3 weeks":
			isRemoveSize = removeVenue.size() >= 1;
			waitForPageToLoad();
			break;
		case "4 weeks":
			isRemoveSize = removeVenue.size() >= 0;
			waitForPageToLoad();
			break;
		}
		return isRemoveSize;
	}

	public boolean getSelectedLanguageAndJustice(String justiceType, String dayName, String dayPattern) {
		boolean isDisplayed = false;
		waitForPage();
		switch (dayName) {
		case "Monday":
			if (dayPattern.equals("AM")) {
				isDisplayed = getTextFromWebElement(walesLanguage.get(0)).contains("W");
				isDisplayed = getTextFromWebElement(districtJudge.get(0)).contains(justiceType);
			} else {
				isDisplayed = getTextFromWebElement(singleJustice.get(0)).contains(justiceType);
			}

			break;
		case "TuesDay":
			if (dayPattern.equals("AM")) {
				isDisplayed = getTextFromWebElement(walesLanguage.get(0)).contains("W");

			} else {
				isDisplayed = getTextFromWebElement(singleJustice.get(0)).contains(justiceType);
			}
			break;
		case "Wednesday":
			if (dayPattern.equals("AM")) {
				isDisplayed = getTextFromWebElement(walesLanguage.get(1)).contains("W");
				isDisplayed = getTextFromWebElement(districtJudge.get(0)).contains(justiceType);
			} else {
				isDisplayed = getTextFromWebElement(singleJustice.get(1)).contains(justiceType);
			}
			break;
		case "Thursday":
			if (dayPattern.equals("AM")) {
				isDisplayed = getTextFromWebElement(walesLanguage.get(2)).contains("W");
				isDisplayed = getTextFromWebElement(districtJudge.get(1)).contains(justiceType);
			} else {
				isDisplayed = getTextFromWebElement(singleJustice.get(2)).contains(justiceType);
			}

			break;

		}
		return isDisplayed;
	}

	public boolean viewSelectedRotaProfileLanguageAndJustice(String justiceType) {
		boolean isDisplayed = false;
		boolean isBankHoliday = false;
		waitForPage();
		if (isBankHoliday == false) {
			switch (justiceType) {

			case "W":
				isDisplayed = getTextFromWebElement(rotaProfileLanguage).contains(justiceType);
				break;
			case "DJ":
				isDisplayed = getTextFromWebElement(rotaProfileDJ).contains(justiceType);
				break;
			case "SJ":
				isDisplayed = getTextFromWebElement(rotaProfileSJ.get(0)).contains(justiceType);
				break;
			case "DJSJ":
				isDisplayed = getTextFromWebElement(rotaProfileSJ.get(0)).contains("SJ");
				break;
			case "MJ1":
				waitForPageToLoad();
				isDisplayed = isElementDisplayed(rotaProfileMJ2);
				break;
			case "MJ2":
				waitForPageToLoad();
				isDisplayed = isElementDisplayed(rotaProfileMJ1);
				break;
			case "3MJ (1*chair+2Winger)":
				int nonCourt = wingerCount.size() + chairCount.size();
				isDisplayed = nonCourt >= 3;
				break;
			default:

			}
		}
		return isDisplayed;
	}

	public boolean viewSelectedNonRoleSaittingSlot(String nonRolebasedSittingSlots) {
		boolean isDisplayed = false;
		boolean isBankHoliday = false;
		if (isBankHoliday == false) {
			switch (nonRolebasedSittingSlots) {

			case "3 (1*chair+2Winger)":

				int nonCourt = wingerCount.size() + chairCount.size();
				isDisplayed = nonCourt == 3;
				break;
			case "1 SJ":
				isDisplayed = getTextFromWebElement(rotaProfileSJ.get(0)).contains("SJ");
				break;
			case "1 DJ":

				isDisplayed = getTextFromWebElement(rotaProfileDJ).contains("DJ");
				break;
			default:

			}
		}
		return isDisplayed;
	}

	public void selectCrownCourtMagistrate() {
		click(selectMagistrate.get(0));
	}

	public int getNumberOfMagistares(String typeOfCourt) {
		int noOfMagistares = 0;
		switch (typeOfCourt) {
		case "DFJA":
			noOfMagistares = dfjaMagCount.size();
			break;
		case "CROWN":
			noOfMagistares = selectMagistrate.size();
			break;
		case "SINGLE JUSTICE":
			noOfMagistares = SJMagCount.size();
			break;
		case "DISTRICT JUDGE":
			noOfMagistares = DJMagCount.size();
			break;
		default:
		}
		return noOfMagistares;
	}

	public void selectedRotaProfileLanguageAndJustice(String justiceType, String operationType) {
		waitForPage();
		switch (justiceType) {

		case "W":
			click(rotaProfileLanguage);
			break;
		case "DJ":
			if (operationType.equals("DNegative")) {
				click(selectRotaProfileSJDJ.get(1));

			} else if (operationType.equals("DDataUpdate")) {
				waitForPage();
				int size = selectRotaProfileSJDJ.size();
				if (size > 1) {
					click(selectRotaProfileSJDJ.get(0));
					waitForPageToLoad();

					click(selectRotaProfileSJDJ.get(1));
					waitForPageToLoad();

					click(selectRotaProfileSJDJ.get(2));
					waitForPageToLoad();
				}
			} else {
				click(rotaProfileDJ);
			}

			break;
		case "SJ":
			waitForPage();
			int elementSize = rotaProfileSJ.size();
			if (elementSize - 1 > 0 && operationType.equals("DUpdate")) {
				click(rotaProfileSJ.get(1));
			} else if (operationType.equals("DAdd")) {

				click(selectRotaProfileSJ);
			} else if (operationType.equals("DNegative")) {
				click(selectRotaProfileDJSJ);
			}
			break;
		case "MJ1":
			waitForPage();
			click(rotaProfileMJ1);
			break;
		case "MJ2":
			waitForPage(); 
			click(rotaProfileMJ2);
			break;
		default:

		}
	}
	
	public boolean isPreventPopDisplayed()
	{
	 return isElementDisplayed(popupBox);
	}
	
	public void clickContinuePopUpButton()
	{
		click(continuePopUpButton);
		waitForPage();
	}

}
