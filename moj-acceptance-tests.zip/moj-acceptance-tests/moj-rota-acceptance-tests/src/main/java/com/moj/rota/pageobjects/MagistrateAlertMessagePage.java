package com.moj.rota.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.moj.common.pageobjects.MOJBasePage;

public class MagistrateAlertMessagePage extends MOJBasePage {

	@FindBy(css = "#magistrateTransfer-messages-content a")
	private WebElement transferMessageLink;

	@FindBy(css = "#location-messages-content a")
	private WebElement locationMessageLink;

	@FindBy(css = "#benchChair-messages-content a")
	private WebElement benchChairMessageLink;

	@FindBy(css = "#magistrateScheduledSittings-messages-content a")
	private WebElement scheduleSittingMessageLink;

	@FindBy(css = "#messages-content a")
	private WebElement personalDetailsMessageLink;

	@FindBy(css = "#message-panel-title-magistrateTransfers-0>strong")
	private WebElement title;

	@FindBy(css = "#message-panel-title-personalDetails-0>strong")
	private WebElement personalDetailTitle;

	@FindBy(css = "#message-panel-magistrateTransfers-0 .col-xs-12.col-sm-6.col-md-8.col-lg-8")
	private WebElement changedMessage;

	@FindBy(css = "#message-panel-magistrateTransfers-1 .col-xs-12.col-sm-6.col-md-8.col-lg-8")
	private WebElement cancelledMessage;

	@FindBy(css = "#message-panel-title-magistrateTransfers-0>strong")
	private WebElement effectiveDateMesage;

	@FindBy(css = "#message-panel-personalDetails-0 .panel-body > div.col-xs-12.col-sm-6.col-md-8.col-lg-8")
	private WebElement personalDetailsChangedMessage;

	@FindBy(id = "mark-as-read-btn-magistrateTransfers-LJA-0")
	private WebElement messageRemoveButton;

	@FindBy(id = "mark-as-read-btn-personalDetails-MAGISTRATE-0")
	private WebElement personalMessageRemoveButton;

	@FindBy(css = ".ui-dialog-buttonset button.ui-button.ui-widget.ui-state-default.ui-corner-all.ui-button-text-only:nth-child(2)")
	private WebElement removeConfirm;

	@FindBy(css = ".ui-dialog-buttonset button.ui-button.ui-widget.ui-state-default.ui-corner-all.ui-button-text-only:nth-child(1)")
	private WebElement removeCancel;

	@FindBy(css = "#message-panel-title-benchChairs-0 > strong")
	private WebElement benchChairLocationName;

	@FindBy(css = "#message-panel-benchChairs-0 .col-xs-12.col-sm-6.col-md-8.col-lg-8")
	private WebElement benchChairLocationMessage;

	@FindBy(id = "mark-as-read-btn-benchChairs-LJA-0")
	private WebElement benchChairRemoveButton;

	@FindBy(css = "#absencePeriod-messages-content a")
	private WebElement sittingEligibilityLink;

	@FindBy(css = "#message-panel-title-absencePeriods-0>strong")
	private WebElement dfcTitle;

	@FindBy(css = "#message-panel-absencePeriods-0 .col-xs-12.col-sm-6.col-md-8.col-lg-8")
	private WebElement dfcChnagedMessage;

	@FindBy(css = "#message-panel-absencePeriods-1 > div.panel-body > div.col-xs-12.col-sm-6.col-md-8.col-lg-8")
	private WebElement dfcRemovedMessage;

	@FindBy(id = "mark-as-read-btn-absencePeriods-LJA-0")
	private WebElement dfcRemoveButton;

	public MagistrateAlertMessagePage(WebDriver driver) {
		super(driver);
	}

	public void clickMessageCategory(String categoryType) {
		waitForPage();
		switch (categoryType) {
		case "Transfer magistrate":
			waitForElementTobeClickable(transferMessageLink);
			click(transferMessageLink);
			break;
		case "Personal Details":
			waitForElementTobeClickable(personalDetailsMessageLink);
			click(personalDetailsMessageLink);
			break;
		case "BenchChair":
			waitForElementTobeClickable(benchChairMessageLink);
			click(benchChairMessageLink);
			break;
		case "Location":
			waitForElementTobeClickable(locationMessageLink);
			click(locationMessageLink);
			break;
		case "ScheduleSittings":
			waitForElementTobeClickable(scheduleSittingMessageLink);
			click(scheduleSittingMessageLink);
			break;
		case "DFCEdit":
			waitForElementTobeClickable(sittingEligibilityLink);
			click(sittingEligibilityLink);
			break;
		}
	}

	public String getTransferMagistrateContent(String contentType) {
		String content = null;
		waitForPageToLoad();
		switch (contentType) {
		case "title":
			content = getTextFromWebElement(title);
			break;
		case "CancelledMessage":
			content = getTextFromWebElement(cancelledMessage);
			break;
		case "EffectiveDate":
			content = getTextFromWebElement(effectiveDateMesage);
			break;
		case "Chnaged_Message":
			content = getTextFromWebElement(changedMessage);
			break;
		default:
		}
		return content;
	}

	public String getPersonalDetalsMagistrateContent(String contentType) {
		String content = null;
		waitForPageToLoad();
		switch (contentType) {
		case "title":
			content = getTextFromWebElement(personalDetailTitle);
			break;
		case "Chnaged_Message":
			content = getTextFromWebElement(personalDetailsChangedMessage);
			break;
		default:
		}
		return content;
	}

	public void clickRemoveButton(String categoryType) {
		switch (categoryType) {
		case "Transfer magistrate":
			click(messageRemoveButton);
			break;
		case "Personal Details":
			click(personalMessageRemoveButton);
			break;
		case "BenchChair":
			click(benchChairRemoveButton);
			break;
		case "DFCEdit":
			click(dfcRemoveButton);
			break;
		}

	}

	public void clickConfirm() {
		click(removeConfirm);
	}

	public void clickCancel() {
		click(removeCancel);
	}

	public boolean isRemoveButtonDisplayed(String categoryType) {
		boolean isRemoveButtonDisplayed = false;
		switch (categoryType) {
		case "Transfer magistrate":
			isRemoveButtonDisplayed = isElementNotDisplayed(messageRemoveButton);
			break;
		case "Personal Details":
			isRemoveButtonDisplayed = isElementNotDisplayed(personalMessageRemoveButton);
			break;
		case "BenchChair":
			isRemoveButtonDisplayed = isElementNotDisplayed(benchChairRemoveButton);
			break;
		case "DFCEdit":
			isRemoveButtonDisplayed = isElementNotDisplayed(dfcRemoveButton);
			break;
		}
		return isRemoveButtonDisplayed;
	}

	public String getBechChairContent(String contentType) {
		String content = null;
		waitForPageToLoad();
		switch (contentType) {
		case "location":
			content = getTextFromWebElement(benchChairLocationName);
			break;
		case "Chnaged_Message":
			content = getTextFromWebElement(benchChairLocationMessage);
			break;
		default:
		}
		return content;
	}

	public String getEditDFCMessageDetails(String contentType) {
		String content = null;
		waitForPageToLoad();
		switch (contentType) {
		case "title":
			content = getTextFromWebElement(dfcTitle);
			break;
		case "removed_message":
			content = getTextFromWebElement(dfcRemovedMessage);
			break;
		case "Chnaged_Message":
			content = getTextFromWebElement(dfcChnagedMessage);
			break;
		default:
		}
		return content;
	}
}
