package com.moj.rota.pageobjects;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.moj.common.pageobjects.MOJBasePage;

public class OptimisationStatusPage extends MOJBasePage {

	public OptimisationStatusPage(WebDriver driver) {
		super(driver);
		waitForVisibilityOfElement(pageTitle);
	}

	@FindBy(css = ".container>h1")
	private WebElement pageTitle;

	@FindBy(css = "div[id*='lja-panel-heading-LJA-'] > div > div > h3 > a")
	private List<WebElement> ljaLocations;

	@FindBy(css = "div[id*='status-LJA-']")
	private List<WebElement> optimisationStatus;

	@FindBy(css = "div[id*='lja-optimser-collapse-LJA-'] > div > form > div:nth-child(3)")
	private List<WebElement> nextRotaPeriod;
	
	@FindBy(css = "#history-LJA-50 > div > div:nth-child(1) > div > svg > rect")
	private WebElement googleChart;
	
	@FindBy(css = "div[id*='history-LJA-'] > h4")
	private WebElement optimisationHistroy;
		
	@FindBy(css = "div[id*='lja-panel-heading-DFC-'] > div > div > h3 > a")
	private List<WebElement> dfjaLocation;
	
	@FindBy(css = "div[id*='status-DFC-']")
	private List<WebElement> optimisationDfcStatus;
	
	@FindBy(css = "div[id*='lja-optimser-collapse-DFC-'] > div > form > div:nth-child(3)")
	private List<WebElement> nextRotaDFCPeriod;
	
	@FindBy(css = "div[id*='history-DFC-'] > h4")
	private WebElement dfcHistory;
		
	@FindBy(css = "div[id*='history-LJA-'] > table > tbody > tr:nth-child(1) > td:nth-child(1)")
	private WebElement rotaPeriodStartDate;
	
	@FindBy(css = "div[id*='history-LJA-'] > table > tbody > tr:nth-child(1) > td:nth-child(2)")
	private WebElement optimisationDuration;
		
	public boolean isOptimisationPageDisplayed() {
		waitForPage();
		return isElementDisplayed(pageTitle);
	}

	public String getLocationLables(String typeOfLable) {
		String locationLable = null;
		switch (typeOfLable) {
		case "North":
			locationLable = getTextFromWebElement(ljaLocations.get(0));
			break;
		case "South":
			locationLable = getTextFromWebElement(ljaLocations.get(1));
			break;
		default:
		}
		return locationLable;
	}

	public void clickOnLocation(String typeOfLocation) {
		waitForPage();
		switch (typeOfLocation) {
		case "Local Justice Area 10 North":
			//click(ljaLocations.get(0));
			for(WebElement element:ljaLocations)
			{
				if(getTextFromWebElement(element).contains(typeOfLocation))
				{
					click(element);	
					break;
				}
			}
			break;
		case "Local Justice Area 10 South":
			//click(ljaLocations.get(1));
			for(WebElement element:ljaLocations)
			{   
				if(getTextFromWebElement(element).contains(typeOfLocation))
				{
					click(element);	
					break;
				}
			}
			break;
		case "Designated Family Centre 8":
			//click(dfjaLocation.get(0));
			for(WebElement element:dfjaLocation)
			{   
				if(getTextFromWebElement(element).contains(typeOfLocation))
				{
					click(element);	
					break;
				}
			}
			break;
		default:
		}

	}

	public String getOptimisationStatus(String typeOfLocation) {
		String status = null;
		switch (typeOfLocation) {
		case "Local Justice Area 10 North":
			status = getTextFromWebElement(optimisationStatus.get(10));
			break;
		case "Local Justice Area 10 South":
			status = getTextFromWebElement(optimisationStatus.get(11));
			break;
		case "Designated Family Centre 8":
			status = getTextFromWebElement(optimisationDfcStatus.get(11));
			break;
		default:
		}
		return status;

	}

	public String getNextRotaPeriod(String typeOfLocation) {
		String nextRotaPeriodData = null;
		switch (typeOfLocation) {
		case "Local Justice Area 10 North":
			nextRotaPeriodData = getTextFromWebElement(nextRotaPeriod.get(10));
			break;
		case "Local Justice Area 10 South":
			nextRotaPeriodData = getTextFromWebElement(nextRotaPeriod.get(11));
			break;
		case "Designated Family Centre 8":
			nextRotaPeriodData = getTextFromWebElement(nextRotaDFCPeriod.get(11));
			break;
		default:
		}
		return nextRotaPeriodData;

	}
	
	public boolean isHistroyDisplayed(String historyType)
	{
		boolean isHistoryDisplayed=false;
		switch(historyType)
		{
		case "without history":
			isHistoryDisplayed= isElementNotDisplayed(optimisationHistroy);
			break;
		case "with history":
			isHistoryDisplayed= isElementDisplayed(optimisationHistroy);
			break;
		}
		return isHistoryDisplayed;
	}
	
	public boolean isDFCHistoryDisplayed()
	{
		return isElementNotDisplayed(dfcHistory);
	}
	
	public boolean isRotaStartDateDisplayed()
	{
		return getTextFromWebElement(rotaPeriodStartDate).length()>0;
	}
	
	public boolean isDurationDisplayed()
	{
		return getTextFromWebElement(optimisationDuration).length()>0;
	}
}
