package com.moj.rota.pageobjects;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import com.moj.common.pageobjects.MOJBasePage;
import com.moj.rota.listingpattern.pageobjects.DraftRotaMagistrateListPopupPage;
import com.moj.rota.magistrate.pageobjects.MagistrateHomePage;

public class MagistratePersonalDetailsPage extends MOJBasePage {

	private static String winHandleBefore = null;

	public MagistratePersonalDetailsPage(WebDriver driver) {
		super(driver);
		winHandleBefore = driver.getWindowHandle();
		//switchToNewWindow();
		if(isElementNotDisplayed(switchFrame))
		{
		switchToIFrame(switchFrame);
		}
	}

	@FindBy(css = ".btn.btn-info.btn-xs")
	private WebElement logout;

	@FindBy(id = "loggedInName")
	private WebElement loginName;

	@FindBy(css = ".breadcrumb>li>a")
	private WebElement homePage;

	@FindBy(css = "#content>div>h1")
	private WebElement pageTitle;

	@FindBy(css = ".panel-title")
	private WebElement boxTitle;

	@FindBy(id = "title")
	private WebElement nameTitle;

	@FindBy(id = "firstName")
	private WebElement fname;

	@FindBy(id = "lastName")
	private WebElement lname;

	@FindBy(id = "dob")
	private WebElement dateofBirth;

	@FindBy(id = "gender-1")
	private WebElement genderMale;

	@FindBy(id = "gender-2")
	private WebElement genderFemale;

	@FindBy(id = "addressLine1")
	private WebElement address1;

	@FindBy(id = "addressLine2")
	private WebElement address2;

	@FindBy(id = "addressLine3")
	private WebElement address3;

	@FindBy(id = "addressLine4")
	private WebElement address4;

	@FindBy(id = "addressLine5")
	private WebElement address5;

	@FindBy(id = "postCode")
	private WebElement postCode;

	@FindBy(id = "homePhone")
	private WebElement firstPreferedContactNumber;

	@FindBy(id = "phone1Type")
	private WebElement phoneType1;

	@FindBy(id = "officePhone")
	private WebElement secondPreferedContactNumber;

	@FindBy(id = "phone2Type")
	private WebElement phoneType2;

	@FindBy(id = "mobilePhone")
	private WebElement thirdPreferedContactNumber;

	@FindBy(id = "phone3Type")
	private WebElement phoneType3;

	@FindBy(id = "preferredNotificationMethod")
	private WebElement notificationMethod;

	@FindBy(id = "emailAddress")
	private WebElement email;

	@FindBy(id = "jeanNumber")
	private WebElement jeanNumber;

	@FindBy(id = "localAuthorityEmployee")
	private WebElement localAuthority;

	@FindBy(id = "localAuthorityName")
	private WebElement localAuthorityName;

	@FindBy(id = "welsh")
	private WebElement welshLangPref;

	@FindBy(id = "personal-details-confirm-btn")
	protected WebElement confirmButton;

	@FindBy(css = "#wrap > div > div.page-header.hidden-print > h6")
	protected WebElement magistrateLoginName;

	@FindBy(id = "personal-details-save-btn")
	protected WebElement districtConfirmButtom;

	// district judge related ids change

	@FindBy(id = "phone1")
	private WebElement disFirstPreferedContactNumber;

	@FindBy(id = "phone2")
	private WebElement disSeconsPreferedContactNumber;

	@FindBy(id = "phone3")
	private WebElement disThirdPreferedContactNumber;

	@FindBy(id = "phoneType1")
	private WebElement disPhoneType1;

	@FindBy(id = "phoneType2")
	private WebElement disPhoneType2;

	@FindBy(id = "phoneType3")
	private WebElement disPhoneType3;

	public void selectTitle(String title) {
		Select selectTitle = new Select(getElement(nameTitle));
		selectTitle.selectByVisibleText(title);
	}

	public void enterFirstName(String firstName) {
		getElement(fname).sendKeys(firstName);
	}

	public void enterLastName(String lastName) {
		getElement(lname).sendKeys(lastName);
	}

	public void enterDateofBirth(String dob) {
		getElement(dateofBirth).sendKeys(dob);
	}

	public void selectGenderAsMale() {
		getElement(genderMale).click();
	}

	public void selectGenderAsFemale() {
		getElement(genderFemale).click();
	}

	public void enterAddress1(String add1) {
		getElement(address1).sendKeys(add1);
	}

	public void enterAddress2(String add2) {
		getElement(address2).sendKeys(add2);
	}

	public void enterAddress3(String add3) {
		getElement(address3).sendKeys(add3);
	}

	public void enterAddress4(String add4) {
		getElement(address4).sendKeys(add4);
	}

	public void enterAddress5(String add5) {
		getElement(address5).sendKeys(add5);
	}

	public void enterPostCode(String pCode) {
		getElement(postCode).sendKeys(pCode);
	}

	public void selectNotificationMethod(String ntfMethod) {
		Select selectTitle = new Select(notificationMethod);
		selectTitle.selectByVisibleText(ntfMethod);
	}

	public void enterEmailAddress(String emailAddress) {
		getElement(email).sendKeys(emailAddress);
	}

	public void selectWelshLangPref() {
		getElement(welshLangPref).click();
	}

	public boolean isPageFieldsDisplayed(String pageFields, boolean isDistrictJudePage) {
		boolean isElemtDisplayed = false;
		switch (pageFields) {
		case "Title":
			isElemtDisplayed = isWebElementDisplayed(nameTitle);
			break;
		case "First_name":
			isElemtDisplayed = isWebElementDisplayed(fname);
			break;
		case "Last_name":
			isElemtDisplayed = isWebElementDisplayed(lname);
			break;
		case "Date_of_birth":
			isElemtDisplayed = isWebElementDisplayed(dateofBirth);
			break;
		case "Gender":
			isElemtDisplayed = isWebElementDisplayed(genderMale);
			isElemtDisplayed = isWebElementDisplayed(genderFemale);
			break;
		case "Address_line1":
			isElemtDisplayed = isWebElementDisplayed(address1);
			break;
		case "Address_line2":
			isElemtDisplayed = isWebElementDisplayed(address2);
			break;
		case "Address_line3":
			isElemtDisplayed = isWebElementDisplayed(address3);
			break;
		case "Address_line4":
			isElemtDisplayed = isWebElementDisplayed(address4);
			break;
		case "Address_line5":
			isElemtDisplayed = isWebElementDisplayed(address5);
			break;
		case "PostCode":
			isElemtDisplayed = isWebElementDisplayed(postCode);
			break;

		case "first_prefered_contact_number":
			if (isDistrictJudePage) {
				isElemtDisplayed = isWebElementDisplayed(disFirstPreferedContactNumber);
			} else {
				isElemtDisplayed = isWebElementDisplayed(firstPreferedContactNumber);
			}

			break;

		case "Home_Type":
			if (isDistrictJudePage) {
				isElemtDisplayed = isWebElementDisplayed(disPhoneType1);
			} else {
				isElemtDisplayed = isWebElementDisplayed(phoneType1);
			}

			break;
		case "second_prefered_contact_number":
			if (isDistrictJudePage) {
				isElemtDisplayed = isWebElementDisplayed(disSeconsPreferedContactNumber);
			} else {
				isElemtDisplayed = isWebElementDisplayed(secondPreferedContactNumber);
			}
			break;
		case "Office_Type":
			if (isDistrictJudePage) {
				isElemtDisplayed = isWebElementDisplayed(disPhoneType2);
			} else {
				isElemtDisplayed = isWebElementDisplayed(phoneType2);
			}

			break;

		case "third_prefered_contact_number":
			if (isDistrictJudePage) {
				isElemtDisplayed = isWebElementDisplayed(disThirdPreferedContactNumber);
			} else {
				isElemtDisplayed = isWebElementDisplayed(thirdPreferedContactNumber);
			}

			break;

		case "Mobile_Type":
			if (isDistrictJudePage) {
				isElemtDisplayed = isWebElementDisplayed(disPhoneType3);
			} else {
				isElemtDisplayed = isWebElementDisplayed(phoneType3);
			}
			;
			break;

		case "Notification_method":
			isElemtDisplayed = isWebElementDisplayed(notificationMethod);
			break;
		case "Ejudiciary Email Address":
			isElemtDisplayed = isWebElementDisplayed(email);
			break;

		case "JEAN_Number":
			isElemtDisplayed = isWebElementDisplayed(jeanNumber);
			break;
		case "local_authority":
			isElemtDisplayed = isWebElementDisplayed(localAuthority);
			break;

		case "Welsh_language":
			isElemtDisplayed = isWebElementDisplayed(welshLangPref);
			break;
		default:
			System.out.println("Not elements displyed");

		}

		return isElemtDisplayed;
	}

	public boolean isPersonalDetailsPageDisplayed() {
		return isElementDisplayed(pageTitle);
	}

	public String getMyAccountLabel() {
		return getTextFromWebElement(logout);
	}

	public boolean isLoginNameDisplayed() {
		return isElementDisplayed(loginName);
	}

	public String getHomeBreadCumLabel() {
		return getTextFromWebElement(homePage);
	}

	public String getPageTitle() {
		return getTextFromWebElement(pageTitle);
	}

	public String getConfirmButtonLabel() {
		return getTextFromWebElement(confirmButton);
	}

	public String getDistrictConfirmButtonLabel() {
		return getTextFromWebElement(districtConfirmButtom);
	}

	public void enterPhoneNumberAndType(String phoneNumber, String phoneType) {
		switch (phoneType) {
		case "Home":
			enterText(firstPreferedContactNumber, phoneNumber);
			selectDropDown(phoneType1, phoneType);
			break;
		case "Office":
			enterText(secondPreferedContactNumber, phoneNumber);
			selectDropDown(phoneType2, phoneType);
			break;
		case "Mobile":
			enterText(thirdPreferedContactNumber, phoneNumber);
			selectDropDown(phoneType3, phoneType);
			break;
		default:
		}
	}

	public MagistrateSearchPage clickConfirm() {
		click(confirmButton);
		driver.switchTo().window(winHandleBefore);
		return returnPageFactory(MagistrateSearchPage.class);
	}

	public String getTelePhoneNumber(String phoneType) {

		String phoneNumber = null;
		switch (phoneType) {
		case "Home":
			phoneNumber = getTextFromWebElement(firstPreferedContactNumber);
			break;
		case "Office":
			phoneNumber = getTextFromWebElement(secondPreferedContactNumber);
			break;
		case "Mobile":
			phoneNumber = getTextFromWebElement(thirdPreferedContactNumber);
			break;
		default:
		}

		return phoneNumber;
	}

	public String getTelePhoneType(String phoneType) {
		String acPhoneType = null;
		switch (phoneType) {
		case "Home":
			acPhoneType = getSelectedDropDownOption(phoneType1);
			break;
		case "Office":
			acPhoneType = getSelectedDropDownOption(phoneType2);
			break;
		case "Mobile":
			acPhoneType = getSelectedDropDownOption(phoneType3);
			break;
		default:
		}

		return acPhoneType;
	}

	public boolean isMagLoginNameDisplayed() {
		return isElementDisplayed(magistrateLoginName);
	}

	public MagistrateHomePage clickMagistrateConfirm() {
		click(confirmButton);
		return returnPageFactory(MagistrateHomePage.class);
	}

	public void disEnterPhoneNumberAndType(String phoneNumber, String phoneType) {
		switch (phoneType) {
		case "Home":
			enterText(disFirstPreferedContactNumber, phoneNumber);
			selectDropDown(disPhoneType1, phoneType);
			break;
		case "Office":
			enterText(disSeconsPreferedContactNumber, phoneNumber);
			selectDropDown(disPhoneType2, phoneType);
			break;
		case "Mobile":
			enterText(disThirdPreferedContactNumber, phoneNumber);
			selectDropDown(disPhoneType3, phoneType);
			break;
		default:
		}
	}

	public DistrictJudgeSearchPage clickMagConfirm() {
		click(districtConfirmButtom);
		driver.switchTo().window(winHandleBefore);
		return returnPageFactory(DistrictJudgeSearchPage.class);
	}

	public String getdisJTelePhoneType(String phoneType) {
		String acPhoneType = null;
		switch (phoneType) {
		case "Home":
			acPhoneType = getSelectedDropDownOption(disPhoneType1);
			break;
		case "Office":
			acPhoneType = getSelectedDropDownOption(disPhoneType2);
			break;
		case "Mobile":
			acPhoneType = getSelectedDropDownOption(disPhoneType3);
			break;
		default:
		}

		return acPhoneType;
	}

	public void selectEnglishAndEnterLocalAuthority(String localAuthorityNameVal) {
		if (getStatusOfCheckBox(localAuthority) == false) {
			click(localAuthority);
			waitForPageToLoad();
			enterText(localAuthorityName, localAuthorityNameVal);
		}

		if (getStatusOfCheckBox(welshLangPref) == false) {
			click(welshLangPref);
		}
	}

	public DraftRotaMagistrateListPopupPage clickDraftRotaConfirm() {
		click(confirmButton);
		driver.switchTo().window(winHandleBefore);
		return returnPageFactory(DraftRotaMagistrateListPopupPage.class);
	}

	public void enterFirstNameAndLastName(String firstName, String lastName) {
		enterText(fname, firstName);
		enterText(lname, lastName);
	}

	public boolean isFirstNameEditable() {
		return getStatusOfElement(fname);
	}
	
	public boolean isEmailEditable() {
		return getStatusOfElement(email);
	}
	
	public RotaAdminHomePage clickHomePage()
	{
	 click(homePage);
	 return getPage(RotaAdminHomePage.class);
	}
}
