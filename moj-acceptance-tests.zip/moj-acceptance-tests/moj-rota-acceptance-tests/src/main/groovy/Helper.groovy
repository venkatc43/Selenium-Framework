package uk.co.which.ga.groovy


class Helper {
    static boolean checkDataLayerVariable(String source, String expectedVariableName, String expectedVariableValue) {
        def htmlNode = new XmlParser().parseText(source)
        final dataLayerText = htmlNode.body.script.text()
        println dataLayerText
        (dataLayerText =~ /dataLayer = \[\{.*?\'(.+?)\' : \'(.+?)\'.*?\}\]/).each { actualVariable, actualVariableValue ->
            if (expectedVariableName == actualVariable && expectedVariableValue == actualVariableValue) {
                return true;
            }

        }
        return false;

    }
}
