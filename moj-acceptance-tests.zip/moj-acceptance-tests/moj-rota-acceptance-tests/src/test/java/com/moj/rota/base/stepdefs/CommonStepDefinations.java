package com.moj.rota.base.stepdefs;


import static com.jayway.restassured.RestAssured.given;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import com.jayway.restassured.builder.RequestSpecBuilder;
import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.jcraft.jsch.JSchException;
import com.moj.common.webdriver.MOJDriverProvider;
import com.moj.rota.magistrate.pageobjects.MagistrateLoginPage;
import com.moj.rota.pageobjects.RotaAdminHomePage;
import com.moj.rota.pageobjects.RotaLoginPage;
import com.moj.test.utils.DatabaseUtil;
import com.moj.test.utils.ReadConfigFile;
import com.rota.session.IdObfuscationServiceImpl;
import com.rota.session.ServiceException;
import com.thoughtworks.selenium.webdriven.commands.Click;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class CommonStepDefinations extends BaseStepDefination {
	private Logger logger = Logger.getLogger(getClass());		
	private String endpointUrl=null;
	private IdObfuscationServiceImpl idObfuscationServiceImpl=null;
	private int magsitrateID=0;
	private static boolean isExcelReport=false;
	private static boolean isNoNReport=false;
	private static int reportsIdLoadCount=0;
	private static int idLoadCount=0;
	public static String dosshTunnel=null;
	@Before("@ROTA")
	public void rotaSetUp() throws Exception {
		config =new ReadConfigFile();		
		driver = MOJDriverProvider.getWebDriver();
		//MOJDriverProvider.setWebDriver((RemoteWebDriver)driver);
		driver.manage().deleteAllCookies();
		onRotaLoginPage = new RotaLoginPage(driver);
		onMagistrateLoginPage = new MagistrateLoginPage(driver);
		environment=System.getProperty("env");
		if(environment==null)
		{
			environment="test";
		}
		
	}
	
	@Before("@ROTA-DB")
	public void rotaDBSetUp() throws Exception {
		isDbCleanup=true;
		getTunnelConnection();
		try {
			if(connection==null)
			{
			connection =DatabaseUtil.getConnection();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	@Before("@ROTA-Rest")
	public void rotaRestsetUp() throws Exception {
		isExcelReport=false;
		isNoNReport=true;
		idLoadCount=++idLoadCount;
		getBaseDetails();
				
	}

	
	
	@Before("@ROTA-REST-EXCEL")
	public void rotaRestExcelsetUp() throws Exception {
		isExcelReport=true;
		isNoNReport=false;
		reportsIdLoadCount=reportsIdLoadCount++;
		getBaseDetails();
	}
		
	@After
	public void tearDown(Scenario scenario) throws Exception {
		if (scenario.isFailed()) {
			if(driver!=null)
			{
				if(!driver.getClass().getSimpleName().equalsIgnoreCase("HtmlUnitDriver")){
		            final byte[] screenshot = ((TakesScreenshot) driver)
		                        .getScreenshotAs(OutputType.BYTES);
		            scenario.embed(screenshot, "image/png"); //stick it in the report
				}
			}
			
		}
		if (environment.equals("sit") || environment.equals("sandbox")) {
			if (isReports) {
				onStandardReportsPage.switchToPreviousWindow(windowName);
			}
			if (isMagistrateUI) {
				onMagistrateHomePage.clickLogoutLink();
			} else {
				driver.switchTo().defaultContent();
				driver.findElement(By.cssSelector(".close.close-overlay")).click();
				onRotaAdminHomePage.clickLogoutLink();
			}
		}
														
	}
		
	@Given("^the ROTA Admin is on landing page$")
	public void the_ROTA_Admin_is_on_landing_page() throws Throwable {
		String applicationUrl = System.getProperty("applicationUrl");
		if (applicationUrl !=null) {
			onRotaLoginPage.navigateToSite(applicationUrl);
		} else {
			onRotaLoginPage.navigateToSite(config.getPropertyValue("rotaAdminUI"));
		}
		
	}
	
	@Given("^the ROTA Admin is logged in$")
	public void the_ROTA_Admin_is_logged_in() throws Throwable {
		List<String> loginCredentials = enterUserNameAndPassword("");
		rotaAdminLoggedIn(loginCredentials);
	}
	
	@Given("^the ROTA Admin is logged in \"(.*?)\"$")
	public void the_ROTA_Admin_is_logged_in(String userName) throws Throwable {
		List<String> loginCredentials = enterUserNameAndPassword(userName);
		rotaAdminLoggedIn(loginCredentials);
	}
	
	@When("^I switch to second screen$")
	public void i_switch_to_second_screen() throws Throwable {
		navigateToRotaAdminHomePage();
	}
	
	@When("^I switch to first screen$")
	public void i_switch_to_first_screen() throws Throwable {
		//switchToPreviousWindow();
		// driver.close();
		 List<String> tabs = new ArrayList<String> (driver.getWindowHandles());
		 driver.switchTo().window(tabs.get(0));
		 waitForPage();
	}

	private List<String> enterUserNameAndPassword(String userName) {
		List<String> loginCredentials = new ArrayList<String>();
		if(userName!=null && !userName.equals(""))
		{
			loginCredentials.add(userName);
		} else {
			loginCredentials.add(config.getUsername());
		}
		loginCredentials.add(config.getPassword());
		String applicationUrl = System.getProperty("applicationUrl");
		if (applicationUrl !=null) {
			onRotaLoginPage.navigateToSite(applicationUrl);
		}else {
				onRotaLoginPage.navigateToSite(config.getPropertyValue("rotaAdminUI"));
			}
		return loginCredentials;
	}
	
	private void navigateToRotaAdminHomePage() throws Exception
	{
		onRotaLoginPage.switchToSecondScreen();
		environment=System.getProperty("env");
		if(environment==null)
		{
			environment="test";
		}
		onRotaAdminHomePage=onRotaLoginPage.navigateToSiteWithouLogin(config.getPropertyValue("rotaAdminUIHome"));
	}

	private void switchToPreviousWindow()
	{
		onRotaListingPatternPage.switchToPreviousScreen();
	}
	
	@Given("^I am on Magistrate login page$")
	public void i_am_on_Magistrate_login_page() throws Throwable {
		String applicationUrl = System.getProperty("applicationUrl");
		if (applicationUrl !=null) {
			onRotaLoginPage.navigateToSite(applicationUrl);
		}else {
				onRotaLoginPage.navigateToSite(config.getPropertyValue("magistrateUI"));
			}
		
		
	}
	
	@Given("^I enter username \"(.*?)\" ,pasword \"(.*?)\"$")
	public void i_enter_username_pasword(String userNmae, String password) throws Throwable {
		isMagistrateUI =true;
		List<String> loginCredentials = new ArrayList<String>();
		loginCredentials.add(userNmae);
		loginCredentials.add(password);
		magistrateLogin(loginCredentials);
	}
	
	@Given("^I complete the Add District Judge form with no data$")
	public void i_complete_the_Add_District_Judge_form_with_no_data() throws Throwable {
	 onCreateDistrictJudgePage = onRotaAdminHomePage.clickCreateDistrictJudge();
		onCreateDistrictJudgePage.completeDJFormWithNoData();
	}

	@Given("^Rota admin add all headers to request$")
	public void rota_admin_add_all_headers_to_request() throws Throwable {
		Map<String,String> headers= new HashMap<String,String>();
		
		String userName=config.getPropertyValue("authusername");
		String courtNumber=config.getPropertyValue("courtNumber");
		String clearText=DatabaseUtil.getRotaAdminIDID(connection, userName);
		String sessionId=config.getPropertyValue("x-rota-admin-app-session-id");
		urlSessionId=idObfuscationServiceImpl.obfuscate(sessionId, clearText);
		
		headers.put("x-rota-admin-app-session-id", sessionId);
		headers.put("authusername", userName);
		headers.put("x-rota-admin-api-key", config.getPropertyValue("x-rota-admin-api-key"));
		headers.put("x-security-app-session-id", sessionId);
		headers.put("x-rota-admin-app-name", config.getPropertyValue("x-rota-admin-app-name"));
		headers.put("accept", config.getPropertyValue("accept"));
		headers.put("content-type", config.getPropertyValue("content-type"));
		requestSpec = new RequestSpecBuilder().addHeaders(headers).setBaseUri(endpointUrl).build();
		
		if((!isExcelReport && isNoNReport) && !isNonRepDraftLoadedIDS)
		{
			isDraftLoadedIDS=false;
			isNonRepDraftLoadedIDS=true;
		}
		
		if(!isDraftLoadedIDS)
		{
		isDraftLoadedIDS=true;
		//getting locations and rota locations ids
		getListingPatternLocationsAndRotaLocationIDS(requestSpec,courtNumber,urlSessionId);
		}

		if(isExcelReport)
		{
			headers.remove("content-type");
			headers.replace("accept", "application/vnd.ms-excel");
			requestSpec = new RequestSpecBuilder().addHeaders(headers).setBaseUri(endpointUrl).build();
		}
		
	}

	private void getLocationsAndRotaLocationIDS(RequestSpecification requestSpec,String courtNumber,String sessionID) {
		//getting location ids
		response =given().spec(requestSpec).urlEncodingEnabled(true).log().ifValidationFails().
				 when().get("/RotaAdminREST/webresources/rota/status/"+sessionID);
		response.then().spec(getResponseSpecification());
		JsonPath jsonPath = new JsonPath(response.getBody().asInputStream());
		
		List<Object> listOfdata = jsonPath.get();

		for (int i = 0; i < listOfdata.size(); i++) {
			Map<String, Object> data = (HashMap<String, Object>) listOfdata.get(i);
			if(data.get("name").equals("Local Justice Area "+courtNumber+" North"))
			{
				ljaNorthLocationID=(String) data.get("justiceAreaId");
								
			} else if(data.get("name").equals("Local Justice Area "+courtNumber+" South"))
			{
				ljaSouthLocationID=(String) data.get("justiceAreaId");
				
				//getting rotalocation ids
				Response locationResponse =given().spec(requestSpec).urlEncodingEnabled(true).log().ifValidationFails().
						 when().get("/RotaAdminREST/webresources/rota/"+ljaSouthLocationID+"/LJA/DRAFT_ROTA/"+sessionID);
				
				locationResponse.then().spec(getResponseSpecification());
				JsonPath rotaLocations = new JsonPath(locationResponse.getBody().asInputStream());
				
				rotaPeriodStartDate=rotaLocations.get("rotaPeriodStart");
				
				List<Object> rotaLocationsData = rotaLocations.getList("rotaLocations");
				
				
				for (int j = 0; j < rotaLocationsData.size(); j++) {
					Map<String, Object> locationsData = (HashMap<String, Object>) rotaLocationsData.get(j);
					
					if(locationsData.get("locationName").equals("LJA "+courtNumber+" South Magistrates Court 1"))
					{
						magCourt1=(String) locationsData.get("id");
						List<Object> venuesCourt1List=(ArrayList<Object>) locationsData.get("rotaVenues");
						
						Map<String, Object> venuesCourt1Data = (HashMap<String, Object>) venuesCourt1List.get(0);
						magCourt1Venue=(String) venuesCourt1Data.get("id");
						
						if(venuesCourt1List.size()>=2)
						{
						Map<String, Object> venuesCourt2Data = (HashMap<String, Object>) venuesCourt1List.get(1);
						magSouthCourt2Venue=(String) venuesCourt2Data.get("id");
						}
						
					} else if(locationsData.get("locationName").equals("LJA "+courtNumber+" South Magistrates Court 2"))
					{
						magCourt2=(String) locationsData.get("id");
						List<Object> venuesCourt2List=(ArrayList<Object>) locationsData.get("rotaVenues");
						Map<String, Object> venuesCourt2Data = (HashMap<String, Object>) venuesCourt2List.get(0);
						magCourt2Venue=(String) venuesCourt2Data.get("id");
					}else if(locationsData.get("locationName").equals("LJA "+courtNumber+" South Crown Court"))
					{
						magCrownCourt=(String) locationsData.get("id");
						List<Object> venuesCrownList=(ArrayList<Object>) locationsData.get("rotaVenues");
						Map<String, Object> venuesCrownCourtData = (HashMap<String, Object>) venuesCrownList.get(0);
						magCrownCourtVenue=(String) venuesCrownCourtData.get("id");;
					}

				}
								
			} else if(data.get("name").equals("Designated Family Centre "+courtNumber+""))
			{
				dfjaID=(String) data.get("justiceAreaId");
				
				//getting rotalocation ids
				Response locationResponse =given().spec(requestSpec).urlEncodingEnabled(true).log().ifValidationFails().
						 when().get("/RotaAdminREST/webresources/rota/"+dfjaID+"/DFC/DRAFT_ROTA/"+sessionID);
				
				locationResponse.then().spec(getResponseSpecification());
				JsonPath rotaLocations = new JsonPath(locationResponse.getBody().asInputStream());
				
				rotaPeriodStartDate=rotaLocations.get("rotaPeriodStart");
				
				List<Object> rotaLocationsData = rotaLocations.getList("rotaLocations");
				
				
				for (int j = 0; j < rotaLocationsData.size(); j++) {
					Map<String, Object> locationsData = (HashMap<String, Object>) rotaLocationsData.get(j);
					
					if(locationsData.get("locationName").equals("DFJA"+courtNumber+" Location"))
					{
						dfjaLocationID=(String) locationsData.get("id");
						List<Object> venuesCourt1List=(ArrayList<Object>) locationsData.get("rotaVenues");
						
						Map<String, Object> venuesCourt1Data = (HashMap<String, Object>) venuesCourt1List.get(0);
						dfjaLocationVenue=(String) venuesCourt1Data.get("id");
						
					} 
				}
				
				
				
			}
				
				
		}
	}
	
	private void getListingPatternLocationsAndRotaLocationIDS(RequestSpecification requestSpec,String courtNumber,String sessionID) {
		//getting location ids
		response =given().spec(requestSpec).urlEncodingEnabled(true).log().all().
				 when().get("/RotaAdminREST/webresources/rota/status/"+sessionID);
		response.then().log().all().spec(getResponseSpecification());
		JsonPath jsonPath = new JsonPath(response.getBody().asInputStream());
		
		List<Object> listOfdata = jsonPath.get();
		logger.info("list of data :"+listOfdata);
		logger.info("list of data size:"+listOfdata.size());
		for (int i = 0; i < listOfdata.size(); i++) {
			logger.info("print the data :"+i);
			Map<String, Object> data = (HashMap<String, Object>) listOfdata.get(i);
			logger.info("getting court names :"+data);
			if(data.get("name").equals("Local Justice Area "+courtNumber+" North"))
			{
				logger.info("LJA name :"+data.get("name"));
				ljaNorthLocationID=(String) data.get("justiceAreaId");
				logger.info("LJA north id :"+ljaNorthLocationID);
								
			} else if(data.get("name").equals("Local Justice Area "+courtNumber+" South"))
			{
				ljaSouthLocationID=(String) data.get("justiceAreaId");
				logger.info("LJA South id :"+ljaSouthLocationID);
				
				//getting rotalocation ids
				Response locationResponse =given().spec(requestSpec).urlEncodingEnabled(true).log().ifValidationFails().
						 when().get("/RotaAdminREST/webresources/listing-pattern/"+ljaSouthLocationID+"/LJA/"+sessionID);
				
				locationResponse.then().log().all().spec(getResponseSpecification());
				JsonPath rotaLocations = new JsonPath(locationResponse.getBody().asInputStream());				
				List<Object> rotaLocationsData = rotaLocations.getList("listingPatternLocations");
				logger.info("Rota location data :"+rotaLocationsData);
				
				for (int j = 0; j < rotaLocationsData.size(); j++) {
					Map<String, Object> locationsData = (HashMap<String, Object>) rotaLocationsData.get(j);
					
					if(locationsData.get("locationName").equals("LJA "+courtNumber+" South Magistrates Court 1"))
					{
						magCourt1=(String) locationsData.get("id");
						logger.info("Magistrate Court1 :"+magCourt1);
						List<Object> venuesCourt1List=(ArrayList<Object>) locationsData.get("listingPatternVenues");
						
						Map<String, Object> venuesCourt1Data = (HashMap<String, Object>) venuesCourt1List.get(0);
						magCourt1Venue=(String) venuesCourt1Data.get("id");
						logger.info("Magistrate Court1 venue :"+magCourt1Venue);
						
						if(venuesCourt1List.size()>=2)
						{
						Map<String, Object> venuesCourt2Data = (HashMap<String, Object>) venuesCourt1List.get(1);
						magSouthCourt2Venue=(String) venuesCourt2Data.get("id");
						logger.info("Magistrate Court1 venue2 :"+magSouthCourt2Venue);
						}
						
					} else if(locationsData.get("locationName").equals("LJA "+courtNumber+" South Magistrates Court 2"))
					{
						magCourt2=(String) locationsData.get("id");
						logger.info("Magistrate Court2 :"+magCourt2);
						List<Object> venuesCourt2List=(ArrayList<Object>) locationsData.get("listingPatternVenues");
						Map<String, Object> venuesCourt2Data = (HashMap<String, Object>) venuesCourt2List.get(0);
						magCourt2Venue=(String) venuesCourt2Data.get("id");
						logger.info("Magistrate Court2 venue:"+magCourt2Venue);
					}else if(locationsData.get("locationName").equals("LJA "+courtNumber+" South Crown Court"))
					{
						magCrownCourt=(String) locationsData.get("id");
						logger.info("Magistrate crown Court:"+magCrownCourt);
						List<Object> venuesCrownList=(ArrayList<Object>) locationsData.get("listingPatternVenues");
						Map<String, Object> venuesCrownCourtData = (HashMap<String, Object>) venuesCrownList.get(0);
						magCrownCourtVenue=(String) venuesCrownCourtData.get("id");
						logger.info("Magistrate crown Court venue:"+magCrownCourtVenue);
					}

				}
								
			} else if(data.get("name").equals("Designated Family Centre "+courtNumber+""))
			{
				dfjaID=(String) data.get("justiceAreaId");
				logger.info("DFC Court id:"+dfjaID);
				
				//getting rotalocation ids
				Response locationResponse =given().spec(requestSpec).urlEncodingEnabled(true).log().ifValidationFails().
						 when().get("/RotaAdminREST/webresources/listing-pattern/"+dfjaID+"/DFC/"+sessionID);
				
				locationResponse.then().log().all().spec(getResponseSpecification());
				JsonPath rotaLocations = new JsonPath(locationResponse.getBody().asInputStream());
								
				List<Object> rotaLocationsData = rotaLocations.getList("listingPatternLocations");
				logger.info("DFC location data:"+rotaLocationsData);
				
				for (int j = 0; j < rotaLocationsData.size(); j++) {
					Map<String, Object> locationsData = (HashMap<String, Object>) rotaLocationsData.get(j);
					
					if(locationsData.get("locationName").equals("DFJA"+courtNumber+" Location"))
					{
						dfjaLocationID=(String) locationsData.get("id");
						logger.info("DFC location id:"+dfjaLocationID);
						List<Object> venuesCourt1List=(ArrayList<Object>) locationsData.get("listingPatternVenues");
						
						Map<String, Object> venuesCourt1Data = (HashMap<String, Object>) venuesCourt1List.get(0);
						dfjaLocationVenue=(String) venuesCourt1Data.get("id");
						logger.info("DFC location venue:"+dfjaLocationVenue);
						
					} 
				}
				
				
				
			}
				
				
		}
	}
	
	@Given("^Optimised Rota admin add all headers to request$")
	public void optimised_Rota_admin_add_all_headers_to_request() throws Throwable {
		Map<String,String> headers= new HashMap<String,String>();
		
		String userName=config.getPropertyValue("authusername-op");
		String courtNumber=config.getPropertyValue("courtNumber-op");
		String clearText=DatabaseUtil.getRotaAdminIDID(connection, userName);
		String sessionId=config.getPropertyValue("x-rota-admin-app-session-id-op");
		optimisedUrlSessionId=idObfuscationServiceImpl.obfuscate(sessionId, clearText);
		courtSessionID=idObfuscationServiceImpl.obfuscate(sessionId, String.valueOf(magsitrateID));
		//courtSessionID=optimisedUrlSessionId;
		
		headers.put("x-rota-admin-app-session-id", sessionId);
		headers.put("authusername", userName);
		headers.put("x-rota-admin-api-key", config.getPropertyValue("x-rota-admin-api-key"));
		headers.put("x-security-app-session-id", sessionId);
		headers.put("x-rota-admin-app-name", config.getPropertyValue("x-rota-admin-app-name"));
		headers.put("accept", config.getPropertyValue("accept"));
		headers.put("content-type", config.getPropertyValue("content-type"));
		requestSpec = new RequestSpecBuilder().addHeaders(headers).setBaseUri(endpointUrl).build();
		
		if((!isExcelReport && isNoNReport) && !isNonRepOptimisedLoadedIDS)
		{
			isOptimisedLoadedIDS=false;
			isNonRepOptimisedLoadedIDS=true;
		}
		
		if(!isOptimisedLoadedIDS)
		{
		isOptimisedLoadedIDS=true;
		//getting locations and rota locations ids
		getLocationsAndRotaLocationIDS(requestSpec,courtNumber,optimisedUrlSessionId);
		}
		
		if(isExcelReport)
		{
			headers.remove("content-type");
			headers.replace("accept", "application/vnd.ms-excel");
			requestSpec = new RequestSpecBuilder().addHeaders(headers).setBaseUri(endpointUrl).build();
		}
	}
	
	@Given("^Published Rota admin add all headers to request$")
	public void published_Rota_admin_add_all_headers_to_request() throws Throwable {
		Map<String,String> headers= new HashMap<String,String>();
		
		String userName=config.getPropertyValue("authusername-pub");
		String courtNumber=config.getPropertyValue("courtNumber-pub");
		String clearText=DatabaseUtil.getRotaAdminIDID(connection, userName);
		String sessionId=config.getPropertyValue("x-rota-admin-app-session-id-pub");
		publishedUrlSessionId=idObfuscationServiceImpl.obfuscate(sessionId, clearText);
		
		publishCourtSessionID=idObfuscationServiceImpl.obfuscate(sessionId, String.valueOf(magsitrateID));
		
		headers.put("x-rota-admin-app-session-id", sessionId);
		headers.put("authusername", userName);
		headers.put("x-rota-admin-api-key", config.getPropertyValue("x-rota-admin-api-key"));
		headers.put("x-security-app-session-id", sessionId);
		headers.put("x-rota-admin-app-name", config.getPropertyValue("x-rota-admin-app-name"));
		headers.put("accept", config.getPropertyValue("accept"));
		headers.put("content-type", config.getPropertyValue("content-type"));
		requestSpec = new RequestSpecBuilder().addHeaders(headers).setBaseUri(endpointUrl).build();
		
		if((!isExcelReport && isNoNReport) && !isNonRepPublishedLoadedIDS)
		{
			isPublishedLoadedIDS=false;
			isNonRepPublishedLoadedIDS=true;
		}
		
		if(!isPublishedLoadedIDS)
		{
			isPublishedLoadedIDS=true;
		//getting locations and rota locations ids
		getLocationsAndRotaLocationIDS(requestSpec,courtNumber,publishedUrlSessionId);
		}
		
		if(isExcelReport)
		{
			headers.remove("content-type");
			headers.replace("accept", "application/vnd.ms-excel");
			requestSpec = new RequestSpecBuilder().addHeaders(headers).setBaseUri(endpointUrl).build();
		}
	}
	
	private void getBaseDetails() throws IOException, ServiceException {
		try {
			if(connection==null || connection.isClosed())
			{
			getTunnelConnection();
			connection =DatabaseUtil.getConnection();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		config =new ReadConfigFile();
		idObfuscationServiceImpl=new IdObfuscationServiceImpl();
		idObfuscationServiceImpl.setEnabled(true);
		//setting password
		password=System.getProperty("password");
		if(password==null || password.isEmpty())
		{
		password=config.getPropertyValue("password");
		}
		//setting rotaAdminApiKey
		rotaAdminApiKey=System.getProperty("adminApiKey");
		if(rotaAdminApiKey==null || rotaAdminApiKey.isEmpty())
		{
			rotaAdminApiKey=config.getPropertyValue("x-rota-admin-api-key");
		}
		
		//setting endpoint url
		endpointUrl=System.getProperty("endpoint");
		if(endpointUrl==null || endpointUrl.isEmpty())
		{
			endpointUrl=config.getPropertyValue("endPointUrl");
		}
		idObfuscationServiceImpl.setPassword(password);
		magsitrateID =DatabaseUtil.getMagistrateIDForSession(connection);
	}
	
	private void getTunnelConnection() throws JSchException, IOException {
		dosshTunnel=System.getProperty("doSSH");
		if(dosshTunnel!=null)
		{
			if(session !=null && session.isConnected()){
	             session.disconnect();  
	         } 
			session=DatabaseUtil.doSshTunnel();
		}
	}
	
}
