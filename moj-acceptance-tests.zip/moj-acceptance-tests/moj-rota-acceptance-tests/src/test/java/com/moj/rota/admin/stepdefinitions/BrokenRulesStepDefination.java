package com.moj.rota.admin.stepdefinitions;

import java.util.List;

import com.moj.rota.base.stepdefs.BaseStepDefination;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class BrokenRulesStepDefination extends BaseStepDefination {
	
	String brokenRuleDate=null;
	String filterTypeVal=null;
	String tabName=null;
	
	@When("^I click on broken rules$")
	public void i_click_on_broken_rules() throws Throwable {
		waitForPage();
		assertUtil.isTrue(onRotaListingPatternPage.getBrokenRulesCount().length()>0);
		onBrokenRulesPage=onRotaListingPatternPage.clickonBrokenRules();
	}

	@Then("^I should see the expanded broken rules$")
	public void i_should_see_the_expanded_broken_rules() throws Throwable {
	   assertUtil.isTrue(onBrokenRulesPage.isBrokenRuleContentDisplayed());
	}
	
	@Then("^Summary by broken rule \"(.*?)\" tab content section should consists of:$")
	public void summary_by_broken_rule_tab_content_section_should_consists_of(String tabName, List<String> tabContent)
			throws Throwable {

		switch (tabName) {
		case "Detail":
			for (String brokenRuleContent : tabContent) {
				if(brokenRuleContent.equalsIgnoreCase("Delete checkbox"))
			 	{
				assertUtil.isTrue(onBrokenRulesPage.isBrokenRuleButtonDisplayed(brokenRuleContent));	
			 	} else {
				assertUtil.isTrue(brokenRuleContent,onBrokenRulesPage.getBrokenRuleContent(brokenRuleContent).length() > 0);
			 	}
			}
			break;
		case "Summary By Broken Rule":
			for (String brokenRuleContent : tabContent) {
				if(brokenRuleContent.equalsIgnoreCase("Summary Delete button"))
			 	{
				assertUtil.isTrue(onBrokenRulesPage.isBrokenRuleButtonDisplayed(brokenRuleContent));	
			 	} else {
				assertUtil.isTrue(brokenRuleContent,onBrokenRulesPage.getBrokenRuleContent(brokenRuleContent).length() > 0);
			 	}
			}
			break;
		case "Summary By sitter":
			for (String brokenRuleContent : tabContent) {
				if(brokenRuleContent.equalsIgnoreCase("Sitter Delete Button"))
			 	{
				assertUtil.isTrue(onBrokenRulesPage.isBrokenRuleButtonDisplayed(brokenRuleContent));	
			 	} else {
				assertUtil.isTrue(brokenRuleContent,onBrokenRulesPage.getBrokenRuleContent(brokenRuleContent).length() > 0);
			 	}
			}
			break;

		}

		onBrokenRulesPage.closeBrokenRulePopUp();
	}

	@When("^I click on broken rule date$")
	public void i_click_on_broken_rule_date() throws Throwable {
		brokenRuleDate=onBrokenRulesPage.clickOnBrokenRuleDate();
	}

	@Then("^I should see the broken rule image in the session$")
	public void i_should_see_the_session() throws Throwable {
	    assertUtil.isTrue(onBrokenRulesPage.isBrokenRuleSessionDisplayed());
	    //onBrokenRulesPage.closeBrokenRulePopUp();
	}
	
	@Then("^I should see the \"(.*?)\" tab$")
	public void i_should_see_the_tab(String tabName) throws Throwable {
		assertUtil.isEquals(tabName, onBrokenRulesPage.getTabName(tabName)); 
	}

	@Then("^Broken rule \"(.*?)\" should consists of:$")
	public void broken_rule_should_consists_of(String tabName, List<String> summaryDetails) throws Throwable {
		switch(tabName)
		{
		case "Detail":
			 for(String detailTabElement:summaryDetails)
			    {
				 	if(detailTabElement.equalsIgnoreCase("Delete button") || detailTabElement.equalsIgnoreCase("Print Button"))
				 	{
				 	assertUtil.isTrue(onBrokenRulesPage.isBrokenRuleButtonDisplayed(detailTabElement));	
				 	} else {
			    	assertUtil.isEquals(detailTabElement.trim(), onBrokenRulesPage.getDetailTabSummary(detailTabElement).trim());
				 	}
			    }
			 break;
		case "Summary By Broken Rule":
			 onBrokenRulesPage.clickSummaryByRule();
			 for(String detailTabElement:summaryDetails)
			    {
				 	if(detailTabElement.equalsIgnoreCase("Summary Print Button"))
				 	{
				 	assertUtil.isTrue(onBrokenRulesPage.isBrokenRuleButtonDisplayed(detailTabElement));	
				 	} else {
			    	assertUtil.isEquals(detailTabElement.trim(), onBrokenRulesPage.getSummaryByRuleTabTitles(detailTabElement).trim());
				 	}
			    }
			 break;
		case "Summary By sitter":
			onBrokenRulesPage.clickSummaryBySitter();
			 for(String detailTabElement:summaryDetails)
			    {
				 	if(detailTabElement.equalsIgnoreCase("Sitter Print Button"))
				 	{
				 	assertUtil.isTrue(onBrokenRulesPage.isBrokenRuleButtonDisplayed(detailTabElement));	
				 	} else {
			    	assertUtil.isEquals(detailTabElement.trim(), onBrokenRulesPage.getSummaryByRuleTabTitles(detailTabElement).trim());
				 	}
			    }
			 break;
					
		}
				
	}
	
	@When("^I click on filter type: \"(.*?)\"$")
	public void i_click_on_filter_type(String filterType) throws Throwable {
		filterTypeVal=filterType;
		onBrokenRulesPage.clickFilterType(filterTypeVal);
	    
	}

	@Then("^I should see the updated results with color :\"(.*?)\"$")
	public void i_should_see_the_updated_results_with_color(String filterColor) throws Throwable {
		if(!(filterColor==null) && !filterColor.equals(""))
		{
	    assertUtil.isEquals(filterColor, onBrokenRulesPage.getSoftAndHardRulesColor(filterTypeVal));
		}
	}

	@Then("^I should see the sitter: \"(.*?)\" , Rule description \"(.*?)\"$")
	public void i_should_see_the_sitter_Rule_description(String sitter, String ruleDescription) throws Throwable {
		if (filterTypeVal.equals("Rule description")) {
			assertUtil.isTrue(sitter, onBrokenRulesPage.getFilterResultCount("Sitter", filterTypeVal));
			assertUtil.isTrue(sitter, onBrokenRulesPage.getFilterResultCount("Rule description", filterTypeVal));
		} else if (filterTypeVal.equals("Fixed Sittings")) {
			assertUtil.isFalse(onBrokenRulesPage.isFixedSittingsResultsDisplayed());
		} else
		{
			assertUtil.isTrue(sitter,
					onBrokenRulesPage.getSitterAndRuleDescription("Sitter", filterTypeVal).length() > 0);
			assertUtil.isTrue(ruleDescription,
					onBrokenRulesPage.getSitterAndRuleDescription("Rule description", filterTypeVal).length() > 0);
		}
		//closing broken rule popup
		onBrokenRulesPage.closeBrokenRulePopUp();
	}
	
	@When("^I click on sitter$")
	public void i_click_on_sitter() throws Throwable {
		onBrokenRulesPage.clickFilterType("Sitter"); 
	}

	@Then("^I should see the sitter information window$")
	public void i_should_see_the_sitter_information_window() throws Throwable {
		assertUtil.isTrue("Sittings panel not displayed",onBrokenRulesPage.isSittingpanelBoxDisplayed());
	}

	@Then("^Sitter window should consists of:$")
	public void sitter_window_should_consists_of(List<String> sitterInformations) throws Throwable {
	   for(String sittingInformation:sitterInformations) 
	   {
		   assertUtil.isTrue(sittingInformation,onBrokenRulesPage.getSitterInformation(sittingInformation).length()>0);
	   }
	   onBrokenRulesPage.closeBrokenRulePopUp();
	}
	
	@When("^I select All or single rule check box \"(.*?)\"$")
	public void i_select_All_or_single_rule_check_box(String deleteType) throws Throwable {
		onBrokenRulesPage.selectDeleteType(deleteType);
	}

	@When("^I click on delete button$")
	public void i_click_on_delete_button() throws Throwable {
		onBrokenRulesPage.clickDelete();
	}

	@Then("^I should see the delete confirmation popup$")
	public void i_should_see_the_delete_confirmation_popup() throws Throwable {
	  assertUtil.isTrue("Deletepopup", onBrokenRulesPage.isDeletePopUpDisplayed());
	}

	@Then("^Delete pop up should contains cancel,confirm buttons$")
	public void delete_pop_up_should_contains_cancel_confirm_buttons() throws Throwable {
		assertUtil.isTrue("Deletepopup Description", onBrokenRulesPage.isDeletePopUpDescription());
		if(tabName==null)
		{
			tabName="Detail";
		}
		switch(tabName)
		{
		case "Summary By Rule":
			assertUtil.isTrue("Deletepopup Ok button ", onBrokenRulesPage.isDeletePopUpOkButton(1));
			assertUtil.isTrue("Deletepopup Cancel button", onBrokenRulesPage.isDeletePopUpByRuleCancel());
			onBrokenRulesPage.closeBrokenRulePopUp();
			break;
		case "Summary By Sitter":
			assertUtil.isTrue("Deletepopup Ok button ", onBrokenRulesPage.isDeletePopUpOkButton(1));
			assertUtil.isTrue("Deletepopup Cancel button", onBrokenRulesPage.isDeletePopUpBySitterCancel());
			onBrokenRulesPage.closeBrokenRulePopUp();
			break;
		case "Detail":
			assertUtil.isTrue("Deletepopup Ok button ", onBrokenRulesPage.isDeletePopUpOkButton(0));
			assertUtil.isTrue("Deletepopup Cancel button", onBrokenRulesPage.isDeletePopUpCancel());
			
		}
					    
	}
	
	@Then("^Deleted broken rule should not exist \"(.*?)\"$")
	public void deleted_broken_rule_should_not_exist(String deleteType) throws Throwable {
	   if(deleteType.equals("Select Single Rule"))
	   {
		   int beforeDeleteSize=onBrokenRulesPage.getBrokesRulesCount();
		   onBrokenRulesPage.deleteBrokenRule();
		   waitForPage();
		   assertUtil.isTrue("Broken rule not deleted",beforeDeleteSize>onBrokenRulesPage.getBrokesRulesCount());
	   }
	   onBrokenRulesPage.closeBrokenRulePopUp();
	}
	
	@When("^I Click on tab \"(.*?)\"$")
	public void i_Click_on_tab(String tabType) throws Throwable {
		tabName=tabType;
		onBrokenRulesPage.clickTabName(tabType);
	}

}
