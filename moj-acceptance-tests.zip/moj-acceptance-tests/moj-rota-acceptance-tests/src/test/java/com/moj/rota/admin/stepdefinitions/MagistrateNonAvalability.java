package com.moj.rota.admin.stepdefinitions;

import java.util.List;
import com.moj.rota.base.stepdefs.BaseStepDefination;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class MagistrateNonAvalability extends BaseStepDefination {
	
	private static String rotaPeriod =null;
	private static String nonaAvaliability =null;
	private static String arrowButtons=null;
	
	@Then("^Should display the Non-availability page$")
	public void should_display_the_Non_availability_page() throws Throwable {
	    assertUtil.isTrue(onMagistrateNonAvailabilityPage.isNonAvailabilityDisplayed());
	}

	@Then("^Non availability page consists of:$")
	public void non_availability_page_consists_of(List<String> nonavailabilityFields) throws Throwable {
		
		for(String fieldName:nonavailabilityFields)
		{
			assertUtil.isTrue(fieldName,onMagistrateNonAvailabilityPage.isPageFieldsDisplayed(fieldName));
		}
	    
	}
	
	@When("^I click on help button type \"(.*?)\"$")
	public void i_click_on_help_button_type(String buttonType) throws Throwable {
		waitForPage();
		onMagistrateNonAvailabilityPage.clickHelpButton(buttonType);
	}

	@When("^I click on Rota period \"(.*?)\"$")
	public void i_click_on_Rota_period(String rotaPeriods) throws Throwable {
		rotaPeriod=rotaPeriods;
		waitForPage();
		if(isMagistrateUI)
		{
			onMagistrateNonAvailabilityPage.clickMagRotaPeriod(rotaPeriods);
		} else {
			onMagistrateNonAvailabilityPage.clickRotaPeriod(rotaPeriods);	
		}
		waitForPage();
		
	}

	@When("^I click on non availability save button$")
	public void i_click_on_non_availability_save_button() throws Throwable {
		if(isMagistrateUI)
		{
			onMagistrateHomePage=onMagistrateNonAvailabilityPage.clickOnMagSave();
		}else {
			onMagistrateSearchPage=onMagistrateNonAvailabilityPage.clickonSave();
		}
		waitForPage();
		
	}

	@Then("^I should see help panel button \"(.*?)\"$")
	public void i_should_see_help_panel_button(String outcomeButton) throws Throwable {
		if(isMagistrateUI)
		{
			onMagistrateNonAvailabilityPage=onMagistrateHomePage.clickStep3Link();
			
		} else if(isDistrictJudge){
			onMagistrateNonAvailabilityPage=onDistrictJudgeSearchPage.clickNonAvailability();
		} else {
			onMagistrateNonAvailabilityPage=onMagistrateSearchPage.clickNonAvailability();
		}
		waitForPage();
		assertUtil.isEquals(outcomeButton, onMagistrateNonAvailabilityPage.getHelpPanelButtonLabel());
	}

	@Then("^should see the help panel information based on \"(.*?)\"$")
	public void should_see_the_help_panel_information_based_on(String helpPnaelInfo) throws Throwable {
		
		switch(helpPnaelInfo)
		{
		case "Hide":
			assertUtil.isTrue(helpPnaelInfo, onMagistrateNonAvailabilityPage.isHelpPanelInfoDisplayed(helpPnaelInfo));
			break;
		case "Show":
			assertUtil.isEquals(helpPnaelInfo, onMagistrateNonAvailabilityPage.getHelpPanelButtonLabel());
			break;
		
		default:
		}


	}

	@Then("^should see the selected Rota period button \"(.*?)\"$")
	public void should_see_the_selected_Rota_period_color(String buttonType) throws Throwable {
		//color code #3398b6=dark blue
		if(isMagistrateUI)
		{
			waitForPage();
			onMagistrateNonAvailabilityPage.clickMagRotaPeriod(rotaPeriod);
			waitForPage();
			assertUtil.isEquals(buttonType, onMagistrateNonAvailabilityPage.getMagRotaPeriodColors(rotaPeriod));
		} else {
			waitForPage();
			onMagistrateNonAvailabilityPage.clickRotaPeriod(rotaPeriod);
			waitForPage();
			assertUtil.isEquals(buttonType, onMagistrateNonAvailabilityPage.getRotaPeriodColors(rotaPeriod));
		}
		
		
		

	}
	
	@When("^I click on clanedar to select non availability type :\"(.*?)\"$")
	public void i_click_on_clanedar_to_select_non_availability_type(String nonAvailabilityType) throws Throwable {
		
		nonaAvaliability=nonAvailabilityType;
		waitForPage();
		onMagistrateNonAvailabilityPage.seleactNonAvalability(nonAvailabilityType);
	    
	}

	@Then("^I should see selected non availability with \"(.*?)\"$")
	public void i_should_see_selected_non_availability_with(String blackrossedMark) throws Throwable {
		if(isMagistrateUI)
		{
			onMagistrateNonAvailabilityPage=onMagistrateHomePage.clickStep3Link();
			waitForPage();
			onMagistrateNonAvailabilityPage.clickMagRotaPeriod(rotaPeriod);
		} else if (isDistrictJudge){
			onMagistrateNonAvailabilityPage=onDistrictJudgeSearchPage.clickNonAvailability();
			waitForPage();
			onMagistrateNonAvailabilityPage.clickRotaPeriod(rotaPeriod);
		} else {
			onMagistrateNonAvailabilityPage=onMagistrateSearchPage.clickNonAvailability();
			waitForPage();
			onMagistrateNonAvailabilityPage.clickRotaPeriod(rotaPeriod);
		}
		
		boolean isSelectable=onMagistrateNonAvailabilityPage.isNonSeletableDay(nonaAvaliability);
		waitForPage();
		if(!isSelectable && blackrossedMark.equals("cross-small.png"))
		{
		waitForPage();
		assertUtil.isTrue(blackrossedMark, onMagistrateNonAvailabilityPage.getSelectedNonAvaliability(nonaAvaliability).contains(blackrossedMark));
		
		} else if(blackrossedMark.equals("cross-small.png") && isSelectable){
			// this scenarion if we are unable to select the perticular day then just checking it is not able to select condition only
			assertUtil.isTrue(isSelectable);
		} else {
			assertUtil.isTrue(blackrossedMark, onMagistrateNonAvailabilityPage.getNonSelectedNonAvaliability(nonaAvaliability).contains(blackrossedMark));
		}
	}
	
	@When("^I click on Month heading$")
	public void i_click_on_Month_heading() throws Throwable {
		//waitForPage();
		onMagistrateNonAvailabilityPage.clickOnMonthHeading();
	}

	@When("^I click on arrow button \"(.*?)\"$")
	public void i_click_on_arrow_button(String arrowButtonsVal) throws Throwable {
		arrowButtons=arrowButtonsVal;
		onMagistrateNonAvailabilityPage.clickArrowButtons(arrowButtons);
	}

	@Then("^should see larger month format calendar$")
	public void should_see_larger_month_format_calendar() throws Throwable {
		if(arrowButtons.equals("6Months"))
		{
			 assertUtil.isTrue(onMagistrateNonAvailabilityPage.isSixMonthViewDisplayed());
		} else {
			assertUtil.isTrue(onMagistrateNonAvailabilityPage.isNextMonthViewDisplayed());
		}
	   
	}

	@Then("^Should display navigation to next or previous month buttons \"(.*?)\"$")
	public void should_display_navigation_to_next_or_previous_month_buttons(String arrows) throws Throwable {
		if(arrowButtons.equals("6Months"))
		{
			if(isMagistrateUI)
			{
				assertUtil.isTrue(onMagistrateNonAvailabilityPage.isMagPresentDisplayed());
			} else {
				assertUtil.isTrue(onMagistrateNonAvailabilityPage.isPresentDisplayed());
			}
			
		} else {
			assertUtil.isTrue(onMagistrateNonAvailabilityPage.isNextAndPrevViewsdisplayed(arrows));
		}
	}

	@Then("^I should see the month belongs to current period \"(.*?)\"$")
	public void i_should_see_the_month_belongs_to_current_period(String currentPeriod) throws Throwable {
		assertUtil.isTrue(onMagistrateNonAvailabilityPage.getMonthsCurrentPeriod(arrowButtons));
	}



}
