package com.moj.rota.admin.stepdefinitions;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.List;

import com.moj.rota.base.stepdefs.BaseStepDefination;
import com.moj.rota.pageobjects.MagistrateSearchPage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class MagistrateSearch extends BaseStepDefination {
	
	@And("^I complete the Search Magistrate form with no data$")
	public void i_complete_the_Search_Magistrate_form_with_no_data() throws Throwable {
		onMagistrateSearchPage = clickOnSearchMagistrateLink().clickSearchButton();
	}

	@Then("^\"(.*?)\" validation messages should be displayed$")
	public void validation_messages_should_be_displayed(String errorMsg) throws Throwable {
		assertEquals(errorMsg, onMagistrateSearchPage.getErrorMsgWithNoData());
	}

	@And("^I complete the Search Magistrate form with valid data$")
	public void i_complete_the_Search_Magistrate_form_with_valid_data() throws Throwable {
		onMagistrateSearchPage = clickOnSearchMagistrateLink().enterValidData();
	}

	@Then("^the appropriate results should be displayed$")
	public void the_appropriate_results_should_be_displayed() throws Throwable {
		if(isDistrictJudge)
		{
			assertTrue(onDistrictJudgeSearchPage.disJudgeFoundMsg());
		} else {
			assertTrue(onMagistrateSearchPage.MagistratesFoundMsg());
		}
		
		
	}

	@And("^I complete the Search Magistrate form with invalid data$")
	public void i_complete_the_Search_Magistrate_form_with_invalid_data() throws Throwable {
		//insert invalid jean number
		onMagistrateSearchPage = clickOnSearchMagistrateLink()
								.enterJeanNumber("123")
								.clickSearchButton();
	}
	
	@Then("^the fields validation messages should be displayed$")
	public void the_fields_validation_messages_should_be_displayed() throws Throwable {
		assertTrue(onMagistrateSearchPage.inValidJeanNumber());
	}

	@And("^I complete the Search Magistrate form with criteria that results in no data$")
	public void i_complete_the_Search_Magistrate_form_with_criteria_that_results_in_no_data() throws Throwable {
		onMagistrateSearchPage = clickOnSearchMagistrateLink()
								 .enterFirstName("invalidFirstName")
								 .clickSearchButton();
	}

	@Then("^\"(.*?)\" message should be displayed$")
	public void message_should_be_displayed(String msg) throws Throwable {
		assertEquals(msg, onMagistrateSearchPage.noResultFoundMsg());
	}
	
	private MagistrateSearchPage clickOnSearchMagistrateLink() {
		return onRotaAdminHomePage.clickOnSearchMagistrateLink();
	}
	
	@When("^I enter search parameters first name :\"(.*?)\" ,last name :\"(.*?)\" ,JEAN number :\"(.*?)\" and click on Search button$")
	public void i_enter_search_parameters(String firstName, String lastName, String jeanNumber) throws Throwable {
		onMagistrateSearchPage.enterSearchData(firstName, lastName, jeanNumber); 
	}

	@Then("^Search results should contains \"(.*?)\"$")
	public void search_results_should_contains(String name) throws Throwable {
	   assertUtil.isTrue(onMagistrateSearchPage.getSearchResultsName(name));
	}

	@Then("^Search results also consist of:$")
	public void search_results_also_consist_of(List<String> resultsSection) throws Throwable {
		for (int i=0;i<resultsSection.size();i++) {
			assertUtil.isTrue(resultsSection.get(i),onMagistrateSearchPage.getSearchResultsSection(resultsSection.get(i),i));
		}

	}
	
	@When("^I click on Search results section :\"(.*?)\"$")
	public void i_click_on_Search_results_section(String location) throws Throwable {
		waitForPage();
		switch(location)
		{
		case "Sitting location" :
			onMagistrateSittingLocationsPage=onMagistrateSearchPage.clickSittingLocation();
			break;
		case "Sitting eligibility" :
			onMagistrateSittingEligibiltyPage=onMagistrateSearchPage.clickSittingEligibility();
			break;
		case "Personal Details" :
			onMagistratePersonalDetailsPage = onMagistrateSearchPage.clickPersonalDetails();
			break;
			
		case "Non-availability" :
			onMagistrateNonAvailabilityPage = onMagistrateSearchPage.clickNonAvailability();
			break;
			
		case "Sitting Preferences" :
			onMagistrateSittingPrefecencesPage = onMagistrateSearchPage.clickOnSittingPreferences();
			break;
			
		case "Sittings" :
			onMagistrateSittingsPage = onMagistrateSearchPage.clickOnSittings();
			break;
		}
		
		
	}
	
	@When("^I click on home pages in screen(\\d+) and screen(\\d+)$")
	public void i_click_on_home_pages_in_screen_and_screen(int arg1, int arg2) throws Throwable {
	    onRotaAdminHomePage=onMagistratePersonalDetailsPage.clickHomePage();
	    onRotaAdminHomePage=onMagistrateSearchPage.clickHomePage();
	}
	
	
}
