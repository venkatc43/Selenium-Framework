package com.moj.rota.admin.stepdefinitions;

import com.moj.rota.base.stepdefs.BaseStepDefination;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class ListingPatternStepDefination extends BaseStepDefination {
	
	private static String patternType=null;
	private static String dayPattern=null;
	private static String dayName=null;
	private static String operationType=null;
	private static String rotaOperationType=null;
	private static String swapType=null;
		
	@When("^I click on create ROta on home page$")
	public void i_click_on_create_ROta_on_home_page() throws Throwable {
		onRotaListingPatternPage=onRotaAdminHomePage.clickOnCreateRota();
	}

	@When("^I select justice area \"(.*?)\"$")
	public void i_select_justice_area(String justiceArea) throws Throwable {
		onRotaListingPatternPage.selectJusticeArea(justiceArea);
	}

	@When("^I click on Lisitn pattern$")
	public void i_click_on_Lisitn_pattern() throws Throwable {
		onRotaListingPatternPage.clickLisitngPattern();
	}

	@Then("^Should display the Listing pattern page$")
	public void should_display_the_Listing_pattern_page() throws Throwable {
		
		assertUtil.isTrue(onRotaListingPatternPage.isRotaListingDisplayed());
	    
	}
	
	@Then("^I should see selected justice area \"(.*?)\"$")
	public void i_should_see_selected_justice_area(String justiceArea) throws Throwable {
		assertUtil.isEquals(justiceArea, onRotaListingPatternPage.getJusticeAreaTitle()); 
	}

	@Then("^Patterns like \"(.*?)\", \"(.*?)\", \"(.*?)\", \"(.*?)\"$")
	public void patterns_like(String week1, String week2, String week3, String week4) throws Throwable {
		assertUtil.isEquals(week1, onRotaListingPatternPage.getPatternsTitle(week1)); 
		assertUtil.isEquals(week2, onRotaListingPatternPage.getPatternsTitle(week2)); 
		assertUtil.isEquals(week3, onRotaListingPatternPage.getPatternsTitle(week3)); 
		assertUtil.isEquals(week4, onRotaListingPatternPage.getPatternsTitle(week4)); 
	}

	@Then("^I should see the locations \"(.*?)\", \"(.*?)\", \"(.*?)\"$")
	public void i_should_see_the_locations(String dfja, String crownCourt, String magistratesCourt) throws Throwable {
		//assertUtil.isTrue(dfja, onRotaListingPatternPage.getLocationsTitle(dfja).contains(dfja)); 
		assertUtil.isTrue(crownCourt, onRotaListingPatternPage.getLocationsTitle(crownCourt).contains(crownCourt));
		assertUtil.isTrue(magistratesCourt, onRotaListingPatternPage.getLocationsTitle(magistratesCourt).contains(magistratesCourt));
		
	}

	@Then("^I should see the Generate Rota button$")
	public void i_should_see_the_Generate_Rota_button() throws Throwable {
		assertUtil.isTrue(onRotaListingPatternPage.isGenerateRotaDisplayed());
	}
	
	@When("^I click on pattern type \"(.*?)\"$")
	public void i_click_on_pattern_type(String patternTypeValue) throws Throwable {
		waitForPage();
		patternType =patternTypeValue;
		onRotaListingPatternPage.selectPatternType(patternTypeValue);
	}

	@When("^I select the location \"(.*?)\"$")
	public void i_select_the_location(String location) throws Throwable {
		onRotaListingPatternPage.clickOnLocation(patternType);
	}
	
	@When("^I click on \"(.*?)\" under selected location$")
	public void i_click_on_under_selected_location(String arg1) throws Throwable {
		onRotaListingPatternPage.clickOnWeekNumberUnderLocation(patternType);
	}

	@When("^I click on \"(.*?)\" venue$")
	public void i_click_on_venue(String addVenue) throws Throwable {
		if(addVenue.equals("Add"))
		{
		operationType=addVenue;
		onRotaListingPatternPage.clickOnAddVenue(patternType); 
		} else if(addVenue.equals("DAdd") || addVenue.equals("DUpdate")){
			operationType=addVenue;
			onRotaListingPatternPage.draftRotaAddVenue(patternType);
		} else if(addVenue.equals("DDelete"))
		{
			operationType=addVenue;
		}
	}

	@When("^I enter venue name \"(.*?)\"$")
	public void i_enter_venue_name(String venueName) throws Throwable {
		waitForPage();
		if (operationType.equals("Add")) {
			onRotaListingPatternPage.enterVenueName(patternType, venueName,0);
		} else if (operationType.equals("DAdd") || operationType.equals("DUpdate")) {
			waitForPage();
			onRotaListingPatternPage.enterVenueName(patternType, venueName,1);
		}
	}

	@Then("^I should see the neewly added venue \"(.*?)\"$")
	public void i_should_see_the_neewly_added_venue(String venueName) throws Throwable {
		//waitForPage();
		
		if (operationType.equals("Add")) {
	   assertUtil.isEquals(venueName, onRotaListingPatternPage.getenteredVenueName(patternType,0));
		} else if (operationType.equals("DAdd") || operationType.equals("DUpdate") ) {
			 assertUtil.isEquals(venueName, onRotaListingPatternPage.getenteredVenueName(patternType,1));
		} else if (operationType.equals("DAdd"))
		{
			assertUtil.isFalse(onRotaListingPatternPage.isVenueRemoveDisplayed());
		}
	}

	@Then("^I should see the selected pattern type \"(.*?)\"$")
	public void i_should_see_the_selected_pattern_type(String selectedPatternType) throws Throwable {
	   assertUtil.isTrue(selectedPatternType, onRotaListingPatternPage.getSelectedPatternRadioStatus(patternType));
	}
	
	@Then("^I should see the split sessions \"(.*?)\" and \"(.*?)\" including saturday and sunday$")
	public void i_should_see_the_split_sessions_and_including_saturday_and_sunday(String am, String pm) throws Throwable {
		//waitForPage();
		if(patternType.equals("1 week"))
		{
		assertUtil.isEquals(am.toLowerCase(), onRotaListingPatternPage.getAMLabel()); 
		assertUtil.isEquals(pm.toLowerCase(), onRotaListingPatternPage.getPMLabel());
		}
	}

	@Then("^I should see the sessions should be closed$")
	public void i_should_see_the_sessions_should_be_closed() throws Throwable {
		if(patternType.equals("1 week"))
		{
		assertUtil.isTrue(onRotaListingPatternPage.getSATClosedLabel());
		assertUtil.isTrue(onRotaListingPatternPage.getSunClosedLabel());
		}
	}
	
	@When("^I click on closed session on day \"(.*?)\" and AM or PM pattern \"(.*?)\" ,operation_type \"(.*?)\"$")
	public void i_click_on_closed_session_on_day_and_AM_or_PM_pattern(String dayNmaeVal, String dayPatternVal,String operationTypeVal) throws Throwable {
		dayPattern=dayPatternVal;
		dayName=dayNmaeVal;
		operationType=operationTypeVal;
		waitForPage();
		if(operationTypeVal.equals("DLinkUpdate") || operationTypeVal.equals("DLAdd"))
		{
			onRotaListingPatternPage.clickDraftLinkesSessionUpdate(dayPatternVal,dayNmaeVal,operationTypeVal);
		} else {
			onRotaListingPatternPage.clickCloseSession(dayPatternVal,dayNmaeVal,operationTypeVal);
		}
		
	}

	@When("^I select panel type \"(.*?)\" ,business type \"(.*?)\" ,sessions \"(.*?)\"$")
	public void i_select_panel_type_business_type(String panelType, String businessType,String sessions) throws Throwable {
		waitForPage();
		if(!(operationType.equals("Delete")))
		{
		onRotaListingPatternPage.selectPanelBusinessBasedOnDay(dayName, panelType, businessType, sessions);
		}
	}

	
	@Then("^I should see the selected panel type \"(.*?)\" ,business type \"(.*?)\"$")
	public void i_should_see_the_selected_panel_type_business_type(String panelType, String businessType) throws Throwable {
		waitForPage();
		if(!(operationType.equals("Delete")) || operationType.equals("Select"))
		{
		assertUtil.isTrue(onRotaListingPatternPage.getPanelBusinessNameByAMAndPM(dayPattern, dayName, panelType, businessType,operationType)); 
		} /*else {
		assertUtil.isFalse(onRotaListingPatternPage.isDeleteSession());	
		}*/
	}

	@Then("^should see the selected \"(.*?)\"$")
	public void should_see_the_selected(String numberOfSessions) throws Throwable {
		waitForPage();
		waitForPage();
		if (operationType.equals("Delete") && dayPattern.equals("PM")) {
			assertUtil.isTrue(onRotaListingPatternPage.getPMClosedLabel());
		} else if (dayPattern.equals("PM") || operationType.equals("Update")) {
			assertUtil.isTrue(onRotaListingPatternPage.isLinkedSessionDisplayed(dayName, operationType, dayPattern));
		} else if (operationType.equals("Delete")) {
			assertUtil.isTrue(onRotaListingPatternPage.getSunClosedLabel());
		} else if (operationType.equals("Add-Sun")) {
			assertUtil.isTrue(onRotaListingPatternPage.isLinkedSessionDisplayed(dayName, operationType, dayPattern));
		} else {
			assertUtil.isFalse(onRotaListingPatternPage.isLinkedSessionDisplayed(dayName, operationType, dayPattern));
		}
		
	}
	
	@When("^I click on Generate Rota button$")
	public void i_click_on_Generate_Rota_button() throws Throwable {
		onRotaListingPatternPage.clickOnGenerateButton();
	}

	@When("^I click on confirm buttom$")
	public void i_click_on_confirm_buttom() throws Throwable {
	   waitForPage();
	   onRotaListingPatternPage.clickOnConfirmButton();
	}

	@Then("^I should see the Rota profile page \"(.*?)\"$")
	public void i_should_see_the_Rota_profile_page(String rotaProfile) throws Throwable {
	   assertUtil.isTrue(onRotaListingPatternPage.getRotaProfileTitle().contains(rotaProfile));
	}

	@Then("^I should see the Rota period$")
	public void i_should_see_the_Rota_period() throws Throwable {
		assertUtil.isTrue(onRotaListingPatternPage.isRotaPeriod());
	}

	@Then("^I should see the Abort Rota button$")
	public void i_should_see_the_Abort_Rota_button() throws Throwable {
		assertUtil.isTrue(onRotaListingPatternPage.isRotaAbortButton()); 
	}

	@When("^I click on week to see seleected listing pattern session data \"(.*?)\"$")
	public void i_click_on_week_to_see_seleected_listing_pattern_session_data(String weekNumber) throws Throwable {
		waitForPage();
		onRotaListingPatternPage.clcickNextWeekButton(weekNumber);
	}
	
	@When("^I click on location \"(.*?)\" ,\"(.*?)\" ,\"(.*?)\"$")
	public void i_click_on_location(String location, String weekNumber,String dayNameVal) throws Throwable {
		patternType =weekNumber;
		dayName=dayNameVal;
		dayPattern="AM";
		operationType="Select";
		onRotaListingPatternPage.clickOnLocation(patternType);
	}
	
	@Then("^I should see the Rota profile selected panel type \"(.*?)\" ,business type \"(.*?)\"$")
	public void i_should_see_Rota_Profile_the_selected_panel_type_business_type(String panelType, String businessType) throws Throwable {
		if(operationType.equals("Select"))
		{
		assertUtil.isTrue(onRotaListingPatternPage.getRotaPfofilePanelBusinessNameByAMAndPM(dayPattern, dayName, panelType, businessType)); 
		}
	}
	
	@When("^I click on Abort Rota button$")
	public void i_click_on_Abort_Rota_button() throws Throwable {
		waitForPage();
		onRotaListingPatternPage.clickOnAbortRota(); 
	}

	@When("^I click on confirm or cancel or refresh button \"(.*?)\"$")
	public void i_click_on_confirm_or_cancel_or_refresh_button(String rotaType) throws Throwable {
		rotaOperationType=rotaType;
		onRotaListingPatternPage.clickConfirmOrCancelRota(rotaType);
	}

	@Then("^I should see \"(.*?)\"$")
	public void i_should_see(String pageTitle) throws Throwable {
		waitForPage();
	    if(rotaOperationType.equals("Confirm"))
	    {
	    	assertUtil.isTrue(onRotaListingPatternPage.getCreateRotalLable().contains(pageTitle));
	    } else {
	    	assertUtil.isTrue(onRotaListingPatternPage.getRotaProfileTitle().contains(pageTitle));
	    }
	}
	
	@When("^I click on remove venue$")
	public void i_click_on_remove_venue() throws Throwable {
		onRotaListingPatternPage.removeVenue(patternType);
		waitForPage();
	}

	@Then("^I should not see remove venue option after deleting selected venue$")
	public void i_should_not_see_the_split_sessions_and_including_saturday_and_sunday() throws Throwable {
		waitForPage();
		assertUtil.isTrue(onRotaListingPatternPage.isAMSessionDisplayed(patternType));
		
	}
	
	@When("^I select language and justice type \"(.*?)\"$")
	public void i_select_language_and_justice_type(String justiceType) throws Throwable {
		if(!(operationType.equals("Delete")) && !justiceType.equals(""))
		{
		waitForPage();
		onRotaListingPatternPage.selectLanguageAndJustice(justiceType,dayName,dayPattern);
		} else {
			waitForPage();
		}
	}

	@Then("^I should see the selected justice type \"(.*?)\"$")
	public void i_should_see_the_selected_justice_type(String justiceType) throws Throwable {
	    waitForPage();
		if(!(operationType.equals("Delete")) && !justiceType.equals(""))
		{
			assertUtil.isTrue(onRotaListingPatternPage.getSelectedLanguageAndJustice(justiceType,dayName,dayPattern));
		}
	}
	
	@Then("^I should see the selected  profile type \"(.*?)\" and non role stting slot \"(.*?)\"$")
	public void i_should_see_the_selected_profile_type_and_non_role_stting_slot(String justiceType,String nonRolebasedSittingSlots) throws Throwable {
		if(!justiceType.equals(""))
		{
			assertUtil.isTrue(onRotaListingPatternPage.viewSelectedRotaProfileLanguageAndJustice(justiceType));
		}
		
		if(!nonRolebasedSittingSlots.equals(""))
		{
			assertUtil.isTrue(onRotaListingPatternPage.viewSelectedNonRoleSaittingSlot(nonRolebasedSittingSlots));
		}
		
	}
	
	
	@Then("^I should see the number of magistrates \"(.*?)\" can sit on court \"(.*?)\"$")
	public void i_should_see_the_number_of_magistrates_can_sit_on_court(String noOfMagistrates, String typeOfCourt) throws Throwable {
		
		if(typeOfCourt.equals("CROWN"))
		{
			onRotaListingPatternPage.selectCrownCourtMagistrate();
		}
		
		assertUtil.isEquals(Integer.parseInt(noOfMagistrates), onRotaListingPatternPage.getNumberOfMagistares(typeOfCourt));
	    
	}
	
	@When("^I click on week to see seleected Draft rota court session data \"(.*?)\" ,operation_type \"(.*?)\"$")
	public void i_click_on_week_to_see_seleected_Draft_rota_court_session_data_operation_type(String weekNumber, String operationTypeVal) throws Throwable {
		waitForPage();
		operationType=operationTypeVal;
		onRotaListingPatternPage.clcickNextWeekButton(weekNumber);
	}

		
	@When("^I select Draft rota profile justice type for am or pm \"(.*?)\"$")
	public void i_select_Draft_rota_profile_justice_type(String justiceType) throws Throwable {
		if(!(operationType.equals("Delete")) && !justiceType.equals(""))
		{
		waitForPage();
		onRotaListingPatternPage.selectedRotaProfileLanguageAndJustice(justiceType,operationType);
		} 
	    
	}
	
	@Then("^I should see the selected Rota profile justice type \"(.*?)\"$")
	public void i_should_see_the_selected_Rota_profile_justice_type(String justiceType) throws Throwable {
		if(!justiceType.equals(""))
		{
			assertUtil.isTrue(onRotaListingPatternPage.viewSelectedRotaProfileLanguageAndJustice(justiceType));
		}
	}

	@Then("^I should see the linked court sessions \"(.*?)\"$")
	public void i_should_see_the_linked_court_sessions(String numberOfLinkedSessions) throws Throwable {
		if(onRotaListingPatternPage.isLinkedSessionsDisplayed()==true)
		{
			int count =Character.getNumericValue(numberOfLinkedSessions.charAt(0));
		  assertUtil.isEquals(count, onRotaListingPatternPage.linkedSessionCount());
	    } else {
	    	assertUtil.isTrue(onRotaListingPatternPage.closedSessionsCount() >1);
	    }
	}
	
	@When("^I click on Swap icon in draft rota$")
	public void i_click_on_Swap_icon_in_draft_rota() throws Throwable {
		onRotaListingPatternPage.clickSwapTabToOpen();
	}

		
	@When("^I select magistrate to swap \"(.*?)\" , first magistrate \"(.*?)\"  and second \"(.*?)\"$")
	public void i_select_magistrate_to_swap_first_magistrate_and_second(String swapTypeVal, String firstMagistrate ,String secondMagistrate) throws Throwable {
		waitForPage();
		swapType =swapTypeVal;
		onRotaListingPatternPage.selectSwapMagistrate(swapType);
	}

	@When("^I click swap button to swap selected magistrates$")
	public void i_click_swap_button_to_swap_selected_magistrates() throws Throwable {
		onRotaListingPatternPage.clickSwapButton();
	}

	@Then("^I should see swapped magistrate \"(.*?)\" ,\"(.*?)\"$")
	public void i_should_see_swapped_magistrate(String firstMagistrate, String secondMagistrate) throws Throwable {
	   assertUtil.isTrue(secondMagistrate, onRotaListingPatternPage.getSwappedMagistrateName(swapType,secondMagistrate).length()>0);
	}
	
	@When("^I enter the bank holiday date$")
	public void i_enter_the_bank_holiday_date() throws Throwable {
		onRotaListingPatternPage.enterBankHoldayDate(patternType);
	}

	@Then("^I should see the bank holiday Red label$")
	public void i_should_see_the_bank_holiday_Red_label_and_grey_shading_on_bank_holiday() throws Throwable {
		assertUtil.isTrue("BankHoliday Label", onRotaListingPatternPage.isBankHoliday(patternType)); 
	}
	
	@When("^I click on Maintain rota$")
	public void i_click_on_Maintain_rota() throws Throwable {
		onRotaListingPatternPage=onRotaAdminHomePage.clickOnMaintainRota();
	}
	
	@Then("^I should see the swap vaditaion message \"(.*?)\"$")
	public void i_should_see_the_swap_vaditaion_message(String validationMessage) throws Throwable {
	   assertUtil.isTrue(onRotaListingPatternPage.getSwapValidationMessage(swapType).contains(validationMessage));
	}
	
	@When("^I select magistrate eligibility$")
	public void i_select_magistrate_eligibility() throws Throwable {
		locationStartDate =onRotaListingPatternPage.getCurrentLocationStartDate();
		onMagistrateSittingEligibiltyPage=onRotaListingPatternPage.selectEligibilty();
		isSwapUi=true;
	}
	
	@When("^I perform a swap with District judge \"(.*?)\" to Becnh of three magistrates \"(.*?)\" ,\"(.*?)\"$")
	public void i_perform_a_swap_with_District_judge_to_Becnh_of_magistrates(String dj,String bench, String swapTypeVal) throws Throwable {
		waitForPage();
		swapType =swapTypeVal;
		onRotaListingPatternPage.selectSwapMagistrate(swapType);
	}

	@Then("^Selecting single magistrate swap option should be disabled$")
	public void selecting_single_magistrate_swap_option_should_be_disabled() throws Throwable {
		switch(swapType)
		{
		case "DJ TO BENCH":
		case "BENCH TO DJ":
			assertUtil.isTrue(onRotaListingPatternPage.isMagistrateSwapOptionDisabled());
			break;
		case "MAGISTRATE TO DJ":
			assertUtil.isFalse(onRotaListingPatternPage.isMagistrateSwapOptionDisabled());
			break;
		}
	   
	}

	@Then("^Should see district judge and bench swap options$")
	public void should_see_district_judge_and_bench_swap_options() throws Throwable {
		switch(swapType)
		{
		case "DJ TO BENCH":
		case "BENCH TO DJ":
			 assertUtil.isFalse(onRotaListingPatternPage.isDistrictJudgeSwapOptionDisabled());
			break;
		case "MAGISTRATE TO DJ":
			assertUtil.isTrue(onRotaListingPatternPage.isDistrictJudgeSwapOptionDisabled());
			break;
		}
		 
	}
	
	@Then("^I should see the swapped DJ and Bench$")
	public void i_should_see_the_swapped_DJ_and_Bench() throws Throwable {
		assertUtil.isTrue(onRotaListingPatternPage.getSwappedMagistrateName(swapType,"DJ").length()>0); 	    
	}
	
	@When("^I select first dj \"(.*?)\" ,second dj \"(.*?)\" \"(.*?)\"$")
	public void i_select_first_dj_second_dj(String DJ1, String DJ2, String swapTypeVal) throws Throwable {
		waitForPage();
		swapType =swapTypeVal;
		onRotaListingPatternPage.selectSwapMagistrate(swapType);
	}
	
	@Then("^Should see the swapped DJ's or Deputy DJ's$")
	public void should_see_the_swapped_DJ_s_or_Deputy_DJ_s() throws Throwable {
		assertUtil.isTrue(onRotaListingPatternPage.getSwappedMagistrateName(swapType,"DJ").length()>0);
	}
	
	@When("^I click on DJ to add Deputy DJ$")
	public void i_click_on_DJ_to_add_Deputy_DJ() throws Throwable {
		waitForPage();
		onRotaListingPatternPage.clickDJ();
	}

	@When("^I enter name of the deputy DJ \"(.*?)\"$")
	public void i_enter_name_of_the_deputy_DJ(String nameOfDeputyDJ) throws Throwable {
		onRotaListingPatternPage.enterDeputyDJName(nameOfDeputyDJ);
	}

	@When("^I click on save the new deputy DJ$")
	public void i_click_on_save_the_new_deputy_DJ() throws Throwable {
		onRotaListingPatternPage.saveDeputy(); 
	}
	
	@When("^I click on to remove Deputy DJ$")
	public void i_click_on_to_remove_Deputy_DJ() throws Throwable {
		onRotaListingPatternPage.removeDeputyDJ();
	}
	
	@Then("^I should see the popup like you already have created same session in previous screen$")
	public void i_should_see_the_pop_like_you_already_have_created_same_session_in_previous_screen() throws Throwable {
		assertUtil.isTrue("Prevent message box not displayed", onRotaListingPatternPage.isPreventPopDisplayed());
		onRotaListingPatternPage.clickContinuePopUpButton();
	    
	}

}
