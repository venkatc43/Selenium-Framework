package com.moj.rota.admin.stepdefinitions;

import java.util.List;

import com.moj.rota.base.stepdefs.BaseStepDefination;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class MagistratePersonalDetails extends BaseStepDefination {
	
		
	@Then("^Should display the personal details page$")
	public void should_display_the_personal_details_page() throws Throwable {
		assertUtil.isTrue("Personal page details not displayed",onMagistratePersonalDetailsPage.isPersonalDetailsPageDisplayed());
	}

	@Then("^should contains the \"(.*?)\" , logged in user in the top right corner$")
	public void should_contains_the_logged_in_user_in_the_top_right_corner(String myAccount) throws Throwable {
		assertUtil.isEquals(myAccount, onMagistratePersonalDetailsPage.getMyAccountLabel().trim());
		if(isMagistrateUI)
		{
			assertUtil.isTrue(onMagistratePersonalDetailsPage.isMagLoginNameDisplayed());	
		} else {
			assertUtil.isTrue(onMagistratePersonalDetailsPage.isLoginNameDisplayed());
		}
		
	}

	@Then("^\"(.*?)\" should contains at top left of the page$")
	public void should_contains_at_top_left_of_the_page(String home) throws Throwable {
		assertUtil.isEquals(home, onMagistratePersonalDetailsPage.getHomeBreadCumLabel());
	}

	@Then("^should see the page title \"(.*?)\" and \"(.*?)\" buttons$")
	public void should_see_the_page_title_and_buttons(String pageTitle, String confirmButton) throws Throwable {
		assertUtil.isEquals(pageTitle, onMagistratePersonalDetailsPage.getPageTitle());
		if(isDistrictJudge)
		{
			assertUtil.isEquals(confirmButton, onMagistratePersonalDetailsPage.getDistrictConfirmButtonLabel());
		} else {
			assertUtil.isEquals(confirmButton, onMagistratePersonalDetailsPage.getConfirmButtonLabel());
		}
		
	}

	@Then("^should see the correct order of the fields$")
	public void should_see_the_correct_order_of_the_fields(List<String> orderOftheFields) throws Throwable {
		
		for(int i=1;i<orderOftheFields.size();i++)
		{
			String fieldName=orderOftheFields.get(i);
			assertUtil.isTrue(fieldName,onMagistratePersonalDetailsPage.isPageFieldsDisplayed(fieldName,isDistrictJudge));
		}
	    
	}
	
	@When("^I update prefred phone number \"(.*?)\" and type \"(.*?)\"$")
	public void i_update_prefred_phone_number_and_type(String phoneNumber, String contactType) throws Throwable {
		if(isDistrictJudge)
		{
			onMagistratePersonalDetailsPage.disEnterPhoneNumberAndType(phoneNumber, contactType);
		} else {
			onMagistratePersonalDetailsPage.enterPhoneNumberAndType(phoneNumber, contactType);
		}
		
	}
	
	@When("^I update the first name :\"(.*?)\" ,last name :\"(.*?)\"$")
	public void i_update_the_first_name_last_name(String firstName, String lastName) throws Throwable {
		onMagistratePersonalDetailsPage.enterFirstNameAndLastName(firstName, lastName);
	}

	@When("^I click on confirm button$")
	public void i_click_on_confirm_button() throws Throwable {
		if(isMagistrateUI==true)
		{
			onMagistrateHomePage=onMagistratePersonalDetailsPage.clickMagistrateConfirm();
		}else if(isDistrictJudge==true){
			onMagistratePersonalDetailsPage.clickMagConfirm();
		} else {
			onMagistratePersonalDetailsPage.clickConfirm();
		}
		
	}

	@Then("^should see the updated details \"(.*?)\",\"(.*?)\"$")
	public void should_see_the_updated_details(String phoneNumber, String phoneType) throws Throwable {
		waitForPage();
		if(isMagistrateUI)
		{
			onMagistratePersonalDetailsPage=onMagistrateHomePage.clickPersonalDetailLink();	
		}else if(isDistrictJudge){
			onMagistratePersonalDetailsPage=onDistrictJudgeSearchPage.clickPersonalDetails();
		} else {
			onMagistratePersonalDetailsPage=onMagistrateSearchPage.clickPersonalDetails();
		}
		
		if(isDistrictJudge){
			// assertUtil.isEquals(phoneNumber, onMagistratePersonalDetailsPage.getTelePhoneNumber(phoneType));
		    assertUtil.isEquals(phoneType, onMagistratePersonalDetailsPage.getdisJTelePhoneType(phoneType));
			
		} else {
			// assertUtil.isEquals(phoneNumber, onMagistratePersonalDetailsPage.getTelePhoneNumber(phoneType));
		    assertUtil.isEquals(phoneType, onMagistratePersonalDetailsPage.getTelePhoneType(phoneType));
		}
	   
	    
	}
	
	@Then("^Should not able to edit the email field$")
	public void should_not_able_to_edit_the_email_field() throws Throwable {
		assertUtil.isFalse("Email :",onMagistratePersonalDetailsPage.isEmailEditable());
	}



}
