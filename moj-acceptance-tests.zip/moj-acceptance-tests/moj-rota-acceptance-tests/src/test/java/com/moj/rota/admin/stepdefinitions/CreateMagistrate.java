package com.moj.rota.admin.stepdefinitions;

import static org.junit.Assert.assertTrue;

import java.util.List;

import com.moj.rota.base.stepdefs.BaseStepDefination;
import com.moj.rota.pageobjects.ErrorCreatingMagistratePage;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class CreateMagistrate extends BaseStepDefination {
	
	private ErrorCreatingMagistratePage onErrorCreatingMagistratePage;
			
	@When("^I complete the Add Magistrate form with first name :\"(.*?)\" ,last name :\"(.*?)\" ,email \"(.*?)\" and \"(.*?)\",\"(.*?)\"$")
	public void i_complete_the_Add_Magistrate_form_with_and(String firstName, String lastName, 
			String emailAddress,String data,String location) throws Throwable {
		
		switch(data)
		{
		case "valid" :
			onConfirmationPopUp = onRotaAdminHomePage.clickOnCreateMagistrateLink().
			createMagistrateWithValidData(firstName,lastName,emailAddress,location);
			onRotaAdminHomePage = onConfirmationPopUp.clickContinueButton();
			break;
		case "invalid" :
			onErrorCreatingMagistratePage = onRotaAdminHomePage.clickOnCreateMagistrateLink()
            .createMagistrateWithInValidData(location);
			break;
		default :
			System.out.println("There is no option");
		}
		
		
	}

	@When("^I click on create magidtrate link$")
	public void i_click_on_create_magidtrate_link() throws Throwable {
		onCreateMagistratePage = onRotaAdminHomePage.clickOnCreateMagistrateLink();
	}
	
	@Then("^should display create Magistrate page$")
	public void should_display_create_Magistrate_page() throws Throwable {
		assertTrue("Create Magistrate page not displayed",onCreateMagistratePage.isPersonalDetailsDisplayed());
	}

	@Then("^Magistrate personal details section should consist of:$")
	public void magistrate_personal_details_section_should_consist_of(List<String> pageFields) throws Throwable {
		for (int i=1;i<pageFields.size();i++) {
			String field=pageFields.get(i);
			assertTrue("Page Fields not displayed:" + field, onCreateMagistratePage.isPageFieldsDisplayed(field));
		}

	}
	
	@Then("^the Magistrate \"(.*?)\" be created$")
	public void the_Magistrate_be_created(String status) throws Throwable {
		waitForPage();
	    switch(status)
	    {
	    case "should":
	    	assertTrue(onRotaAdminHomePage.verifyAdminHomePageisDisplayed());
	    	break;
	    case "should not":
	    	assertTrue(onErrorCreatingMagistratePage.errorHeading());
	    	onRotaAdminHomePage=onErrorCreatingMagistratePage.closeErrorDialog();
	    	break;
	    default :
	    	System.out.println("No option selected");
	    }
	}
	
}
