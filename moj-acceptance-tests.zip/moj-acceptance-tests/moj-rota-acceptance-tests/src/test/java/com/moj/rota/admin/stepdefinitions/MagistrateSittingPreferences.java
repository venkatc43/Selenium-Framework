package com.moj.rota.admin.stepdefinitions;

import java.util.List;

import com.moj.rota.base.stepdefs.BaseStepDefination;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class MagistrateSittingPreferences extends BaseStepDefination {
	
	@Then("^Should display the Sitting Preferences page$")
	public void should_display_the_Sitting_Preferences_page() throws Throwable {
	   assertUtil.isTrue(onMagistrateSittingPrefecencesPage.isSittingPreferencesPageDisplayed());
	}

	@Then("^should see the page title \"(.*?)\" and name of the magistrate$")
	public void should_see_the_page_title_and_name_of_the_magistrate(String pageTitle) throws Throwable {
		assertUtil.isEquals(pageTitle, onMagistrateSittingPrefecencesPage.getPageTitle()); 
	}

	@Then("^should see the Sitting Preferences fields:$")
	public void should_see_the_Sitting_Preferences_fields(List<String> fields) throws Throwable {
	   for(int i=1;i<fields.size();i++)
	   {
		   assertUtil.isTrue(fields.get(i), onMagistrateSittingPrefecencesPage.isPageFieldsDisplayed(fields.get(i),isMagistrateUI)); 
	   }
	}

	@Then("^Should see the disable fileds$")
	public void should_see_the_disable_fileds(List<String> disabledFields) throws Throwable {
		for(int i=0;i<disabledFields.size();i++)
		   {
			   assertUtil.isTrue(disabledFields.get(i), onMagistrateSittingPrefecencesPage.isDisabledPageFieldsDisplayed(disabledFields.get(i))); 
		   } 
	}
	
	@When("^I Select weekly pattern \"(.*?)\"$")
	public void i_Select_weekly_pattern(String weeklyPattern) throws Throwable {
		if(weeklyPattern!=null && !weeklyPattern.equals(""))
		{
		onMagistrateSittingPrefecencesPage.selectWeeklyPattern(weeklyPattern);
		}
	}

	@When("^I checked half day sitting and select morning or after noon \"(.*?)\"$")
	public void i_checked_half_day_sitting_and_select_morning_or_after_noon(String halfDayPattern) throws Throwable {
		if(halfDayPattern!=null && !halfDayPattern.equals(""))
		{
		onMagistrateSittingPrefecencesPage.selectHalfDayPattern(halfDayPattern);
		}
	}

	@When("^I select youth member ship only \"(.*?)\"$")
	public void i_select_youth_member_ship_only(String youthMemebership) throws Throwable {
		if(youthMemebership!=null && !youthMemebership.equals(""))
		{
		onMagistrateSittingPrefecencesPage.selectYouthMemberShip();
		}
	}

	@When("^I select Family member ship only \"(.*?)\"$")
	public void i_select_Family_member_ship_only(String familyMemberShip) throws Throwable {
		if(familyMemberShip!=null && !familyMemberShip.equals(""))
		{
		onMagistrateSittingPrefecencesPage.selectFaliyMemberShip();
		}
	}

	@Then("^should see the warning message \"(.*?)\"$")
	public void should_see_the_warning_message(String warningMessage) throws Throwable {
		if(warningMessage.equals("Cannot select pattern and half day") || warningMessage.equals("Cannot select all"))
		{
	   assertUtil.isTrue(onMagistrateSittingPrefecencesPage.isWarningMessageDisplayed(warningMessage));
		} else {
		assertUtil.isFalse(onMagistrateSittingPrefecencesPage.isWarningMessageDisplayed(warningMessage));
		}
		isPreferenceValidation=true;
		
	}

	@When("^I select frequency \"(.*?)\", Able to sit on \"(.*?)\"$")
	public void i_select_frequency_Able_to_sit_on(String frequency, String ableToSit) throws Throwable {
		if(frequency!=null && !frequency.equals(""))
		{
		onMagistrateSittingPrefecencesPage.selectFrequency(frequency);
		}
		
		if(ableToSit!=null && !ableToSit.equals(""))
		{
		onMagistrateSittingPrefecencesPage.selectSitOnDays(ableToSit);
		}
	}

	@When("^I select available at short notice \"(.*?)\"$")
	public void i_select_available_at_short_notice(String availableAtShortNotice) throws Throwable {
		if(availableAtShortNotice!=null && !availableAtShortNotice.equals(""))
		{
		waitForPage();
		onMagistrateSittingPrefecencesPage.selectAvailableAtShortNotice(availableAtShortNotice);
		}
	}

	@When("^I click on sitting preferences save button$")
	public void i_click_on_sitting_preferences_save_button() throws Throwable {
		if(isMagistrateUI)
		{
			onMagistrateHomePage=onMagistrateSittingPrefecencesPage.clickonMagSave();
		} else {
			onMagistrateSittingPrefecencesPage.clickonSave();
		}
		
	}

	@Then("^I should see selected frequency \"(.*?)\" ,sit on days \"(.*?)\",Available short notice \"(.*?)\"$")
	public void i_should_see_selected_frequency_sit_on_days_Available_short_notice(String selectedFrequency, String sitOndays, String selectedShortNotice) throws Throwable {
	  if(isMagistrateUI)
	  {
		  onMagistrateSittingPrefecencesPage = onMagistrateHomePage.clickStep2Link();
	  } else {
		  onMagistrateSittingPrefecencesPage=onMagistrateSearchPage.clickOnSittingPreferences(); 
	  }
	  waitForPage(); 
	   assertUtil.isEquals(selectedFrequency, onMagistrateSittingPrefecencesPage.getSelectedFrequency());
	   assertUtil.isEquals(selectedShortNotice, onMagistrateSittingPrefecencesPage.getSelectedShortNotice());
	   assertUtil.isTrue(sitOndays, onMagistrateSittingPrefecencesPage.selectedSitOnDays(sitOndays));
	}

	@When("^I select special requirements \"(.*?)\"$")
	public void i_select_special_requirements(String specialRequirements) throws Throwable {
		
		if(specialRequirements!=null && !specialRequirements.equals(""))
		{
		onMagistrateSittingPrefecencesPage.enterSpecialRequirements(specialRequirements);
		}
	}

	@Then("^I should see selected sittings only \"(.*?)\" weekly pattern \"(.*?)\"$")
	public void i_should_see_selected_sittings_only_weekly_pattern(String sittingType, String weeklyPattern) throws Throwable {
		onMagistrateSearchPage.clickOnSittingPreferences();
		waitForPage();
		if(sittingType!=null && !sittingType.equals(""))
		{
			assertUtil.isTrue(sittingType, onMagistrateSittingPrefecencesPage.getSelectedFamilyMember());
		}
		
		if(weeklyPattern!=null && !weeklyPattern.equals(""))
		{
			assertUtil.isTrue(weeklyPattern, onMagistrateSittingPrefecencesPage.getSelectedWeeklyPattern(weeklyPattern));
		}
	   
	}

	@Then("^I should see half day sitting \"(.*?)\" ,special requirements \"(.*?)\"$")
	public void i_should_see_special_requirements_half_day_sitting(String halfDaySitting,String specialRequirements) throws Throwable {
		waitForPage();
		assertUtil.isTrue(specialRequirements, onMagistrateSittingPrefecencesPage.getenteredSpecialRequirements());
		if(halfDaySitting!=null && !halfDaySitting.equals(""))
		{
			assertUtil.isEquals(halfDaySitting, onMagistrateSittingPrefecencesPage.getSelectedHalfDayPattern());
		}
	}

  //District judge related
	
	@When("^I select able to sit on days :$")
	public void i_select_able_to_sit_on_days(List<String> sitOnDays) throws Throwable {
		for (int i = 0; i < sitOnDays.size(); i++) {
			onMagistrateSittingPrefecencesPage.selectSitOnDays(sitOnDays.get(i));
		}
	}

	@Then("^I should see selected sit on days:$")
	public void i_should_see_selected_sit_on_days(List<String> sitOnDays) throws Throwable {
		onMagistrateSittingPrefecencesPage=onDistrictJudgeSearchPage.clickOnSittingPreferences();
		for (int i = 0; i < sitOnDays.size(); i++) {
			assertUtil.isTrue(sitOnDays.get(i), onMagistrateSittingPrefecencesPage.selectedSitOnDays(sitOnDays.get(i)));
		}
	}

	@Then("^I should see special requirements \"(.*?)\"$")
	public void i_should_see_special_requirements(String specialRequirements) throws Throwable {
		assertUtil.isTrue(specialRequirements, onMagistrateSittingPrefecencesPage.getenteredSpecialRequirements());
	}


}
