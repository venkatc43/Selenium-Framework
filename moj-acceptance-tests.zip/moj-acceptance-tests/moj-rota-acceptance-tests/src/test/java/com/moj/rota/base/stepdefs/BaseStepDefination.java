
package com.moj.rota.base.stepdefs;

import java.sql.Connection;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Random;

import org.openqa.selenium.WebDriver;

import com.jayway.restassured.builder.ResponseSpecBuilder;
import com.jayway.restassured.response.Response;
import com.jayway.restassured.specification.RequestSpecification;
import com.jayway.restassured.specification.ResponseSpecification;
import com.jcraft.jsch.Session;
import com.moj.rota.listingpattern.pageobjects.BrokenRulesPage;
import com.moj.rota.listingpattern.pageobjects.DraftRotaMagistrateListPopupPage;
import com.moj.rota.listingpattern.pageobjects.RotaListingPatternPage;
import com.moj.rota.magistrate.pageobjects.MagistrateHomePage;
import com.moj.rota.magistrate.pageobjects.MagistrateLoginPage;
import com.moj.rota.pageobjects.ConfirmationPopUp;
import com.moj.rota.pageobjects.CreateDistrictJudgePage;
import com.moj.rota.pageobjects.CreateMagistratePage;
import com.moj.rota.pageobjects.DistrictJudgeSearchPage;
import com.moj.rota.pageobjects.MagistrateAdvanceSearchPage;
import com.moj.rota.pageobjects.MagistrateAlertMessagePage;
import com.moj.rota.pageobjects.MagistrateNonAvailabilityPage;
import com.moj.rota.pageobjects.MagistratePersonalDetailsPage;
import com.moj.rota.pageobjects.MagistrateSearchPage;
import com.moj.rota.pageobjects.MagistrateSittingEligibiltyPage;
import com.moj.rota.pageobjects.MagistrateSittingLocationsPage;
import com.moj.rota.pageobjects.MagistrateSittingPrefecencesPage;
import com.moj.rota.pageobjects.MagistrateSittingsPage;
import com.moj.rota.pageobjects.OptimisationStatusPage;
import com.moj.rota.pageobjects.RotaAdminHomePage;
import com.moj.rota.pageobjects.RotaLoginPage;
import com.moj.rota.pageobjects.StandardReportsPage;
import com.moj.rota.parameters.pageobjects.BenchChairPage;
import com.moj.rota.parameters.pageobjects.CombinedYouthPanelsPage;
import com.moj.rota.parameters.pageobjects.LocalBenchCompositionPage;
import com.moj.rota.parameters.pageobjects.RotaParametersLocationPage;
import com.moj.test.utils.AssertUtil;
import com.moj.test.utils.ReadConfigFile;


public class BaseStepDefination{
	
	protected AssertUtil assertUtil;
	
	public BaseStepDefination()
	{
		assertUtil = getAssertUtil();
	}
	
	protected static WebDriver driver;
	protected static WebDriver proxy_driver;
	
	public ConfirmationPopUp onConfirmationPopUp;

	public static RequestSpecification requestSpec;
	
	public static String urlSessionId =null;
	public static String optimisedUrlSessionId =null;
	public static String publishedUrlSessionId =null;
	public static String courtSessionID =null;
	public static String publishCourtSessionID =null;
	public static String rotaAdminApiKey =null;
	public static String password =null;
	public static String requirements=null;
	public static Response response =null;
	
	public static String locationID =null;
	
	public static String ljaNorthLocationID =null;
	public static String ljaSouthLocationID =null;
	public static String dfjaID =null;
	public static String magCourt1 =null;
	public static String magCourt2 =null;
	public static String magCrownCourt =null;
	public static String dfjaLocationID =null;
	public static String magCourt1Venue =null;
	public static String magSouthCourt2Venue =null;
	public static String magCourt2Venue =null;
	public static String magCrownCourtVenue =null;
	public static String rotaPeriodStartDate =null;
	public static String dfjaLocationVenue =null;
	public static boolean isDraftLoadedIDS =false;
	public static boolean isOptimisedLoadedIDS =false;
	public static boolean isPublishedLoadedIDS =false;
	public static boolean isNonRepDraftLoadedIDS =false;
	public static boolean isNonRepOptimisedLoadedIDS =false;
	public static boolean isNonRepPublishedLoadedIDS =false;
	public static String requestType =null;
	public static String venuesType =null;
	public ReadConfigFile config=null;	
	public static boolean isMagistrateUI= false;
	public static boolean isDistrictJudge= false;
	public static String createdSessionID=null;
	public static boolean isSwapUi= false;
	public static String locationStartDate= null;
	public static String windowName=null;
	public static boolean isReports=false;
	public static boolean isDbCleanup=false;
	public static boolean isPreferenceValidation=false;
	public static Connection connection=null;
	public static Session session=null;
	public static String random_password= "testpass"+randomNumber(1000,99999);
	public static final String SET_NEW_PASSWORD=random_password;
	public static final String SET_CONFIRM_NEW_PASSWORD=random_password;
				
	protected static RotaLoginPage onRotaLoginPage;
	protected static RotaAdminHomePage onRotaAdminHomePage;
	protected static MagistrateSearchPage onMagistrateSearchPage;
    protected static MagistrateAdvanceSearchPage onMagisstrateAdvanceSearchPage;
	protected static DistrictJudgeSearchPage onDistrictJudgeSearchPage;
	protected static CreateDistrictJudgePage onCreateDistrictJudgePage;
	protected static CreateMagistratePage onCreateMagistratePage;
	protected static String errorMsg;
	protected static String environment ="";
	
	protected static MagistrateLoginPage onMagistrateLoginPage;
	protected static MagistrateHomePage onMagistrateHomePage;
	protected static MagistrateSittingLocationsPage onMagistrateSittingLocationsPage;
	protected static MagistrateSittingEligibiltyPage onMagistrateSittingEligibiltyPage;
	protected static MagistratePersonalDetailsPage onMagistratePersonalDetailsPage;
	protected static MagistrateNonAvailabilityPage onMagistrateNonAvailabilityPage;
	protected static MagistrateSittingPrefecencesPage onMagistrateSittingPrefecencesPage;
	protected static RotaListingPatternPage onRotaListingPatternPage;
	protected static DraftRotaMagistrateListPopupPage onDraftRotaMagistrateListPopupPage;
	protected static MagistrateAlertMessagePage onMagistrateAlertMessagePage;
	protected static MagistrateSittingsPage onMagistrateSittingsPage;
	protected static RotaParametersLocationPage onRotaParametersLocationPage;
	protected static BenchChairPage onRotaParametersBenchChairPage;
	protected static LocalBenchCompositionPage onRotaParametersLocalBenchPage;
	protected static CombinedYouthPanelsPage onCombinedYouthPanelsPage;
	protected static OptimisationStatusPage onOptimisationStatusPage;
	protected static StandardReportsPage onStandardReportsPage;
	protected static BrokenRulesPage onBrokenRulesPage;
	
	protected void magistrateLogin(List<String> loginCredentials) {
		if(environment.equals("sit") || environment.equals("sandbox"))
		{
		String userName=System.getProperty("userName");
		String password=System.getProperty("password");
		//onMagistrateLoginPage.enterUsername(userName);
		//onMagistrateLoginPage.enterPassword(password);
		onMagistrateHomePage=onMagistrateLoginPage.sitLogin(userName,password);
		} else {
		onMagistrateLoginPage.enterUsername(System.getProperty("userName"));
		onMagistrateLoginPage.enterPassword(System.getProperty("password"));
		onMagistrateHomePage = onMagistrateLoginPage.clickLoginButton();
		}
		
	}
	
	protected void rotaAdminLoggedIn(List<String> loginCredentials) {
		if(environment.equals("sit") || environment.equals("sandbox"))
		{
			String userName=System.getProperty("rotaUserName");
			String password=System.getProperty("rotaPassword");
			onRotaAdminHomePage = onRotaLoginPage.sitLogin(userName,password);
		}else {
			/*onRotaLoginPage.enterUsername(loginCredentials.get(0));
			onRotaLoginPage.enterPassword(loginCredentials.get(1));*/
			String userName=System.getProperty("rotaUserName");
			String password=System.getProperty("rotaPassword");
			onRotaLoginPage.enterUsername(userName);
			onRotaLoginPage.enterPassword(password);
			onRotaAdminHomePage = onRotaLoginPage.clickLoginButton();	
		}
			
	}
	
	public static String randomNumber(int min, int max) {

	    Random rand = new Random();

	    int randomNum = rand.nextInt((max - min) + 1) + min;

	    return String.valueOf(randomNum);
	}
	
	public AssertUtil getAssertUtil()
	{
		if(assertUtil==null)
		{
			assertUtil = new AssertUtil();
		}
		
		return assertUtil;
	}
	
	public void waitForPage()
	{
		//driver.manage().timeouts().pageLoadTimeout(5, TimeUnit.SECONDS);
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public String getDate(int month)
	{
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.MONTH, month);
		
		String modifiedDate= new SimpleDateFormat("dd/MM/yyyy").format(calendar.getTime());
		return modifiedDate;
	}
	
	public String getDateForRestRequest(int month)
	{
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.MONTH, month);
		
		String modifiedDate= new SimpleDateFormat("dd-MM-yyyy").format(calendar.getTime());
		return modifiedDate;
	}
	

	public static ResponseSpecification getResponseSpecification()
	{
		ResponseSpecification responseSpec = new ResponseSpecBuilder().expectStatusCode(200).build();
		return responseSpec;
	}
	
	public String getDraftLJALocationID(String ljaLocation)
	{
		String ljaLocationID=null;
		switch(ljaLocation)
		{
		case "Local Justice Area 8 North":
			ljaLocationID=ljaNorthLocationID;
			break;
		case "Local Justice Area 8 South":
			ljaLocationID=ljaSouthLocationID;
			break;
		case "Designated Family Centre 8":
			ljaLocationID=dfjaID;
			break;
		}
		
		return ljaLocationID;
	}
	
	public String getDraftRotaLocationID(String location)
	{
		String locationID=null;
		switch(location)
		{
		case "LJA 8 South Magistrates Court1":
			locationID=magCourt1;
			break;
		case "LJA 8 South Magistrates Court2":
			locationID=magCourt2;
			break;
		case "DFJA8 Location":
			locationID=dfjaLocationID;
			break;
		case "LJA 8 South Crown Court":
			locationID=magCrownCourt;
			break;
		}
		
		return locationID;
	}
	
	public String getOptimisedVenueID(String location)
	{
		String venueID=null;
		switch(location)
		{
		case "LJA 9 South Magistrates Court 1":
			venueID=magCourt1Venue;
			break;
		case "LJA 9 South Magistrates Court 2":
			venueID=magCourt2Venue;
			break;
		case "LJA 9 South Crown Court":
			venueID=magCrownCourtVenue;
			break;
		}
		
		return venueID;
	}
	
	public String getPublishedVenueID(String location)
	{
		String venueID=null;
		switch(location)
		{
		case "LJA 10 South Magistrates Court 1":
			venueID=magCourt1Venue;
			break;
		case "LJA 10 South Magistrates Court 2":
			venueID=magCourt2Venue;
			break;
		case "LJA 10 South Crown Court":
			venueID=magCrownCourtVenue;
			break;
		case "LJA 10 South Magistrates Court 2 mag":
			venueID=magSouthCourt2Venue;
			break;
		}
		
		return venueID;
	}
	
	public int getDayNumber() throws Exception
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat( "dd/MM/yyyy" ); 
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(dateFormat.parse(rotaPeriodStartDate));
		calendar.add(Calendar.DATE, 5);
		Date today = calendar.getTime();
	    String todayName=today.toString().substring(0, 3);
	    int dayNumber=0;
	    dayNumber = getDayNumberByDayName(todayName, dayNumber);
	    return dayNumber;
	}
	
	public int getDayNumberByDate(String date) throws Exception
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat( "dd/MM/yyyy" ); 
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(dateFormat.parse(date));
		Date today = calendar.getTime();
	    String todayName=today.toString().substring(0, 3);
	    int dayNumber=0;
	    dayNumber = getDayNumberByDayName(todayName, dayNumber);
	    return dayNumber;
	}

	private int getDayNumberByDayName(String todayName, int dayNumber) {
		switch(todayName)
	    {
	    case "Mon":
	    	dayNumber=1;
	    	break;
	    case "Tue":
	    	dayNumber=2;
	    	break;
	    case "Wed":
	    	dayNumber=3;
	    	break;
	    case "Thu":
	    	dayNumber=4;
	    	break;
	    case "Fri":
	    	dayNumber=5;
	    	break;
	    case "Sat":
	    	dayNumber=6;
	    	break;
	    case "Sun":
	    	dayNumber=7;
	    	break;
	    }
		return dayNumber;
	}
	
	public String getDate() throws ParseException
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat( "dd/MM/yyyy" );
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(dateFormat.parse(rotaPeriodStartDate));
		calendar.add(Calendar.DATE, 5);
		
		String modifiedDate= dateFormat.format(calendar.getTime());
		return modifiedDate;
	}
	
	public String getYesterdaysDate(int previousDays) throws ParseException
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat( "dd/MM/yyyy" );
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DATE, previousDays);
		
		String modifiedDate= dateFormat.format(calendar.getTime());
		return modifiedDate;
	}
	
	public String getDateForRestRequest() throws ParseException
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat( "dd-MM-yyyy" );
		Calendar calendar = Calendar.getInstance();		
		String modifiedDate= dateFormat.format(calendar.getTime());
		return modifiedDate;
	}
	
	public String getDateByString(String date) throws ParseException
	{
		SimpleDateFormat dateFormat = new SimpleDateFormat( "dd/MM/yyyy" );
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(dateFormat.parse(date));
		calendar.add(Calendar.DATE, 5);
		
		String modifiedDate= dateFormat.format(calendar.getTime());
		return modifiedDate;
	}
		
	public String converedDateByString(String date,int numberToAdd) throws ParseException
	{
		String month =date.substring(2,5);
		System.out.println("Month :"+month);
		
		int convertedMonth=0;
		switch(month)
		{
		case "Jan":
			convertedMonth=1;
			break;
		case "Feb":
			convertedMonth=2;
			break;
		case "Mar":
			convertedMonth=3;
			break;
		case "Apr":
			convertedMonth=4;
			break;
		case "May":
			convertedMonth=5;
			break;
		case "Jun":
			convertedMonth=6;
			break;
		case "Jul":
			convertedMonth=7;
			break;
		case "Aug":
			convertedMonth=8;
			break;
		case "Sep":
			convertedMonth=9;
			break;
		case "Oct":
			convertedMonth=10;
			break;
		case "Nov":
			convertedMonth=11;
			break;
		case "Dec":
			convertedMonth=12;
			break;
		}
		
		String convertedDate=date.substring(0,1)+"/"+convertedMonth+"/"+date.substring(6,10);
		SimpleDateFormat dateFormat = new SimpleDateFormat( "dd/MM/yyyy" );
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(dateFormat.parse(convertedDate));
		calendar.add(Calendar.DATE,numberToAdd);		
		String modifiedDate= dateFormat.format(calendar.getTime());
		return modifiedDate;
		
	}
}
