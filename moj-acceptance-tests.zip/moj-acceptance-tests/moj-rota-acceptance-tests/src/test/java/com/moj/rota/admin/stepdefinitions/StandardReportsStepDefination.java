package com.moj.rota.admin.stepdefinitions;

import java.util.List;

import com.moj.rota.base.stepdefs.BaseStepDefination;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class StandardReportsStepDefination extends BaseStepDefination {
	
	private static String reportType=null;
	private static String homeLocationHeader=null;
	private static String percentageHeader=null;
	private static String specialReqHeader=null;
	@When("^I click on Standard reports$")
	public void i_click_on_Standard_reports() throws Throwable {
		isReports=true;
		onStandardReportsPage=onRotaAdminHomePage.clickOnReports();
		windowName=onStandardReportsPage.getCurrentWindowName();
	}

	@Then("^I should see the standrad reports page$")
	public void i_should_see_the_standrad_reports_page() throws Throwable {
	    assertUtil.isTrue(onStandardReportsPage.isReportsPageDisplayed());
	}

	@Then("^Repots page should consists of:$")
	public void repots_page_should_consists_of(List<String> reportContents) throws Throwable {
	    for(String reportLbaleType:reportContents)
	    {
	    	assertUtil.isEquals(reportLbaleType, onStandardReportsPage.getReportLables(reportLbaleType));
	    }
	}
	
	@When("^I select report type : \"(.*?)\"$")
	public void i_select_report_type(String reportName) throws Throwable {
		reportType=reportName;
		onStandardReportsPage.selectReportName(reportName);
	}

	@When("^Select Location justice area \"(.*?)\"$")
	public void select_Location_justice_area(String ljaLocation) throws Throwable {
		onStandardReportsPage.selectLJALocation(ljaLocation);
	}

	@When("^Click on View Report button$")
	public void click_on_View_Report_button() throws Throwable {
		onStandardReportsPage.clickViewReport();
	}

	@Then("^I should see the PDF format Report$")
	public void i_should_see_the_PDF_format_Report() throws Throwable {
	   assertUtil.isTrue(onStandardReportsPage.getPDFPageTitle().length()>0);
	}

	@Then("^I should see the PDF report title \"(.*?)\"$")
	public void i_should_see_the_PDF_report_title(String reportTitleHeader) throws Throwable {
		assertUtil.isTrue(onStandardReportsPage.getPDFPageTitle().contains(reportTitleHeader));
		
	}

	@Then("^Magistrate header \"(.*?)\" and Actual name of the header$")
	public void magistrate_header_and_Actual_name_of_the_header(String headerName) throws Throwable {
		assertUtil.isEquals(headerName, onStandardReportsPage.getReportContentHeaders(headerName));
		//checking name value
		assertUtil.isTrue(onStandardReportsPage.getReportNameValues(reportType).length()>0);
	}

	@Then("^PDF report headers should be \"(.*?)\" ,\"(.*?)\" ,\"(.*?)\" ,\"(.*?)\"$")
	public void pdf_report_headers_should_be(String homeLocation, String percentageAssigned, 
			String specialRequirements, String reportType) throws Throwable {
		homeLocationHeader=homeLocation;
		percentageHeader=percentageAssigned;
		specialReqHeader=specialRequirements;
		
		if(reportType.equals("Special Requirements"))
		{
			assertUtil.isEquals(specialRequirements, onStandardReportsPage.getReportContentHeaders(specialRequirements));
						
		} else {
			assertUtil.isEquals(homeLocation, onStandardReportsPage.getReportContentHeaders(homeLocation));
			assertUtil.isEquals(percentageAssigned, onStandardReportsPage.getReportContentHeaders(percentageAssigned));
			
		}
	    
	}
	
	@Then("^PDF report values should be home location \"(.*?)\" ,percentage assigned \"(.*?)\" ,special requirements \"(.*?)\"$")
	public void pdf_report_values_should_be_home_location_percentage_assigned_special_requirements(String homeLocation,
			String percentage, String specialRequirements) throws Throwable {
		if(reportType.equals("Special Requirements"))
		{
			assertUtil.isEquals(specialRequirements,onStandardReportsPage.getReportContentValues(specialReqHeader));	
		} else {
			assertUtil.isEquals(homeLocation,onStandardReportsPage.getReportContentValues(homeLocationHeader));
			assertUtil.isEquals(percentage,onStandardReportsPage.getReportContentValues(percentageHeader));
		}
		
	}

	@Then("^PDF report headers should consists of :$")
	public void pdf_report_headers_should_consists_of(List<String> exceptionReportHeaders) throws Throwable {
	    for(String reportHeaderType:exceptionReportHeaders)
	    {
	    assertUtil.isEquals(reportHeaderType, onStandardReportsPage.getReportContentHeaders(reportHeaderType));	
	    }
	}
	
}
