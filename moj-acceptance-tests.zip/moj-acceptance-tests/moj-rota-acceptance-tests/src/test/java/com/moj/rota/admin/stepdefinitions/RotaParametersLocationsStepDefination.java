package com.moj.rota.admin.stepdefinitions;

import java.util.List;

import com.moj.rota.base.stepdefs.BaseStepDefination;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RotaParametersLocationsStepDefination extends BaseStepDefination {
	
	private static String newLocationName=null;
	private static String deleteLocation=null;
	private static String deleteYesOrNo=null;
	private static String operationType=null;

	@When("^I click on Rota parameters in home page$")
	public void i_click_on_Rota_parameters_in_home_page() throws Throwable {
		
		onRotaParametersLocationPage=onRotaAdminHomePage.clickOnRotaParametrs(); 
	}

	@When("^I click on \"(.*?)\" tab$")
	public void i_click_on_tab(String rotapametersTabs) throws Throwable {
		switch(rotapametersTabs)
		{
		case "Location":
			onRotaParametersLocationPage.clickTabs(rotapametersTabs);
			break;
		case "BenchChair":
			onRotaParametersBenchChairPage=onRotaParametersLocationPage.clickBenchChairTab();
			break;
		case "LocalBechChair":
			onRotaParametersLocalBenchPage=onRotaParametersLocationPage.clickLocalBenchCompositionTab();
			break;
		case "Combined Youth Panels":
			onCombinedYouthPanelsPage=onRotaParametersLocationPage.clickOnCombineYouthPanelTab();
			break;
		}
		
	}

	@Then("^I should see the Locations page$")
	public void i_should_see_the_Locations_page() throws Throwable {
	   assertUtil.isTrue(onRotaParametersLocationPage.getRotaparametrsTitle().length()>0);
	   assertUtil.isTrue(onRotaParametersLocationPage.isLocationsTabDisplayed());
	}

	@Then("^Locations page should consists of:$")
	public void locations_page_should_consists_of(List<String> locations) throws Throwable {
	   for(int i=1;i<locations.size();i++)
	   {
		   String locationName =locations.get(i);
		   assertUtil.isEquals(locationName, onRotaParametersLocationPage.getLocationsTitle(locationName));
	   }
	}
	
	@When("^I slect location \"(.*?)\"$")
	public void i_slect_location(String location) throws Throwable {
		onRotaParametersLocationPage.clickLocation(location);
	}

	@When("^I enter location name :\"(.*?)\" and click on add button \"(.*?)\"$")
	public void i_enter_location_name(String newLocationNameVal,String operationType) throws Throwable {
		newLocationName=newLocationNameVal;
		onRotaParametersLocationPage.addNewLocation(newLocationName,operationType);
	}
	@Then("^I should see the added new location \"(.*?)\"$")
	public void i_should_see_the_added_new_location(String operationType) throws Throwable {
	   if(operationType.equals("Add"))
	   {
		   assertUtil.isEquals(newLocationName,onRotaParametersLocationPage.getNewlyAddedLocationName(newLocationName).trim());
	   }else {
		   assertUtil.isTrue(onRotaParametersLocationPage.getErrorLabel(newLocationName));
	   }
	}
	
	@When("^I click to delete location \"(.*?)\"$")
	public void i_click_to_delete_location(String deleteLocationVal) throws Throwable {
		deleteLocation=deleteLocationVal;
		onRotaParametersLocationPage.deleteLocation(deleteLocation); 
	}

	@When("^I \"(.*?)\" to delete location$")
	public void i_to_delete_location(String yesOrNo) throws Throwable {
		deleteYesOrNo=yesOrNo;
		onRotaParametersLocationPage.confirmDeleteLocation(yesOrNo);
	}

	@Then("^should not exist the delete location$")
	public void should_not_exist_the_delete_location() throws Throwable {
	   
		waitForPage();
		if(deleteYesOrNo.equals("Yes"))
		{
			assertUtil.isFalse(deleteLocation, onRotaParametersLocationPage.isLocationDisplayed(deleteLocation));
		} else {
			assertUtil.isTrue(deleteLocation, onRotaParametersLocationPage.isLocationDisplayed(deleteLocation));
		}
	}
	
	//Bench chair related
	
	@Then("^I should see the bench chair page$")
	public void i_should_see_the_bench_chair_page() throws Throwable {
	    assertUtil.isTrue(onRotaParametersBenchChairPage.isBenchChairTabDisplayed());
	}

	@Then("^Bench chair page should consists of:$")
	public void bench_chair_page_should_consists_of(List<String> listOfLocations) throws Throwable {
	    
		for(String location:listOfLocations)
		   {
			   assertUtil.isEquals(location, onRotaParametersBenchChairPage.getLocationsTitle(location));
		   }
	}

	@When("^I click on LJA location \"(.*?)\"$")
	public void i_click_on_LJA_location(String ljaLocation) throws Throwable {
		onRotaParametersBenchChairPage.clickLJALocation(ljaLocation);
	}

	@When("^I enter date and magistrate \"(.*?)\" \"(.*?)\"$")
	public void i_enter_date_and_magistrate(String magName, String operationType) throws Throwable {
		if(operationType.equals("Add"))
		{
			onRotaParametersBenchChairPage.enterMagistrateData(magName);	
		} 
		
	}

	@When("^Click on Allocate button \"(.*?)\"$")
	public void click_on_Allocate_button(String operationType) throws Throwable {
		if(operationType.equals("Add"))
		{
		onRotaParametersBenchChairPage.clickAllocateButton();
		} else {
			waitForPage();
			onRotaParametersBenchChairPage.clickonRemoveButton();
		}
	}

	@Then("^I should see the allocated magistrate \"(.*?)\" ,\"(.*?)\"$")
	public void i_should_see_the_allocated_magistrate(String magName, String operationType) throws Throwable {
		if(operationType.equals("Add"))
		{
			assertUtil.isTrue(magName, onRotaParametersBenchChairPage.getMagName().contains(magName));
		} else {
			 assertUtil.isTrue(magName, onRotaParametersBenchChairPage.getBechChairTBA().contains(magName));
		}
	} 
	
	//Local bench chair composition
		@Then("^I should see the Local bench chair composition page$")
		public void i_should_see_the_Local_bench_chair_composition_page() throws Throwable {
			assertUtil.isTrue(onRotaParametersLocalBenchPage.isLocalBenchCompositionDisplayed());
		}

	@Then("^Local bench Bench chair composition page should consists of:$")
	public void local_bench_Bench_chair_composition_page_should_consists_of(List<String> ljaLocations)
			throws Throwable {
		for (String location : ljaLocations) {
			assertUtil.isEquals(location, onRotaParametersLocalBenchPage.getLocationsTitle(location));
		}
	}
	
	@When("^I click on local bench composition location \"(.*?)\"$")
	public void i_click_on_local_bench_composition_location(String location) throws Throwable {
		onRotaParametersLocalBenchPage.clickLJALocation(location); 
	}

	@When("^I click on add button$")
	public void i_click_on_add_button() throws Throwable {
		onRotaParametersLocalBenchPage.clickOnAddButton();
	}

	@When("^I select panel type :\"(.*?)\"$")
	public void i_select_panel_type(String panelType) throws Throwable {
		onRotaParametersLocalBenchPage.selectPanelType(panelType);
	}

	@When("^I select the special authorty type :\"(.*?)\"$")
	public void i_select_the_special_authorty_type(String specialAuthority) throws Throwable {
		onRotaParametersLocalBenchPage.selectSpecialRequirements(specialAuthority); 
	}

	@When("^I select the roles Chair and Winger$")
	public void i_select_the_roles_Chair_and_Winger() throws Throwable {
		onRotaParametersLocalBenchPage.clickRoleCheckBoxes();
	}

	@Then("^I should see the selected panel type \"(.*?)\",\"(.*?)\", roles$")
	public void i_should_see_the_selected_panel_type_roles(String panelType, String specialAuthority) throws Throwable {
		waitForPage();
	    assertUtil.isEquals(panelType, onRotaParametersLocalBenchPage.getSelectedPanelType());
	    assertUtil.isEquals(specialAuthority, onRotaParametersLocalBenchPage.getSpecialAuthorityType());
	    assertUtil.isTrue(onRotaParametersLocalBenchPage.getStatusOfRoleCheckBoxes());
	}
	
	@When("^I click on remove button$")
	public void i_click_on_remove_button() throws Throwable {
		onRotaParametersLocalBenchPage.clickonRemoveButton();
	}

	@Then("^Should not exist the deleted local bench chair$")
	public void should_not_exist_the_deleted_local_bench_chair() throws Throwable {
	    assertUtil.isFalse(onRotaParametersLocalBenchPage.isPanelTypeExist());
	}
	
	//CombinedYouth panels
	@Then("^I should see the Combined youth panels page$")
	public void i_should_see_the_Combined_youth_panels_page() throws Throwable {
		assertUtil.isTrue(onCombinedYouthPanelsPage.isCombinedYouthPanelDisplayed());
	}

	@Then("^Combined youth panels page should consists of:$")
	public void combined_youth_panels_page_should_consists_of(List<String> ljaLocations) throws Throwable {
		for (String location : ljaLocations) {
			assertUtil.isEquals(location, onCombinedYouthPanelsPage.getLocationsTitle(location));
		} 
	}
	
	@When("^I click on Combined youth panel LJA location \"(.*?)\"$")
	public void i_click_on_Combined_youth_panel_LJA_location(String location) throws Throwable {
		onCombinedYouthPanelsPage.clickLJALocation(location);
	}

	@When("^I enter name of LJA to add a combined panel \"(.*?)\" \"(.*?)\"$")
	public void i_enter_name_of_LJA_to_add_a_combined_panel(String ljaName, String operationTypeVal) throws Throwable {
		operationType=operationTypeVal;
		onCombinedYouthPanelsPage.enterLJAName(ljaName);
	}
	
	@When("^I click on Combined panel add button$")
	public void i_click_on_Combined_panel_add_button() throws Throwable {
		onCombinedYouthPanelsPage.clickOnAddButton();
	}

	@Then("^I should see added Youth panel or any eeror message \"(.*?)\"$")
	public void i_should_see_added_Youth_panel_or_any_eeror_message(String messageDetails) throws Throwable {
		assertUtil.isEquals(messageDetails, onCombinedYouthPanelsPage.getSucessOrVadidationMessage(operationType).trim());	    
	}

	@When("^I click on Combined youth panel remove button$")
	public void i_click_on_Combined_youth_panel_remove_button() throws Throwable {
		onCombinedYouthPanelsPage.clickonRemoveButton(); 
	}

	@Then("^Should not exist the deleted Combined youth panel$")
	public void should_not_exist_the_deleted_Combined_youth_panel() throws Throwable {
	   assertUtil.isFalse(onCombinedYouthPanelsPage.isCombinedYouthLJAExist()); 
	}

	@Then("^I should see the \"(.*?)\"$")
	public void i_should_see_the(String noCombinedPanelMessage) throws Throwable {
	   assertUtil.isEquals(noCombinedPanelMessage, onCombinedYouthPanelsPage.getNoCombinedYouthPanelMessage());
	}
	
}


