package com.moj.rota.admin.stepdefinitions;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import com.moj.rota.base.stepdefs.BaseStepDefination;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class MagistrateAdvanceSearch extends BaseStepDefination {

	private static boolean searchType;
	private static boolean isDistrciJudge=false;
	private static String dayName=null;
	
    @When("^I opt for an advanced search$")
    public void I_opt_for_an_advanced_search() throws Throwable {
        onMagisstrateAdvanceSearchPage = onRotaAdminHomePage.clickOnAdvanceSearch();
        onMagisstrateAdvanceSearchPage.clickAdvanceTab();
    }

    @Then("^the advanced search options are displayed$")
    public void the_advanced_search_options_are_displayed() throws Throwable {
        onMagisstrateAdvanceSearchPage.displayAdvancedContent();
    }

    @And("^all the available LJAs are listed on the LJAS select list$")
    public void all_the_available_LJAs_are_listed_on_the_LJAS_select_list() throws Throwable {
        onMagisstrateAdvanceSearchPage.localJusticeAreaDropdown();
    }

    @And("^search type radio buttons 'local justice area' and 'combined panel' are displayed$")
    public void search_type_radio_buttons_local_justice_area_and_combined_panel_are_displayed() throws Throwable {
        onMagisstrateAdvanceSearchPage.localJusticeAreaRadiobtn();
        onMagisstrateAdvanceSearchPage.combinedPanelRadiobtn();
    }

    @And("^select an adult panel option for the \"([^\"]*)\" and \"([^\"]*)\"$")
    public void select_an_adult_panel_option_for_the_and(String justiceArea1, String justiceArea2) throws Throwable {
        onMagisstrateAdvanceSearchPage.enterLocation(justiceArea1);
        onMagisstrateAdvanceSearchPage.selectLocation(justiceArea2);
    }

    @And("^I perform the search$")
    public void I_click_search() throws Throwable {
    	isDistrciJudge=false;
        onMagisstrateAdvanceSearchPage.clickSearchButton();
    }
    
    @When("^I click on search button in magistrate advanced search$")
    public void i_click_on_search_button_in_magistrate_advanced_search() throws Throwable {
    	onMagistrateSearchPage=onMagisstrateAdvanceSearchPage.clickOnSearchButton();
    }

    @Then("^the advanced search results should be displayed$")
    public void the_advanced_search_results_should_be_displayed() throws Throwable {
    	if(isDistrciJudge)
    	{
    		assertTrue(onMagisstrateAdvanceSearchPage.districtJudgesFoundMsg());
    	} else {
    		assertTrue(onMagisstrateAdvanceSearchPage.MagistratesFoundMsg("Magistrates found"));
    	}
        
    }

    @When("^I choose \"([^\"]*)\" for \"([^\"]*)\"$")
    public void I_choose_for(String panel_type, String location) throws Throwable {
        onMagisstrateAdvanceSearchPage.selectPanel(panel_type);
        onMagisstrateAdvanceSearchPage.enterLocation(location);
    }

    @When("^I choose \"([^\"]*)\" and \"([^\"]*)\" for \"([^\"]*)\"$")
    public void I_choose_and_for(String panel_type, String panel_staus, String location) throws Throwable {
        onMagisstrateAdvanceSearchPage.selectPanel(panel_type);
        onMagisstrateAdvanceSearchPage.enterPanelStatus(panel_staus);
        onMagisstrateAdvanceSearchPage.enterLocation(location);
    }

    @And("^I also choose additional criteria such as \"([^\"]*)\"$")
    public void I_also_choose_additional_criteria_such_as(String additional_criteria) throws Throwable {
        onMagisstrateAdvanceSearchPage.clickCheckBox(additional_criteria);
    }

    @Then("^the number of Magistrates returned should be (.+)$")
    public void the_number_of_Magistrates_returned_should_be_(int numberOfMagistratesReturned) throws Throwable {
    	waitForPage();
        assertEquals(numberOfMagistratesReturned, onMagisstrateAdvanceSearchPage.numberOfMags());
    }
    
    @When("^I also choose available on:\"(.*?)\",available from:\"(.*?)\" and available to:\"(.*?)\"$")
    public void i_also_choose_available_on_available_from_and_available_to(String availableOn, String availableFrom, String availableTo) throws Throwable {
    	onMagisstrateAdvanceSearchPage.availabilityOptions(availableOn, availableFrom, availableTo);
    }
    
    @When("^I select day type pattern AM or PM \"(.*?)\"$")
    public void i_select_day_type_pattern_AM_or_PM(String dayPattern) throws Throwable {
    	onMagisstrateAdvanceSearchPage.selectDayPattern(dayPattern);
    }
    
    @When("^I slect search type :\"(.*?)\"$")
    public void i_slect_search_type(String type) throws Throwable {
    	if(type.equalsIgnoreCase("Local Justice"))
    	{
    	searchType =true;
    	}
    	onMagisstrateAdvanceSearchPage.selectSearchType(type);
    }

    @When("^I also choose short notice :\"(.*?)\" and Consecutive days \"(.*?)\"$")
    public void i_also_choose_short_notice_and_Consecutive_days(String shortNotice, String consecutiveDays) throws Throwable {
    	onMagisstrateAdvanceSearchPage.selectShortAndConsecutiveDays(shortNotice, consecutiveDays);
    }
    
    @When("^I also select local justice area \"(.*?)\" Location :\"(.*?)\" and panel status:\"(.*?)\"$")
    public void i_also_select_local_justice_area_Location_and_panel_status(String justiceArea, String location, String panel_status) throws Throwable {
        if(searchType)
        {
          onMagisstrateAdvanceSearchPage.enterLocation(justiceArea);
          onMagisstrateAdvanceSearchPage.selectLJALocation(location);
          onMagisstrateAdvanceSearchPage.selectPanel("Adult");
        } else {
        	onMagisstrateAdvanceSearchPage.selectComindLocation(location);
        }
        
        onMagisstrateAdvanceSearchPage.enterPanelStatus(panel_status);
       
    }

    @When("^I select Magistrates from other LJA's$")
    public void i_select_Magistrates_from_other_LJA_s() throws Throwable {
    	onMagisstrateAdvanceSearchPage.selectAdhocLJA();
    }
    
    @Then("^\"(.*?)\" message should be displayed in search results section$")
    public void message_should_be_displayed_in_search_results_section(String message) throws Throwable {
    	assertUtil.isEquals(message, onMagisstrateAdvanceSearchPage.advanceNoresultsFound()); 
    }
    
    @Then("^the advanced search results should be displayed \"(.*?)\"$")
    public void the_advanced_search_results_should_be_displayed(String messageType) throws Throwable {
    	
    	switch(messageType)
    	{
    	case "Magistrates found":
    		 assertTrue(onMagisstrateAdvanceSearchPage.MagistratesFoundMsg(messageType));
    		 break;
    	case "No matches found":
   		 assertTrue(onMagisstrateAdvanceSearchPage.noMatchfoundMsg());
   		 break;
   		 
   		 default:
    		
    	}
        
    }
    
    @When("^I choose Local justice area :\"(.*?)\" and search day name :\"(.*?)\"$")
    public void i_choose_Local_justice_area_and_search_day_name(String justiceArea, String dyaName) throws Throwable {
    	 onMagisstrateAdvanceSearchPage.enterLocation(justiceArea);
    }

    @Then("^the Number of Magistrates displayed \"(.*?)\"$")
    public void the_Number_of_Magistrates_displayed(String noOfMagistratesDisplayed) throws Throwable {
    	
    	if(noOfMagistratesDisplayed!=null && !noOfMagistratesDisplayed.equalsIgnoreCase(""))
    	{
    		assertUtil.isEquals(noOfMagistratesDisplayed, onMagisstrateAdvanceSearchPage.getMagistratesCount());	
    	}
    	
        
    }
    
    
    //District judge related
    
    @When("^I click on advanced search$")
    public void i_click_on_advanced_search() throws Throwable {
    	onMagisstrateAdvanceSearchPage = onRotaAdminHomePage.clickOnJudgeAdvanceSearch();
        onMagisstrateAdvanceSearchPage.clickAdvanceTab();
    }
    
    @When("^I choose \"(.*?)\" and \"(.*?)\" and \"(.*?)\"$")
    public void i_choose_and_and(String justiceArea, String location, String authority) throws Throwable {
         onMagisstrateAdvanceSearchPage.enterLocation(justiceArea);
         onMagisstrateAdvanceSearchPage.selectLJALocation(location);
         if(authority!=null && !authority.equals(""))
         {
         onMagisstrateAdvanceSearchPage.selectAuthority(authority);
         }
    }
    
    @And("^I click on search button$")
    public void I_click_search_button() throws Throwable {
    	isDistrciJudge=true;
        onMagisstrateAdvanceSearchPage.clickJudgeSearchButton();
    }
    
    @When("^I choose special Authority \"(.*?)\"$")
    public void i_choose_special_Authority(String specialAuthority) throws Throwable {
    	if(specialAuthority!=null && !specialAuthority.equals(""))
    	{
    	onMagisstrateAdvanceSearchPage.selectSpecialAuthority(specialAuthority);
    	}
    }
    
    @When("^I select \"(.*?)\" and \"(.*?)\" for \"(.*?)\"$")
    public void i_select_and_for(String panelType, String location, String justiceArea) throws Throwable {
    	
    	onMagisstrateAdvanceSearchPage.enterLocation(justiceArea);
        onMagisstrateAdvanceSearchPage.selectLJALocation(location);
        if(panelType!=null && !panelType.equals(""))
    	{
        onMagisstrateAdvanceSearchPage.selectPanel(panelType);
    	}
    }

    @When("^I select adhoc option magistrate sitting in other LJA or DFJA$")
    public void i_select_adhoc_option_magistrate_sitting_in_other_LJA_or_DFJA() throws Throwable {
    	onMagisstrateAdvanceSearchPage.selectAdhocLJA();
    }
    
    
    @Then("^Should not able to edit the fields in pages :\"(.*?)\"$")
    public void should_not_able_to_edit_the_fields_in_pages(String pageName) throws Throwable {
    	boolean isFieldEditable=false;
    	switch(pageName)
		{
		case "Sitting location" :
			isFieldEditable=onMagistrateSittingLocationsPage.isHomeCourtLocationEditable();
			break;
		case "Sitting eligibility" :
			isFieldEditable=onMagistrateSittingEligibiltyPage.isDateOfAppointmentEditable();
			break;
		case "Personal Details" :
			isFieldEditable=onMagistratePersonalDetailsPage.isFirstNameEditable();
			break;
			
		case "Non-availability" :
			isFieldEditable=onMagistrateNonAvailabilityPage.isDayselectionEditable();
			break;
			
		case "Sitting Preferences" :
			isFieldEditable=onMagistrateSittingPrefecencesPage.isSittingPreferenceEditable();
			break;
		}
    	
    	assertUtil.isFalse(pageName, isFieldEditable);
    }
    
    @Then("^I should recognise the magistrate as \"(.*?)\"$")
    public void i_should_recognise_the_magistrate_as(String recogniseResultsType) throws Throwable {
    	assertUtil.isTrue(recogniseResultsType, onMagistrateSittingPrefecencesPage.selectedSitOnDays(recogniseResultsType));
    }

    @Then("^I should see exclude \"(.*?)\"$")
    public void i_should_see_exclude(String excludeMessage) throws Throwable {
    	assertUtil.isEquals(excludeMessage, onMagisstrateAdvanceSearchPage.getExcludeWarningMessage());
    }

    @Then("^Saturday, Bank Holiday and Short Notice options are not available when a date or date range is entered$")
    public void saturday_Bank_Holiday_and_Short_Notice_options_are_not_available_when_a_date_or_date_range_is_entered() throws Throwable {
    	assertUtil.isFalse("ShortNotice", onMagisstrateAdvanceSearchPage.isBankSatShortNoticeDisplayed("ShortNotice"));
    	assertUtil.isFalse("Saturday", onMagisstrateAdvanceSearchPage.isBankSatShortNoticeDisplayed("Saturday"));
    	assertUtil.isFalse("BankHoliday", onMagisstrateAdvanceSearchPage.isBankSatShortNoticeDisplayed("BankHoliday"));
    }
    
    //beanch chair
    
    @When("^I find magistrate having bench chair \"(.*?)\" and click on sitting eligibilty$")
    public void i_find_magistrate_having_bench_chair_and_click_on_sitting_eligibilty(String magName) throws Throwable {
    	onMagistrateSittingEligibiltyPage=onMagisstrateAdvanceSearchPage.clickBenchChairMagistrate(magName);
    }

    @Then("^I should see the bench chair appointments sections$")
    public void i_should_see_the_bench_chair_appointments_sections() throws Throwable {
       assertUtil.isTrue(onMagistrateSittingEligibiltyPage.isBenchChairAppointsmentDisplayed());
    }

    @Then("^I should see the \"(.*?)\" ,appointment date$")
    public void i_should_see_the_appointment_date(String ljaLocation) throws Throwable {
       assertUtil.isEquals(ljaLocation, onMagistrateSittingEligibiltyPage.getLJALocationForBenchChair());
       assertUtil.isTrue(onMagistrateSittingEligibiltyPage.getAppDateForBenchChair().length()>0);
    }

}
