package com.moj.rota.admin.stepdefinitions;

import java.util.List;

import com.moj.rota.base.stepdefs.BaseStepDefination;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class MagistrateSittingEligibility extends BaseStepDefination {
	
	private static String panelType=null;
	
	@Then("^Should display the Sitting Eligibility page$")
	public void should_display_the_Sitting_Eligibility_page() throws Throwable {
		assertUtil.isTrue(onMagistrateSittingEligibiltyPage.isSittingEligiblePageDisplayed());
	}

	@Then("^Sitting eligibility page consists of:$")
	public void sitting_eligibility_page_consists_of(List<String> allPanels) throws Throwable {
		
		for (int i=0;i<allPanels.size();i++) {
			if(isDistrictJudge)
			{
				assertUtil.isTrue(allPanels.get(i),onMagistrateSittingEligibiltyPage.getDJSittingEligibilityPanels(allPanels.get(i),i));
			} else {
				assertUtil.isTrue(allPanels.get(i),onMagistrateSittingEligibiltyPage.getSittingEligibilityPanels(allPanels.get(i),i));
			}
			
		}
	    
	}
	
	@Then("^Observe some of the fileds should be in disabled status :$")
	public void observe_some_of_the_fileds_should_be_in_disabled_status(List<String> disabledFields) throws Throwable {
		for (int i=1;i<disabledFields.size();i++) {
			String disabledField=disabledFields.get(i);
			assertUtil.isFalse(disabledField,onMagistrateSittingEligibiltyPage.getDisabledFieldStatus(disabledField));
		}
	}
	
	@When("^I enter leaving date:\"(.*?)\" ,leaving reason \"(.*?)\"$")
	public void i_enter_leaving_date_leaving_reason(String leavingDate, String leavingReason) throws Throwable {
		if(isSwapUi)
		{
			if(leavingDate.equals(""))
			{
				onMagistrateSittingEligibiltyPage.enteLeavingDate(converedDateByString(locationStartDate,2));
			} else {
				onMagistrateSittingEligibiltyPage.enteLeavingDate(leavingDate);
			}
		
		}else {
			if(leavingDate.equals("Yesterday"))
			{
			onMagistrateSittingEligibiltyPage.enteLeavingDate(getYesterdaysDate(-1));
			}else if(leavingDate.equals("Today")){
			onMagistrateSittingEligibiltyPage.enteLeavingDate(getYesterdaysDate(0));	
			}else{
				onMagistrateSittingEligibiltyPage.enteLeavingDate(leavingDate);	
		   }
			
		}
		onMagistrateSittingEligibiltyPage.selectLeavingReason(leavingReason);
	}

	@When("^I select out of hours duties$")
	public void i_select_out_of_hours_duties() throws Throwable {
		onMagistrateSittingEligibiltyPage.selectOutOfHours();
	}

	@When("^I click on save$")
	public void i_click_on_save() throws Throwable {
		onMagistrateSittingEligibiltyPage.clicSaveButton();
	}

	@Then("^I should see selected \"(.*?)\" ,leaving reason \"(.*?)\"$")
	public void i_should_see_selected_leaving_reason(String leavingDate, String leavingReason) throws Throwable {
		
		if(isDistrictJudge)
		{
			onDistrictJudgeSearchPage.clickSittingEligibility();
		} else {
			onMagistrateSearchPage.clickSittingEligibility();
		}
		
	   // assertUtil.isEquals(leavingDate, onMagistrateSittingEligibiltyPage.getLeavingDate());
		waitForPage();
	    assertUtil.isEquals(leavingReason, onMagistrateSittingEligibiltyPage.getSelectedLeavingReason());
	    
	    
	    
	}
	
	@When("^I click on create/view/edit$")
	public void i_click_on_create_view_edit() throws Throwable {
		onMagistrateSittingEligibiltyPage.clickInActivity();
	}

	@When("^I click on button type \"(.*?)\"$")
	public void i_click_on_button_type(String buttonType) throws Throwable {
		onMagistrateSittingEligibiltyPage.clickOnButtonType(buttonType);
	}

	@When("^I enter start date \"(.*?)\" ,endate \"(.*?)\"$")
	public void i_enter_start_date_endate(String startDate, String endDate) throws Throwable {
		if(isSwapUi)
		{
		onMagistrateSittingEligibiltyPage.enterStartDate(converedDateByString(locationStartDate,0));
		onMagistrateSittingEligibiltyPage.enterEndDate(converedDateByString(locationStartDate,10));
		} else {
		onMagistrateSittingEligibiltyPage.enterStartDate(getDate(0));
		onMagistrateSittingEligibiltyPage.enterEndDate(getDate(1));
		}
	}

	@When("^I enter authority \"(.*?)\" ,reason \"(.*?)\"$")
	public void i_enter_authority_reason(String authority, String reason) throws Throwable {
		onMagistrateSittingEligibiltyPage.selectAuthority(authority);
		onMagistrateSittingEligibiltyPage.enterReason(reason);
	}

	@When("^I click on confirm details$")
	public void i_click_on_confirm_details() throws Throwable {
		onMagistrateSittingEligibiltyPage.clickConfirmButton();
		waitForPage();
	}

	@Then("^I should see the current status \"(.*?)\"$")
	public void i_should_see_the_current_status(String status) throws Throwable {
		waitForPage();
		 if(isDistrictJudge)
		 {
			 assertUtil.isEquals(status, onMagistrateSittingEligibiltyPage.getDJCurrentStatus()); 
		 } else {
			 assertUtil.isEquals(status, onMagistrateSittingEligibiltyPage.getCurrentStatus()); 
		 }
		 
		 onMagistrateSittingEligibiltyPage.clicSaveButton();
	}
	
	@When("^I select panel type \"(.*?)\", New Winger \"(.*?)\" ,\"(.*?)\"$")
	public void i_select_panel_type_New_Winger(String panelTypeVal, String newWinger, String date) throws Throwable {
		panelType =panelTypeVal;
		if(newWinger!=null && !newWinger.equals(""))
		{
		waitForPage();
		onMagistrateSittingEligibiltyPage.selectNewWinger(panelType, newWinger, date);
		}
	    
	}

	@When("^I select Winger \"(.*?)\" ,\"(.*?)\"$")
	public void i_select_Winger(String winger, String date) throws Throwable {
		if(winger!=null && !winger.equals(""))
		{
		waitForPage();
		onMagistrateSittingEligibiltyPage.selectWinger(panelType, winger, date);
		}
	}

	@When("^I select Traninee chair \"(.*?)\" ,\"(.*?)\"$")
	public void i_select_Traninee_chair(String traineeChair, String date) throws Throwable {
		if(traineeChair!=null && !traineeChair.equals(""))
		{
		waitForPage();
		onMagistrateSittingEligibiltyPage.selectTraineeChair(panelType, traineeChair, date);
		}
	}

	@When("^I select Char \"(.*?)\" ,\"(.*?)\"$")
	public void i_select_Char(String chair, String date) throws Throwable {
		if(chair!=null && !chair.equals(""))
		{
		waitForPage();
		onMagistrateSittingEligibiltyPage.selectChair(panelType, chair, date);
		}
	}

	@Then("^I should see selected roles on each panel \"(.*?)\"$")
	public void i_should_see_selected_roles_on_each_panel(String role) throws Throwable {
		onMagistrateSearchPage.clickSittingEligibility();
		waitForPage();
		assertUtil.isTrue(role,onMagistrateSittingEligibiltyPage.selectedRole(panelType, role));
		//assertUtil.isTrue(role,onMagistrateSittingEligibiltyPage.panelCheckBoxStatus(panelType, role));
	}
	
	@When("^I select Crown court and special authorities ,\"(.*?)\"$")
	public void i_select_Crown_court_and_special_authorities(String date, List<String> authorities) throws Throwable {
		
		for(String authorityName:authorities)
		{
		waitForPage();
		onMagistrateSittingEligibiltyPage.selectSpecialAuthorities(authorityName, date);
		}
	}

	@Then("^Should see selected special authorities$")
	public void should_see_selected_special_authorities(List<String> specialAuthorities) throws Throwable {
		waitForPage();
		if(!isMagistrateUI)
		{
		onMagistrateSearchPage.clickSittingEligibility();
		}
		for(String authorityName:specialAuthorities)
		{
			assertUtil.isTrue(authorityName, onMagistrateSittingEligibiltyPage.getSelectedAuthoritiesStatus(authorityName));
		}
	    
	}
	
	@When("^I click on Transfer magistrate$")
	public void i_click_on_Transfer_magistrate() throws Throwable {
		onMagistrateSittingEligibiltyPage.clickTransferMgistrate();
	}

	@When("^I select new local justice area \"(.*?)\"$")
	public void i_select_new_local_justice_area(String transferLJA) throws Throwable {
		onMagistrateSittingEligibiltyPage.selectNewLJA(transferLJA);
	}

	@When("^I enter effective date \"(.*?)\"$")
	public void i_enter_effective_date(String ljaEffectiveDate) throws Throwable {
		if(isSwapUi)
		{
			onMagistrateSittingEligibiltyPage.newLJAEffectiveDate(converedDateByString(locationStartDate,2));	
		} else {
			onMagistrateSittingEligibiltyPage.newLJAEffectiveDate(ljaEffectiveDate);
		}
		
	}

	@Then("^I should see new local justice area \"(.*?)\" ,effeactive date :\"(.*?)\"$")
	public void i_should_see_new_local_justice_area_effeactive_date(String newLjaName, String effectiveDate) throws Throwable {
		onMagistrateSearchPage.clickSittingEligibility();
		waitForPage();
	    assertUtil.isEquals(newLjaName, onMagistrateSittingEligibiltyPage.getNewLJA());
	    //assertUtil.isEquals(effectiveDate, onMagistrateSittingEligibiltyPage.getNewLJAEffectiveDate());
	}

	@Then("^I should see cancel button$")
	public void i_should_see_cancel_button() throws Throwable {
		assertUtil.isTrue(onMagistrateSittingEligibiltyPage.isCancelButtonDisplayed());
	}
	
	@When("^I click on cancel transfer magistrate$")
	public void i_click_on_cancel_transfer_magistrate() throws Throwable {
		onMagistrateSittingEligibiltyPage.clickOnTransferRemoveButton();
	}

	@Then("^I should not see cancel button$")
	public void i_should_not_see_cancel_button() throws Throwable {
		onMagistrateSearchPage.clickSittingEligibility();
		assertUtil.isFalse(onMagistrateSittingEligibiltyPage.isCancelButtonDisplayed());
	}
	
	@When("^I reset the sitting eligibility page$")
	public void i_reset_the_sitting_eligibility_page() throws Throwable {
		onMagistrateSittingEligibiltyPage.selectOutOfHours();

	}
	
	//Magistrate ui related
	
	@Then("^I should see selected leaving reason \"(.*?)\" ,current LJA \"(.*?)\"$")
	public void i_should_see_selected_leaving_reason_current_LJA(String leavingReason, String CurrentLJA) throws Throwable {
		waitForPage();
	    assertUtil.isEquals(leavingReason, onMagistrateSittingEligibiltyPage.getSelectedLeavingReason());
	    assertUtil.isEquals(CurrentLJA, onMagistrateSittingEligibiltyPage.getMagCurrentJusticeArea());
	}

	@Then("^Also eligibility section should consists of:$")
	public void also_eligibility_section_should_consists_of(List<String> eligibilityFields) throws Throwable {
	   for(String eligibilityField:eligibilityFields)
	   {
		   assertUtil.isTrue(eligibilityField, onMagistrateSittingEligibiltyPage.getSelectedEligibilityFields(eligibilityField));  
	   }
	}

	@Then("^Selected Adult panel section consists:$")
	public void selected_Adult_panel_section_consists(List<String> adultPanelList) throws Throwable {
		for(String adultPanel:adultPanelList)
		{
			assertUtil.isTrue(adultPanel,onMagistrateSittingEligibiltyPage.selectedRole("Adult_Panel", ""));
			assertUtil.isFalse(adultPanel,onMagistrateSittingEligibiltyPage.panelCheckBoxStatus("Adult_Panel", ""));
		}
		
	}

	@Then("^Selected Youth panel section consists:$")
	public void selected_Youth_panel_section_consists(List<String> youthPanel) throws Throwable {
		for(String youthPanelelement:youthPanel)
		{
			assertUtil.isTrue(youthPanelelement,onMagistrateSittingEligibiltyPage.selectedRole("Youth_Panel", ""));
			assertUtil.isFalse(youthPanelelement,onMagistrateSittingEligibiltyPage.panelCheckBoxStatus("Youth_Panel", ""));
		}
	}

	@Then("^Selected Family panel section consists:$")
	public void selected_Family_panel_section_consists(List<String> familyPanel) throws Throwable {
		for(String familyPanelEment:familyPanel)
		{
			assertUtil.isTrue(familyPanelEment,onMagistrateSittingEligibiltyPage.selectedRole("Family_Panel", ""));
			assertUtil.isFalse(familyPanelEment,onMagistrateSittingEligibiltyPage.panelCheckBoxStatus("Family_Panel", ""));
		}
	    
	}
	
	@Then("^I click on close button$")
	public void i_click_close() throws Throwable {
		onMagistrateSittingEligibiltyPage.clickOnMagClose();
	}
	
	//District-judge related
	
	@Then("^Should see the following fileds on DJ Sitting eligibilty :$")
	public void should_see_the_following_fileds_on_DJ_Sitting_eligibilty(List<String> djSittingEligibilityFields) throws Throwable {
		for (int i=1;i<djSittingEligibilityFields.size();i++) {
			String disabledField=djSittingEligibilityFields.get(i);
			assertUtil.isTrue(disabledField,onMagistrateSittingEligibiltyPage.getDJFieldStatus(disabledField));
		} 
	}
	
	@When("^I enter reason \"(.*?)\"$")
	public void i_enter_reason(String reason) throws Throwable {
		onMagistrateSittingEligibiltyPage.enterReason(reason);
	}

	@When("^I select Authorities and special Authorities$")
	public void i_select_Authorities_and_special_Authorities(List<String> authAnsSpecialAuthorities) throws Throwable {
		for(String authorityName:authAnsSpecialAuthorities)
		{
		onMagistrateSittingEligibiltyPage.selectDJSpecialAuthorities(authorityName);
		}
	}

	@Then("^Should see selected Authorities and special authorities$")
	public void should_see_selected_Authorities_and_special_authorities(List<String> authAnsSpecialAuthorities) throws Throwable {
		
		onDistrictJudgeSearchPage.clickSittingEligibility();
		
		for(String authorityName:authAnsSpecialAuthorities)
		{
			assertUtil.isTrue(authorityName, onMagistrateSittingEligibiltyPage.getDJSelectedAuthoAndSpecialAuthorities(authorityName));
		}
	}

	

}
