package com.moj.rota.admin.stepdefinitions;

import java.util.List;

import com.moj.rota.base.stepdefs.BaseStepDefination;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RotaScheduledSittingStepDefination extends BaseStepDefination {

	@Then("^I should see the Sittings page$")
	public void i_should_see_the_Sittings_page() throws Throwable {
		/*if(isDistrictJudge)
		{
			assertUtil.isTrue(onMagistrateSittingsPage.isDJSittingsPageDisplayed());
		} else {
		assertUtil.isTrue(onMagistrateSittingsPage.isSittingsPageDisplayed());
		}*/
		assertUtil.isTrue(onMagistrateSittingsPage.isSittingsPageDisplayed());
	}

	@Then("^scheduled sitting page should consists of:$")
	public void scheduled_sitting_page_should_consists_of(List<String> listOfSections) throws Throwable {
			for (int i = 1; i < listOfSections.size(); i++) {
				assertUtil.isTrue(listOfSections.get(i),
						onMagistrateSittingsPage.isPageFieldsDisplayed(listOfSections.get(i),isDistrictJudge));
			}
	
	}

	@When("^I click on below mentioned identifiers :$")
	public void i_click_on_below_mentioned_identifiers(List<String> listOfIdentifiers) throws Throwable {
		for (int i = 0; i < listOfIdentifiers.size(); i++) {
			assertUtil.isTrue(listOfIdentifiers.get(i),onMagistrateSittingsPage.clickFilterColumns(listOfIdentifiers.get(i),isDistrictJudge));
		}

	}
	
	@When("^I click scheduled sitting flags :\"(.*?)\"$")
	public void i_click_scheduled_sitting_flags(String falgs) throws Throwable {
		onMagistrateSittingsPage.clickOnFilterFlagColumns(falgs);
		waitForPage();
	}
	
	@Then("^I should see the not confirmed magistrates$")
	public void i_should_see_the_not_confirmed_magistrates() throws Throwable {
		assertUtil.isTrue(onMagistrateSittingsPage.getNotConfirmedMagistrate());
	}
	
	@Then("^I should see the magistrate status \"(.*?)\"$")
	public void i_should_see_the_magistrate_status(String status) throws Throwable {
	    assertUtil.isTrue(onMagistrateNonAvailabilityPage.getMagistrateStatus(status));
	}
	
	@When("^I hover the cancelled sitting$")
	public void when_I_hover_the_cancelled_sitting() throws Throwable {
		onMagistrateSittingsPage.clickToLateToCancel();
	}

	@Then("^I should see the validation message \"(.*?)\"$")
	public void ishould_see_the_validation_message(String validationMessage) throws Throwable {
	   assertUtil.isTrue(onMagistrateSittingsPage.getValidationMessage().matches(validationMessage));
	}
	
	@When("^I click on vacate sitting$")
	public void i_click_on_vacate_sitting() throws Throwable {
		onMagistrateSittingsPage.clickVacated();
	}

	@When("^I enter vacate \"(.*?)\"$")
	public void i_enter_vacate(String vacateReason) throws Throwable {
		onMagistrateSittingsPage.enterReason(vacateReason); 
	}

	@When("^I click on vacate or cancel button \"(.*?)\"$")
	public void i_click_on_vacate_or_cancel_button(String operationType) throws Throwable {
		onMagistrateSittingsPage.clickVacated(operationType);
	}

	@Then("^I should not see the vacated sitting \"(.*?)\"$")
	public void i_should_not_see_the_vacated_sitting(String operationType) throws Throwable {
		assertUtil.isTrue(onMagistrateSittingsPage.isVacated(operationType));
	}
	
	@Then("^I should see the vacated reason \"(.*?)\"$")
	public void i_should_see_the_vacated_reason(String operationType) throws Throwable {
		if(operationType.equals("Confirm"))
		{
		assertUtil.isTrue(onMagistrateSittingsPage.isVacatedMessageDisplayed());
		}
	}

	@When("^I change non availability status to available$")
	public void when_I_change_non_availibity_status() throws Throwable {
		onMagistrateNonAvailabilityPage.changeToAvailable();
	}
	
	@When("^I enter Sittings range from \"(.*?)\" and sittings to \"(.*?)\"$")
	public void i_enter_Sittings_range_from_and_sittings_to(String fromDate, String toDate) throws Throwable {
		waitForPage();
		String sittingsFrom="";
		String sittingsTo="";
		switch(fromDate)
		{
		case "currentDate":
			sittingsFrom=getYesterdaysDate(0);
			break;
		case "currentDatePlusOneMonth":
			sittingsFrom=getDateForRestRequest(1);
			break;
		case "currentDatePlusTwoYears":
			sittingsFrom=getDateForRestRequest(24);
			break;
		}
		
		switch(toDate)
		{
		case "currentDatePlusOneMonth":
			sittingsTo=getDateForRestRequest(1);
			break;
		case "currentDatePlusSixMonths":
			sittingsTo=getDateForRestRequest(6);
			break;
		}
		onMagistrateSittingsPage.enterDateRange(sittingsFrom.replace("-", "/"), sittingsTo.replace("-", "/")); 
	}

	@When("^I click on Search$")
	public void i_click_on_Search() throws Throwable {
		onMagistrateSittingsPage.clickOnSearch();
	}

	@Then("^I should see the search results displayed message \"(.*?)\"$")
	public void i_should_see_the_search_results_displayed_message(String results) throws Throwable {
	   if(results.equals("Results Found")) 
	   {
		   assertUtil.isTrue(onMagistrateSittingsPage.isPageFieldsDisplayed("location",isDistrictJudge));  
	   } else {
		   assertUtil.isEquals(results,onMagistrateSittingsPage.getErrorMessage(results));  
	   }
	}

}
