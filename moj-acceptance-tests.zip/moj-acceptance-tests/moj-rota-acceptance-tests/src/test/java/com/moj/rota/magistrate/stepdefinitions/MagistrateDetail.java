package com.moj.rota.magistrate.stepdefinitions;

import java.util.List;
import com.moj.rota.base.stepdefs.BaseStepDefination;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class MagistrateDetail extends BaseStepDefination {
		
	@Given("^I log in for the first time as a Magistrate$")
	public void i_log_in_for_the_first_time_as_a_Magistrate(List<String> MagLoginCredentials) throws Throwable {
		onMagistrateLoginPage.enterUsername(MagLoginCredentials.get(0));
		onMagistrateLoginPage.enterPassword(MagLoginCredentials.get(1));
		onMagistrateHomePage = onMagistrateLoginPage.clickLoginButton();
	}
	
	@Then("^I should see the message, \"(.*?)\"$")
	public void i_should_see_the_message(String welcomeMessage) throws Throwable {
	   assertUtil.isTrue(onMagistrateHomePage.getWelcomeMessage().trim().length()>0);
	}

	@Then("^I should see the Magistrate ui page$")
	public void i_should_see_the_Magistrate_ui_page() throws Throwable {
	   assertUtil.isTrue(onMagistrateHomePage.isMagistreateUI());
	}

	@Then("^Magistrate ui home page consists of:$")
	public void magistrate_ui_home_page_consists_of(List<String> magistrateUIFields) throws Throwable {
		
		for(int i=1;i<magistrateUIFields.size();i++)
		{
			String fiield=magistrateUIFields.get(i);
			assertUtil.isTrue(fiield, onMagistrateHomePage.getHomePageFields(fiield).contains(fiield));
		}
	   
	}
	
	@Given("^I click on Magistrate section :\"(.*?)\"$")
	public void i_click_on_Magistrate_section(String magistrateUISection) throws Throwable {
		
		switch(magistrateUISection)
		{
		case "Sitting location" :
			onMagistrateSittingLocationsPage=onMagistrateHomePage.clickMagSittingLocation();
			break;
		case "Sitting eligibility" :
			onMagistrateSittingEligibiltyPage=onMagistrateHomePage.clickMagSittingEligibility();
			break;
		case "Personal Details" :
			onMagistratePersonalDetailsPage=onMagistrateHomePage.clickPersonalDetailLink();
			break;
			
		case "Non-availability" :
			onMagistrateNonAvailabilityPage = onMagistrateHomePage.clickStep3Link();
			break;
			
		case "Sitting Preferences" :
			onMagistrateSittingPrefecencesPage = onMagistrateHomePage.clickStep2Link();
			break;
			
		case "Sittings" :
			onMagistrateSittingsPage = onMagistrateHomePage.clickOnSittings();
			break;
			
		}
		 
	}
}
