package com.moj.rota.admin.stepdefinitions;

import java.util.List;
import java.util.Map;
import com.moj.rota.base.stepdefs.BaseStepDefination;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class MagistrateSittingLocation extends BaseStepDefination {
	
	private static String panelLocation=null;
	//Fields display
	@When("^I click on Magistrate Search link on home page$")
	public void i_click_on_Magistrate_Search_link_on_home_page() throws Throwable {
		onMagistrateSearchPage = onRotaAdminHomePage.clickOnSearchMagistrateLink();
	}

	@When("^I enter first name :\"(.*?)\" ,last name :\"(.*?)\" and click on Search button$")
	public void i_enter_first_name_last_name_and_click_on_Search_button(String firstName, String lastName) throws Throwable {
		onMagistrateSearchPage.enterSearchData(firstName, lastName);
	}

	@Then("^Should display the Sitting location page$")
	public void should_display_the_Sitting_location_page() throws Throwable {
	   assertUtil.isTrue(onMagistrateSittingLocationsPage.isSittingLocationPageDisplayed());
	}

	@Then("^Page title should be \"(.*?)\"$")
	public void page_title_should_be(String pageTitle) throws Throwable {
		switch(pageTitle)
		{
		case "Sitting Locations" :
			assertUtil.isEquals(pageTitle, onMagistrateSittingLocationsPage.getPageTitle());
			break;
			
		case "Sitting Eligibility" :
			assertUtil.isEquals(pageTitle, onMagistrateSittingEligibiltyPage.getPageTitle());
			break;
			
		case "Listing Pattern" :
			assertUtil.isEquals(pageTitle, onRotaListingPatternPage.getPageTitle());
			break;
			
		default:
		}
		
		
	}

	@Then("^Page box title should be \"(.*?)\"$")
	public void page_box_title_should_be(String pageBoxTitle) throws Throwable {
		if(isDistrictJudge)
		{
			assertUtil.isEquals(pageBoxTitle, onMagistrateSittingLocationsPage.getDJPageBoxTitle());
		} else {
			assertUtil.isEquals(pageBoxTitle, onMagistrateSittingLocationsPage.getPageBoxTitle());
		}
		
	}

	@Then("^Page should contains panel boxes includes:$")
	public void page_should_contains_panel_boxes_includes(List<String> sittingLocationPanels) throws Throwable {
		for (int i=1;i<sittingLocationPanels.size();i++) {
			String panel=sittingLocationPanels.get(i);
			assertUtil.isTrue(panel,onMagistrateSittingLocationsPage.isPageFieldsDisplayed(panel));
		}
	   
	}
	
	//Validations
	
	@When("^I select Home Court \"(.*?)\",\"(.*?)\" ,\"(.*?)\"$")
	public void i_select_Home_Court(String location, String percentage, String panelLocationVal) throws Throwable {
		panelLocation=panelLocationVal;
		onMagistrateSittingLocationsPage.enterValidData(location, percentage, panelLocationVal);
	}

	@When("^I click on save button$")
	public void i_click_on_save_button() throws Throwable {
		onMagistrateSittingLocationsPage.clickErrorSaveButton();
	   
	}
	
	@When("^I click on save button to set the sitting location$")
	public void i_click_on_save() throws Throwable {
		onMagistrateSittingLocationsPage.clickSaveButton();
	   
	}

	@Then("^Should see error details \"(.*?)\"$")
	public void should_see_error_details(String errorMessage) throws Throwable {
	if(isDistrictJudge)
	{
		assertUtil.isEquals(errorMessage,onMagistrateSittingLocationsPage.getDJErrorDetails());
	} else {
		assertUtil.isEquals(errorMessage,onMagistrateSittingLocationsPage.getErrorMessage(panelLocation));
	}
	 
	}
	
	@When("^I add adhoc location \"(.*?)\"$")
	public void i_add_adhoc_location(String adhocLocation) throws Throwable {
		onMagistrateSittingLocationsPage.enterAdHocLocation(adhocLocation);
	}

	@Then("^Should see added ad-hoc location \"(.*?)\" ,\"(.*?)\"$")
	public void should_see_added_ad_hoc_location(String adhocLocation,String adhocType) throws Throwable {
		
		switch(adhocType)
		{
		case "Add":
			onMagistrateSittingLocationsPage.clickSaveButton();
			waitForPage();
			onMagistrateSittingLocationsPage=onMagistrateSearchPage.clickSittingLocation();
			assertUtil.isEquals(adhocLocation, onMagistrateSittingLocationsPage.getAdhocLocationLable().trim());
			break;
		case "Duplicate":
			assertUtil.isEquals("Location already added", onMagistrateSittingLocationsPage.getAdhocLocationErrorLable().trim());
			break;
		}
		 
	}

	@Then("^Should see the Magistrate Search results page$")
	public void should_see_the_Magistrate_Search_results_page() throws Throwable {
		assertUtil.isTrue(onMagistrateSearchPage.isMagistrateSearchPage()); 
		waitForPage();
	}
	
	@When("^I delete ad hoc location \"(.*?)\"$")
	public void i_delete_ad_hoc_location(String arg1) throws Throwable {

		onMagistrateSittingLocationsPage.deleteAdhoc();
	}

	@Then("^Should not see deleted ad-hoc location \"(.*?)\"$")
	public void should_not_see_deleted_ad_hoc_location(String arg1) throws Throwable {

		assertUtil.isTrue(onMagistrateSittingLocationsPage.getAdhocLocationLable().length()<=0);
	}
	
	//Magistrate related
	@Then("^I should see home cout location \"(.*?)\" ,percentage \"(.*?)\"$")
	public void i_should_see_home_cout_location_percentage(String homeCourtLocation, String percentage) throws Throwable {
	   assertUtil.isEquals(homeCourtLocation, onMagistrateSittingLocationsPage.getSelectedHomeCourtLocation());
	   assertUtil.isEquals(percentage, onMagistrateSittingLocationsPage.getSelectedHomeCourtPercentage());
	}

	@Then("^Should panels consists of:$")
	public void should_panels_consists_of(Map<String,String> PanelsAndTypes) throws Throwable {
		
		for (Map.Entry<String, String> entry : PanelsAndTypes.entrySet()) {
			String panelType=entry.getKey();
			String panelValue=entry.getValue();
			assertUtil.isEquals(panelValue, onMagistrateSittingLocationsPage.getSelectedPanels(panelType));
		}
	}

	//DJ related
	
	@When("^I click on delete location$")
	public void i_click_on_delete_location() throws Throwable {
		onMagistrateSittingLocationsPage.clickOnDelete(); 
	}
	
	@When("^I select LJA location \"(.*?)\" and location \"(.*?)\" ,\"(.*?)\"$")
	public void i_select_LJA_location_and_location(String ljaLocation, String location, String operation) throws Throwable {
	   if(operation.equals("Add"))
	   {
		   onMagistrateSittingLocationsPage.addLJALocation(ljaLocation); 
		  // onMagistrateSittingLocationsPage.selectLocation(location);
	   } else {
		   onMagistrateSittingLocationsPage.clickOnDJDelete();
	   }
	}
	
	@When("^Slect sitting pattern$")
	public void slect_sitting_pattern() throws Throwable {
		onMagistrateSittingLocationsPage.selectDays(); 
	}
	
	@When("^I add adhoc location for data setup$")
	public void i_add_adhoc_location_for_data_setup(List<String> locations) throws Throwable {
	   for(String location:locations)
	   {
		   waitForPage();
		   onMagistrateSittingLocationsPage.enterAdHocLocation(location); 
	   }
	}

	
}
