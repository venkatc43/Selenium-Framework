package com.moj.rota.admin.stepdefinitions;

import java.sql.Connection;

import com.moj.rota.base.stepdefs.BaseStepDefination;
import com.moj.rota.base.stepdefs.CommonStepDefinations;
import com.moj.test.utils.DatabaseUtil;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class DBCleanupStepDefination extends BaseStepDefination{
		
	private int magistrateID=0;
	
	private int districtJudgeID=0;
		
	@Given("^I pass Magistrate first name \"(.*?)\" and last name \"(.*?)\"$")
	public void i_pass_Magistrate_first_name_and_last_name(String firstName, String lastName) throws Throwable {
		magistrateID =DatabaseUtil.getMagistrateID(connection, firstName, lastName);
	}

	@When("^I get the magistrate id$")
	public void i_get_the_magistrate_id() throws Throwable {
	    
	}

	@When("^I should delte the Magistrate from data base$")
	public void i_should_delte_the_Magistrate_from_data_base() throws Throwable {
		if(magistrateID!=0)
		{
		assertUtil.isTrue(DatabaseUtil.deleteMagistrate(connection,magistrateID));
		} else {
			assertUtil.isFalse("Magistrate id is 0 so not able to delete",false);
		}
	}
	
	@Given("^I pass district judge first name \"(.*?)\" and last name \"(.*?)\"$")
	public void i_pass_district_judge_first_name_and_last_name(String firstName, String lastName) throws Throwable {
		
		districtJudgeID =DatabaseUtil.getDistrictJudgeID(connection, firstName, lastName);
	}

	
	@When("^I should delte the district judge from data base$")
	public void i_should_delte_the_district_judge_from_data_base() throws Throwable {
		if(districtJudgeID!=0)
		{
		assertUtil.isTrue(DatabaseUtil.deleteDistrictJudge(connection,districtJudgeID));
		} else {
			assertUtil.isFalse("District judge id is 0 so not able to delete",false);
		}
	}
	
	
}
