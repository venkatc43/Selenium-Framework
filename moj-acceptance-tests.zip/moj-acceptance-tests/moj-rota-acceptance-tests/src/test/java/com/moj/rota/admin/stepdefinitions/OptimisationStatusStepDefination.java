package com.moj.rota.admin.stepdefinitions;

import java.util.List;

import com.moj.rota.base.stepdefs.BaseStepDefination;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class OptimisationStatusStepDefination extends BaseStepDefination {
	
	String locationVal=null;
	
	@When("^I click on Optimisation status in home page$")
	public void i_click_on_Optimisation_status_in_home_page() throws Throwable {
		onOptimisationStatusPage=onRotaAdminHomePage.clickOnOptimisationStatus(); 
		waitForPage();
	}

	@Then("^I should see the optimisation status page$")
	public void i_should_see_the_optimisation_status_page() throws Throwable {
		waitForPage();
	   assertUtil.isTrue(onOptimisationStatusPage.isOptimisationPageDisplayed());
	}

	@Then("^Optimisation status page should consists of:$")
	public void optimisation_status_page_should_consists_of(List<String> optimisationLocations) throws Throwable {
		waitForPage();
	   for(String location:optimisationLocations)
	   {
		   if(location.contains("South"))
		   {
			 assertUtil.isTrue(location, onOptimisationStatusPage.getLocationLables("South").length()>0);  
		   } else {
			   assertUtil.isTrue(location, onOptimisationStatusPage.getLocationLables("North").length()>0); 
		   }
		   
	   }
	}
	
	@When("^I Select the location \"(.*?)\"$")
	public void i_click_on_location(String location) throws Throwable {
		waitForPage();
		locationVal=location;
		onOptimisationStatusPage.clickOnLocation(location);
	}

	@Then("^I should see the status \"(.*?)\" ,Next rota period \"(.*?)\"$")
	public void i_should_see_the_status_Next_rota_period(String status, String nextRotaPeriod) throws Throwable {
		waitForPage();
	   assertUtil.isTrue(status, onOptimisationStatusPage.getOptimisationStatus(locationVal).length()>1);
	   if(nextRotaPeriod.equals("next_rota_period_displayed"))
	   {
	   assertUtil.isTrue(onOptimisationStatusPage.getNextRotaPeriod(locationVal).length()>1);
	   } else {
	   assertUtil.isTrue(onOptimisationStatusPage.getNextRotaPeriod(locationVal).length()==0);  
	   }
	}
	
	@Then("^I should see optimisation history type \"(.*?)\"$")
	public void i_should_see_optimisation_history_type(String historyType) throws Throwable {
		if(locationVal.contains("Designated"))
		{
			assertUtil.isFalse(onOptimisationStatusPage.isDFCHistoryDisplayed());	
		} else {
			switch(historyType)
			   {
			   case "without history":
					assertUtil.isFalse(onOptimisationStatusPage.isHistroyDisplayed(historyType));
					break;
				case "with history":
					assertUtil.isTrue(onOptimisationStatusPage.isHistroyDisplayed(historyType));
					break;
			   } 
			
		}
		
	}
	
	@Then("^I should see the optiisation histroy date and duration \"(.*?)\"$$")
	public void i_should_see_the_optiisation_histroy_date_and_duration(String historyType) throws Throwable {
	    if(historyType.equals("with history"))
	    {
	    	assertUtil.isTrue("Optimisation history rota start date not displayed",onOptimisationStatusPage.isRotaStartDateDisplayed());
	    	assertUtil.isTrue("Optimisation history duration not displayed",onOptimisationStatusPage.isDurationDisplayed());
	    }
	}
	
	
	//Start optimisation alerts
	
	@When("^I click on start optimisation for LJA$")
	public void i_click_on_start_optimisation_for_LJA() throws Throwable {
	   onRotaListingPatternPage.clickStartOptimisation(); 
	}

	@Then("^I should see the optimisation alert pop up$")
	public void i_should_see_the_optimisation_alert_pop_up() throws Throwable {
	   assertUtil.isTrue(onRotaListingPatternPage.isValidationPupupDisplayed());
	}

	@Then("^Alert popup should contains$")
	public void alert_popup_should_contains(List<String> popupContents) throws Throwable {
	   for(String contentType:popupContents) 
	   {
		  assertUtil.isTrue(onRotaListingPatternPage.getValidationContent(contentType).trim().contains(contentType.trim())); 
	   }
	}

	@Then("^Click cancel button on alert pop up$")
	public void click_cancel_button_on_alert_pop_up() throws Throwable {
		onRotaListingPatternPage.clickCancelPopUp();
	}



}
