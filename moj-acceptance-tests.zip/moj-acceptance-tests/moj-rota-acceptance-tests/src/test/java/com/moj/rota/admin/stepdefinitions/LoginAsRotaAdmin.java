package com.moj.rota.admin.stepdefinitions;

import static org.junit.Assert.assertTrue;

import java.util.List;

import com.moj.rota.base.stepdefs.BaseStepDefination;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class LoginAsRotaAdmin extends BaseStepDefination {
	
	@And("^the Admin enters valid credentials$")
	public void the_Admin_enters_valid_credentials(List<String> loginCredentials) throws Throwable {
		rotaAdminLoggedIn(loginCredentials);
	}
	
	@Then("^the Admin should be logged in to the application as \"(.*?)\"$")
	public void the_Admin_should_be_logged_in_to_the_application_as(String username) throws Throwable {
		
		assertTrue(onRotaAdminHomePage.loggedInName(username));
	}

	@Given("^the Admin enters invalid credentials$")
	public void the_Admin_enters_invalid_credentials() throws Throwable {
		onRotaLoginPage.enterUsername("test");
		onRotaLoginPage.enterPassword("password");
	}

	@Then("^the Admin should not be logged in to the application$")
	public void the_Admin_should_not_be_logged_in_to_the_application() throws Throwable {
		assertTrue(onRotaLoginPage.errorMessage());
	}

}
