package com.moj.rota.admin.stepdefinitions;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import com.moj.rota.base.stepdefs.BaseStepDefination;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class CreateMagistrateMessageValidation extends BaseStepDefination {

	@When("^I complete the Add Magistrate form with no data$")
	public void i_complete_the_Add_Magistrate_form_with_no_data() throws Throwable {
		onCreateMagistratePage = onRotaAdminHomePage.clickOnCreateMagistrateLink()
													.clickNextWithInvalidData();		
	}
	
	@Then("^the empty fields validation messages should be displayed$")
	public void the_empty_fields_validation_messages_should_be_displayed() throws Throwable {
		assertTrue(onCreateMagistratePage.errorWithNoData());
	}

	@When("^I complete the Add Magistrate form with incomplete ([^\"]*)$")
	public void i_complete_the_Add_Magistrate_form_with_incomplete_Title(String field) throws Throwable {
		errorMsg = onRotaAdminHomePage.clickOnCreateMagistrateLink().getErrorMsg(field);
		
	}

	@Then("^the validation ([^\"]*) should be displayed$")
	public void the_validation_should_be_displayed(String msg) throws Throwable {
		assertEquals(msg, errorMsg);
	}
	
}
