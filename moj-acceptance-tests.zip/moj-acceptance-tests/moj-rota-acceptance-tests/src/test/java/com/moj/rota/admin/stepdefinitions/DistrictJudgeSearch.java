package com.moj.rota.admin.stepdefinitions;

import static org.junit.Assert.assertEquals;

import com.moj.rota.base.stepdefs.BaseStepDefination;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class DistrictJudgeSearch extends BaseStepDefination {
		
	@And("^I complete the Search District Judge form with no data$")
	public void i_complete_the_District_Judge_form_with_no_data() throws Throwable {
		onDistrictJudgeSearchPage =	onRotaAdminHomePage.clickSearchDistrictJudge();
		onDistrictJudgeSearchPage.completeDJFormWithNoData();
	}
	
	@Then("^\"(.*?)\" validation messages should be displayed on the District Judge Search page$")
	public void validation_messages_should_be_displayed(String errorMsg) throws Throwable {
		if (errorMsg.equals("Please enter search criteria"))
		assertEquals(errorMsg, onDistrictJudgeSearchPage.getErrorMsgWithNoData());
		else
		assertEquals(errorMsg, onDistrictJudgeSearchPage.getErrorMsgWithInvalidData());
			
	}
	
	@Given("^I complete the Search District Judge form with valid data$")
	public void i_complete_the_Search_District_Judge_form_with_valid_data() throws Throwable {
	    onDistrictJudgeSearchPage =	onRotaAdminHomePage.clickSearchDistrictJudge();
	    onDistrictJudgeSearchPage.completeDJFormWithValidData();
	    
	}
	
	@Given("^I complete the Search District Judge form with invalid data$")
	public void i_complete_the_Search_District_Judge_form_with_invalid_data() throws Throwable {
		onDistrictJudgeSearchPage =	onRotaAdminHomePage.clickSearchDistrictJudge();
		onDistrictJudgeSearchPage.completeDJFormWithInvalidData();
		
	}


	@Then("^the appropriate results should be displayed on the District Judge Search page$")
	public void the_appropriate_results_should_be_displayed_on_the_District_Judge_Search_page() throws Throwable {
		onDistrictJudgeSearchPage.districtJudgeFoundMsg();
	}

	@Given("^I complete the Search District Judge form with criteria that results in no data$")
	public void i_complete_the_Search_District_Judge_form_with_criteria_that_results_in_no_data() throws Throwable {
		onDistrictJudgeSearchPage =	onRotaAdminHomePage.clickSearchDistrictJudge();
		onDistrictJudgeSearchPage.completeDJFormWithZeroData();
	}

	@Then("^no results should be displayed on the District Judge Search page$")
	public void no_results_should_be_displayed_on_the_District_Judge_Search_page() throws Throwable {
		onDistrictJudgeSearchPage.getNoResultsMessage();
	}
	
	@When("^I click on District judge search link on home page$")
	public void i_click_on_District_judge_search_link_on_home_page() throws Throwable {
		onDistrictJudgeSearchPage =	onRotaAdminHomePage.clickSearchDistrictJudge(); 
	}

	@When("^I enter search parameters first name :\"(.*?)\" ,last name :\"(.*?)\"$")
	public void i_enter_search_parameters_first_name_last_name(String firstName, String lastName) throws Throwable {
		 onDistrictJudgeSearchPage.completeDJFormWithValidData(firstName,lastName);
	}

	@Then("^should see the search results \"(.*?)\"$")
	public void should_see_the_search_results(String djName) throws Throwable {
	    assertUtil.isEquals(djName, onDistrictJudgeSearchPage.getSearchResultsName());
	}
	
	@When("^I click on district judge Search results section :\"(.*?)\"$")
	public void i_click_on_Search_results_section(String location) throws Throwable {
		isDistrictJudge=true;
		switch(location)
		{
		case "Sitting location" :
			onMagistrateSittingLocationsPage=onDistrictJudgeSearchPage.clickSittingLocation();
			break;
		case "Sitting eligibility" :
			onMagistrateSittingEligibiltyPage=onDistrictJudgeSearchPage.clickSittingEligibility();
			break;
		case "Personal Details" :
			onMagistratePersonalDetailsPage = onDistrictJudgeSearchPage.clickPersonalDetails();
			break;
			
		case "Non-availability" :
			onMagistrateNonAvailabilityPage = onDistrictJudgeSearchPage.clickNonAvailability();
			break;
			
		case "Sitting Preferences" :
			onMagistrateSittingPrefecencesPage = onDistrictJudgeSearchPage.clickOnSittingPreferences();
			break;
			
		case "Sittings" :
			onMagistrateSittingsPage = onDistrictJudgeSearchPage.clickOnSittings();
			break;
		}
		
		
	}



}
