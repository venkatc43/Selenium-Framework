package com.moj.rota.admin.stepdefinitions;

import java.util.List;

import com.moj.rota.base.stepdefs.BaseStepDefination;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class DraftRotaIdentifyFlagsStepDefination extends BaseStepDefination {
	
	
	private static boolean isNewWingerExists=false;
	private static boolean isSpecialRequirements=false;
	private static boolean isTraineeChair=false;
	private static String wingerType=null;
	private static String dayPattern=null;
	private static String magistrateType=null;
	private static String filter=null;
			
	@When("^I click on search magistrate icon to select different requirements\"(.*?)\" ,\"(.*?)\"$")
	public void i_click_on_search_magistrate_icon_to_select_different_requirements(String requirementsVal,String dayPatternVal) throws Throwable {
		requirements=requirementsVal;
		dayPattern=dayPatternVal;
		waitForPage();
	    onDraftRotaMagistrateListPopupPage=onRotaListingPatternPage.clickMagistrateSearch(requirementsVal,dayPatternVal);
	}

	@When("^I add flags \"(.*?)\" to selected magistrate$")
	public void i_add_flags_to_selected_magistrate(String requirements) throws Throwable {
		waitForPage();
		isNewWingerExists=onDraftRotaMagistrateListPopupPage.isNewWingerExists();
		isSpecialRequirements=onDraftRotaMagistrateListPopupPage.isSpecialRequirements();
		isTraineeChair=onDraftRotaMagistrateListPopupPage.isTraineeChain();
		waitForPage();
		if((!isNewWingerExists&&requirements.equals("New Winger")) || (!isSpecialRequirements&&requirements.equals("Special Requirements")))
		{
		onDraftRotaMagistrateListPopupPage.clickMagistrate(requirements);
		} else if((!isTraineeChair&&requirements.equals("Trainee Chair")) || requirements.equals("Local Authority"))
		{
			onDraftRotaMagistrateListPopupPage.clickMagistrate(requirements);
		}
		
		
	}

	@When("^I click on search magistrate close option \"(.*?)\"$")
	public void i_click_on_search_magistrate_close_option(String requirementsText) throws Throwable {
		switch(requirements)
		{
		case "Special Requirements":
			if(!isSpecialRequirements)
			{
			onMagistrateSittingPrefecencesPage=onDraftRotaMagistrateListPopupPage.selectMagistratePreferences();
			onMagistrateSittingPrefecencesPage.enterSpecialRequirements(requirementsText);
			onDraftRotaMagistrateListPopupPage=onMagistrateSittingPrefecencesPage.clickonDraftSave();
			//onRotaListingPatternPage=onDraftRotaMagistrateListPopupPage.closeMagistrateList(requirements);
			//onDraftRotaMagistrateListPopupPage=onRotaListingPatternPage.clickMagistrateSearch(requirements,dayPattern);
			}
			break;
		case "New Winger":
		case "Trainee Chair":
			if ((!isNewWingerExists&&requirements.equals("New Winger")) || (!isTraineeChair&&requirements.equals("Trainee Chair"))) {
				onMagistrateSittingEligibiltyPage = onDraftRotaMagistrateListPopupPage.selectMagistrateEligibility(requirements);
				if (requirements.equals("New Winger")) {
					onMagistrateSittingEligibiltyPage.identifyNewWingerInAdultPanel(getDate(1));
				} else {
					onMagistrateSittingEligibiltyPage.identifyTraineeChairFamilyPanel(getDate(1));
				}
				onDraftRotaMagistrateListPopupPage = onMagistrateSittingEligibiltyPage.clickOnDraftRotaSaveButton();
				//onRotaListingPatternPage = onDraftRotaMagistrateListPopupPage.closeMagistrateList(requirements);
				//onDraftRotaMagistrateListPopupPage = onRotaListingPatternPage.clickMagistrateSearch(requirements,dayPattern);
				
			}
			
			break;
		case "Local Authority":
			onMagistratePersonalDetailsPage=onDraftRotaMagistrateListPopupPage.selectMagistratePersonalDetails();
			onMagistratePersonalDetailsPage.selectEnglishAndEnterLocalAuthority(requirementsText);
			onDraftRotaMagistrateListPopupPage=onMagistratePersonalDetailsPage.clickDraftRotaConfirm();
			//onRotaListingPatternPage=onDraftRotaMagistrateListPopupPage.closeMagistrateList(requirements);
			//onDraftRotaMagistrateListPopupPage=onRotaListingPatternPage.clickMagistrateSearch(requirements,dayPattern);
			
			break;
		default:
		}
		
		onRotaListingPatternPage=onDraftRotaMagistrateListPopupPage.closeMagistrateList(requirements);
		
	}

	@When("^I select Magistrate to add selected flag \"(.*?)\"$")
	public void i_select_Magistrate_to_add_selected_falg(String selectMagistrate) throws Throwable {
		onDraftRotaMagistrateListPopupPage=onRotaListingPatternPage.clickMagistrateSearch(requirements,dayPattern);
		waitForPage();
		onRotaListingPatternPage=onDraftRotaMagistrateListPopupPage.selectMagistrate(selectMagistrate);
	}

	@Then("^I should see the selected \"(.*?)\"$")
	public void i_should_see_the_selected(String flag) throws Throwable {
		waitForPage();
		switch(requirements)
		{
		case "Special Requirements":
			assertUtil.isEquals(flag, onRotaListingPatternPage.getSpecialRequirementFlag());
			break;
		case "New Winger":
			assertUtil.isEquals(flag, onRotaListingPatternPage.getNewWingerFlag());
			break;
		case "Trainee Chair":
			assertUtil.isEquals(flag, onRotaListingPatternPage.getTraineeChairFlag());
			break;
		case "Local Authority":
			assertUtil.isTrue(onRotaListingPatternPage.getLocalAuthorityFlag().contains(flag));
			flag="W";
			assertUtil.isTrue(onRotaListingPatternPage.getWelshSpeakingLnagFlag().contains(flag));
			break;
		default:
		}
		
	    
	}
	
	@Then("^I should see the requirements \"(.*?)\"$")
	public void i_should_see_the_requirements(String requirementsText) throws Throwable {
		if(requirements.equals("Special Requirements"))
		{
		onRotaListingPatternPage.mouseOverOnSpecialRequirements();
		//assertUtil.isTrue(requirementsText, onRotaListingPatternPage.isMouseOverDisplayed()); 
		}
	}


	@When("^I select flag \"(.*?)\" ,\"(.*?)\"$")
	public void i_select_flag(String flags,String operationType) throws Throwable {
		waitForPage();
		onRotaListingPatternPage.clickRBAndLA(operationType); 
	}

	@Then("^I should see the selected flag \"(.*?)\" ,\"(.*?)\"$")
	public void i_should_see_the_selected_flag(String color,String operationType) throws Throwable {
		waitForPage();
		if(operationType.equals("DAdd"))
		{
		String[] colors = color.split(",");
		String RBColor=colors[0];
		String LSColor=colors[1];
		
		assertUtil.isEquals(RBColor, onRotaListingPatternPage.getColorOfReturningBench(operationType));
		assertUtil.isEquals(LSColor, onRotaListingPatternPage.getColorOfLastSitting(operationType));
		} else {
			assertUtil.isEquals(color, onRotaListingPatternPage.getColorOfReturningBench(operationType));
			assertUtil.isEquals(color, onRotaListingPatternPage.getColorOfLastSitting(operationType));
		}
	   
	}
	
	@When("^I click on Sitting identifier$")
	public void i_click_on_Sitting_identifier() throws Throwable {
		onRotaListingPatternPage.clickSitiingIdentifier();
	}

	@Then("^I should see the all identifiers :$")
	public void i_should_see_the_all_identifiers(List<String> listOfIdentifiers) throws Throwable {
		for(int i=0;i<listOfIdentifiers.size();i++)
		{
			assertUtil.isEquals(listOfIdentifiers.get(i), onRotaListingPatternPage.getIdentifierLabel(i));
		}
	   
	}
	
	@When("^I select sitting identifier type \"(.*?)\"$")
	public void i_select_sitting_identifier_type(String sittingIdentifier) throws Throwable {
		onRotaListingPatternPage.selectSittingIdentifier(sittingIdentifier);
	}

	@Then("^I should see selected magistrate sitting identifier \"(.*?)\"$")
	public void i_should_see_selected_magistrate_sitting_identifier(String sittingIdenfiiferFlag) throws Throwable {
		if(sittingIdenfiiferFlag.equals("DDelete"))
		{
		assertUtil.isTrue(onRotaListingPatternPage.isSittingIdentifierIcon(sittingIdenfiiferFlag));
		} else {
			assertUtil.isEquals(sittingIdenfiiferFlag, onRotaListingPatternPage.getSelectedSittingIdentifier(sittingIdenfiiferFlag));
		}
	   
	}
	
	@When("^I click on Sitting identifier winger \"(.*?)\"$")
	public void i_click_on_Sitting_identifier_winger(String winger) throws Throwable {
		wingerType=winger;
		onRotaListingPatternPage.clickSitiingIdentifier(winger);  
	}

	@When("^I select Matching sitting identifier type \"(.*?)\"$")
	public void i_select_Matching_sitting_identifier_type(String identifier) throws Throwable {
		   onRotaListingPatternPage.selectMatchingIdentifier(identifier,wingerType);  
	}
	
	@Then("^I should see the matching pair icon \"(.*?)\"$")
	public void i_should_see_the_matching_pair_icon(String pairIcon) throws Throwable {
		if(wingerType.equals("Winger2"))
		{
			assertUtil.isTrue(onRotaListingPatternPage.isMatchingPair());
		}
	    
	}
	
	@When("^I click on matching pair$")
	public void i_click_on_matching_pair() throws Throwable {
		onRotaListingPatternPage.clickOnMatchingPair();
	}

	@Then("^Search results panel should be visible$")
	public void search_results_panel_should_be_visible() throws Throwable {
	   assertUtil.isTrue(onRotaListingPatternPage.isSearchResultsPanel());
	}

	@Then("^I should see the two matching magistrates$")
	public void i_should_see_the_two_matching_magistrates() throws Throwable {
		//Matching Sessions for +mag1 and mag2 should contains
		//Matching Sessions for length is 22 so expecting more than that..assuming mag1,mag2 displyed
	   assertUtil.isTrue(onRotaListingPatternPage.getSearchPanelTitle().length()>23);
	}

	@Then("^Title bar should consists of:$")
	public void title_bar_should_consists_of(List<String> searchResultsContent) throws Throwable {
	   for(String content:searchResultsContent)
	   {  
		   assertUtil.isTrue(content, onRotaListingPatternPage.getSearchResultsContent(content).length()>0);
	   }
	   onRotaListingPatternPage.closeMatchingPair();
	   
	}
	
	@When("^I click on first results date$")
	public void i_click_on_first_results_date() throws Throwable {
		onRotaListingPatternPage.clickSearchResultsDate(); 
	}

	@When("^I click on magistrate type \"(.*?)\"$")
	public void i_click_on_magistrate_type(String magistrateTypeVal) throws Throwable {
		magistrateType=magistrateTypeVal;
		onRotaListingPatternPage.clickMatchMagistrateType(magistrateTypeVal);
	}

	@When("^I should see the updated results$")
	public void i_should_see_the_updated_results() throws Throwable {
		assertUtil.isTrue(onRotaListingPatternPage.getSearchResultsCount()>=1);
		onRotaListingPatternPage.clickMatchMagistrateType(magistrateType+"After");
	}

	@Then("^I should see the tick mark$")
	public void i_should_see_the_tick_mark() throws Throwable {
	   assertUtil.isTrue(onRotaListingPatternPage.isSucessTickMarkDisplayed());
	   onRotaListingPatternPage.closeMatchingPair();
	}
	
	@Then("^I should see the search results \"(.*?)\"$")
	public void i_should_see_the_search_results(String resultsType) throws Throwable {
		
		if(resultsType.equals("Should displayed"))
		{
			//checking results count should be greater than zero
			assertUtil.isTrue(onDraftRotaMagistrateListPopupPage.isDistrictJudgeSearchResultsDisplayed());
		} else {
			//checking in the results should not display the scheduled Dj
			assertUtil.isTrue(onDraftRotaMagistrateListPopupPage.getDJSearchResultsNotDisplayed());
		}
	    
	}
	
	//pen search
	@When("^I click on filter options either mentor or appraiser \"(.*?)\"$")
	public void i_click_on_filter_options_either_mentor_or_appraiser(String filterType) throws Throwable {
		filter=filterType;
		onDraftRotaMagistrateListPopupPage.clickFilter(filterType);
	}

	@Then("^I should see the filtered results \"(.*?)\"$")
	public void i_should_see_the_filtered_results(String filterResults) throws Throwable {
		assertUtil.isTrue(onDraftRotaMagistrateListPopupPage.getFilterTypeResult(filterResults).length()>0);
	}
	
	@When("^I enter the first magistrate name$")
	public void i_enter_the_first_magistrate_name() throws Throwable {
		onDraftRotaMagistrateListPopupPage.enterMagistrateName();
	}

	@Then("^I should match the magistrate name$")
	public void i_should_match_the_magistrate_name() throws Throwable {
		assertUtil.isTrue(onDraftRotaMagistrateListPopupPage.getSearchResultMagName().length()>0);
		onDraftRotaMagistrateListPopupPage.clickFilter(filter);
	}
	
	@When("^I enter the first district judge name$")
	public void i_enter_the_first_district_judge_name() throws Throwable {
		onDraftRotaMagistrateListPopupPage.enterMagistrateName(); 
	}

	@Then("^I should see matched district judge$")
	public void i_should_see_matched_district_judge() throws Throwable {
		assertUtil.isTrue(onDraftRotaMagistrateListPopupPage.getSearchResultMagName().length()>0);
	}

}
