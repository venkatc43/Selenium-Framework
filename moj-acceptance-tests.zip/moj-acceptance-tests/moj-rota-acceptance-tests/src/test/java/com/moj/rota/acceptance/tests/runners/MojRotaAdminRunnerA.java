package com.moj.rota.acceptance.tests.runners;

import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = {
                "target/test-classes"
                
        },
        		plugin = {
        		        "pretty", "html:target/cucumber-report/RotaAdminMagistrate",
        		        "json:target/cucumber-report/mojA/cucumber_Magistrate.json",
        		        "rerun:target/cucumber-report/mojA/rerun.txt"},
        tags = {"@MagistratePersonalDetails"},
        glue = {"com/moj/rota/"})
public class MojRotaAdminRunnerA {
}
