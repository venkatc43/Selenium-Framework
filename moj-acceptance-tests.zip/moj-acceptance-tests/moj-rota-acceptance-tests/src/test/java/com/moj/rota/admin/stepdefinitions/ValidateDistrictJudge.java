package com.moj.rota.admin.stepdefinitions;

import static org.junit.Assert.assertEquals;

import com.moj.rota.base.stepdefs.BaseStepDefination;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class ValidateDistrictJudge extends BaseStepDefination {

@Then("^the appropriate validation messages should be displayed$")
public void the_appropriate_validation_messages_should_be_displayed() throws Throwable {
	onCreateDistrictJudgePage.verifyErrors();
}

@Given("^I complete the Add District Judge form with incomplete ([^\"]*)$")
public void i_complete_the_Add_District_Judge_form_with_incomplete_Title(String field) throws Throwable {
	errorMsg = onRotaAdminHomePage.clickCreateDistrictJudge().getErrorMsg(field);
	
}

@Then("^the appropriate District Judge validation ([^\"]*) should be displayed$")
public void the_validation_should_be_displayed(String msg) throws Throwable {
	assertEquals(msg, errorMsg);
}

	
	
}
