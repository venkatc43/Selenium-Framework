package com.moj.rota.magistrate.stepdefinitions;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.List;

import com.moj.rota.base.stepdefs.BaseStepDefination;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class LoginAsMagistrate extends BaseStepDefination {
	
	private String magUsername;
	
	@Given("^I login with valid details for the first time$")
	public void i_login_with_valid_details_for_the_first_time(List<String> loginCredentials)
			throws Throwable {
		magUsername = loginCredentials.get(0);
		magistrateLogin(loginCredentials);
	}

	@Then("^I can view my ROTA Profile$")
	public void i_can_view_my_ROTA_Profile() throws Throwable {
		assertTrue(onMagistrateHomePage.loggedInName(magUsername));
	}

	@Given("^I try to login with invalid details$")
	public void i_try_to_login_with_invalid_details() throws Throwable {
		onMagistrateLoginPage.enterUsername("invaliduser@test.com");
		onMagistrateLoginPage.enterPassword("invalidPass");
	}

	@Then("^I will see the message, \"(.*?)\"$")
	public void i_will_see_the_message(String errorMsg) throws Throwable {
		assertEquals(errorMsg, onMagistrateLoginPage.errorMessage());
	}
}
