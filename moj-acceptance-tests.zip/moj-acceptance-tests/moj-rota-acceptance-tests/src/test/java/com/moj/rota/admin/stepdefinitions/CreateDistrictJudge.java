package com.moj.rota.admin.stepdefinitions;

import com.moj.rota.base.stepdefs.BaseStepDefination;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class CreateDistrictJudge extends BaseStepDefination {
	
	@Given("^I complete the Add District Judge form with valid data$")
	public void i_complete_the_Add_District_Judge_form_with_valid_data() throws Throwable {
	 
		onCreateDistrictJudgePage =onRotaAdminHomePage.clickCreateDistrictJudge();
		onConfirmationPopUp= onCreateDistrictJudgePage.completeDJFormWithValidData();
		onRotaAdminHomePage = onConfirmationPopUp.clickContinueButton();
	}
	
	@Given("^I complete the Add District Judge form with first name \"(.*?)\",last name :\"(.*?)\"$")
	public void i_complete_the_Add_District_Judge_form_with_first_name_last_name(String firstName, String lastName) throws Throwable {
		onCreateDistrictJudgePage =onRotaAdminHomePage.clickCreateDistrictJudge();
		onConfirmationPopUp= onCreateDistrictJudgePage.completeDJFormWithValidData(firstName,lastName);
		onRotaAdminHomePage = onConfirmationPopUp.clickContinueButton(); 
	}

	@Then("^the District Judge should be created$")
	public void the_District_Judge_should_be_created() throws Throwable {
		onRotaAdminHomePage.verifyAdminHomePageisDisplayed();
	}

	@Given("^I complete the Add District Judge form with invalid data$")
	public void i_complete_the_Add_District_Judge_form_with_invalid_data() throws Throwable {
		onCreateDistrictJudgePage =onRotaAdminHomePage.clickCreateDistrictJudge();
		onCreateDistrictJudgePage.leaveMandatoryFieldsIncomplete();
	}

	@Then("^the District Judge should not be created$")
	public void the_District_Judge_should_not_be_created() throws Throwable {
		onCreateDistrictJudgePage.verifyErrors();
	}
	
	
}
