package com.moj.rota.admin.stepdefinitions;

import java.util.Map;

import com.moj.rota.base.stepdefs.BaseStepDefination;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class MagistrateAlertMessageStepDefination extends BaseStepDefination {
	
	private static String categoryType=null;
	
	@When("^I click messages link  on home page$")
	public void i_click_messages_link_on_home_page() throws Throwable {
		onMagistrateAlertMessagePage=onRotaAdminHomePage.clickOnMessageLink();
	}

	@When("^I click messages category \"(.*?)\"$")
	public void i_click_messages_category(String messageCategory) throws Throwable {
		categoryType=messageCategory;
		onMagistrateAlertMessagePage.clickMessageCategory(messageCategory);
	}

	@Then("^transfer magistrate message detail should consists of:$")
	public void transfer_magistrate_message_detail_should_consists_of(Map<String,String> messageDetails) throws Throwable {
		for (Map.Entry<String, String> content : messageDetails.entrySet()) {
			String contentType=content.getKey();
			String contentValue=content.getValue();
			assertUtil.isTrue(contentType,onMagistrateAlertMessagePage.getTransferMagistrateContent(contentType).matches(contentValue));
		}
	}

	@When("^I click on remove link button$")
	public void i_click_on_remove_link_button() throws Throwable {
		onMagistrateAlertMessagePage.clickRemoveButton(categoryType);
	}
	
	@When("^I click on either confirm or cancel \"(.*?)\"$")
	public void i_click_on_either_confirm_or_cancel(String actionType) throws Throwable {
	    if(actionType.equals("Confirm"))
	    {
	    	onMagistrateAlertMessagePage.clickConfirm();
	    } else {
	    	onMagistrateAlertMessagePage.clickCancel();
	    }
	}

	@Then("^Message should be removed based on action type \"(.*?)\"$")
	public void message_should_be_removed_based_on_category(String removeAction) throws Throwable {
	    if(removeAction.equals("Cancel"))
	    {
	    	assertUtil.isTrue(onMagistrateAlertMessagePage.isRemoveButtonDisplayed(categoryType));
	    } else {
	    	assertUtil.isFalse(onMagistrateAlertMessagePage.isRemoveButtonDisplayed(categoryType));
	    }
	}


	@Then("^Personal details message detail should consists of:$")
	public void personal_details_message_detail_should_consists_of(Map<String,String> messageDetails) throws Throwable {
		for (Map.Entry<String, String> content : messageDetails.entrySet()) {
			String contentType=content.getKey();
			String contentValue=content.getValue();
			assertUtil.isTrue(contentType,onMagistrateAlertMessagePage.getPersonalDetalsMagistrateContent(contentType).matches(contentValue));
		} 
	}
	
	@Then("^Bench chair message detail should consists of:$")
	public void bench_chair_message_detail_should_consists_of(Map<String,String> messageDetails) throws Throwable {
		for (Map.Entry<String, String> content : messageDetails.entrySet()) {
			String contentType=content.getKey();
			String contentValue=content.getValue();
			assertUtil.isTrue(contentType,onMagistrateAlertMessagePage.getBechChairContent(contentType).matches(contentValue));
		} 
	}
	
	@Then("^Should see the periods of absence message consists of:$")
	public void should_see_the_periods_of_absence_message_consists_of(Map<String,String> messageDetails) throws Throwable {
		waitForPage();
		for (Map.Entry<String, String> content : messageDetails.entrySet()) {
			String contentType=content.getKey();
			String contentValue=content.getValue();
			assertUtil.isTrue(contentType,onMagistrateAlertMessagePage.getEditDFCMessageDetails(contentType).matches(contentValue));
		}
	}
}
