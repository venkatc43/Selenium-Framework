/**
 * 
 */
package com.rota.session;

/**
 * ServiceException - Exception Raised when there is an error in the service 
 * @author
 *
 */
public class ServiceException extends Exception {
	private static final long serialVersionUID = 6351654222861438112L;
	
	public ServiceException(){
	    super();
	}

    public ServiceException(String error) {
        super(error);
    }

	public ServiceException(String error, Exception exception) {
		super(error, exception);
	}

	public ServiceException(Exception exception) {
		super(exception.getMessage());
	}

	public String getMessage() {
		return (super.getMessage());
	}
}