package com.rota.session;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import javax.xml.bind.DatatypeConverter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.util.StringUtils;

/**
 * IdObfuscationServiceImpl - implementation using AES cipher and Base64
 * encoding.
 * <p/>
 * <p>
 * The class achieves obfuscation via AES enciphering and subsequent Base64
 * encoding.
 * </p>
 * <p>
 * The reverse operation, to 'deobfuscate', performs Base64 decoding then
 * deciphering using AES.
 * </p>
 * <p>
 * The same password is used when enciphering and deciphering. Note that during
 * enciphering an IV is generated and this same IV is also used during
 * deciphering. The IV is the same per request, and included in the obfuscated
 * value. During deciphering the IV is removed from the obfuscated value and
 * used in conjunction with the password and salt to decipher.
 * </p>
 * <p>
 * The encryption key is generated per request, based on the password and
 * supplied session ID.
 * </p>
 */
public class IdObfuscationServiceImpl implements IdObfuscationService {

    final static Logger logger = LoggerFactory.getLogger(IdObfuscationServiceImpl.class);

    private static final String CIPHER_ALGORITHM = "AES/CBC/PKCS5Padding";
    private static final String KEY_FACTORY_ALGORITHM = "PBKDF2WithHmacSHA1";
    private static final String KEY_ALGORITHM = "AES";
    private static final int ITERATIONS = 512;
    private static final int KEYLEN_BITS = 128;
    private static final String UTF_8 = "UTF8";

    private String password;

    private boolean enabled;

    /**
     * Constructor
     */
    public IdObfuscationServiceImpl() {
    }

    /**
     * Obfuscates (enciphers, encodes) an entity ID value using AES cipher and
     * Base64.
     *
     * @param sessionId the session id
     * @param clearText the text to encipher and encode
     * @return the obfuscated value
     * @throws com.moj.magsrota.common.exceptions.ServiceException
     *
     */
    @Override
    public String obfuscate(String sessionId, String clearText) throws ServiceException {
        logger.debug("Attempt to obfuscate value {}", clearText);

        // If not enabled, return supplied value
        if (!enabled) {
            logger.warn("Obfuscation is disabled");
            return clearText;
        }

        if (StringUtils.isEmpty(sessionId)) {
            throw new ServiceException("sessionId cannot be null");
        }

        if (StringUtils.isEmpty(clearText)) {
            throw new ServiceException("clearText cannot be null");
        }

        // Generate key
        SecretKeySpec symKey = generateKey(sessionId);

        // Encrypt clear text
        String textEncrypted;
        try {
            textEncrypted = encrypt(clearText, symKey, sessionId);
        } catch (Exception e) {
            logger.error("Failed to obfuscate value {}", clearText, e);
            throw new ServiceException(e);
        }
        return textEncrypted;
    }

    /**
     * Deobfuscates an entity ID value from a obfuscated (enciphered, encoded)
     * value using AES and Base64.
     *
     * @param sessionId
     *            the session id
     * @param ciphertext
     *            the value to decode and decipher
     * @return the deobfuscated (cleartext) value
     * @throws com.moj.magsrota.common.exceptions.ServiceException
     *
     */
    @Override
    public String deobfuscate(String sessionId, String ciphertext) throws ServiceException {
        logger.debug("Attempt to deobfuscate value {}", ciphertext);

        // If not enabled, return supplied value
        if (!enabled) {
            logger.warn("Obfuscation is disabled");
            return ciphertext;
        }

        if (StringUtils.isEmpty(sessionId)) {
            throw new ServiceException("sessionid cannot be null");
        }

        if (StringUtils.isEmpty(ciphertext)) {
            throw new ServiceException("ciphertext cannot be null");
        }

        // Generate key
        SecretKeySpec symKey = generateKey(sessionId);

        // Decrypt obfuscated text
        String textDecrypted;
        try {
            textDecrypted = decrypt(ciphertext, symKey);
        } catch (Exception e) {
            logger.error("Failed to deobfuscate value {}", ciphertext, e);
            throw new ServiceException(e);
        }
        return textDecrypted;
    }

    /**
     * Sets password
     *
     * @param password the password
     */
    @Required
    public void setPassword(String password) throws ServiceException {
        this.password = password;
    }

    /**
     * Sets enabled flag
     *
     * @param enabled the enabled flag
     */
    @Required
    public void setEnabled(boolean enabled) throws ServiceException {
        this.enabled = enabled;
    }

    /**
     * Generates a key
     *
     * @param sessionId
     *            the session id
     * @throws ServiceException
     */
    private SecretKeySpec generateKey(String sessionId) throws ServiceException {
        try {
            byte[] salt = sessionId.getBytes(UTF_8);

            // Derive the key, given password and salt (via session id)
            return getSymKey(this.password, salt);
	} catch (UnsupportedEncodingException | NoSuchAlgorithmException | InvalidKeySpecException e) {
            throw new ServiceException("Failed to create service", e);
        }
    }

    /**
     * Encrypts the plainMessage using AES cipher.
     *
     * @param plainMessage
     *            the cleartext message
     * @param symKey
     *            the encryption key
     * @param sessionId
     *            the session id
     * @return the encrypted text
     */
    private String encrypt(final String plainMessage, final SecretKeySpec symKey, final String sessionId) {
        try {
            final byte[] encodedMessage = plainMessage.getBytes(UTF_8);

            final Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);
            final int blockSize = cipher.getBlockSize();

            // Create an initialisation vector based on the session id
            final IvParameterSpec iv = new IvParameterSpec(sessionId.substring(0, blockSize).getBytes(UTF_8));
            
            // Encipher
            cipher.init(Cipher.ENCRYPT_MODE, symKey, iv);
            final byte[] encryptedMessage = cipher.doFinal(encodedMessage);

            // Concatenate IV and encrypted message
            final byte[] ivAndEncryptedMessage = new byte[iv.getIV().length + encryptedMessage.length];
            System.arraycopy(iv.getIV(), 0, ivAndEncryptedMessage, 0, blockSize);
            System.arraycopy(encryptedMessage, 0, ivAndEncryptedMessage, blockSize, encryptedMessage.length);

            // Base64 encode the encrypted data
            final String ivAndEncryptedMessageBase64 = DatatypeConverter.printBase64Binary(ivAndEncryptedMessage);

            // Encoding url for url reserved characters
            return URLEncoder.encode(ivAndEncryptedMessageBase64, UTF_8);

        } catch (UnsupportedEncodingException e) {
            throw new IllegalArgumentException("Not using a supported encoding", e);
        } catch (InvalidKeyException e) {
            throw new IllegalArgumentException("Not using a valid AES key", e);
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("Unexpected exception during encryption", e);
        }
    }

    /**
     * Decrypts the encrypted text using AES cipher.
     *
     * @param ivAndEncryptedMessageBase64
     *            the encrypted text
     * @param symKey
     *            the encryption key
     * @return the decrypted text
     */
    private String decrypt(final String ivAndEncryptedMessageBase64, final SecretKeySpec symKey) {
        try {

            // Perform URL decoding
            String trueIvAndEncryptedMessageBase64 = URLDecoder.decode(ivAndEncryptedMessageBase64, UTF_8);

            // Base64 decode the encrypted data
            final byte[] ivAndEncryptedMessage = DatatypeConverter.parseBase64Binary(trueIvAndEncryptedMessageBase64);

            final Cipher decipher = Cipher.getInstance(CIPHER_ALGORITHM);
            final int blockSize = decipher.getBlockSize();

            // Retrieve random IV (initialization vector) from start of the
            // received message
            final IvParameterSpec iv = getIvParameterFromMessage(ivAndEncryptedMessage, blockSize);

            // Retrieve the encrypted message itself
            final byte[] encryptedMessage = new byte[ivAndEncryptedMessage.length - blockSize];
            System.arraycopy(ivAndEncryptedMessage, blockSize, encryptedMessage, 0, encryptedMessage.length);

            // Decipher
            decipher.init(Cipher.DECRYPT_MODE, symKey, iv);
            final byte[] encodedMessage = decipher.doFinal(encryptedMessage);

            final String message = new String(encodedMessage, UTF_8);

            return message;
        } catch (UnsupportedEncodingException e) {
            throw new IllegalArgumentException("Not using a supported encoding", e);
        } catch (InvalidKeyException e) {
            throw new IllegalArgumentException("Not using a valid AES key", e);
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("Unexpected exception during decryption", e);
        }
    }

    /**
     * Creates a new key using password and salt.
     *
     * @param password
     *            the password
     * @param salt
     *            the salt
     * @return the secret key
     * @throws java.security.NoSuchAlgorithmException
     *
     * @throws java.security.spec.InvalidKeySpecException
     *
     */
    private SecretKeySpec getSymKey(String password, byte[] salt) throws NoSuchAlgorithmException, InvalidKeySpecException {
        SecretKeyFactory factory = SecretKeyFactory.getInstance(KEY_FACTORY_ALGORITHM);
        KeySpec spec = new PBEKeySpec(password.toCharArray(), salt, ITERATIONS, KEYLEN_BITS);
        SecretKey tmp = factory.generateSecret(spec);
        return new SecretKeySpec(tmp.getEncoded(), KEY_ALGORITHM);
    }

    /**
     * Gets the IV (initialization vector) parameter from the concatenated
     * IV+encrypted message.
     *
     * @param ivAndEncryptedMessage
     *            the combined IV and encrypted message
     * @param blockSize
     *            the blocksize for the cipher
     * @return the IV parameter
     */
    private IvParameterSpec getIvParameterFromMessage(final byte[] ivAndEncryptedMessage, int blockSize) {
        final byte[] ivData = new byte[blockSize];
        System.arraycopy(ivAndEncryptedMessage, 0, ivData, 0, blockSize);
        return new IvParameterSpec(ivData);
    }
}
