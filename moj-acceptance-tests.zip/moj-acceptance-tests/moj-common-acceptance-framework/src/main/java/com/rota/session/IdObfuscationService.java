package com.rota.session;

/**
 * IdObfuscationService - obfuscation of ID's through encryption
 */
public interface IdObfuscationService {

    String obfuscate(String sessionId, String value) throws ServiceException;

    String deobfuscate(String sessionId, String value) throws ServiceException;

    void setPassword(String password) throws ServiceException;

    void setEnabled(boolean enabled) throws ServiceException;
}
