package com.moj.common.webdriver;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.NotImplementedException;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.openqa.selenium.Capabilities;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxBinary;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxProfile;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriverService;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.moj.test.utils.ReadConfigFile;

public class MOJDriverProvider extends EventFiringWebDriver{
	private static Logger logger = Logger.getLogger(MOJDriverProvider.class);	
	 public enum BrowserDriver {
	        FIREFOX,
	        CHROME,
	        SAFARI,
	        IE,
	        IPAD_6,
	        IPAD_7,
	        SAMSUNG_GALAXY_NOTE,
	        GOOGLE_NEXUS,
	        IPHONE_5,
	        IPHONE_4S,
	        SAMSUNG_S3,
	        PHANTOM,
	        BROWSER_DEVICE_NAME,
	    }
	
	protected static WebDriver driver=null;
	public static WebDriverWait driverWait= null;
	private static DesiredCapabilities capabilities;
	//private static final Thread CLOSE_THREAD = new Thread(() -> driver.quit());	 
	private static final Dimension BROWSER_WINDOW_SIZE = new Dimension(1280, 1024);
	private static String hostName=null;
    private static String port=null;
    private static String platform=null;
    public static String URL = null;
    
    private static final Thread CLOSE_THREAD = new Thread() {
        @Override
        public void run() {
        	driver.quit();
        	logger.info("Driver quitted");
        }
    };
    
	public MOJDriverProvider() {
		super(driver);
	}
	
	static {
		String browser_name = System.getProperty("browser_name");
		logger.info("Browser to run scripts: "+browser_name);
		hostName = System.getProperty("hostName");
		//hostName ="192.168.3.90";
		logger.info("Grid node ip address: "+hostName);
		port = System.getProperty("port");
		//port="5566";
		logger.info("Grid node port: "+port);
		platform = System.getProperty("platform");
		//platform="WIN8";
		logger.info("Platform to run scripts: "+platform);
		URL="http://" + hostName + ":" + port + "/wd/hub";
		
		if (browser_name != null) {
			driver = (RemoteWebDriver) getDriver(BrowserDriver.valueOf(browser_name));
		} else {
			driver = (RemoteWebDriver) getDriver(BrowserDriver.FIREFOX);
		}
		Runtime.getRuntime().addShutdownHook(CLOSE_THREAD);
		
	}
	    		  
	  public static WebDriver getDriver(BrowserDriver browserDriver){
		capabilities = new DesiredCapabilities();
		if (driver == null || driver.toString().contains("(null)")) {
			ReadConfigFile conf = null;
			try {
				conf = new ReadConfigFile();			
			 switch (browserDriver) {
	            case FIREFOX:
	            	driver = (RemoteWebDriver) getFirefoxDriver();
	                break;
	            case CHROME:
	            	driver = (RemoteWebDriver) getChromeDriver();
	            	 break;
	            case IE:
	            	driver = (RemoteWebDriver) getIEDriver();
	            	 break;
	            case SAFARI:
				     driver =(RemoteWebDriver) getSafariDriver();
				     break;
	           
	            case IPAD_7:
	                capabilities.setCapability("browserName", "iPad");
	                capabilities.setCapability("platform", "MAC");
	                capabilities.setCapability("device", "iPad 3rd (7.0)");
	                capabilities.setCapability("browserstack.debug", "true");
	                driver = new RemoteWebDriver(new java.net.URL(URL),capabilities);
	                break;
	            case IPAD_6:
	                capabilities.setCapability("browserName", "iPad");
	                capabilities.setCapability("platform", "MAC");
	                capabilities.setCapability("device", "iPad 3rd (6.0)");
	                capabilities.setCapability("browserstack.debug", "true");
	                driver = new RemoteWebDriver(new java.net.URL(URL),capabilities);
	                break;
	            case SAMSUNG_GALAXY_NOTE:
	                capabilities.setCapability("browserName", "android");
	                capabilities.setCapability("platform", "ANDROID");
	                capabilities.setCapability("device", "Samsung Galaxy Note 10.1");
	                capabilities.setCapability("browserstack.debug", "true");
	                driver = new RemoteWebDriver(new java.net.URL(URL),capabilities);
	                break;
	            case GOOGLE_NEXUS:
	                capabilities.setCapability("browserName", "android");
	                capabilities.setCapability("platform", "ANDROID");
	                capabilities.setCapability("device", "Google Nexus 7");
	                capabilities.setCapability("browserstack.debug", "true");
	                driver = new RemoteWebDriver(new java.net.URL(URL),capabilities);
	                break;
	            case IPHONE_5:
	                capabilities.setCapability("browserName", "iPhone");
	                capabilities.setPlatform(Platform.MAC);
	                capabilities.setCapability("device", "iPhone 5");
	                capabilities.setCapability("browserstack.debug", "true");
	                driver = new RemoteWebDriver(new java.net.URL(URL),capabilities);
	                break;
	            case IPHONE_4S:
	                capabilities.setCapability("browserName", "iPhone");
	                capabilities.setCapability("platform", "MAC");
	                capabilities.setCapability("device", "iPhone 4S (6.0)");
	                capabilities.setCapability("browserstack.debug", "true");
	                driver = new RemoteWebDriver(new java.net.URL(URL),capabilities);
	                break;
	            case SAMSUNG_S3:
	                capabilities.setCapability("browserName", "android");
	                capabilities.setCapability("platform", "ANDROID");
	                capabilities.setCapability("device", "Samsung Galaxy S III");
	                capabilities.setCapability("browserstack.debug", "true");
	                driver = new RemoteWebDriver(new java.net.URL(URL),capabilities);
	                break;
	            case PHANTOM:
	            	 driver=(RemoteWebDriver) getPhantomDriver();
				     break;

	            default:
	                throw new NotImplementedException("Unknown Driver:" + browserDriver);
			}
			} catch (IOException e) {
				e.printStackTrace();
			}
			int driverTimeWait = StringUtils.isEmpty(conf.getDriverWait()) ? 10 : Integer.parseInt(conf.getDriverWait());
			driverWait =  new WebDriverWait(driver, driverTimeWait);
			
		}
		
		//Maximise the window
		customiseDriver();
		return driver;

	}
	
	private static WebDriver getChromeDriver() {
		ClassLoader classLoader = MOJDriverProvider.class.getClassLoader();
		File file = new File(classLoader.getResource("drivers/chromedriver.exe").getFile());
		System.setProperty("webdriver.chrome.driver",file.getAbsolutePath());
		ChromeOptions options = new ChromeOptions();
		DesiredCapabilities capabilities =  DesiredCapabilities.chrome();
		capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		if (hostName == null) {
		driver = new ChromeDriver(capabilities);
		} else {
			try {
				capabilities.setBrowserName("chrome");
				capabilities.setPlatform(Platform.valueOf(platform));
				driver = new RemoteWebDriver(new java.net.URL(URL),capabilities);
			} catch (MalformedURLException e) {
				logger.error(URL + " Error " + e.getMessage());
			}
		}
		return driver;
	}
	
	private static WebDriver getFirefoxDriver() {
		DesiredCapabilities capabilities = DesiredCapabilities.firefox();
		if (hostName == null) {
			FirefoxProfile profile = new FirefoxProfile();
			profile.setPreference("browser.usedOnWindows10", false);
			profile.setPreference("browser.usedOnWindows10.introURL", "about:blank");
			driver = new FirefoxDriver(profile);
		} else {
			try {
				
				//FirefoxBinary binary = new FirefoxBinary(new File("/usr/bin/firefox"));
				FirefoxProfile profile = new FirefoxProfile();
				capabilities.setBrowserName("firefox");
				capabilities.setPlatform(Platform.valueOf(platform));
				capabilities.setCapability(FirefoxDriver.PROFILE, profile);
				//capabilities.setCapability(FirefoxDriver.BINARY, binary);
				driver = new RemoteWebDriver(new java.net.URL(URL), capabilities);
			} catch (MalformedURLException e) {
				logger.error(URL + " Error " + e.getMessage());
			}
		}
		return driver;
	}
	
	public static WebDriver getIEDriver() {
		ClassLoader classLoader = MOJDriverProvider.class.getClassLoader();
		File file = new File(classLoader.getResource("drivers/IEDriverServer.exe").getFile());
		DesiredCapabilities ieCapabilities =DesiredCapabilities.internetExplorer(); 
		capabilities.setBrowserName("internet explorer");
		capabilities.setPlatform(Platform.WIN8);
		ieCapabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		System.setProperty("webdriver.ie.driver", file.getAbsolutePath());
		if (hostName == null) {
		driver = new InternetExplorerDriver(ieCapabilities);
		} else {
			try {
				driver = new RemoteWebDriver(new java.net.URL(URL),ieCapabilities);
			} catch (MalformedURLException e) {
				logger.error(URL + " Error " + e.getMessage());
			}	
		}
		return driver;
	}
	
	private static WebDriver getSafariDriver(){
		capabilities.setCapability("browser", "Safari");
		capabilities.setCapability("browser_version", "6.1");
		capabilities.setCapability("os", "OS X");
		capabilities.setCapability("os_version", "Mountain Lion");
		capabilities.setCapability("resolution", "1024x768");
		capabilities.setCapability("browserstack.debug", "true");
		try {
			driver = new RemoteWebDriver(new java.net.URL(URL),capabilities);
		} catch (MalformedURLException e) {
			logger.error(URL + " Error " + e.getMessage());
		}
		return driver;
	}
	
	private static WebDriver getPhantomDriver(){
		ClassLoader classLoader = MOJDriverProvider.class.getClassLoader();
		File file = new File(classLoader.getResource("drivers/phantomjs.exe").getFile());
		DesiredCapabilities capabilities =  DesiredCapabilities.phantomjs();
		capabilities.setJavascriptEnabled(true);
    	capabilities.setCapability("takesScreenshot", true);
    	capabilities.setCapability(PhantomJSDriverService.PHANTOMJS_EXECUTABLE_PATH_PROPERTY,file.getAbsolutePath());
    	if (hostName == null) {
	    driver =new PhantomJSDriver(capabilities);
    	}else {
    		try {
    			driver = new RemoteWebDriver(new java.net.URL(URL),capabilities);
    		} catch (MalformedURLException e) {
    			logger.error(URL + " Error " + e.getMessage());
    		}
    	}
		return driver;
	}
	
	private static void customiseDriver() {
		driver.manage().window().setSize(BROWSER_WINDOW_SIZE);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	public static WebDriver getWebDriver(){			
		return driver;
		  
	}
		
	public static String getBrowserName()
    {
        Capabilities cp = ((RemoteWebDriver)driver).getCapabilities();
        String browserName = cp.getBrowserName().toLowerCase();
        return browserName;
    }
		
	@Override
    public void close() {
        if (Thread.currentThread() != CLOSE_THREAD) {
            throw new UnsupportedOperationException("You shouldn't close this WebDriver. It's shared and will close when the JVM exits.");
        }
        super.close();
    }
	
}
