package com.moj.test.utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class ReadConfigFile {

	protected static Properties properties = null;
	protected InputStream fis = null;
	private String environment =null;

	public ReadConfigFile() throws IOException {
		environment=System.getProperty("env");
		if(environment==null)
		{
			environment="test";	
		}
		
		switch(environment)
		{
		case "sit":
			fis=ReadConfigFile.class.getClassLoader().getResourceAsStream("sit_config.properties");
			break;
		case "ci":
			fis=ReadConfigFile.class.getClassLoader().getResourceAsStream("ci_config.properties");
			break;
		case "nft":
			fis=ReadConfigFile.class.getClassLoader().getResourceAsStream("nft_config.properties");
			break;
		case "sandbox":
			fis=ReadConfigFile.class.getClassLoader().getResourceAsStream("sandbox_config.properties");
			break;
		default:
			fis=ReadConfigFile.class.getClassLoader().getResourceAsStream("config.properties");
			break;
		}
		
		properties = new Properties();
		properties.load(fis);

	}

	public static String getUrl() {

		return properties.getProperty("url");

	}

	public  String getDriverWait() {
		return properties.getProperty("driver_wait");
	}

	public  String getMaxWindow() {
		return properties.getProperty("maximize_browser");
	}
	
	public  String getBrowser(){
		
		return properties.getProperty("browser_name");
	}

	public  String getChromeDriver() {
		return properties.getProperty("chrome_server_location_ubuntu");
	}
	
	public  String getIEDriver() {
		return properties.getProperty("ie_server_location");
	}

	public static String IDPurl() {
		return properties.getProperty("IDPurl");
		
	}
	
	//Email properties
	
	public String getHost(){
		return properties.getProperty("host");
	}
	
	public String getMailStoreType(){
		return properties.getProperty("mailStoreType");
	}
	
	public String getUsername(){
		return properties.getProperty("username");
	}
	
	public String getPassword(){
		return properties.getProperty("password");
	}
	
	public String getPropertyValue(String key) {

		return properties.getProperty(key);

	}

}
