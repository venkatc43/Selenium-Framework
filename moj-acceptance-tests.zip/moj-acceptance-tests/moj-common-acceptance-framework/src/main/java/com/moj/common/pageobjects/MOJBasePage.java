package com.moj.common.pageobjects;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.AjaxElementLocatorFactory;

import com.github.javafaker.Faker;
import com.moj.common.webdriver.WebDriverUtils;

public class MOJBasePage extends WebDriverUtils {

	protected WebDriver driver;
	public Faker faker = new Faker(java.util.Locale.UK);
	public static String requirementsVal = null;

	String[] titles = { "Mr", "Mrs", "Miss", "Ms", "Dr", "Reverend", "Sir", "Dame", "Lord", "Lady", "Professor",
			"Captain", "Admiral", "General", "Major", "Colonel" };

	public final String TITLE = (titles[new Random().nextInt(titles.length)]);
	public final String FIRST_NAME = faker.name().firstName();
	public final String LAST_NAME = faker.name().lastName();
	public final String DOB = randomDOB();
	public final String ADDRESS_LINE_1 = faker.address().streetAddressNumber();
	public final String ADDRESS_LINE_2 = faker.address().streetName();
	public final String POSTCODE = validPostCode();

	public final String EMAIL = faker.internet().emailAddress();
	public final String INVALID_EMAIL = "test@test.com";
	public final String APP_DATE = new SimpleDateFormat("dd/MM/yyyy").format(new Date());
	public static final Logger logger = Logger.getLogger(MOJBasePage.class);
	
	@FindBy(tagName = "iframe")
	public WebElement switchFrame;

	public MOJBasePage(WebDriver driver) {
		super(driver);
		this.driver = driver;
		PageFactory.initElements(new AjaxElementLocatorFactory(driver, 20), this);

	}

	public <T> T getPage(Class<T> classs) {
		return PageFactory.initElements(driver, classs);
	}

	public static String validPostCode() {

		Faker faker = new Faker();
		String postCode = "";
		boolean success = false;

		while (!success) {
			postCode = faker.letterify("??") + faker.numerify("#") + " " + faker.numerify("#") + faker.letterify("??");

			String regexp = "^([A-PR-UWYZ](([0-9](([0-9]|[A-HJKSTUW])?)?)|([A-HK-Y][0-9]([0-9]|[ABEHMNPRVWXY])?)) [0-9][ABD-HJLNP-UW-Z]{2})|GIR 0AA$";
			Pattern pattern = Pattern.compile(regexp);

			Matcher matcher = pattern.matcher(postCode.toUpperCase());

			if (matcher.matches()) {
				success = true;

			}

		}
		return postCode;
	}

	public static String randomDOB() {

		int yyyy = random(1950, 1995);
		int mm = random(1, 12);
		int dd = random(1, 28);

		String year = Integer.toString(yyyy);
		String month = Integer.toString(mm);
		String day = Integer.toString(dd);

		if (mm < 10) {
			month = "0" + mm;
		}

		if (dd < 10) {
			day = "0" + dd;
		}

		return day + '/' + month + '/' + year;
	}

	public static int random(int lowerBound, int upperBound) {
		return (lowerBound + (int) Math.round(Math.random() * (upperBound - lowerBound)));
	}

	public void closeDriver() {
		driver.close();
	}

	public static String getDate(int month) {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.MONTH, month);

		String modifiedDate = new SimpleDateFormat("dd/MM/yyyy").format(calendar.getTime());
		return modifiedDate;
	}

}
