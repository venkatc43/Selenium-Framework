package com.moj.common.webdriver;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebDriverUtils {

	private WebDriver webDriver;
	private static final Integer WAIT_TIMEOUT = 60;
	private Logger logger = Logger.getLogger(getClass());
	private ArrayList<String> tabs=null;
	public static String parentHandle=null;

	public WebDriverUtils(WebDriver webDriver) {
		this.webDriver = webDriver;
	}

	public WebDriver getDriver() {
		return webDriver;
	}

	public void mouseHover(final WebElement webElement) {
		Actions builder = new Actions(webDriver);
		builder.moveToElement(webElement).build().perform();

	}
	
	
	public WebElement isElementVisible(WebElement element) {
		return element.isDisplayed() ? element : null;
	}

	public WebElement getElement(final By selector) {
		WebElement webElement = (new WebDriverWait(getDriver(), WAIT_TIMEOUT))
				.until(ExpectedConditions.visibilityOfElementLocated(selector));
		return webElement;

	}

	public List<WebElement> getElements(final By selector) {
		return (new WebDriverWait(getDriver(), WAIT_TIMEOUT))
				.until(ExpectedConditions.presenceOfAllElementsLocatedBy(selector));

	}

	public boolean isWebElementDisplayed(final WebElement element) {
		return getElement(element).isDisplayed();
	}

	public boolean waitForWebElementNotDisplayed(final By selector) {
		return (new WebDriverWait(getDriver(), WAIT_TIMEOUT))
				.until(ExpectedConditions.invisibilityOfElementLocated(selector));

	}

	public static WebElement findElement(WebElement parentSelector, By childSelector) {
		try {
			return parentSelector.findElement(childSelector);
		} catch (NoSuchElementException e) {
			return null;
		} catch (WebDriverException e) {
			System.out.println("WebDriverException thrown by findElement(%s)");
			return null;
		}
	}

	public void click(WebElement webElemnt) {

		if (MOJDriverProvider.getBrowserName().equals("chrome")) {
			try {
				JavascriptExecutor js = (JavascriptExecutor) webDriver;
				js.executeScript("window.scrollTo(0," + webElemnt.getLocation().x + ")");
			} catch (Exception e) {

			}
		}
		WebElement element = getElement(webElemnt);
		waitForElementTobeClickable(element);
		element.click();
	}

	public void clearField(WebElement element) {
		getElement(element).clear();
	}

	public Boolean getStatusOfCheckBox(WebElement element) {
		return element.isSelected();
	}

	public Boolean getStatusOfElement(WebElement element) {
		return getElement(element).isEnabled();
	}

	public String getTextFromWebElement(WebElement element) {
		return getElement(element).getText();
	}

	public String getSelectedDropDownOption(WebElement element) {
		return new Select(getElement(element)).getFirstSelectedOption().getText();
	}

	public void enterText(WebElement element, String charSequence) {
		clearField(element);
		getElement(element).sendKeys(charSequence);
	}

	public void enterTextWithClick(WebElement element, String charSequence) {
		getElement(element).sendKeys(charSequence);
	}

	public <T> T returnPageFactory(Class<T> pageClassToProxy) {
		return PageFactory.initElements(webDriver, pageClassToProxy);
	}

	public void pressTab() {
		Actions builder = new Actions(webDriver);
		builder.sendKeys(Keys.TAB).build().perform();
		builder.sendKeys(Keys.RETURN).build().perform();
	}
	
	public void pressEnter() {
		Actions builder = new Actions(webDriver);
		builder.sendKeys(Keys.ENTER);
		builder.build().perform();
		builder.release();
	}

	public void waitForPageToLoad() {
		new WebDriverWait(webDriver, WAIT_TIMEOUT).until(new ExpectedCondition<Boolean>() {
			public Boolean apply(WebDriver driver) {
				return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
			}
		});
	}

	public void implicitWait(long timeout) {
		webDriver.manage().timeouts().implicitlyWait(timeout, TimeUnit.SECONDS);
	}

	public boolean isElementDisplayed(WebElement element) {
		try {
			return getElement(element).isDisplayed();

		} catch (final NoSuchElementException e) {
			return false;
		}
	}

	public boolean isElementNotDisplayed(WebElement element) {
		try {
			return element.isDisplayed();

		} catch (final NoSuchElementException e) {
			return false;
		}
	}

	public void waitForVisibilityOfElement(WebElement element) {
		int attempts = 0;
		while (attempts < 3) {
			try {
				new WebDriverWait(getDriver(), WAIT_TIMEOUT).until(ExpectedConditions.visibilityOf(element));
			} catch (Exception e) {
			}
			attempts++;
		}
	}

	public void waitForVisibilityOfAllElement(List<WebElement> element) {
		int attempts = 0;
		while (attempts < 3) {
			try {
				new WebDriverWait(getDriver(), WAIT_TIMEOUT).until(ExpectedConditions.visibilityOfAllElements(element));
			} catch (Exception e) {
			}
			attempts++;
		}
	}

	public WebElement getElement(WebElement element) {
		int attempts = 0;
		while (attempts < 3) {
			try {
				element = MOJDriverProvider.driverWait.until(ExpectedConditions.visibilityOf(element));
				break;
			} catch (Exception e) {
				logger.error("Element not found", e);
				element = null;
			}
			attempts++;
		}

		return element;
	}

	public void selectDropDown(WebElement element, String title) {
		new Select(getElement(element)).selectByVisibleText(title);
	}

	public void switchToNewWindow() {
		for (String winHandle : webDriver.getWindowHandles()) {
			webDriver.switchTo().window(winHandle);
		}
	}
	
	public void switchToIFrame(WebElement element) {
		webDriver.switchTo().frame(element);
	}

	public String getActualColorFromRGB(String rgbCode) {
		String[] hexValue = rgbCode.replace("rgba(", "").replace(")", "").split(",");

		int hexValue1 = Integer.parseInt(hexValue[0]);
		hexValue[1] = hexValue[1].trim();
		int hexValue2 = Integer.parseInt(hexValue[1]);
		hexValue[2] = hexValue[2].trim();
		int hexValue3 = Integer.parseInt(hexValue[2]);
		hexValue[3] = hexValue[3].trim();

		String actualColor = String.format("#%02x%02x%02x", hexValue1, hexValue2, hexValue3, hexValue3);
		return actualColor;
	}

	public String getReadOnlyTextData(WebElement element) {
		return element.getAttribute("value");
	}

	public void waitForElementTobeClickable(WebElement element) {
		//new WebDriverWait(webDriver, WAIT_TIMEOUT).until(ExpectedConditions.elementToBeClickable(element));
        int attempts = 0;
        while(attempts < 3) {
            try {
            	new WebDriverWait(webDriver, WAIT_TIMEOUT).until(ExpectedConditions.elementToBeClickable(element));
                break;
            } catch(Exception e) {
            	logger.info("Exception occured :");
            }
            attempts++;
        }
		
	}

	public void waitForPage() {
		//webDriver.manage().timeouts().pageLoadTimeout(3, TimeUnit.SECONDS);
		try {
			Thread.sleep(3000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	public void dragBrowserUP()
	{
	JavascriptExecutor jse = (JavascriptExecutor)webDriver;
	jse.executeScript("window.scrollBy(0,-500)", "");
	}
	
	public void rightClick(WebElement element) {
		try {
			Actions action = new Actions(webDriver).contextClick(element);
			action.build().perform();

			logger.info("Sucessfully Right clicked on the element");
		} catch (StaleElementReferenceException e) {
			logger.info("Element is not attached to the page document "
					+ e.getStackTrace());
		} catch (NoSuchElementException e) {
			logger.info("Element " + element + " was not found in DOM "
					+ e.getStackTrace());
		} catch (Exception e) {
			logger.info("Element " + element + " was not clickable "
					+ e.getStackTrace());
		}
	}
			
}
