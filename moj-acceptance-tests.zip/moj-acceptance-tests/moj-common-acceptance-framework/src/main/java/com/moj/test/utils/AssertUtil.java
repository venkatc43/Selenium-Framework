package com.moj.test.utils;


import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;

public class AssertUtil {
	
	public void isEquals(Object expectd,Object actual)
	{
		assertEquals(actual +": is not same as expected :"+expectd,expectd,actual);
	}
	
	public void isTrue(String messageKey,boolean actual)
	{
		assertTrue(messageKey +" :"+actual +": Expected data not displayed :", actual);
	}
	
	public void isTrue(boolean actual)
	{
		assertTrue(actual +": Expected data not displayed :", actual);
	}
	
	public void isFalse(boolean actual)
	{
		assertFalse(actual +": Expected data displayed :", actual);
	}
	
	public void isFalse(String messageKey,boolean actual)
	{
		assertFalse(messageKey +" :"+actual +": Expected data not displayed :", actual);
	}
	
	
}
