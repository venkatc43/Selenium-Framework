package com.moj.test.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Properties;
 
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;
public class CTestDriver
{
  private static void doSshTunnel( String strSshUser, String strSshPassword, String strSshHost, int nSshPort, String strRemoteHost, int nLocalPort, int nRemotePort ) throws JSchException
  {
    final JSch jsch = new JSch();
    Session session = jsch.getSession( strSshUser, strSshHost, 22 );
    session.setPassword( strSshPassword );
     
    final Properties config = new Properties();
    config.put( "StrictHostKeyChecking", "no" );
    session.setConfig( config );
     
    session.connect();
    session.setPortForwardingL(nLocalPort, strRemoteHost, nRemotePort);
  }
   
  public static void main(String[] args)
  {
    try
    {
      String strSshUser = "venkatac.dv2";                  // SSH loging username
      String strSshPassword = "JanuarY2016";                   // SSH login password
      String strSshHost = "10.224.16.2";                   // hostname or ip or SSH server
      int nSshPort = 22;                                    // remote SSH host port number
      String strRemoteHost = "10.124.28.11";  // hostname or ip of your database server
      int nLocalPort = 5400;                                // local port number use to bind SSH tunnel
      int nRemotePort = 5432;                               // remote port number of your database 
      String strDbUser = "moj_user";                    // database loging username
      String strDbPassword = "moj_user";                    // database login password
       
      CTestDriver.doSshTunnel(strSshUser, strSshPassword, strSshHost, nSshPort, strRemoteHost, nLocalPort, nRemotePort);
       
      Class.forName("org.postgresql.Driver");
      Connection con = DriverManager.getConnection("jdbc:postgresql://localhost:"+nLocalPort+"/mojdb", strDbUser, strDbPassword);
      
      Statement stmt = con.createStatement();
      String sql = "select * from user_group where ug_name like '%rota.admin@email.com8%'";
      ResultSet resultSet = stmt.executeQuery(sql);

      while(resultSet.next()){
         //Retrieve by column name
    	  String password1  = String.valueOf(resultSet.getString("ug_password"));
    	  System.out.println("getting password :"+password1);
      }
      resultSet.close();
      
      
      
      
      con.close();
    }
    catch( Exception e )
    {
      e.printStackTrace();
    }
    finally
    {
      System.exit(0);
    }
  }

}
