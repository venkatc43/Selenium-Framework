/*package com.moj.test.utils;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.jcraft.jsch.JSch;
import com.jcraft.jsch.Session;
 
 
public class SSHJDBCExample {
 
    *//**
     * Java Program to connect to remote database through SSH using port forwarding
     * @author Pankaj@JournalDev
     * @throws SQLException 
     *//*
    public static void main(String[] args) throws SQLException {
 
        int lport=0;
        String rhost="10.124.28.11";
        String host="10.224.16.2";
        int rport=5400;
        String user="venkatac.dv2";
        String password="venkatac.dv2";
        String dbuserName = "moj_user";
        String dbpassword = "moj_user";
        String url = "jdbc:postgresql://127.0.0.1:"+rport+"/mojdb";
        String driverName="org.postgresql.Driver";
        Connection conn = null;
        Session session= null;
        try{
            //Set StrictHostKeyChecking property to no to avoid UnknownHostKey issue
            java.util.Properties config = new java.util.Properties(); 
            config.put("StrictHostKeyChecking", "no");
            JSch jsch = new JSch();
            session=jsch.getSession(user, host, 22);
            session.setPassword("JanuarY2016");
            session.setConfig(config);
            session.connect();
            System.out.println("Connected");
            //int assinged_port=session.setPortForwardingL(lport, rhost, rport);
            //System.out.println("localhost:"+assinged_port+" -> "+rhost+":"+rport);
            //System.out.println("Port Forwarded");
             
            //mysql database connectivity
            Class.forName(driverName).newInstance();
            conn = DriverManager.getConnection (url, dbuserName, dbpassword);
            
             Statement stmt = conn.createStatement();
		      String sql = "select * from user_group where ug_name like '%rota.admin@email.com8%'";
		      ResultSet resultSet = stmt.executeQuery(sql);

		      while(resultSet.next()){
		         //Retrieve by column name
		    	  String password1  = String.valueOf(resultSet.getString("ug_password"));
		    	  System.out.println("getting password :"+password1);
		      }
		      resultSet.close();
            
            
            System.out.println ("Database connection established");
            System.out.println("DONE");
            System.out.println ("Database connection established");
            System.out.println("DONE");
        }catch(Exception e){
            e.printStackTrace();
        }finally{
            if(conn != null && !conn.isClosed()){
                System.out.println("Closing Database Connection");
                conn.close();
            }
            if(session !=null && session.isConnected()){
                System.out.println("Closing SSH Connection");
                session.disconnect();
            }
        }
    }
 
}*/