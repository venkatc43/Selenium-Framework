/**
 * 
 */
package com.moj.test.utils;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

/**
 * @author Venkat
 *
 */
public class DatabaseUtil {
	private static Logger logger = Logger.getLogger(DatabaseUtil.class);
	private static Connection connection = null;
	public static Connection getConnection() throws Exception {
		ReadConfigFile config =new ReadConfigFile();
		String url = config.getPropertyValue("db_host");
		String dbName = config.getPropertyValue("db_name");
		String driver = config.getPropertyValue("db_driver_url");
		String userName = config.getPropertyValue("db_username");
		String password = config.getPropertyValue("db_password");
				
		try {

			if(connection==null)
			{
			Class.forName(driver);
			logger.info("PostgreSQL JDBC Driver Registered!");
			logger.info("UserName :"+userName);
			logger.info("Password :"+password);
			logger.info("DB Host :"+url);
			
			connection = DriverManager.getConnection(url+dbName,userName,password);
			logger.info("Data base connection established");
			}

		} catch (ClassNotFoundException e) {

			logger.info("Where is your PostgreSQL JDBC Driver? " + "Include in your library path!");
			e.printStackTrace();

		} catch (SQLException e) {

			logger.info("Connection Failed! Check output console");
			e.printStackTrace();

		}

		return connection;
	}
		
	public static Integer getMagistrateID(Connection conn,String firstName,String lastName) {
		Statement stmt = null;
		int magistrate_id=0;
		   try{
		      stmt = conn.createStatement();
		      String firstNameVal ="%"+firstName+"%";
		      String lastNameVal ="%"+lastName+"%";
		      String sql = "select * from magistrate where mag_surname like" +" '" + lastNameVal +"'" + " and mag_forenames like" +" '"+ firstNameVal+"'";
		      ResultSet resultSet = stmt.executeQuery(sql);

		      while(resultSet.next()){
		         //Retrieve by column name
		         magistrate_id  = resultSet.getInt("mag_magistrates_id");
		      }
		      resultSet.close();
		   }catch(SQLException se){
		      //Handle errors for JDBC
		      se.printStackTrace();
		   }catch(Exception e){
		      //Handle errors for Class.forName
		      e.printStackTrace();
		   }finally{
		      //finally block used to close resources
		      try{
		         if(stmt!=null)
		        	 stmt.close();
		      }catch(SQLException se){
		      }// do nothing
		   }//end try
		   
		   return magistrate_id;

	}
	
	public static Integer getAddressMagistrateID(Connection conn,int magistrateID) {
		Statement stmt = null;
		int add_magistrate_id=0;
		   try{
		      stmt = conn.createStatement();
		      String sql = "select mag_addr_address_id from magistrate where mag_magistrates_id="+magistrateID+"";

		      ResultSet resultSet = stmt.executeQuery(sql);

		      while(resultSet.next()){
		         //Retrieve by column name
		    	  add_magistrate_id  = resultSet.getInt("mag_addr_address_id");
		      }
		      resultSet.close();
		   }catch(SQLException se){
		      //Handle errors for JDBC
		      se.printStackTrace();
		   }catch(Exception e){
		      //Handle errors for Class.forName
		      e.printStackTrace();
		   }finally{
		      //finally block used to close resources
		      try{
		         if(stmt!=null)
		        	 stmt.close();
		      }catch(SQLException se){
		      }// do nothing
		     
		   }//end try
		   
		   return add_magistrate_id;

	}
	
	public static List<Integer> getMagistrateChangeID(Connection conn,int magistrateID) {
		Statement stmt = null;
		List<Integer> add_magistrate_id= new ArrayList<Integer>();
		   try{
		      stmt = conn.createStatement();
		      String sql = "select mcm_id from magistrate_change_message where mcm_magistrate_id="+magistrateID+"";

		      ResultSet resultSet = stmt.executeQuery(sql);

		      while(resultSet.next()){
		         //Retrieve by column name
		    	  add_magistrate_id.add(resultSet.getInt("mcm_id"));
		      }
		      resultSet.close();
		   }catch(SQLException se){
		      //Handle errors for JDBC
		      se.printStackTrace();
		   }catch(Exception e){
		      //Handle errors for Class.forName
		      e.printStackTrace();
		   }finally{
		      //finally block used to close resources
		      try{
		         if(stmt!=null)
		        	 stmt.close();
		      }catch(SQLException se){
		      }// do nothing
		     
		   }//end try
		   
		   return add_magistrate_id;

	}
	
	public static Integer getUserGroupID(Connection conn,int magistrateID) {
		Statement stmt = null;
		int user_groupID= 0;
		   try{
		      stmt = conn.createStatement();
		      String sql = "select * from user_group where ug_member_id="+magistrateID+"";

		      ResultSet resultSet = stmt.executeQuery(sql);

		      while(resultSet.next()){
		         //Retrieve by column name
		    	  user_groupID=resultSet.getInt("ug_id");
		      }
		      resultSet.close();
		   }catch(SQLException se){
		      //Handle errors for JDBC
		      se.printStackTrace();
		   }catch(Exception e){
		      //Handle errors for Class.forName
		      e.printStackTrace();
		   }finally{
		      //finally block used to close resources
		      try{
		         if(stmt!=null)
		        	 stmt.close();
		      }catch(SQLException se){
		      }// do nothing
		     
		   }//end try
		   
		   return user_groupID;

	}
	
	public static boolean deleteMagistrate(Connection connection,int magistrateID)
	{
		Statement stmt = null;
		boolean isDeleteMagistrate=false;
		   try{
		      stmt = connection.createStatement();
		    
		      String adhoc_location_sql ="delete from magistrate_adhoc_location where mal_magistrates_id="+magistrateID+"";
		      stmt.executeUpdate(adhoc_location_sql);
		      		      
		      String magistrate_lja_assignment_sql ="delete from magistrate_lja_assignment where mla_magistrate_id="+magistrateID+"";
		      stmt.executeUpdate(magistrate_lja_assignment_sql);
		      
		      String panel_participant_sql ="delete from panel_participant where ppa_magistrate_id="+magistrateID+"";
		      stmt.executeUpdate(panel_participant_sql);
		      
		      String magistrate_non_availability_sql ="delete from magistrate_non_availability where ma_magistrate_id="+magistrateID+"";
		      stmt.executeUpdate(magistrate_non_availability_sql);
		      
		      //int address_id=getAddressMagistrateID(connection, magistrateID);
		      
		      //String address_sql ="delete from address where addr_address_id="+address_id+"";
		     // stmt.executeUpdate(address_sql);
		      
		      String contact_number_sql ="delete from contact_number where con_magistrate_id="+magistrateID+"";
		      stmt.executeUpdate(contact_number_sql);
		      
		      String lja_change_message_sql ="delete from lja_change_message where lcm_magistrate_id="+magistrateID+"";
		      stmt.executeUpdate(lja_change_message_sql);
		      
		      String magistrate_notification_sql ="delete from magistrate_notification where mn_magistrate_id="+magistrateID+"";
		      stmt.executeUpdate(magistrate_notification_sql);
		      
		      String magistrate_status_sql ="delete from magistrate_status where ms_magistrate_id="+magistrateID+"";
		      stmt.executeUpdate(magistrate_status_sql);
		      
		      String sitting_pattern_sql ="delete from sitting_pattern where sp_magistrate_id="+magistrateID+"";
		      stmt.executeUpdate(sitting_pattern_sql);
		      
		      List<Integer> listOfChnageIDS=getMagistrateChangeID(connection, magistrateID);
		      
		      for(int changeID:listOfChnageIDS)
		      {
		    	  String change_message ="delete from combined_panel_to_magistrate_change_message where cpmcm_mcm_id="+changeID+"";
			      stmt.executeUpdate(change_message);  
		      }
		      
		      String mag_change_message ="delete from magistrate_change_message where mcm_magistrate_id="+magistrateID+"";
		      stmt.executeUpdate(mag_change_message);
		      
		      String mag_lja_location ="delete from magistrate_lja_location where mll_magistrates_id="+magistrateID+"";
		      stmt.executeUpdate(mag_lja_location);
		      
		      int uger_groupID=getUserGroupID(connection, magistrateID);
		      if(uger_groupID>0)
		      {
		      String user_group_to_user_role_group ="delete from user_group_to_user_role where ugur_ug_id="+uger_groupID+"";
		      stmt.executeUpdate(user_group_to_user_role_group);
		      }
		      		      
		      String user_group_to_user_role ="delete from user_group_to_user_role where ugur_ug_id="+magistrateID+"";
		      stmt.executeUpdate(user_group_to_user_role);
		      
		      String user_group ="delete from user_group where ug_member_id="+magistrateID+"";
		      stmt.executeUpdate(user_group);
		      
		      String magistrate_sql ="delete from magistrate where mag_magistrates_id="+magistrateID+"";
		      stmt.executeUpdate(magistrate_sql);
		      
		      isDeleteMagistrate=true;
		     
	      ;
		   }catch(SQLException se){
		      //Handle errors for JDBC
		      se.printStackTrace();
		   }catch(Exception e){
		      //Handle errors for Class.forName
		      e.printStackTrace();
		   }finally{
		      //finally block used to close resources
		      try{
		         if(stmt!=null)
		        	 stmt.close();
		      }catch(SQLException se){
		      }// do nothing
		     
		   }//end try
		   
		   return isDeleteMagistrate;
	}
	
	public static Integer getDistrictJudgeID(Connection conn,String firstName,String lastName) {
		Statement stmt = null;
		int districtJudgeID=0;
		   try{
		      stmt = conn.createStatement();
		      String firstNameVal ="%"+firstName+"%";
		      String lastNameVal ="%"+lastName+"%";
		      String sql = "select * from district_judge where dis_surname like" +" '" + lastNameVal +"'" + " and dis_forenames like" +" '"+ firstNameVal+"'";
		      ResultSet resultSet = stmt.executeQuery(sql);

		      while(resultSet.next()){
		         //Retrieve by column name
		    	  districtJudgeID  = resultSet.getInt("dis_id");
		      }
		      resultSet.close();
		   }catch(SQLException se){
		      //Handle errors for JDBC
		      se.printStackTrace();
		   }catch(Exception e){
		      //Handle errors for Class.forName
		      e.printStackTrace();
		   }finally{
		      //finally block used to close resources
		      try{
		         if(stmt!=null)
		        	 stmt.close();
		      }catch(SQLException se){
		      }// do nothing
		   }//end try
		   
		   return districtJudgeID;

	}
	
	public static boolean deleteDistrictJudge(Connection connection,int distractJudgeID)
	{
		Statement stmt = null;
		boolean isDeleteMagistrate=false;
		   try{
		      stmt = connection.createStatement();
		    
		      String authority_sql ="delete from district_judge_authority where dj_district_judge_id="+distractJudgeID+"";
		      stmt.executeUpdate(authority_sql);
		      		      
		      String inactivity_sql ="delete from district_judge_inactivity where dj_ina_district_judge_id="+distractJudgeID+"";
		      stmt.executeUpdate(inactivity_sql);
		      
		      String nonAvailability ="delete from district_judge_non_availability where dj_district_judge_id="+distractJudgeID+"";
		      stmt.executeUpdate(nonAvailability);
		      
		      List<Integer> session_ids=getDJSessionID(connection, distractJudgeID);
		      for(int session_id:session_ids)
		      {
		      String session_sql ="delete from dj_sitting_pattern_to_session where dsps_djtl_id="+session_id+"";
		      stmt.executeUpdate(session_sql);
		      }
		      
		      String location_sql ="delete from district_judge_to_location where djtl_dis_id="+distractJudgeID+"";
		      stmt.executeUpdate(location_sql);
		      
		      String court_seesion ="delete from rota_court_session where rcs_dj_dis_id="+distractJudgeID+"";
		      stmt.executeUpdate(court_seesion);
		      
		      String dj_sql ="delete from district_judge where dis_id="+distractJudgeID+"";
		      stmt.executeUpdate(dj_sql);
		      		      
		      isDeleteMagistrate=true;
		     
	      ;
		   }catch(SQLException se){
		      //Handle errors for JDBC
		      se.printStackTrace();
		   }catch(Exception e){
		      //Handle errors for Class.forName
		      e.printStackTrace();
		   }finally{
		      //finally block used to close resources
		      try{
		         if(stmt!=null)
		        	 stmt.close();
		      }catch(SQLException se){
		      }// do nothing
		     
		   }//end try
		   
		   return isDeleteMagistrate;
	}
	
	public static List<Integer> getDJSessionID(Connection conn,int djID) {
		Statement stmt = null;
		List<Integer> session_id=new ArrayList<Integer>();
		   try{
		      stmt = conn.createStatement();
		      String sql = "select djtl_id from district_judge_to_location where djtl_dis_id="+djID+"";

		      ResultSet resultSet = stmt.executeQuery(sql);

		      while(resultSet.next()){
		         //Retrieve by column name
		    	  session_id.add(resultSet.getInt("djtl_id"));
		      }
		      resultSet.close();
		   }catch(SQLException se){
		      //Handle errors for JDBC
		      se.printStackTrace();
		   }catch(Exception e){
		      //Handle errors for Class.forName
		      e.printStackTrace();
		   }finally{
		      //finally block used to close resources
		      try{
		         if(stmt!=null)
		        	 stmt.close();
		      }catch(SQLException se){
		      }// do nothing
		     
		   }//end try
		   
		   return session_id;

	}
	
	public static String getRotaAdminIDID(Connection conn,String emailAddress) {
		Statement stmt = null;
		String rotamAdminID=null;
		   try{
		      stmt = conn.createStatement();
		      String emailAddressVal ="%"+emailAddress+"%";
		      String sql = "select rota_admin_id from rota_administrator where rota_admin_email_address like" +" '" + emailAddressVal +"'";
		      ResultSet resultSet = stmt.executeQuery(sql);

		      while(resultSet.next()){
		         //Retrieve by column name
		    	  rotamAdminID  = String.valueOf(resultSet.getInt("rota_admin_id"));
		      }
		      resultSet.close();
		   }catch(SQLException se){
		      //Handle errors for JDBC
		      se.printStackTrace();
		   }catch(Exception e){
		      //Handle errors for Class.forName
		      e.printStackTrace();
		   }finally{
		      //finally block used to close resources
		      try{
		         if(stmt!=null)
		        	 stmt.close();
		      }catch(SQLException se){
		      }// do nothing
		   }//end try
		   
		   return rotamAdminID;

	}
	
	public static Integer getMagistrateIDForSession(Connection conn) {
		Statement stmt = null;
		int magistrate_id=0;
		   try{
		      stmt = conn.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_READ_ONLY);
		      String sql = "select * from magistrate";
		      ResultSet resultSet = stmt.executeQuery(sql);
		      resultSet.afterLast();
		      while (resultSet.previous()){
		         //Retrieve by column name
		         magistrate_id  = resultSet.getInt("mag_magistrates_id");
		      }
		      resultSet.close();
		   }catch(SQLException se){
		      //Handle errors for JDBC
		      se.printStackTrace();
		   }catch(Exception e){
		      //Handle errors for Class.forName
		      e.printStackTrace();
		   }finally{
		      //finally block used to close resources
		      try{
		         if(stmt!=null)
		        	 stmt.close();
		         	// conn.close();
		      }catch(SQLException se){
		      }// do nothing
		   }//end try
		   
		   return magistrate_id;

	}
	
	 public static Session doSshTunnel() throws JSchException, IOException
	  {
		 		 
		 ReadConfigFile config =new ReadConfigFile();
		 String strSshUser = config.getPropertyValue("ssh_user");                  // SSH loging username
		 String strSshPassword = config.getPropertyValue("ssh_password");          // SSH login password
		 String strSshHost = config.getPropertyValue("ssh_host");                   // hostname or ip or SSH server
		 int nSshPort = Integer.parseInt(config.getPropertyValue("ssh_port"));       // remote SSH host port number
		 String strRemoteHost = config.getPropertyValue("remote_database_host");     // hostname or ip of your database server
		 int nLocalPort = Integer.parseInt(config.getPropertyValue("ssh_local_port"));   // local port number use to bind SSH tunnel
		 int nRemotePort = Integer.parseInt(config.getPropertyValue("database_remote_port")); 
		
	    final JSch jsch = new JSch();
	    Session session = jsch.getSession( strSshUser, strSshHost, nSshPort );
	    session.setPassword( strSshPassword );
	     
	    final Properties configProperites = new Properties();
	    configProperites.put( "StrictHostKeyChecking", "no" );
	    session.setConfig( configProperites );
	     
	    session.connect();
	    session.setPortForwardingL(nLocalPort, strRemoteHost, nRemotePort);
	    logger.info("SSH connection established");
	    return session;
	    
	  }
	
}
