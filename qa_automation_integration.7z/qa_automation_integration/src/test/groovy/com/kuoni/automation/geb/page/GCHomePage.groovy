package com.kuoni.automation.geb.page

import geb.Page

class GCHomePage  extends Page{
	static at = { title == "GTA Connect" }
	
	static content = {
		contentLink { $("#gcmain").find(href: endsWith("content.jpg"))}
	}
	
	def openPage(String pageName){
		$("a", text: pageName).click()

	}
}
