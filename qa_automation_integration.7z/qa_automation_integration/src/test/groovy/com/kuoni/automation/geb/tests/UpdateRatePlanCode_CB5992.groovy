package com.kuoni.automation.geb.tests

import org.testng.asserts.SoftAssert;
import static com.kuoni.qa.automation.util.GetCoherenceObject.*
import com.gta.nova.rateplan.model.RatePlan
import com.kuoni.qa.automation.common.properties.EnvironmentProperties;
import com.kuoni.qa.automation.common.util.ExcelUtil

import static com.kuoni.qa.automation.util.TestUtil.*
import spock.lang.Shared;
import spock.lang.Unroll;

class UpdateRatePlanCode_CB5992 extends GCContract{
	
	
	@Shared
	def file = "//src//test//groovy//com//kuoni//automation//geb//data//GC_TestData_For_Property_38.xlsx"
	SoftAssert softAssert = new SoftAssert()
	def static oldRPCode
	def newRPCode
	def static ratePlanId
	EnvironmentProperties envprop = new EnvironmentProperties()
	def sheetName = envprop.getValueForProperty("excelSheetName")
	
	@Unroll
	def "Verify RatePlanMarginType in DynAdmin"(){
		
	
	given: "The RatePlan Margin details are  updated in GC"
	
	def excelDataFilePath =System.getProperty("user.dir")+ "//src//test//groovy//com//kuoni//automation//geb//data//GC_TestData_For_Property_38.xlsx"
	
	ExcelUtil excelUtil = new ExcelUtil(excelDataFilePath)
	country = excelUtil.getCellAsString(sheetName, row, "country").toString().trim()
	roomId = excelUtil.getCellAsString(sheetName, row, "roomId").toString().trim()
	propertyName= excelUtil.getCellAsString(sheetName, row, "hotel").toString().trim()
	contractId =  excelUtil.getCellAsString(sheetName, row, "Contract").toString().trim()
	def propertyId = excelUtil.getCellAsString(sheetName, row, "propertyId")
	def ratePlanSku = excelUtil.getCellAsString(sheetName, row, "ratePlanSku")
	oldRPCode=	excelUtil.getCellAsString(sheetName, row, "oldRPCode").toString().trim()
	newRPCode = excelUtil.getCellAsString(sheetName, row, "newRPCode").toString().trim()
	ratePlanId=excelUtil.getCellAsString(sheetName, row, "ratePlanId").toString().trim()

	when: "Update Contract Margin in GC Connect"
		
	openRatePlanPage()
	
	editRateplanCode(contractId,ratePlanId,newRPCode)
	
	println "Old RP Code : " + oldRPCode
	sleep(1*90*1000)
	and:"Invoke Dataloader to push data"
	pushData()
	sleep(5000)
	
	def json = getJson("ratePlanSku" , "id CONTAINS \""+ratePlanSku+"\"")

	
	println json
	
	then: "verify RatePlan Code correctly updated in atg"
	
	println "\n ATG RatePlanCode Type  : " + json["code"]
	
	
	softAssert.assertTrue(json["code"] == newRPCode , "Rateplan Code not updated  in atg!! \n Expected: $newRPCode , actual: " +json["code"])
	softAssert.assertAll()
	where:
	row << getExcelRowList(file)
}
	
	def verifyCoherenceData() {
		given: "Data is pushed to Coherence"
		incrementalPushtoCoherence()
		println "\n Cohernece Validation \n"
		RatePlan ratePlan =	verifyCoherenceRateplans(contractId,ratePlanId)
//		softAssert.assertEquals(newRPCode, ratePlan.get, "Contract Margin not updated  in Coherence!! \n Expected: $newMargin , actual: " +propertyContract.getMargin())
		println "Coherence Doesn't need Rateplan Code hence not validating"
		softAssert.assertAll()
	}

def cleanupData(){
	given: "Data is pushed to Coherence"
	openRatePlanPage()
	editRateplanCode(contractId,ratePlanId,oldRPCode)
	sleep(1*90*1000)
	pushData()
	sleep(5000)
	incrementalPushtoCoherence()
	
}

}
