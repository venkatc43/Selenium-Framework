package com.kuoni.automation.geb.tests

import geb.spock.GebReportingSpec
import groovyx.net.http.*

import org.json.JSONObject
import org.testng.asserts.SoftAssert

import spock.lang.Shared

import com.kuoni.automation.geb.page.GCContentPage
import com.kuoni.automation.geb.page.GCHomePage
import com.kuoni.automation.geb.page.GCLoginPage
import com.kuoni.automation.geb.page.GCSearchPage
import com.kuoni.qa.automation.common.properties.EnvironmentProperties
import com.kuoni.qa.automation.util.PerformDataLoadUtil;

class GCContent extends GebReportingSpec{


	@Shared
	private static EnvironmentProperties envprops
	@Shared
	def SoftAssert softAssert
	def static country
	def city = null
	def static propertyName
	def static roomId
	def contractId = null
	def host
	def auth
	def existWebSite
	def existCategory
	def PerformDataLoadUtil dataload = new PerformDataLoadUtil()

	def getEnvProperties() {
		if (envprops == null)
			envprops = new EnvironmentProperties()
		return envprops
	}
	def updateFailityCodes(List facilityCodesMap){
		GCLoginPage.url = getEnvProperties().getValueForProperty("gc.web.url") + "auth/securelogin"
		browser.driver.manage().window().maximize()
		//println url
		to GCLoginPage
		//at GCLoginPage
		login("lcp39s" , "London1")

		at GCHomePage
		openPage("Content")
		at GCSearchPage
		searchForProperty(country,city,propertyName)
		OpenContentForfirstRow()
		at GCContentPage
		clickOnHeader("Room Types")
		editARoom(roomId)
		updateRoomFacilities(facilityCodesMap)
	}

	def updateRoomCount(String totalRooms){
		GCLoginPage.url = getEnvProperties().getValueForProperty("gc.web.url") + "auth/securelogin"
		browser.driver.manage().window().maximize()
		//println url
		to GCLoginPage
		//at GCLoginPage
		login("lcp39s" , "London1")

		at GCHomePage
		openPage("Content")
		at GCSearchPage
		searchForProperty(country,city,propertyName)
		OpenContentForfirstRow()
		at GCContentPage
		clickOnHeader("Facilities & Services")
		editTotalRooms(totalRooms)
	}

	def openContentPage(){

		GCLoginPage.url = getEnvProperties().getValueForProperty("gc.web.url")
		browser.driver.manage().window().maximize()
		//println url
		to GCLoginPage
		//at GCLoginPage
		login("gsuser1" , "London1")

		at GCHomePage
		openPage("Content")
		at GCSearchPage
		//searchForProperty(country,city)
		searchForProperty(country,propertyName)
		OpenContentForfirstRow()
	}
	
	
	def openCityPage()
	{
		GCLoginPage.url = getEnvProperties().getValueForProperty("gc.web.url")
		browser.driver.manage().window().maximize()
		//println url
		to GCLoginPage
		//at GCLoginPage
		login("gsuser1" , "London1")

		at GCHomePage
		openPage("Cities")
		
		at GCSearchPage
		searchForCity("Denmark","Aalborg")
				
	}
	
	def updateRoomSupplierCode(def sroomId,def newsRoomCode)
	{
		at GCContentPage
		clickOnHeader("Room Types")
		roomSelect(sroomId)
		modifyRoomSupplierCode(newsRoomCode)
	}
	
	
	def changeCityTimeZone(newTimeZone)
	{
		at GCContentPage
		modifyCitytimezone(newTimeZone)
	}
	
	def editRoomView(roomId,newRoomView)
	{
		at GCContentPage
		clickOnHeader("Room Types")
		roomSelect(roomId)
		modifyRoomView(newRoomView)
		
	}
	
	
	def updateRoomDetails(roomId,beds,maxOccupancy,rateBasis,extraBeds,cots)
	{
		at GCContentPage
		clickOnHeader("Room Types")
		roomSelect(roomId)
		modifyRoomDetails(beds,maxOccupancy,rateBasis,extraBeds,cots)
	}
	
	
	def updatePropertyLandmarks(LandDistance)
	{
		at GCContentPage
		clickOnHeader("Facilities & Services")
		editPropertyLandmarks(LandDistance)
	}
	
	
	def editRoomCategory(roomId,newRoomCategory)
	{
		at GCContentPage
		clickOnHeader("Room Types")
		sleep(2000)
		roomSelect(roomId)
		sleep(2000)
		updateRoomCategory(newRoomCategory)
		
	}
	
	def changePropertyType(String newPropType)
	{
		at GCContentPage
		clickOnHeader("Facilities & Services")
		sleep(2000)
		clickPropertyCategoryDetailsEdit()
		sleep(2000)
		updatePropertyType(newPropType)
	}
	
	def updatePropertyRestriction(def propRestrictionId,def pRestrictionType,def pRstartDate,def pRendDate)
	{
		at GCContentPage
		clickOnHeader("Renovations & Updates")
		editPropertyRestriction(propRestrictionId,pRestrictionType,pRstartDate,pRendDate)
	}

	
	
	def updatePropertyWebSite(String newWebsite){

		at GCContentPage
		//clickOnHeader("Property Details")
		clickPropertyHeaderDetailsEdit()
		existWebSite = getExistingPropertyWebsite()
		updateWebSite(newWebsite)

	}
	
	def updateLocation(String newLocationCode)
	{
		at GCContentPage
		clickOnHeader("Facilities & Services")
		clickLocationDetailsEdit()
		updateLocationCode(newLocationCode)
		
	}

	def updatePropertyCategory(String newCategory){
		at GCContentPage
		clickOnHeader("Facilities & Services")
		clickPropertyCategoryDetailsEdit()
		sleep(1000)
		existCategory=getExistingCategory()
		updateCategory(newCategory)
	}


	def pushData() {
		
		dataload.performDataLoadRequest()
	}
	
	def incrementalPushtoCoherence()
	{
		
		dataload.incrementalPushtoCoherence()
		
	}

	def pushToQueueRequest() {
		
		dataload.pushToQueueRequest()
	
	}

	
	def performDataLoadRequest() {
		
		dataload.performDataLoadRequest()
	}

	def getJson(String itemDesc, String rql) {
		
		host =getEnvProperties().getValueForProperty("esb.host.url")
		println host
		def http = new HTTPBuilder(host)
		def getdata = http.get(path: '/test/rs/repositoryData.jsp', requestContentType: ContentType.URLENC, query: [
			repository: "/atg/commerce/catalog/LPMProductCatalog",
			itemDesc:   itemDesc,
			rql:        rql,
			json:       "true"
		]).toString()
		//println getdata
		JSONObject data = new JSONObject(getdata)		
		//assert !data.getJSONArray("items").isEmpty()
		return data.getJSONArray("items").get(0)
	}
}
