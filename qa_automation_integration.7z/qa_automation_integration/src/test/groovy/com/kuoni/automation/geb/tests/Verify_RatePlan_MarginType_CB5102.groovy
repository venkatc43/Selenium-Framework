package com.kuoni.automation.geb.tests

import org.testng.asserts.SoftAssert;
import static com.kuoni.qa.automation.util.GetCoherenceObject.*
import com.gta.nova.rateplan.model.RatePlan
import com.kuoni.qa.automation.common.properties.EnvironmentProperties;
import com.kuoni.qa.automation.common.util.ExcelUtil

import static com.kuoni.qa.automation.util.TestUtil.*
import spock.lang.Shared;
import spock.lang.Unroll;
import static com.kuoni.qa.automation.util.GcTestsHelper_toget_Atg_Ids.*

class Verify_RatePlan_MarginType_CB5102 extends GCContract{
	
	@Shared
	def file = "//src//test//groovy//com//kuoni//automation//geb//data//GC_TestData_For_Property_38.xlsx"
	SoftAssert softAssert = new SoftAssert()
	def static oldRMarginType
	def static newRMarginType
	def static ratePlanId
	EnvironmentProperties envprop = new EnvironmentProperties()
	def sheetName = envprop.getValueForProperty("excelSheetName")
	
	@Unroll
	def "Verify RatePlanMarginType in DynAdmin"(){
		
	
	given: "The RatePlan Margin details are  updated in GC"
	
	def excelDataFilePath =System.getProperty("user.dir")+ file
	
	ExcelUtil excelUtil = new ExcelUtil(excelDataFilePath)
	country = excelUtil.getCellAsString(sheetName, row, "country").toString().trim()
	roomId = excelUtil.getCellAsString(sheetName, row, "roomId").toString().trim()
	propertyName= excelUtil.getCellAsString(sheetName, row, "hotel").toString().trim()
	contractId =  excelUtil.getCellAsString(sheetName, row, "Contract").toString().trim()
	def propertyId = excelUtil.getCellAsString(sheetName, row, "propertyId")
	def rateplanId = excelUtil.getCellAsString(sheetName, row, "ratePlanId")
	oldRMarginType=	excelUtil.getCellAsString(sheetName, row, "oldRMarginType")
	newRMarginType = excelUtil.getCellAsString(sheetName, row, "newRMarginType")
	ratePlanId=excelUtil.getCellAsString(sheetName, row, "ratePlanId").toString().trim()

	when: "Update Contract Margin in GC Connect"
		
	openRatePlanPage()
	
	editRateplanMarginType(contractId,ratePlanId,newRMarginType)
	
	println "Old MarginType : " + oldRMarginType
	sleep(1*90*1000)
	and:"Invoke Dataloader to push data"
	pushData()
	sleep(5000)
	
	def rpMarginId = 	getRpMarginId(rateplanId)
	
	def json = getJson("rpMargin" , "id CONTAINS \""+rpMarginId+"\"")

	
	println json
	
	then: "verify RatePlan Margin correctly updated in atg"
	
	println "\n ATG Margin Type  : " + json["marginType"]
	
	
	softAssert.assertTrue(json["marginType"] == newRMarginType.toString() , "Contract Status not updated  in atg!! \n Expected: $newRMarginType , actual: " +json["marginType"])
	softAssert.assertAll()
	where:
	row << getExcelRowList(file)
}

	def verifyCoherenceData() {
		given: "Data is pushed to Coherence"
		incrementalPushtoCoherence()
		println "\n Cohernece Validation \n"
		RatePlan ratePlan =	verifyCoherenceRateplans(contractId,ratePlanId)
		softAssert.assertEquals(newRMarginType.toString(), (ratePlan.getRateType().toString()).concat("t"), "RatePlan MarginType not updated  in Coherence!! \n Expected: $newRMarginType , actual: " +ratePlan.getRateType().toString())
		println "Coherence Rateplan MarginType " + ratePlan.getRateType().toString()
		softAssert.assertAll()
	}
	
	
def cleanupData(){
	given: "Data is pushed to Coherence"
	openRatePlanPage()
	editRateplanMarginType(contractId,ratePlanId,oldRMarginType)
	sleep(1*90*1000)
	pushData()
	sleep(5000)
	incrementalPushtoCoherence()
	
}

}
