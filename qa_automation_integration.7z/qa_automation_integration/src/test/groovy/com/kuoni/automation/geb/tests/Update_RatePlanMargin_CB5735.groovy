package com.kuoni.automation.geb.tests

import org.testng.asserts.SoftAssert;

import static com.kuoni.qa.automation.util.GcTestsHelper_toget_Atg_Ids.*
import spock.lang.Shared;
import spock.lang.Unroll;
import static com.kuoni.qa.automation.util.GetCoherenceObject.*
import com.gta.nova.rateplan.model.RatePlan
import com.gta.travel.page.object.contract.rateplans.RatePlanDetailsSectionPage
import com.kuoni.qa.automation.common.properties.EnvironmentProperties;
import com.kuoni.qa.automation.common.util.ExcelUtil

import static com.kuoni.qa.automation.util.TestUtil.*

class Update_RatePlanMargin_CB5735 extends GCContract{
	
	
	@Shared
	def file = "//src//test//groovy//com//kuoni//automation//geb//data//GC_TestData_For_Property_38.xlsx"
	SoftAssert softAssert = new SoftAssert()
	
	def static oldRMargin
	def static newRMargin
	def static ratePlanId
	EnvironmentProperties envprop = new EnvironmentProperties()
	def sheetName = envprop.getValueForProperty("excelSheetName")
	
	@Unroll
	def "Verify RatePlanMargin in DynAdmin"(){
		
	
	given: "The Contract Margin details are  updated in GC"
	
	def excelDataFilePath =System.getProperty("user.dir")+file
	
	ExcelUtil excelUtil = new ExcelUtil(excelDataFilePath)
	country = excelUtil.getCellAsString(sheetName, row, "country").toString().trim()
	propertyName= excelUtil.getCellAsString(sheetName, row, "hotel").toString().trim()
	contractId =  excelUtil.getCellAsString(sheetName, row, "Contract").toString().trim()
	def propertyId = excelUtil.getCellAsString(sheetName, row, "propertyId")
	def rateplanId = excelUtil.getCellAsString(sheetName, row, "ratePlanId")
	oldRMargin=	excelUtil.getCell(sheetName, row, "oldRMargin").getNumericCellValue().intValue()
	newRMargin = excelUtil.getCellAsString(sheetName, row, "newRMargin")
	ratePlanId=excelUtil.getCellAsString(sheetName, row, "ratePlanId").toString().trim()

	when: "Update RatePlan Margin in GC Connect"
		
	openRatePlanPage()
	
	editRateplanMargin(contractId,ratePlanId,newRMargin)
	
	println "Old Margin : " + oldRMargin
	sleep(1*90*1000)
	and:"Invoke Dataloader to push data"
	pushData()
	sleep(5000)
	
	def rpMarginId = 	getRpMarginId(rateplanId)
	
	def json = getJson("rpMargin" , "id CONTAINS \""+rpMarginId+"\"")

	
	println json
	
	then: "verify RatePlan Margin correctly updated in atg"
	
	println "\n ATG Margin  : " + json["percentage"]
	
	softAssert.assertEquals(json["percentage"],newRMargin.toString(), "Rateplan Margin not updated  in atg!! \n Expected: $newRMargin , actual: " + json["percentage"])
	softAssert.assertAll()
	where:
	row << getExcelRowList(file)
}
	
	def verifyCoherenceData() {
		given: "Data is pushed to Coherence"
		incrementalPushtoCoherence()
		println "\n Cohernece Validation \n"
		RatePlan ratePlan =	verifyCoherenceRateplans(contractId,ratePlanId)
		softAssert.assertEquals(newRMargin.toString(), ratePlan.getMargin().toString(), "RatePlan Margin not updated  in Coherence!! \n Expected: $newRMargin , actual: " +ratePlan.getMargin().toString())
		println "Coherence Rateplan Margin " + ratePlan.getMargin().toString()
		softAssert.assertAll()
	}

def cleanupData(){
	given: "Data is pushed to Coherence"
	openRatePlanPage()
	editRateplanMargin(contractId,ratePlanId,oldRMargin)
	sleep(1*90*1000)
	pushData()
	sleep(5000)
	incrementalPushtoCoherence()
	
}

}
