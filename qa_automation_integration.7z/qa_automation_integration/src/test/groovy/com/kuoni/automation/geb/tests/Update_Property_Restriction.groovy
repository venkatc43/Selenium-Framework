package com.kuoni.automation.geb.tests

import org.testng.asserts.SoftAssert;

import static com.kuoni.qa.automation.util.TestUtil.*

import com.kuoni.qa.automation.common.properties.EnvironmentProperties;
import com.kuoni.qa.automation.common.util.ExcelUtil

import spock.lang.Shared;
import spock.lang.Unroll;

class Update_Property_Restriction extends GCContent {
	
	@Shared
	def file = "//src//test//groovy//com//kuoni//automation//geb//data//GC_TestData_For_Property_38.xlsx"
	SoftAssert softAssert = new SoftAssert()
	
	def oldpRestrictionType = "Closed for arrival"
	def oldpRstartDate = 2015
	def oldpRendDate = 2015
	def propRestrictionId
	EnvironmentProperties envprop = new EnvironmentProperties()
	def sheetName = envprop.getValueForProperty("excelSheetName")
	
	
	
	
	@Unroll
	def "Verify Property Restriction Details "(){
		
		given: "the Room exists i in GC"
		
		def excelDataFilePath =System.getProperty("user.dir")+ "//src//test//groovy//com//kuoni//automation//geb//data//GC_TestData_For_Property_38.xlsx"
		
		ExcelUtil excelUtil = new ExcelUtil(excelDataFilePath)
		country = excelUtil.getCellAsString(sheetName, row, "country").toString().trim()
		city = excelUtil.getCellAsString(sheetName, row, "city").toString().trim()
		propertyName= excelUtil.getCellAsString(sheetName, row, "hotel").toString().trim()
		
		def propertyId = excelUtil.getCellAsString(sheetName, row, "propertyId")
		propRestrictionId = excelUtil.getCellAsString(sheetName, row, "propRestrictionId")
		def pRestrictionType = excelUtil.getCellAsString(sheetName, row, "pRestrictionType").toString().trim()
		def pRstartDate = excelUtil.getCell(sheetName, row, "pRstartDate").getNumericCellValue().intValue()
		def pRendDate = excelUtil.getCell(sheetName, row, "pRendDate").getNumericCellValue().intValue()
		

		
		when: "Update Property Restriction details in GC Connect"
			
		openContentPage()
		
		println "Existing Restriction Type : "	+ oldpRestrictionType
		println "Existing Restriction Start : "	+ oldpRstartDate
		println "Existing Restriction End : "	+ oldpRendDate
		
		
		updatePropertyRestriction(propRestrictionId,pRestrictionType,pRstartDate,pRendDate)
		
		sleep(1*90*1000)
		and:"Invoke Dataloader to push data"
		pushData()
		sleep(5000)
		
		def json = getJson("propertyRestriction" , "restrictionId CONTAINS \""+propRestrictionId+"\"")
		
			
		println json
		
		then: "verify Property Restriction Details  loaded in atg"
		
		println "\n ATG Restriction Type : " + json["restrictionType"]
		println "ATG Restriction Start : " + json["travelStart"]
		println "\n ATG Restriction End : " + json["travelEnd"]
		
		def atgResType  = "Closed for Business"
		
		softAssert.assertTrue(json["restrictionType"] == atgResType , "Restriction Type not updated correctly in atg!! \n Expected: $pRestrictionType , actual: " +json["restrictionType"])
		softAssert.assertTrue((json["travelStart"]).substring(0,4) == pRstartDate.toString(), "Restriction StartDate not updated correctly in ATG!!\n Expected: $pRstartDate, Actual: " + (json["travelStart"]).substring(0,3))
		softAssert.assertTrue((json["travelEnd"]).substring(0,4) == pRendDate.toString() , "Restriction EndDate not updated correctly in atg!! \n Expected: $pRendDate , actual: " +(json["travelEnd"]).substring(0,3))
		
		
		softAssert.assertAll()
		
		
		where:
		row << getExcelRowList(file)
	}
	
	def cleanup(){

		openContentPage()
		updatePropertyRestriction(propRestrictionId,oldpRestrictionType,oldpRstartDate,oldpRendDate)
		sleep(1*90*1000)
		pushData()
		sleep(5000)
	}


}
