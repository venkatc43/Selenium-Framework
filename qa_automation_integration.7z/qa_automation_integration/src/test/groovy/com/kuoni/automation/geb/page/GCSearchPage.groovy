package com.kuoni.automation.geb.page

import geb.Page
import org.openqa.selenium.Keys

class GCSearchPage extends Page{

	static at = { title == "GTA Connect" }
	
	static content = {
		countryText { $("#country-name") }
		cityText { $("#city-name") }
		PropertyNameText { $("#name") }
		searchButton { $("input" , name: "search") }
		firstRow { $("#row-0")}
		contentLink{ $("a" , text: "Content") }
		citySelect {$("a",text:"Sydney")}
		countrySelect{$("a",text:"Australia")}
		selectCountry{$("#countryId")}
		selectCity{$("#cityName")}
//		citysearchButton{$("#search")}
	}
	
	def searchForProperty(String country,String PropertyName){

		countryText = country
		
		countryText << Keys.chord(Keys.TAB)
		
		waitFor(5) {countrySelect.present}
//		sleep(2000)
//		cityText = city
		countrySelect.click()
		

		PropertyNameText.click()
//		sleep(3000)		
//		citySelect.click()
		
		PropertyNameText=PropertyName
		sleep(1000)
		searchButton.click()
		
	}
	
	def OpenContentForfirstRow(){
		waitFor(10){firstRow.present}
		firstRow.click()
		sleep(2000)
		contentLink.click()
	}
	
	
	def searchForCity(country,city)
	{
		selectCountry=country
		selectCity=city
		sleep(2000)
		searchButton.click()
	}
}
