

package com.kuoni.automation.geb.page


import org.openqa.selenium.JavascriptExecutor

import com.google.common.collect.ByFunctionOrdering;
import com.gta.travel.page.base.GSPageBase
import com.gta.travel.page.object.contract.rateplans.RatePlanDetailsSectionPage
import com.mediaocean.qa.framework.selenium.ui.controls.Link

import geb.Page

import org.openqa.selenium.By;
import org.openqa.selenium.Keys
import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions
import org.openqa.selenium.support.ui.WebDriverWait
import org.openqa.selenium.support.ui.ExpectedConditions

import geb.waiting.WaitingSupport


class GCContentPage extends Page{
	
	static at = { title == "GTA Connect" }
	RatePlanDetailsSectionPage ratePlanobj = new RatePlanDetailsSectionPage()
	static content = {
		roomContentMenu { $("#roomContentMenuOptions-root")}
		editOption {$("a", text: "Edit")}
		updateRoomsEditButton {$("input", name:"roomEdit")}
		failitiesSectionEditLink { $("#propertyFacilitiesShowSection a") }
		totalRoomsTextBox { $("#totalRooms") }
		facilitiesEditUpdatebutton { $("input" , name: "propertyFacilitiesEdit") }
		propertyHeaderDetailsEdit { $("#propertyHeaderContentMenuOptions a") }
		categoryDetailsEdit { $("#categoryDetailsContentMenuOptions a")}
		locationDetailEdit{$("#locationContentMenuOptions a")}
		categorySelect { $("#categoryDetails-category") }
		locationSelect {$("#code")}
		propertyTypeSelect {$("#categoryDetails-type")}
		locationUpdateButton {$("input",name:"locationEdit")}
		categoryDetailsUpdatebutton { $("input" , name: "categoryDetailsEdit") }
		propertyWebSiteEditbox { $("#propertyHeader-website") }
		propertyHeaderUpdatebutton { $("input" , name: "propertyHeaderEdit") }
		selectRoomId {$("#room_29293")}
		roomSelectEdit{$("a", text: "Edit")}
		roomCategory{$("#roomCategory")}
		selectContracts{$("#propertyContract_14708")}
		contractMargin{$("#margin")}
		contractUpdateButton{ $("input" , name: "propertyContractEdit") }
		contractRsp{$("#rspProvided")}
		ratePlanId{$("#ratePlan_19391")}
		rateplanMargin {$("#margin")}
		ratePlanCode {$("#code")}
		ratePlanUpdate{$("input",name:"ratePlanEdit")}
		ratePlanType{$("#rateType")}
//		roomUpdate{$("#roomEdit")}
		selectLandMark{$("#landmarkDistance_15256")}
		landMarkDesc{$("#Ilandmark-name")}
		landmarkDistance{$("#distance")}
		landMarkUpdateButton{$("#landmarkDistanceEdit")}
		landMarkMenu{$("#landmarkDistanceContentMenuOptions-root")}
		rbeds{$("#beds")}
		rmaxOccupancy{$("#maxOccupancy")}
		rratebasis{$("#rateBasis")}
		rextrabed{$("#extraBed")}
		rcots{$("#cots")}
		selectRestriction{$("#propertyRestriction_4449")}
		restrictionType{$("#restrictionType")}
		restrictionStartYear{$("#startDate_years")}
		restrictionEndYear{$("#endDate_years")}
		restrictionUpdateButton{$("#propertyRestrictionEdit")}
		restrictionMenu{$("#propertyRestrictionContentMenuOptions-root")}
		roomView{$("#roomView")}
		firstRow{$("#row0")}
		cityEditwindow{$("#lightContent")}
		cityTimeZoneEdit { $("#submitLightButtonsForm input.gsButton:nth-child(2)")}
		selectTimeZone{$("#timezone")}
		timeZonesaveButton{$("#textSave")}
		rommSuppCode{$("#code")}
		
	}
	
	
	def modifyRoomSupplierCode(newRoomCode)
	{
		waitFor(5){roomContentMenu.present}
		WebElement roomMenu = driver.findElement(By.id("roomContentMenuOptions-root"))
		selectOption("/html/body/div/div/div[7]/div[3]/table/tbody/tr[2]/td/div[1]/span[2]/ul/li/ul/li[3]/a",roomMenu)
		/*roomContentMenu.click()
		editOption.click()*/
		waitFor(5){rommSuppCode.present}
		rommSuppCode=newRoomCode
		updateRoomsEditButton.click()
	}
	
	
	def modifyCitytimezone(newTimeZone)
	{
//		waitFor(10){firtRow.present}
		firstRow.click()
		waitFor(5){cityTimeZoneEdit.present}
//		browser.switchToWindow(cityEditwindow)
		cityTimeZoneEdit.click()
		waitFor(5){selectTimeZone.present}
		selectTimeZone=newTimeZone
		timeZonesaveButton.click()
		
		
	}
	
	
	def updateRoomCategory(String newRoomCategory)
	{
		waitFor(5){roomContentMenu.present}
		WebElement roomMenu = driver.findElement(By.id("roomContentMenuOptions-root"))
		selectOption("/html/body/div/div/div[7]/div[3]/table/tbody/tr[2]/td/div[1]/span[2]/ul/li/ul/li[3]/a",roomMenu)
		sleep(2000)
		roomCategory=newRoomCategory
		updateRoomsEditButton.click()
		
	}
	
	
	def modifyRoomView(newRoomView)
	{
		waitFor(5){roomContentMenu.present}
		WebElement roomMenu = driver.findElement(By.id("roomContentMenuOptions-root"))
		selectOption("/html/body/div/div/div[7]/div[3]/table/tbody/tr[2]/td/div[1]/span[2]/ul/li/ul/li[3]/a",roomMenu)
		/*roomContentMenu.click()
		editOption.click()*/
		waitFor(5){roomView.present}
		roomView=newRoomView
		
		updateRoomsEditButton.click()
		
	}
	
	
	
	def editPropertyRestriction(propRestrictionId,pRestrictionType,pRstartDate,pRendDate)
	{
		def propRestriction = "#propertyRestriction_"+propRestrictionId
		waitFor(5){$(propRestriction).displayed}
		$(propRestriction).click()
		waitFor(5){restrictionMenu.present}
		WebElement restrictionMenu = driver.findElement(By.id("propertyRestrictionContentMenuOptions-root"))
		selectOption("/html/body/div/div/div[7]/div[3]/table/tbody/tr[3]/td/div[1]/span[2]/ul/li/ul/li[3]/a",restrictionMenu)
		waitFor(5){restrictionStartYear.present}
		restrictionType=pRestrictionType
		restrictionStartYear=pRstartDate
		restrictionEndYear=pRendDate
		restrictionUpdateButton.click()
		
		
	}
	
	
	def modifyRoomDetails(beds,maxOccupancy,rateBasis,extraBeds,cots)
	{
		waitFor(5){roomContentMenu.present}
		WebElement roomMenu = driver.findElement(By.id("roomContentMenuOptions-root"))
		selectOption("/html/body/div/div/div[7]/div[3]/table/tbody/tr[2]/td/div[1]/span[2]/ul/li/ul/li[3]/a",roomMenu)
		waitFor(5){rbeds.present}
		rbeds=beds
		rmaxOccupancy=maxOccupancy
		rratebasis=rateBasis
		rcots=cots
		rextrabed=extraBeds
		updateRoomsEditButton.click()
		
	}
	
	
	def editPropertyLandmarks(LandDistance)
	{
		selectLandMark.click()
		waitFor(4){landMarkMenu.present}
		WebElement landMarkMenu = driver.findElement(By.id("landmarkDistanceContentMenuOptions-root"))
		selectOption("/html/body/div/div[1]/div[7]/div[3]/table/tbody/tr[4]/td/div[1]/span[2]/ul/li/ul/li[3]/a",landMarkMenu)
		waitFor(5){landmarkDistance.present}
		landmarkDistance=LandDistance
		landMarkUpdateButton.click()
		
	}
	
	
	def selectOption(String option,WebElement element)
	{
		Actions action = new Actions(driver)
		def test = action.moveToElement(element).build()
		test.perform()
		def mouseover = action.clickAndHold(element)
		//mouseover.perform()
		WebElement menuOption = driver.findElement(By.xpath(option))
		menuOption.click()
		mouseover.release()
		mouseover.perform()
		
	}
	
	
	def editRplanCode(contractId,ratePlanId,newRPCode)
	{
		modifyRatePlan(contractId,ratePlanId)
		waitFor(6){ratePlanCode.present}
		ratePlanCode=newRPCode
		ratePlanUpdate.click()
	}
	
	
	def editRplanMarginType(contractId,ratePlanId,marginType)
	{
		modifyRatePlan(contractId,ratePlanId)
		waitFor(6){ratePlanType.present}
		ratePlanType=marginType
		ratePlanUpdate.click()
	}
	
	def editRPlanMargin(contractId,ratePlanId,newRMargin)
	{
		modifyRatePlan(contractId,ratePlanId)
		waitFor(6) {rateplanMargin.present}
		rateplanMargin = newRMargin
		ratePlanUpdate.click()
		
	}
	
	
	def editRPlanType(def rpType)
	{
		modifyRatePlan()
		ratePlanType=rpType
		ratePlanUpdate.click()
	}

	def editRPlanCode(def code)
	{
		modifyRatePlan()
		waitFor(5){ratePlanCode.present}
		ratePlanCode = code
		ratePlanUpdate.click()
	}
	
	
	
	
	def modifyRatePlan(contractId,ratePlanId)
	{
		selectContract(contractId)
		
		def ratePlan = "#ratePlan_"+ratePlanId
		waitFor(5){$(ratePlan).displayed}
		$(ratePlan).click()
		sleep(2000)
		WebElement rateplanMenu = driver.findElement(By.id("ratePlanContentMenuOptions-root"))
		selectOption("/html/body/div/div/div[7]/div[3]/table/tbody/tr/td/div[2]/div/table/tbody/tr[7]/td/div/div[2]/table/tbody/tr/td/div[1]/span[2]/ul/li/ul/li[3]/a",rateplanMenu)
		
	}
	
	
	def selectOption(WebElement element, String option)
	{	
		Actions action = new Actions(driver)
		def mouseover = action.clickAndHold(element)
		//mouseover.perform()
		WebElement menuOption = driver.findElement(By.linkText(option))
		menuOption.click()
		mouseover.release()
		mouseover.perform()
	}
	

	
	def selectContract(contractId)
	{
		contractId = "#propertyContract_"+contractId
		//waitFor(10){$(contractId).present}
		waitFor(10){$(contractId).displayed}
		$(contractId).click()
	}
	
	def editRsp(def contractId,def rsp)
	{
		selectContract(contractId)
		sleep(3000)
		WebElement contractMenu = driver.findElement(By.id("propertyContractContentMenuOptions-root"))
		selectOption("/html/body/div/div/div[7]/div[3]/table/tbody/tr/td/div[1]/span[2]/ul/li/ul/li[3]/a",contractMenu)
		waitFor{contractRsp.present}
		contractRsp = rsp
		contractUpdateButton.click()
	}
	
	def changeContractStatus(def contractId,def status)
	{
		selectContract(contractId)
		sleep(3000)
		WebElement contractMenu = driver.findElement(By.id("propertyContractContentMenuOptions"))
		selectOption("/html/body/div/div/div[7]/div[3]/table/tbody/tr/td/div[1]/span[2]/ul/li/ul/li[5]/a",contractMenu)
		
		
		
		
	}
	
	def changeContracttoHold(def contractId,def status)
	{
		selectContract(contractId)
		sleep(3000)
		WebElement contractMenu = driver.findElement(By.id("propertyContractContentMenuOptions"))
		selectOption("/html/body/div/div/div[7]/div[3]/table/tbody/tr/td/div[1]/span[2]/ul/li/ul/li[4]/a",contractMenu)
			
	}
	
	
	def editMargin(def newMargin)
	{
	
		WebElement contractMenu = driver.findElement(By.id("propertyContractContentMenuOptions"))
		selectOption("/html/body/div/div/div[7]/div[3]/table/tbody/tr/td/div[1]/span[2]/ul/li/ul/li[3]/a",contractMenu)
		waitFor(5){contractMargin.present}
		contractMargin=newMargin
		contractUpdateButton.click()
				
	}
	
	def clickOnHeader(String headerName){
		$("a" , text: headerName).click()
	}
	
	
	def roomSelect(roomId)
	{
		
		def selectRoom = "#room_"+roomId
		
		waitFor(5){$(selectRoom).displayed}
		$(selectRoom).click()
	}
	
	
	
	
	def updatePropertyType(String propType)
	{
		waitFor(5){propertyTypeSelect.present}
		propertyTypeSelect=propType
		categoryDetailsUpdatebutton.click()
		
	}
	
	def editARoom(String roomId){
		roomId = "#room_"+roomId
		$(roomId).click()
		sleep(1000)
		roomContentMenu.click()
		sleep(1000)
		editOption.click()
		roomContentMenu.click()
	}
	def updateRoomFacilities(List facilities){
		for (int i=0 ; i<facilities.size(); i++ ){
			//$("input" , text: facilities.get(i) ).click()
			//keyDown(Keys.ESCAPE)
			println facilities[i]
			$("#"+facilities[i]).click()
		}
		sleep(1000)
		updateRoomsEditButton.click()
		sleep(2000)
	}
	
	def editTotalRooms(String roomcount){
		failitiesSectionEditLink.click()
		totalRoomsTextBox = roomcount
		facilitiesEditUpdatebutton.click()
	}
	
	def updateWebSite(String newWebsite){
		waitFor(5){propertyWebSiteEditbox.present}
		propertyWebSiteEditbox=newWebsite
		propertyHeaderUpdatebutton.click()
		sleep(1000)		
	}
	
	def updateLocationCode(String location)
	{
		waitFor(5){locationSelect.present}
		locationSelect =location
		locationUpdateButton.click()
	}
	
	def clickPropertyHeaderDetailsEdit(){
		waitFor(5){propertyHeaderDetailsEdit.present}
		propertyHeaderDetailsEdit.click()
		sleep(2000)
	}
	
	def clickLocationDetailsEdit(){
		waitFor(5){locationDetailEdit.present}
		locationDetailEdit.click()
	}
	
	def getExistingPropertyWebsite(){		
		return propertyWebSiteEditbox.value()
	}
	def clickPropertyCategoryDetailsEdit(){
		categoryDetailsEdit.click()
	}
	
	def updateCategory(String category){
		
		categorySelect = category
		categoryDetailsUpdatebutton.click()
		sleep(1000)
	}
	
	def getExistingCategory(){
		sleep(2000)
		return $("#categoryDetails-category option" , selected: "selected").text()
	}
	
	
	
}
