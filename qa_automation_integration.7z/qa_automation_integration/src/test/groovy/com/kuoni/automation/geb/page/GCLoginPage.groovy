package com.kuoni.automation.geb.page

import geb.Page

class GCLoginPage extends Page{

	//static at = { waitFor(5) { title.endsWith("securelogin")
	//	} }
	def DEFALUT_WEBID = "GTA"
	static content = {
		webIDTextBox { $("#qualifier") }
		userNameTextBox { $("#username") }
		passwordTextBox { $("#password") }
		loginButton(to: GCHomePage) { $("#login") }
	}

	def login(def userName, def password) {
		webIDTextBox = DEFALUT_WEBID
		userNameTextBox = userName
		passwordTextBox = password
		loginButton.click()
	}

	def login(def webId, def userName, def password) {
		webIDTextBox = webId
		userNameTextBox = userName
		passwordTextBox = password
		loginButton.click()
	}
}


