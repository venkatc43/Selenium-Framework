package com.kuoni.automation.geb.tests

import org.testng.asserts.SoftAssert;
import static com.kuoni.qa.automation.util.TestUtil.*
import spock.lang.Shared;
import spock.lang.Unroll;
import static com.kuoni.qa.automation.util.GetCoherenceObject.*
import com.gta.nova.coherence.property.model.Room
import com.kuoni.qa.automation.common.properties.EnvironmentProperties;
import com.kuoni.qa.automation.common.util.ExcelUtil

class Verify_RoomSupplier_Code_CB11160 extends GCContent {

		
		@Shared
		def file = "//src//test//groovy//com//kuoni//automation//geb//data//GC_TestData_For_Property_38.xlsx"
		SoftAssert softAssert = new SoftAssert()
		
		def static oldRoomCode
		def static newRoomCode
		def static propertyId
		
		EnvironmentProperties envprop = new EnvironmentProperties()
		def sheetName = envprop.getValueForProperty("excelSheetName")
		
		
		
		@Unroll
		def "Verify Property Room Details "(){
			
			given: "the Room exists i in GC"
			
			def excelDataFilePath =System.getProperty("user.dir")+file
			
			ExcelUtil excelUtil = new ExcelUtil(excelDataFilePath)
			country = excelUtil.getCellAsString(sheetName, row, "country").toString().trim()
			city = excelUtil.getCellAsString(sheetName, row, "city").toString().trim()
			propertyName= excelUtil.getCellAsString(sheetName, row, "hotel").toString().trim()
			roomId = excelUtil.getCellAsString(sheetName, row, "roomId").toString().trim()
			propertyId = excelUtil.getCellAsString(sheetName, row, "propertyId")
			oldRoomCode= excelUtil.getCellAsString(sheetName, row, "oldRoomCode").toString().trim()
			newRoomCode = excelUtil.getCellAsString(sheetName, row, "newRoomCode").toString().trim()
			
	
			
			when: "Update Room details in GC Connect"
				
			openContentPage()
			
			println "Existing Room Code : "	+ oldRoomCode
						
			updateRoomSupplierCode(roomId,newRoomCode)
			
			sleep(1*90*1000)
			and:"Invoke Dataloader to push data"
			pushData()
			sleep(5000)
			
	//		def roomSkuID = getRoomSkuId(roomId)
			def json = getJson("roomSku" , "roomId CONTAINS \""+roomId+"\"")
			
			
			println json
			
			then: "verify Room Details  loaded in atg"
			
			println "\n ATG Room SupplierCode : " + json["supplierRoomCode"]

			softAssert.assertTrue(json["supplierRoomCode"] == newRoomCode , "SupplierRoomCode not updated correctly in atg!! \n Expected: $newRoomCode , actual: " +json["supplierRoomCode"])
			
			softAssert.assertAll()
			
			
			where:
			row << getExcelRowList(file)
		}
		
		def verifyCoherenceData() {
			given: "Data is pushed to Coherence"
			incrementalPushtoCoherence()
			println "\n Cohernece Validation \n"
			Room room =	getCohPropertyRoomDetails(propertyId.toString(),roomId.toInteger())
			
			softAssert.assertEquals(newRoomCode, room.getSupplierRoomCode(), "Room SupplierCode updated  in Coherence!! \n Expected: $newRoomCode , actual: " +room.getSupplierRoomCode())
			println "Coherence Room SupplierCode " + room.getSupplierRoomCode()
			
					
			softAssert.assertAll()
		}
		
		def cleanupData(){
			given: "Data is pushed to Coherence"
			openContentPage()
			updateRoomSupplierCode(roomId,oldRoomCode)
			sleep(1*90*1000)
			pushData()
			sleep(5000)
			incrementalPushtoCoherence()
			
		}
	
	
	}

