package com.kuoni.automation.geb.tests

import org.testng.asserts.SoftAssert;

import static com.kuoni.qa.automation.util.TestUtil.*
import spock.lang.Shared;
import spock.lang.Unroll;

import com.kuoni.qa.automation.common.properties.EnvironmentProperties;
import com.kuoni.qa.automation.common.util.ExcelUtil

class Update_Location_Descriptions_CB6586 extends GCContent {
	
	@Shared
	def file = "//src//test//groovy//com//kuoni//automation//geb//data//GC_TestData_For_Property_38.xlsx"
	SoftAssert softAssert = new SoftAssert()
	def oldLocation
	def newLocation
	EnvironmentProperties envprop = new EnvironmentProperties()
	def sheetName = envprop.getValueForProperty("excelSheetName")
	
	@Unroll
	def "Verify Property location details "(){
		
		
		given: "the property details to update in GC"
		
		def excelDataFilePath =System.getProperty("user.dir")+file
		
		ExcelUtil excelUtil = new ExcelUtil(excelDataFilePath)
		country = excelUtil.getCellAsString(sheetName, row, "country").toString().trim()
		city = excelUtil.getCellAsString(sheetName, row, "city").toString().trim()
		propertyName= excelUtil.getCellAsString(sheetName, row, "hotel").toString().trim()
		
		def propertyId = excelUtil.getCellAsString(sheetName, row, "propertyId")
		
		newLocation = excelUtil.getCellAsString(sheetName, row, "NewLocation").toString().trim()
		
		oldLocation = excelUtil.getCellAsString(sheetName, row, "oldLocation").toString().trim()
		

		when: "Update Category and Website in GC Connect"
			
		openContentPage()
		
		updateLocation(newLocation)
		
		println "GC Existing Location :"	+ oldLocation + ": G2"
		println "GC New Location :"	+ newLocation + ": G1"
		sleep(1*90*1000)
		and:"Invoke Dataloader to push data"
		pushData()
		sleep(5000)
		
		def json = getJson("product" , "externalReferenceId EQUALS \""+propertyId+"\"")
		
		
		println json
		
		then: "verify Location Details correctly loaded in atg"
		
		println "\n ATG Location  : " + json["locationCode"]
		println "G1 is Central \n"
		
		softAssert.assertTrue(json["locationCode"] == "G1" , "Location not updated correctly in atg!! \n Expected: $newLocation , actual: " +json["locationCode"])
		
		softAssert.assertAll()
		where:
		row << getExcelRowList(file)
	}
	
	def cleanup(){
		openContentPage()
		updateLocation(oldLocation)
		sleep(1*90*1000)
		pushData()
		sleep(5000)
		
	}


}
