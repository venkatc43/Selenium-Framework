package com.kuoni.automation.geb.tests

import static com.kuoni.qa.automation.util.TestUtil.*

import org.testng.asserts.SoftAssert

import spock.lang.Shared
import spock.lang.Unroll

import com.kuoni.qa.automation.common.properties.EnvironmentProperties
import com.kuoni.qa.automation.common.util.ExcelUtil
import com.kuoni.spock.annotation.RegressionTestGC

class PropertyType_CB5902 extends GCContent{
	
	@Shared
	def file = "//src//test//groovy//com//kuoni//automation//geb//data//GC_TestData_For_Property_38.xlsx"
	SoftAssert softAssert = new SoftAssert()
	def oldPropertyType
	EnvironmentProperties envprop = new EnvironmentProperties()
	def sheetName = envprop.getValueForProperty("excelSheetName")
	
	@Unroll
	@RegressionTestGC
	def "Verify Property Type details "(){
		
		
		given: "the property details to update in GC"
		
		def excelDataFilePath =System.getProperty("user.dir")+ file
		
		ExcelUtil excelUtil = new ExcelUtil(excelDataFilePath)
		country = excelUtil.getCellAsString(sheetName, row, "country").toString().trim()
//		city = excelUtil.getCellAsString("integration", row, "city").toString().trim()
		propertyName= excelUtil.getCellAsString(sheetName, row, "hotel").toString().trim()
		
		def propertyId = excelUtil.getCellAsString(sheetName, row, "propertyId")
		
		def newPropertyType = "Apartment"
		
		oldPropertyType= "Hotel"
		

		when: "Update Category and Website in GC Connect"
			
		openContentPage()
		
		changePropertyType(newPropertyType)
		
		println "Existing PropertyType :"	+ oldPropertyType 
		sleep(1*90*1000)
		and:"Invoke Dataloader to push data"
		pushData()
		sleep(5000)
		
		def json = getJson("product" , "externalReferenceId EQUALS \""+ propertyId +"\"")
		
		
		println json
		
		then: "verify Location Details correctly loaded in atg"
		
		println "\n ATG PropertyType  : " + json["propertyType"]
		
		
		softAssert.assertEquals(json["propertyType"],"A" , "PropertyType updated correctly in atg!! \n Expected: A , actual: " +json["propertyType"])
		
		softAssert.assertAll()
		where:
		row << getExcelRowList(file)
	}
	
	def cleanup(){
		openContentPage()
		changePropertyType(oldPropertyType)
		sleep(1*90*1000)
		pushData()
		sleep(5000)
		
	}


}
