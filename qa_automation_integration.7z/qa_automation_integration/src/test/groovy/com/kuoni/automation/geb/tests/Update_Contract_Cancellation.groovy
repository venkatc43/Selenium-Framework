package com.kuoni.automation.geb.tests

import static com.kuoni.qa.automation.util.TestUtil.*

import org.testng.asserts.SoftAssert

import static com.kuoni.qa.automation.util.GetCoherenceObject.*
import spock.lang.Shared
import spock.lang.Unroll

import com.gta.nova.coherence.property.model.Property
import com.gta.nova.condition.model.CancellationCondition
import com.kuoni.qa.automation.common.properties.EnvironmentProperties;
import com.kuoni.qa.automation.common.util.ExcelUtil
import com.kuoni.spock.annotation.RegressionTestGC

@RegressionTestGC
class Update_Contract_Cancellation extends GCContract{

	@Shared
	def file = "//src//test//groovy//com//kuoni//automation//geb//data//GC_TestData_For_Property_38.xlsx"
	SoftAssert softAssert = new SoftAssert()

	def static oldCCDays = 5
	def static oldCCPercentage = 50
	def static oldCCNights = "2 Nights"
	EnvironmentProperties envprop = new EnvironmentProperties()
	def sheetName = envprop.getValueForProperty("excelSheetName")
	def static newCCDays
	def static newCCPercentage
	def static newCCNights

	@Unroll
	def "Verify ContractCancellation in DynAdmin"(){


		given: "The Contract Cancellation details are  updated in GC"

		def excelDataFilePath =System.getProperty("user.dir")+ file

		ExcelUtil excelUtil = new ExcelUtil(excelDataFilePath)
		country = excelUtil.getCellAsString(sheetName, row, "country").toString().trim()
		propertyName= excelUtil.getCellAsString(sheetName, row, "hotel").toString().trim()
		contractId =  excelUtil.getCellAsString(sheetName, row, "Contract").toString().trim()
		def propertyId = excelUtil.getCellAsString(sheetName, row, "propertyId").toString().trim()
		def contractCancelId=excelUtil.getCellAsString(sheetName, row, "contractCancelId")
		newCCDays=	excelUtil.getCell(sheetName, row, "newCCDays").getNumericCellValue().intValue()
		newCCPercentage = excelUtil.getCell(sheetName, row, "newCCPercentage").getNumericCellValue().floatValue()
		newCCNights=excelUtil.getCellAsString(sheetName, row, "newCCNights")
		ccancelId=excelUtil.getCellAsString(sheetName, row, "contractCancelId").toString().trim()
		when: "Update Contract Cancellation in GC Connect"

		openContractPage()

		editContractCancellation(contractId,newCCDays,newCCPercentage,newCCNights,ccancelId)

		println "Old Cancel Days : " + oldCCDays
		println "Old Percentage :" + oldCCPercentage
		println "Old Cancel Charge Duration :" + oldCCNights

		sleep(1*90*1000)
		and:"Invoke Dataloader to push data"
		pushData()
		sleep(5000)

		def json = getJson("contractCancellation" , "id CONTAINS \""+contractCancelId+"\"")


		println json

		then: "verify Contract Cancellation correctly updated in atg"

		println "\n ATG Cancel Days  : " + json["daysPrior"]
		println "\n ATG Cancel Percentage  : " + json["chargePercentage"]
		println "\n ATG Cancel Duration  : " + json["duration"]

		softAssert.assertTrue(json["daysPrior"] == newCCDays.toString() , "Contract dayPrior not updated  in atg!! \n Expected: $newCCDays , actual: " +json["daysPrior"])
		softAssert.assertTrue((json["chargePercentage"]).toFloat() == newCCPercentage , "Contract Cancel Percentage not updated  in atg!! \n Expected: $newCCPercentage , actual: " +json["chargePercentage"])
		softAssert.assertTrue(newCCNights.contains(json["duration"]), "Contract Cancel Duration not updated  in atg!! \n Expected: $newCCNights , actual: " +json["duration"])

		softAssert.assertAll()

		where:
		row << getExcelRowList(file)
	}

	def verifyCoherenceData() {
		given: "Data is pushed to Coherence"
		incrementalPushtoCoherence()
		println "\n Cohernece Validation \n"
		CancellationCondition cancellationCondition =	verifyCoherenceCancelConditions(contractId,ccancelId)

		softAssert.assertEquals(newCCDays.toString(), cancellationCondition.getDaysPrior().toString(), "Contract Cancellation DaysPrior not updated  in Coherence!! \n Expected: $newCCDays , actual: " +cancellationCondition.getDaysPrior())
		println " GC Cancel DaysPrior : " +newCCDays +" Coherence Cancellation Duration : " + cancellationCondition.getDaysPrior()

		softAssert.assertEquals(newCCPercentage.toString(), cancellationCondition.getChargePercentage().toString(), "Contract Cancellation Percentage not updated  in Coherence!! \n Expected: $newCCPercentage , actual: " +cancellationCondition.getChargePercentage())
		println " GC Cancel Percentage : " +newCCPercentage +" Coherence Cancellation Percentage : " + cancellationCondition.getChargePercentage()

		softAssert.assertTrue(newCCNights.contains(cancellationCondition.getChargeDuration().toString()) , "Contract Cancellation Duration not updated  in Coherence!! \n Expected: $newCCNights , actual: " +cancellationCondition.getChargeDuration())
		println " GC Cancel Duration : " +newCCNights +" Coherence Cancellation Duration : " + cancellationCondition.getChargeDuration()
		softAssert.assertAll()
		
		
	}

	def cleanupData(){
		given: "Data is pushed to Coherence"
		openContractPage()
		editContractCancellation(contractId,oldCCDays,oldCCPercentage,oldCCNights,ccancelId)
		sleep(1*90*1000)
		pushData()
		sleep(5000)
		incrementalPushtoCoherence()
	}
}
