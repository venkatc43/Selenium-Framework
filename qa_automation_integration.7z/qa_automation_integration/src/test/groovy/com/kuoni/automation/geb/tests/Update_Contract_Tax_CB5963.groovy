package com.kuoni.automation.geb.tests

import static com.kuoni.qa.automation.util.TestUtil.*
import static com.kuoni.qa.automation.util.GetCoherenceObject.*
import org.json.JSONArray
import org.testng.asserts.SoftAssert

import spock.lang.Shared
import spock.lang.Unroll

import com.gta.nova.tax.model.Tax
import com.kuoni.qa.automation.common.properties.EnvironmentProperties;
import com.kuoni.qa.automation.common.util.ExcelUtil

class Update_Contract_Tax_CB5963 extends GCContract {
	
	@Shared
	def file = "//src//test//groovy//com//kuoni//automation//geb//data//GC_TestData_For_Property_38.xlsx"
	SoftAssert softAssert = new SoftAssert()
	
	def oldContractTax = 50
	def static contractTaxPercentage
	EnvironmentProperties envprop = new EnvironmentProperties()
	def sheetName = envprop.getValueForProperty("excelSheetName")
	
	@Unroll
	def "Verify Contract Tax in DynAdmin"(){
		
	
	given: "The Contract Tax details are  updated in GC"
	
	def excelDataFilePath =System.getProperty("user.dir")+ file
	
	ExcelUtil excelUtil = new ExcelUtil(excelDataFilePath)
	country = excelUtil.getCellAsString(sheetName, row, "country").toString().trim()
	roomId = excelUtil.getCellAsString(sheetName, row, "roomId").toString().trim()
	propertyName= excelUtil.getCellAsString(sheetName, row, "hotel").toString().trim()
	contractId =  excelUtil.getCellAsString(sheetName, row, "Contract").toString().trim()
	def propertyId = excelUtil.getCellAsString(sheetName, row, "propertyId")
	
	
	contractTaxPercentage =	excelUtil.getCellAsString(sheetName, row, "contractTaxPercentage").toString().trim()
	contractTaxId = excelUtil.getCellAsString(sheetName, row, "contractTaxId").toString().trim()
		

	when: "Update Contract Tax in GC Connect"
		
	openContractPage()
	
	editContractTax(contractId,contractTaxPercentage,contractTaxId)
	
	println "GC  old Contract Tax : " + oldContractTax
	
	sleep(1*90*1000)
	and:"Invoke Dataloader to push data"
	
	pushData()
	sleep(5000)
	
	def json = getJson("tax" , "taxId CONTAINS \""+contractTaxId+"\"")
	
	println json
	
	then: "verify Contract Tax loaded in atg"
	
	JSONArray actualtaxPercent =  json["taxPercentage"]
	println "Atg Contract Tax  : " + actualtaxPercent.get(0)
	
	
	softAssert.assertTrue(actualtaxPercent.get(0) == contractTaxPercentage , "Contract Tax Locally not updated  in atg!! \n Expected: $contractTaxPercentage , actual: " +actualtaxPercent.get(0))
	
	softAssert.assertAll()
	where:
	row << getExcelRowList(file)
}
	
	def verifyCoherenceData() {
		given: "Data is pushed to Coherence"
		incrementalPushtoCoherence()
		Tax tax = 	getCoherenceTaxDetails(contractId,contractTaxId)
		println "\n Cohernece Validation \n"
		softAssert.assertEquals(contractTaxPercentage, tax.getTaxes().get(0).toString(), "Contract Tax not updated  in Coherence!! \n Expected: $contractTaxPercentage , actual: " +tax.getTaxes().get(0))
		println "Coherence Contract Tax : " + tax.getTaxes().get(0)
		softAssert.assertAll()
	}
	
	
def cleanupData(){
	given: "Data is pushed to Coherence"
	openContractPage()
	
	editContractTax(contractId,oldContractTax,contractTaxId)
	sleep(1*90*1000)
	pushData()
	sleep(5000)
	incrementalPushtoCoherence()
	
}
	

}
