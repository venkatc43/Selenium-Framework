package com.kuoni.automation.geb.tests
import static com.kuoni.qa.automation.util.GcTestsHelper_toget_Atg_Ids.*

import org.testng.asserts.SoftAssert;
import static com.kuoni.qa.automation.util.TestUtil.*
import com.kuoni.qa.automation.common.util.ExcelUtil
import static com.kuoni.qa.automation.util.GetCoherenceObject.*
import spock.lang.Shared;
import spock.lang.Unroll;

import com.gta.nova.propertycontract.model.PropertyContract
import com.kuoni.qa.automation.common.properties.EnvironmentProperties;
import com.kuoni.qa.automation.common.util.ExcelUtil

import static com.kuoni.qa.automation.util.TestUtil.*
class Update_ContractRsp_CB_6627 extends GCContract {
	

	
	@Shared
	def file = "//src//test//groovy//com//kuoni//automation//geb//data//GC_TestData_For_Property_38.xlsx"
	SoftAssert softAssert = new SoftAssert()
	def oldPropertyType
	def static oldRsp
	def static newRsp
	EnvironmentProperties envprop = new EnvironmentProperties()
	def sheetName = envprop.getValueForProperty("excelSheetName")
	
	@Unroll
	def "Verify ContractRSP in DynAdmin"(){
		
	
	given: "The Contract Margin details are  updated in GC"
	
	def excelDataFilePath =System.getProperty("user.dir")+ file
	
	ExcelUtil excelUtil = new ExcelUtil(excelDataFilePath)
	country = excelUtil.getCellAsString(sheetName, row, "country").toString().trim()
	roomId = excelUtil.getCellAsString(sheetName, row, "roomId").toString().trim()
	propertyName= excelUtil.getCellAsString(sheetName, row, "hotel").toString().trim()
	contractId =  excelUtil.getCellAsString(sheetName, row, "Contract")
	def propertyId = excelUtil.getCellAsString(sheetName, row, "propertyId")
	def marginId = excelUtil.getCellAsString(sheetName, row, "marginId")
	
	oldRsp = true
	newRsp = false

	when: "Update Contract Margin in GC Connect"
		
	openContractPage()
	
	editContractRsp(contractId,newRsp)
	
	println "Old Rsp : " + oldRsp
	println "New Rsp : " + newRsp
	sleep(1*90*1000)
	and:"Invoke Dataloader to push data"
	pushData()
	sleep(5000)
	
	def contractMarginId = getContMarginId(contractId)
	
	def json = getJson("margin" , "id CONTAINS \""+contractMarginId+"\"")
	
	println json
	
	then: "verify Contract Rsp correctly loaded in atg"
	
	println "\n ATG Rsp  : " + json["rspProvided"]
	
	
	softAssert.assertTrue(json["rspProvided"] == newRsp.toString() , "Contract RSP not updated  in atg!! \n Expected: $newRsp , actual: " +json["rspProvided"])
	softAssert.assertAll()
	where:
	row << getExcelRowList(file)
}
	
	def verifyCoherenceData() {
		given: "Data is pushed to Coherence"
		incrementalPushtoCoherence()
		println "\n Cohernece Validation \n"
		PropertyContract propertyContract =	verifyCoherenceContractsandRateplans(contractId)
		softAssert.assertEquals(newRsp, propertyContract.isRspProvided(), "Contract RSP not updated  in Coherence!! \n Expected: $newRsp , actual: " +propertyContract.isRspProvided())
		println "Coherence ContractRsp : " + propertyContract.isRspProvided()
		softAssert.assertAll()
	}
	
	def cleanupData(){
		given: "Data is pushed to Coherence"
		openContractPage()
		editContractRsp(contractId,oldRsp)
		sleep(1*90*1000)
		pushData()
		sleep(5000)
		incrementalPushtoCoherence()
		
	}



}
