package com.kuoni.automation.geb.tests

import static com.kuoni.qa.automation.util.TestUtil.*

import org.testng.asserts.SoftAssert

import spock.lang.Shared
import spock.lang.Unroll

import com.kuoni.qa.automation.common.properties.EnvironmentProperties
import com.kuoni.qa.automation.common.util.ExcelUtil
import com.kuoni.spock.annotation.RegressionTestGC

class Room_ViewName_Other_CB8144 extends GCContent{
	
	@Shared
	def file = "//src//test//groovy//com//kuoni//automation//geb//data//GC_TestData_For_Property_38.xlsx"
	SoftAssert softAssert = new SoftAssert()
	def oldPropertyType
	def oldRoomView = "Beach View"
	def newRoomView = null
	EnvironmentProperties envprop = new EnvironmentProperties()
	def sheetName = envprop.getValueForProperty("excelSheetName")
	
	@Unroll
	@RegressionTestGC
	def "Verify RoomView Other in DynAdmin"(){
		
	
	given: "the property details to update in GC"
	
	def excelDataFilePath =System.getProperty("user.dir")+ file
	
	ExcelUtil excelUtil = new ExcelUtil(excelDataFilePath)
	country = excelUtil.getCellAsString(sheetName, row, "country").toString().trim()
	roomId = excelUtil.getCellAsString(sheetName, row, "roomId").toString().trim()
	propertyName= excelUtil.getCellAsString(sheetName, row, "hotel").toString().trim()
	def roomskuId = excelUtil.getCellAsString(sheetName, row, "roomskuId").toString().trim()
	
	def propertyId = excelUtil.getCellAsString(sheetName, row, "propertyId")
	
	newRoomView = excelUtil.getCellAsString(sheetName, row, "newRoomView").toString().trim()
	

	when: "Update Room Category in GC Connect"
		
	openContentPage()
	
	editRoomView(roomId,newRoomView)
	
	println "GC Old Room View : " + oldRoomView

	sleep(1*90*1000)
	and:"Invoke Dataloader to push data"
	pushData()
	sleep(5000)
	
	def json = getJson("roomSku" , "roomId CONTAINS \""+roomskuId+"\"")
	
	println json
	
	then: "verify Room Details correctly loaded in atg"
	
	println "\n ATG RoomView  : " + json["roomViewCode"]
	
	
//	softAssert.assertTrue(json["roomCategory"] == newRoomCat , "Room Category not updated  in atg!! \n Expected: $newRoomCat , actual: " +json["roomCategory"])
	softAssert.assertTrue(newRoomView.toString().toLowerCase().contains(json["roomViewCode"].toString().toLowerCase()) , "Room View Other Code not updated  in atg!! \n Expected: $newRoomView , actual: " +json["roomViewCode"])
	
	softAssert.assertAll()
	where:
	row << getExcelRowList(file)
}

def cleanup(){
	openContentPage()
	editRoomView(roomId,oldRoomView)
	sleep(1*90*1000)
	pushData()
	sleep(5000)
	
}

}
