package com.kuoni.automation.geb.tests

import org.testng.asserts.SoftAssert;

import com.kuoni.qa.automation.common.properties.EnvironmentProperties;
import com.kuoni.qa.automation.common.util.ExcelUtil

import static com.kuoni.qa.automation.util.TestUtil.*
import spock.lang.Shared;
import spock.lang.Unroll;

class Verify_LandMark_Updates_CB9683 extends GCContent{
	
	@Shared
	def file = "//src//test//groovy//com//kuoni//automation//geb//data//GC_TestData_For_Property_38.xlsx"
	SoftAssert softAssert = new SoftAssert()
	
	def oldLandDistance = 12
	EnvironmentProperties envprop = new EnvironmentProperties()
	def sheetName = envprop.getValueForProperty("excelSheetName")
	
	
	@Unroll
	def "Verify Property LandMark in DynAdmin"(){
		
	
	given: "The Contract Cancellation details are  updated in GC"
	
	def excelDataFilePath =System.getProperty("user.dir")+ "//src//test//groovy//com//kuoni//automation//geb//data//GC_TestData_For_Property_38.xlsx"
	
	ExcelUtil excelUtil = new ExcelUtil(excelDataFilePath)
	country = excelUtil.getCellAsString(sheetName, row, "country").toString().trim()
	propertyName= excelUtil.getCellAsString(sheetName, row, "hotel").toString().trim()
//	contractId =  excelUtil.getCellAsString(sheetName, row, "Contract").toString().trim()
	def propertyId = excelUtil.getCellAsString(sheetName, row, "propertyId")
	def landMarkId = excelUtil.getCellAsString(sheetName, row, "landMarkId")
	def LandDistance = excelUtil.getCell(sheetName, row, "LandDistance").getNumericCellValue().floatValue()

	when: "Update Property LandMarks in GC Connect"
		
	openContentPage()
	
	updatePropertyLandmarks(LandDistance)
	
	println "Old Land Mark Distance :" + oldLandDistance
	
	sleep(1*90*1000)
	and:"Invoke Dataloader to push data"
	pushData()
	sleep(5000)
	
	def json = getJson("landmarkDistance" , "landmarkId CONTAINS \""+landMarkId+"\"")

	
	println json
	
	then: "verify that the Property LandMarks updated in atg"
	
	println "\n ATG Land Mark Distance  : " + json["distance"]
		
	softAssert.assertTrue((json["distance"]).toFloat() == LandDistance , "LandMark Distance not updated  in atg!! \n Expected: $LandDistance , actual: " +json["distance"])
	
	softAssert.assertAll()
	
	where:
	row << getExcelRowList(file)
}

def cleanup(){
	openContentPage()
	updatePropertyLandmarks(oldLandDistance)
	sleep(1*90*1000)
	pushData()
	sleep(5000)
	
}

}
