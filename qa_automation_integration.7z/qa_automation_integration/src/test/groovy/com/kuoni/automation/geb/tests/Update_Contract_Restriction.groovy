package com.kuoni.automation.geb.tests

import org.testng.asserts.SoftAssert;

import com.gta.nova.restrictionpolicy.model.RestrictionPolicy
import com.kuoni.qa.automation.common.properties.EnvironmentProperties;
import com.kuoni.qa.automation.common.util.ExcelUtil
import static com.kuoni.qa.automation.util.GetCoherenceObject.*
import static com.kuoni.qa.automation.util.TestUtil.*
import spock.lang.Shared;
import spock.lang.Unroll;

class Update_Contract_Restriction extends GCContract{
	
	@Shared
	def file = "//src//test//groovy//com//kuoni//automation//geb//data//GC_TestData_For_Property_38.xlsx"
	SoftAssert softAssert = new SoftAssert()
	
	def static oldcontract_restrictionDays = 2
	def static contract_restrictionDays
	
	EnvironmentProperties envprop = new EnvironmentProperties()
	def sheetName = envprop.getValueForProperty("excelSheetName")
	
	@Unroll
	def "Verify ContractRestriction in DynAdmin"(){
		
	
	given: "The Contract Cancellation details are  updated in GC"
	
	def excelDataFilePath =System.getProperty("user.dir")+ file
	
	ExcelUtil excelUtil = new ExcelUtil(excelDataFilePath)
	country = excelUtil.getCellAsString(sheetName, row, "country").toString().trim()
	propertyName= excelUtil.getCellAsString(sheetName, row, "hotel").toString().trim()
	contractId =  excelUtil.getCellAsString(sheetName, row, "Contract").toString().trim()
	def propertyId = excelUtil.getCellAsString(sheetName, row, "propertyId")
	contractRestrictionId = excelUtil.getCellAsString(sheetName, row, "contractRestrictionId")
	contract_restrictionDays =	excelUtil.getCell(sheetName, row, "contract_restrictionDays").getNumericCellValue().intValue()

	when: "Update Contract Restriction in GC Connect"
		
	openContractPage()
	
	editContractRestriction(contractId,contract_restrictionDays,contractRestrictionId)
	
	println "Old Restriction Amendment Days : " + oldcontract_restrictionDays
	
	sleep(1*90*1000)
	and:"Invoke Dataloader to push data"
	pushData()
	sleep(5000)
	
	def json = getJson("contractRestriction" , "restrictionId CONTAINS \""+contractRestrictionId+"\"")

	
	println json
	
	then: "verify Contract Restriction correctly updated in atg"
	
	println "\n ATG Restriction Days Prior  : " + json["daysPrior"]
	
	softAssert.assertTrue(json["daysPrior"] == contract_restrictionDays.toString() , "Contract Restriction Days not updated  in atg!! \n Expected: $contract_restrictionDays , actual: " +json["daysPrior"])
	softAssert.assertAll()
	
	where:
	row << getExcelRowList(file)
}
	
	def verifyCoherenceData() {
		given: "Data is pushed to Coherence"
		incrementalPushtoCoherence()
		println "\n Cohernece Validation \n"
		RestrictionPolicy restrictionCondition = verifyCoherenceRestrictions(contractId,contractRestrictionId)

		softAssert.assertEquals(contract_restrictionDays.toString(), restrictionCondition.getDaysPrior().toString(), "Contract Restriction DaysPrior not updated  in Coherence!! \n Expected: $contract_restrictionDays , actual: " +restrictionCondition.getDaysPrior())
		println " GC Contract Restriction DaysPrior : " +contract_restrictionDays +" Coherence Restriction Duration : " + restrictionCondition.getDaysPrior()

		softAssert.assertAll()
		
		
	}

def cleanupData(){
	given: "Data is pushed to Coherence"
	openContractPage()
	editContractRestriction(contractId,oldcontract_restrictionDays,contractRestrictionId)
	sleep(1*90*1000)
	pushData()
	sleep(5000)
	incrementalPushtoCoherence()
	
}

}
