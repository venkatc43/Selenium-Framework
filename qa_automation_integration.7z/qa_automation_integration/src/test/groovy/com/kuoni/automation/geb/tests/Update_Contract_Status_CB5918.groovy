package com.kuoni.automation.geb.tests

import org.testng.asserts.SoftAssert;

import com.gta.nova.propertycontract.model.PropertyContract
import com.kuoni.qa.automation.common.properties.EnvironmentProperties;
import com.kuoni.qa.automation.common.util.ExcelUtil
import static com.kuoni.qa.automation.util.GetCoherenceObject.*
import static com.kuoni.qa.automation.util.TestUtil.*
import spock.lang.Shared;
import spock.lang.Unroll;

class Update_Contract_Status_CB5918 extends GCContract{



	@Shared
	def file = "//src//test//groovy//com//kuoni//automation//geb//data//GC_TestData_For_Property_38.xlsx"
	SoftAssert softAssert = new SoftAssert()
	def static oldPropertyType
	def static oldStatus
	def static newStatus
	EnvironmentProperties envprop = new EnvironmentProperties()
	def sheetName = envprop.getValueForProperty("excelSheetName")

	@Unroll
	def "Verify ContractMargin in DynAdmin"(){


		given: "The Contract Margin details are  updated in GC"

		def excelDataFilePath =System.getProperty("user.dir")+ "//src//test//groovy//com//kuoni//automation//geb//data//GC_TestData_For_Property_38.xlsx"

		ExcelUtil excelUtil = new ExcelUtil(excelDataFilePath)
		country = excelUtil.getCellAsString(sheetName, row, "country").toString().trim()
		roomId = excelUtil.getCellAsString(sheetName, row, "roomId").toString().trim()
		propertyName= excelUtil.getCellAsString(sheetName, row, "hotel").toString().trim()
		contractId =  excelUtil.getCellAsString(sheetName, row, "Contract").toString().trim()
		def propertyId = excelUtil.getCellAsString(sheetName, row, "propertyId")
		def propContractAttributeId =  excelUtil.getCellAsString(sheetName, row, "propContractAttributeId")

		//	oldMargin = excelUtil.getCellAsString("integration", row, "oldMargin").toString().trim()
		//	newMargin = excelUtil.getCellAsString("integration", row, "newMargin").toString().trim()
		oldStatus = "Hold"
		newStatus = "Enable"

		when: "Update Contract Margin in GC Connect"

		openContractPage()

		editContracttoLive(contractId,newStatus)

		println "Old Status : " + oldStatus
		sleep(1*90*1000)
		and:"Invoke Dataloader to push data"
		pushData()
		sleep(5000)

		def json = getJson("propertyContractAttributes" , "propertyContractAttributeId CONTAINS \""+propContractAttributeId+"\"")


		println json

		then: "verify Contract Status correctly updated in atg"

		println "\n ATG Margin  : " + json["status"]


		softAssert.assertTrue(json["status"] == "Live" , "Contract Status not updated  in atg!! \n Expected: $newStatus , actual: " +json["status"])
		softAssert.assertAll()

		where:
		row << getExcelRowList(file)
	}

	def verifyCoherenceData() {
		given: "Data is pushed to Coherence"
		incrementalPushtoCoherence()
		println "\n Cohernece Validation \n"
		PropertyContract propertyContract =	verifyCoherenceContractsandRateplans(contractId)
		softAssert.assertEquals("Live", propertyContract.getContractStatus(), "Contract Status not updated  in Coherence!! \n Expected: LIVE , actual: " +propertyContract.getContractStatus())
		println "Coherence Contract Margin : " + propertyContract.getContractStatus()
		softAssert.assertAll()
	}

	def cleanupData(){
		given: "Data is pushed to Coherence"
		openContractPage()
		editContracttoHold(contractId,oldStatus)
		sleep(1*90*1000)
		pushData()
		sleep(5000)
		incrementalPushtoCoherence()
	}
}
