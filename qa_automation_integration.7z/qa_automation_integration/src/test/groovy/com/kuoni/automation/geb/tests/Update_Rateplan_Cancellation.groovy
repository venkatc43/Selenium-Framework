package com.kuoni.automation.geb.tests

import org.testng.asserts.SoftAssert;

import com.gta.nova.condition.model.CancellationCondition
import com.kuoni.qa.automation.common.properties.EnvironmentProperties;
import com.kuoni.qa.automation.common.util.ExcelUtil
import static com.kuoni.qa.automation.util.GetCoherenceObject.*
import static com.kuoni.qa.automation.util.TestUtil.*
import spock.lang.Shared;
import spock.lang.Unroll;

class Update_Rateplan_Cancellation extends GCContract {
	
	@Shared
	def file = "//src//test//groovy//com//kuoni//automation//geb//data//GC_TestData_For_Property_38.xlsx"
	SoftAssert softAssert = new SoftAssert()
	
	def static rpCanceldays = 2
	def static rpCancelPercentage = 100
	def static rpCacelId
	def static ratePlanId
	def static newrpCanceldays
	def static newrpCancelPercentage
	EnvironmentProperties envprop = new EnvironmentProperties()
	def sheetName = envprop.getValueForProperty("excelSheetName")
	
	@Unroll
	def "Verify Rateplan Cancellation in DynAdmin"(){
		
	
	given: "The RatePlan Cancellation details are  updated in GC"
	
	def excelDataFilePath =System.getProperty("user.dir")+ file
	
	ExcelUtil excelUtil = new ExcelUtil(excelDataFilePath)
	country = excelUtil.getCellAsString(sheetName, row, "country").toString().trim()
	propertyName= excelUtil.getCellAsString(sheetName, row, "hotel").toString().trim()
	contractId =  excelUtil.getCellAsString(sheetName, row, "Contract").toString().trim()
	def propertyId = excelUtil.getCellAsString(sheetName, row, "propertyId")
	rpCacelId = excelUtil.getCellAsString(sheetName, row, "rpCacelId")
	ratePlanId=excelUtil.getCellAsString(sheetName, row, "ratePlanId").toString().trim()
	 newrpCanceldays=	excelUtil.getCell(sheetName, row, "rpCanceldays").getNumericCellValue().intValue()
	 newrpCancelPercentage = excelUtil.getCell(sheetName, row, "rpCancelPercentage").getNumericCellValue().floatValue()

	when: "Update RatePlan Cancellation in GC Connect"
		
	openRatePlanPage()
	
	editRatePlanCancellation(contractId,ratePlanId,rpCacelId,newrpCanceldays,newrpCancelPercentage)
	
	println "Old RP Cancel Time : " + rpCanceldays
	println "Old RP Cancel Percentage :" + rpCancelPercentage
	
	sleep(1*90*1000)
	and:"Invoke Dataloader to push data"
	pushData()
	sleep(5000)
	
	def json = getJson("rpCancellation" , "id CONTAINS \""+rpCacelId+"\"")

	
	println json
	
	then: "verify RatePlan Cancellation correctly updated in atg"
	
	println "\n ATG RP Cancel Days Prior  : " + json["daysPrior"]
	println "\n ATG RP Cancel Charge Percentage  : " + json["chargePercentage"]
	
	
	softAssert.assertTrue(json["daysPrior"].toString() == newrpCanceldays.toString() , "Rateplan Cancel DaysPrior not updated  in atg!! \n Expected: $newrpCanceldays , actual: " +json["daysPrior"])
	softAssert.assertTrue(json["chargePercentage"].toString() == newrpCancelPercentage.toString() , "Rateplan Cancel Charge Percentage not updated  in atg!! \n Expected: $newrpCancelPercentage , actual: " +json["chargePercentage"])
	
	softAssert.assertAll()
	where:
	row << getExcelRowList(file)
}

	
	def verifyCoherenceData() {
		given: "Data is pushed to Coherence"
		incrementalPushtoCoherence()
		println "\n Cohernece Validation \n"
		CancellationCondition cancellationCondition =	verifyCoherenceCancelConditions(contractId,rpCacelId.toString())

		softAssert.assertEquals(newrpCanceldays.toString(), (cancellationCondition.getDaysPrior()).toString(), "RatePlan Cancellation DaysPrior not updated  in Coherence!! \n Expected: $newrpCanceldays , actual: " +cancellationCondition.getDaysPrior())
		println " GC RP Cancel DaysPrior : " +newrpCanceldays +" Coherence Cancellation Duration : " + cancellationCondition.getDaysPrior()

		softAssert.assertEquals(newrpCancelPercentage.toString(), cancellationCondition.getChargePercentage().toString(), "Rateplan Cancellation Percentage not updated  in Coherence!! \n Expected: $newrpCancelPercentage , actual: " +cancellationCondition.getChargePercentage())
		println " GC Cancel Percentage : " +newrpCancelPercentage +" Coherence RP Cancellation Percentage : " + cancellationCondition.getChargePercentage()
		softAssert.assertAll()
				
	}
def cleanupData(){
	given: "Data is pushed to Coherence"
	openRatePlanPage()
	editRatePlanCancellation(contractId,ratePlanId,rpCacelId,rpCanceldays,rpCancelPercentage)
	sleep(1*90*1000)
	pushData()
	sleep(5000)
	incrementalPushtoCoherence()
	
}


}
