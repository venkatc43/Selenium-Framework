package com.kuoni.automation.geb.tests

import org.json.JSONArray
import org.testng.asserts.SoftAssert;
import static com.kuoni.qa.automation.util.GetCoherenceObject.*
import com.gta.nova.tax.model.Tax
import com.kuoni.qa.automation.common.properties.EnvironmentProperties;
import com.kuoni.qa.automation.common.util.ExcelUtil

import static com.kuoni.qa.automation.util.TestUtil.*
import spock.lang.Shared;
import spock.lang.Unroll;

class Update_RoomSuppl_Tax_CB5963 extends GCContract {

	@Shared
	def file = "//src//test//groovy//com//kuoni//automation//geb//data//GC_TestData_For_Property_38.xlsx"
	SoftAssert softAssert = new SoftAssert()
	
	def oldRoomSuppTax = 50
	def oldBaseTax = "true"
	def static roomSuppTaxId
	def static  roomSuppTax
	EnvironmentProperties envprop = new EnvironmentProperties()
	def sheetName = envprop.getValueForProperty("excelSheetName")
	
	
	@Unroll
	def "Verify Room Supplement Tax in DynAdmin"(){
		
	
	given: "The Room Supplement Tax details are  updated in GC"
	
	def excelDataFilePath =System.getProperty("user.dir")+ file
	
	ExcelUtil excelUtil = new ExcelUtil(excelDataFilePath)
	country = excelUtil.getCellAsString(sheetName, row, "country").toString().trim()
	roomId = excelUtil.getCellAsString(sheetName, row, "roomId").toString().trim()
	propertyName= excelUtil.getCellAsString(sheetName, row, "hotel").toString().trim()
	contractId =  excelUtil.getCellAsString(sheetName, row, "Contract").toString().trim()
	def propertyId = excelUtil.getCellAsString(sheetName, row, "propertyId")
	
	
	roomSuppTax =	excelUtil.getCellAsString(sheetName, row, "roomSuppTax").toString().trim()
	def newBaseTax = excelUtil.getCellAsString(sheetName, row, "newBaseTax").toString().trim()
	roomSuppTaxId= 	excelUtil.getCellAsString(sheetName, row, "roomSuppTaxId").toString().trim()

	when: "Update Room Supplement Tax in GC Connect"
		
	openContractPage()
	
	editRoomSuppTax(contractId,roomSuppTaxId,newBaseTax,roomSuppTax)
	
	println "GC  old Room Supplement Tax : " + oldRoomSuppTax
	println "GC  old BaseTax Applies  : " + oldBaseTax
	
	sleep(1*90*1000)
	and:"Invoke Dataloader to push data"
	
	pushData()
	sleep(5000)
	
	def json = getJson("tax" , "taxId CONTAINS \""+roomSuppTaxId+"\"")
	
	println json
	
	then: "verify Room Supplement Tax loaded in atg"
	
	
	println "Atg Room Supplement Base Tax  : " + json["baseApplies"]
	println "Atg Room Supplement Room Supp Tax  : " + json["taxPercentage"]
	
	
	
	JSONArray roomSuppTaxPercentage = json["taxPercentage"]
	println "Atg room Supplement Tax  : " + roomSuppTaxPercentage.get(0)
	
	
	softAssert.assertTrue(json["baseApplies"] == newBaseTax , "Room Supplement BaseTaxApplies Locally not updated  in atg!! \n Expected: $newBaseTax , actual: " +json["baseApplies"])
	softAssert.assertTrue(roomSuppTaxPercentage.get(0) == roomSuppTax , "Room Supplement TaxPercentage Locally not updated  in atg!! \n Expected: $roomSuppTax , actual: " +roomSuppTaxPercentage.get(0))
	
	softAssert.assertAll()
	where:
	row << getExcelRowList(file)
}
	
	
	def verifyCoherenceData() {
		
		given: "Data is pushed to Coherence"
		incrementalPushtoCoherence()
		Tax tax = 	getCoherenceTaxDetails(contractId,roomSuppTaxId)
		println "\n Cohernece Validation \n"
		softAssert.assertEquals(roomSuppTax, tax.getTaxes().get(0).toString(), "RoomSupplement Tax not updated  in Coherence!! \n Expected: $roomSuppTax , actual: " +tax.getTaxes().get(0))
		println "Coherence Contract RoomSupp Tax : " + tax.getTaxes().get(0)
		softAssert.assertAll()
	}
	

def cleanupData(){
	given: "Data is pushed to Coherence"
	openContractPage()
	
	editRoomSuppTax(contractId,roomSuppTaxId,oldBaseTax,oldRoomSuppTax)
	sleep(1*90*1000)
	pushData()
	sleep(5000)
	incrementalPushtoCoherence()
	
}
	
}
