package com.kuoni.automation.geb.page

import geb.Page

import com.kuoni.qa.automation.common.util.ExcelUtil

class PropertyCreationPage extends Page {
	static at = { waitFor { title.endsWith("GTA Connect") } }
	
	static content = {
		propertyName(wait: true) { $("#name") }
		telephone { $("#telephone") }
		country { $("#country-id") }
		
		createButton { $("#create") }
	}
	
	void createProperties(){
		ExcelUtil excel = new ExcelUtil("C:\\Kuoni\\data\\data.xls")
		int rowCount = excel.getLastRowNum("test")
		for (int i=1;i<=rowCount;i++){
			
			String propertyId = excel.getCellAsString("test", i, "propertyId")
			if (propertyId != null && propertyId.trim().equalsIgnoreCase("XXXX")){

				String propertyNameStr = excel.getCellAsString("test", i, "propertyName")
				String telephoneStr = excel.getCellAsString("test", i, "telephone")
				String countryStr = excel.getCellAsString("test", i, "country")
				
				propertyName.value(propertyNameStr)
				telephone.value(telephoneStr)
				country.value(countryStr)
				
				createButton.click()
				
				waitFor(10) { $("#main").find(".message") }
				
				propertyId = getPropertyId();
				excel.setStringValue("test", i, "propertyId", propertyId)
				
			}
		}
	}
	
	String getPropertyId(){
		String message = $("#main").find(".message").text()
		message = message.replaceAll( 'Property ', '' )
		message = message.replaceAll( ' successfully created', '' )
		return message
	}
	
	void logout(){
		$("a", text:"Log out").click()
	}
	

}
