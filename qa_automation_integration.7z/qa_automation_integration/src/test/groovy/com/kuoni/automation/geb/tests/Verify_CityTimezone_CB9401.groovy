package com.kuoni.automation.geb.tests

import org.testng.asserts.SoftAssert;

import com.kuoni.qa.automation.common.properties.EnvironmentProperties;
import com.kuoni.qa.automation.common.util.ExcelUtil

import static com.kuoni.qa.automation.util.TestUtil.*
import spock.lang.Shared;
import spock.lang.Unroll;

class Verify_CityTimezone_CB9401 extends GCContent{
	
	@Shared
	def file = "//src//test//groovy//com//kuoni//automation//geb//data//GC_TestData_For_Property_38.xlsx"
	SoftAssert softAssert = new SoftAssert()
	def oldTimezone
	EnvironmentProperties envprop = new EnvironmentProperties()
	def sheetName = envprop.getValueForProperty("excelSheetName")
	
	@Unroll
	def "Verify City Timezone  details "(){
		
		
		given: "the property details to update in GC"
		
		def excelDataFilePath =System.getProperty("user.dir")+ file
		
		ExcelUtil excelUtil = new ExcelUtil(excelDataFilePath)
		country = excelUtil.getCellAsString(sheetName, row, "country").toString().trim()
//		city = excelUtil.getCellAsString(sheetName, row, "city").toString().trim()
		propertyName= excelUtil.getCellAsString(sheetName, row, "hotel").toString().trim()
		def cityDesc = excelUtil.getCellAsString(sheetName, row, "cityDesc").toString().trim()
		def propertyId = excelUtil.getCellAsString(sheetName, row, "propertyId")
		def newTimeZone = excelUtil.getCellAsString(sheetName, row, "newTimeZone").toString().trim()
		def cityCode4Timezone = excelUtil.getCellAsString(sheetName, row, "cityCode4Timezone").toString().trim()
		def newTimeZonetoCompare= excelUtil.getCellAsString(sheetName, row, "newTimeZonetoCompare").toString().trim()
		oldTimezone= "Europe/Copenhagen (Central European Summer Time)"
		

		when: "Update TimeZone  in GC Connect"
			
		openCityPage()
		
		changeCityTimeZone(newTimeZone)
		
		println "Existing TimeZone :"	+ oldTimezone
		sleep(1*90*1000)
		and:"Invoke Dataloader to push data"
		pushData()
		sleep(5000)
		
		def json = getJson("city" , "description CONTAINS \""+cityDesc+"\"")
		
		
		println json
		
		then: "verify Location Details correctly loaded in atg"
		
		println "\n ATG CityTimeZone  : " + json["timezone"]
		
		
		softAssert.assertTrue(json["timezone"] == newTimeZonetoCompare , "TimeZone not updated correctly in atg!! \n Expected: $newTimeZonetoCompare , actual: " +json["timezone"])
		
		softAssert.assertAll()
		where:
		row << getExcelRowList(file)
	}
	
	def cleanup(){
		openCityPage()
		changeCityTimeZone(oldTimezone)
		sleep(1*90*1000)
		pushData()
		sleep(5000)
		
	}



}
