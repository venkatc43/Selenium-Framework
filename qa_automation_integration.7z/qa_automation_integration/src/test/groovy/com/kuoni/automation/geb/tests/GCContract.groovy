
package com.kuoni.automation.geb.tests

import geb.spock.GebReportingSpec;

import groovyx.net.http.*

import org.json.JSONObject
import org.openqa.selenium.By;
import org.testng.asserts.SoftAssert;

import spock.lang.Shared;
import com.kuoni.automation.geb.page.GCContractPage
import com.kuoni.automation.geb.page.GCContentPage
import com.kuoni.automation.geb.page.GCHomePage
import com.kuoni.automation.geb.page.GCLoginPage
import com.kuoni.automation.geb.page.GCSearchPage
import com.kuoni.qa.automation.common.properties.EnvironmentProperties;
import com.kuoni.qa.automation.util.PerformDataLoadUtil
import com.mediaocean.qa.framework.selenium.ui.controls.Link;

class GCContract extends GebReportingSpec {
	
	@Shared
	private static EnvironmentProperties envprops
	@Shared
	def SoftAssert softAssert
	def static country
	def city
	def static propertyName
	def roomId
	def static contractId
	def static contractRestrictionId
	def static contractTaxId
	def static ccancelId
	def host
	def auth
	def PerformDataLoadUtil dataload = new PerformDataLoadUtil()
	def getEnvProperties() {
		if (envprops == null)
			envprops = new EnvironmentProperties()
		return envprops
	}
	
	
	def openContractPage(){
		
				GCLoginPage.url = getEnvProperties().getValueForProperty("gc.web.url")
				browser.driver.manage().window().maximize()
				//println url
				to GCLoginPage
				//at GCLoginPage
				login("gsuser1" , "London1")
		
				at GCHomePage
				openPage("Content")
				at GCSearchPage
				searchForProperty(country,propertyName)
				OpenContentForfirstRow()
				
				at GCContentPage
				clickOnHeader("Contract")
				sleep(1000)
				clickOnHeader("General Details")
			}
	
	
	def edit_rp_MarketRestrictions(def newRPzone,def newRPcountry)
	{
		
	}
	
	def editRoomSuppTax(contractId,roomSuppTaxId,newBaseTax,roomSuppTax)
	{
		at GCContractPage
		modifyRoomSuppTax(contractId,roomSuppTaxId,newBaseTax,roomSuppTax)
	}
	
	def editContractTax(def contractId,def contractTaxPercentage,def contractTaxId)
	{
		at GCContractPage
		modifyContractTax(contractId,contractTaxPercentage,contractTaxId)
		
	}
	
	
	def editContractResortFee(def contractId,def resortPaylocally,def resortMaxAge,def resortPrice,def resortchargeType,def resortFeeId)
	{
		at GCContractPage
		clickOnHeader("Extras and Supplements")
		modifyContractResortFee(contractId,resortPaylocally,resortMaxAge,resortPrice,resortchargeType,resortFeeId)
		
	}
	
	
	
	
	def editContractRoomSupplement(contractId,roomSuppType,roomSuppAgeMin,roomSuppAgeMax,roomSuppPrice,roomSuppId)
	{
		at GCContractPage
		clickOnHeader("Extras and Supplements")
		modifyContractRoomSupplement(contractId,roomSuppType,roomSuppAgeMin,roomSuppAgeMax,roomSuppPrice,roomSuppId)
	}
	
	def editContractRestriction(def contractId,def contract_restrictionDays,def contractRestrictionId)
	{
		at GCContractPage
		modifyContractRestriction(contractId,contract_restrictionDays,contractRestrictionId)
	}
	
	
	def openRatePlanPage(){
		
		GCLoginPage.url = getEnvProperties().getValueForProperty("gc.web.url")
		browser.driver.manage().window().maximize()
		//println url
		to GCLoginPage
		//at GCLoginPage
		login("gsuser1" , "London1")

		at GCHomePage
		openPage("Content")
		at GCSearchPage
		searchForProperty(country,propertyName)
		OpenContentForfirstRow()
		
		at GCContentPage
	
		clickOnHeader("Contract")

	}
	
	def editRatePlanRestriction(contractId,ratePlanId,rpRestrictionId,rpRestrictionType,rpRestrictionDaysPrior)
	{
		at GCContractPage
		modifyRPrestriction(contractId,ratePlanId,rpRestrictionId,rpRestrictionType,rpRestrictionDaysPrior)
	}
	
	
	def editRatePlanCancellation(def contractId,def ratePlanId,def rpCacelId,def newrpCanceldays,def newrpCancelPercentage)
	{
		at GCContractPage
		modifyRateplanCancellation(contractId,ratePlanId,rpCacelId,newrpCanceldays,newrpCancelPercentage)	
	}
	
	
	def editContractCancellation(contractId,newCCDays,newCCPercentage,newCCNights,ccancelId)
	{
		at GCContractPage
		modifyContractCancellation(contractId,newCCDays,newCCPercentage,newCCNights,ccancelId)
	}
	
	
	def editRateplanCode(def contractId,def ratePlanId,def newRPCode)
	{
		at GCContentPage
		editRplanCode(contractId,ratePlanId,newRPCode)
	}
	
	
	def editRateplanMarginType(contractId,ratePlanId,marginType)
		{
		
			at GCContentPage
			editRplanMarginType(contractId,ratePlanId,marginType)
			
			
		}
	
	def editRateplanMargin(contractId,ratePlanId,newRMargin){
		
		at GCContentPage
		editRPlanMargin(contractId,ratePlanId,newRMargin)
	}
	
	
	def editContractRsp(contractId,rsp)
	{
		at GCContentPage
		editRsp(contractId,rsp)
	}
	
	
	def editContracttoLive(def contractId,def status)
	{
		at GCContentPage
		changeContractStatus(contractId,status)
	}
	
	def editContracttoHold(contractId,status)
	{
		at GCContentPage
		changeContracttoHold(contractId,status)
	}
	
	def editContractMargin(def contractId,def newMargin)
	{
		at GCContentPage
		
		selectContract(contractId)
		sleep(5000)
		editMargin(newMargin)
	}
	
	def pushData() {
		dataload.performDataLoadRequest()
	}
	
	def incrementalPushtoCoherence()
	{
		
		dataload.incrementalPushtoCoherence()
		
	}

	def pushToQueueRequest() {
		
		dataload.pushToQueueRequest()
	
	}

	
	def performDataLoadRequest() {
		
		dataload.performDataLoadRequest()
	}

	def getJson(String itemDesc, String rql) {
		
		host =getEnvProperties().getValueForProperty("esb.host.url")
		println host
		def http = new HTTPBuilder(host)
		def getdata = http.get(path: '/test/rs/repositoryData.jsp', requestContentType: ContentType.URLENC, query: [
			repository: "/atg/commerce/catalog/LPMProductCatalog",
			itemDesc:   itemDesc,
			rql:        rql,
			json:       "true"
		]).toString()
		//println getdata
		JSONObject data = new JSONObject(getdata)
		//assert !data.getJSONArray("items").isEmpty()
		return data.getJSONArray("items").get(0)
	}

}
