package com.kuoni.automation.geb.tests

import org.testng.asserts.SoftAssert;

import com.gta.nova.restrictionpolicy.model.RestrictionPolicy
import com.kuoni.qa.automation.common.properties.EnvironmentProperties;
import com.kuoni.qa.automation.common.util.ExcelUtil
import static com.kuoni.qa.automation.util.GetCoherenceObject.*
import static com.kuoni.qa.automation.util.TestUtil.*
import spock.lang.Shared;
import spock.lang.Unroll;

class Update_Rateplan_Restriction extends GCContract {
	
	
	@Shared
	def file = "//src//test//groovy//com//kuoni//automation//geb//data//GC_TestData_For_Property_38.xlsx"
	SoftAssert softAssert = new SoftAssert()
	
	def static oldrpRestrictionType = "Amendment"
	def static oldrpRestrictionDaysPrior=2
	def static rpRestrictionId
	def static ratePlanId
	def static rpRestrictionType
	def static rpRestrictionDaysPrior
	EnvironmentProperties envprop = new EnvironmentProperties()
	def sheetName = envprop.getValueForProperty("excelSheetName")
	
	@Unroll
	def "Verify RatePlanRestriction in DynAdmin"(){
		
	
	given: "The Rateplan Cancellation details are  updated in GC"
	
	def excelDataFilePath =System.getProperty("user.dir")+ "//src//test//groovy//com//kuoni//automation//geb//data//GC_TestData_For_Property_38.xlsx"
	
	ExcelUtil excelUtil = new ExcelUtil(excelDataFilePath)
	country = excelUtil.getCellAsString(sheetName, row, "country").toString().trim()
	propertyName= excelUtil.getCellAsString(sheetName, row, "hotel").toString().trim()
	contractId =  excelUtil.getCellAsString(sheetName, row, "Contract").toString().trim()
	def propertyId = excelUtil.getCellAsString(sheetName, row, "propertyId")
	rpRestrictionId = excelUtil.getCellAsString(sheetName, row, "rpRestrictionId")
	rpRestrictionType =	excelUtil.getCellAsString(sheetName, row, "rpRestrictionType").toString().trim()
	rpRestrictionDaysPrior =	excelUtil.getCell(sheetName, row, "rpRestrictionDaysPrior").getNumericCellValue().intValue()
	ratePlanId=excelUtil.getCellAsString(sheetName, row, "ratePlanId").toString().trim()
	
	when: "Update Rateplan Restriction in GC Connect"
		
	openRatePlanPage()
	
	editRatePlanRestriction(contractId,ratePlanId,rpRestrictionId,rpRestrictionType,rpRestrictionDaysPrior)
	
	println "Old Restriction Type : " + oldrpRestrictionType
	println "Old RestrictionDays Prior :" + oldrpRestrictionDaysPrior

	sleep(1*90*1000)
	and:"Invoke Dataloader to push data"
	pushData()
	sleep(5000)

	def json = getJson("rpRestriction" , "restrictionId CONTAINS \""+rpRestrictionId+"\"")

	
	println json
	
	then: "verify Rateplan Restriction correctly updated in atg"
	
	println "\n ATG Restriction Type  : " + json["restrictionType"]
	println "\n ATG RestrictionDays Prior  : " + json["daysPrior"]
	
	
	softAssert.assertTrue(json["restrictionType"].toLowerCase() == rpRestrictionType.toLowerCase().replace(" ","") , "Rateplan Restriction Type not updated  in atg!! \n Expected: $rpRestrictionType , actual: " +json["restrictionType"])
	softAssert.assertTrue(json["daysPrior"] == rpRestrictionDaysPrior.toString() , "Rateplan Restriction Days Prior  in atg!! \n Expected: $rpRestrictionDaysPrior , actual: " +json["daysPrior"])
	
	softAssert.assertAll()
	where:
	row << getExcelRowList(file)
}
	
	def verifyCoherenceData() {
		given: "Data is pushed to Coherence"
		incrementalPushtoCoherence()
		println "\n Cohernece Validation \n"
		
		RestrictionPolicy restrictionCondition = verifyCoherenceRestrictions(contractId,rpRestrictionId)

		softAssert.assertEquals("NO_NAME_CHANGES", restrictionCondition.getRestrictionType(), "Rateplan Restriction DaysPrior not updated  in Coherence!! \n Expected: $rpRestrictionType , actual: " +restrictionCondition.getRestrictionType())
		println " GC Rateplan Restriction Type : " +rpRestrictionType +" Coherence Restriction Duration : " + restrictionCondition.getRestrictionType()

		softAssert.assertEquals(rpRestrictionDaysPrior.toString(), restrictionCondition.getDaysPrior().toString(), "Rateplan Restriction DaysPrior not updated  in Coherence!! \n Expected: $rpRestrictionDaysPrior , actual: " +restrictionCondition.getDaysPrior())
		println " GC Rateplan Restriction DaysPrior : " +rpRestrictionDaysPrior +" Coherence Restriction Duration : " + restrictionCondition.getDaysPrior()
		
		softAssert.assertAll()
		
		
	}

def cleanupData(){
	given: "Data is pushed to Coherence"
	openRatePlanPage()
	editRatePlanRestriction(contractId,ratePlanId,rpRestrictionId,oldrpRestrictionType,oldrpRestrictionDaysPrior)
	sleep(1*90*1000)
	pushData()
	sleep(5000)
	incrementalPushtoCoherence()
	
}

}
