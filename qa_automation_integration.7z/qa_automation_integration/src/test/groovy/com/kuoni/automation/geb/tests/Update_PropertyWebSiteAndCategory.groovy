package com.kuoni.automation.geb.tests
import static com.kuoni.qa.automation.util.TestUtil.*

import org.testng.asserts.SoftAssert

import spock.lang.Shared
import spock.lang.Unroll

import com.kuoni.qa.automation.common.properties.EnvironmentProperties;
import com.kuoni.qa.automation.common.util.ExcelUtil

class Update_PropertyWebSiteAndCategory extends GCContent{
		
	@Shared
	def file = "//src//test//groovy//com//kuoni//automation//geb//data//GC_TestData_For_Property_38.xlsx"
	SoftAssert softAssert = new SoftAssert()
	def oldWebSite
	def oldCategory
	EnvironmentProperties envprop = new EnvironmentProperties()
	def sheetName = envprop.getValueForProperty("excelSheetName")
	
	@Unroll
	def "Verify Property category and Website CB-5901 "(){
		
		given: "the property details to update in GC"
		
		def excelDataFilePath =System.getProperty("user.dir")+ "//src//test//groovy//com//kuoni//automation//geb//data//GC_TestData_For_Property_38.xlsx"
		
		ExcelUtil excelUtil = new ExcelUtil(excelDataFilePath)
		country = excelUtil.getCellAsString(sheetName, row, "country").toString().trim()
		city = excelUtil.getCellAsString(sheetName, row, "city").toString().trim()
		propertyName= excelUtil.getCellAsString(sheetName, row, "hotel").toString().trim()
		
		def propertyId = excelUtil.getCellAsString(sheetName, row, "propertyId")
		
		def newwebsite = excelUtil.getCellAsString(sheetName, row, "newwebsite").toString().trim()
		def newcategory = excelUtil.getCellAsString(sheetName, row, "newcategory").toString().trim()
		
		def categoryCode = excelUtil.getCellAsString(sheetName, row, "categoryCode").toString().trim()

		oldWebSite = excelUtil.getCellAsString(sheetName, row, "oldWebSite").toString().trim()
		oldCategory =  excelUtil.getCellAsString(sheetName, row, "oldCategory").toString().trim()
		

		when: "Update Category and Website in GC Connect"
			
		openContentPage()
		
		updatePropertyWebSite(newwebsite)
		
		println "Existing website"	+ oldWebSite
		updatePropertyCategory(newcategory)
		println "Existing category"	+ oldCategory
		sleep(1*90*1000)
		and:"Invoke Dataloader to push data"
		pushData()	
		sleep(5000)	
		
		def json = getJson("product" , "externalReferenceId EQUALS \""+propertyId+"\"")
		
		
		println json
		
		then: "verify website and category correctly loaded in atg"
		
		println "\n ATG WebSite : " + json["website"]
		println "ATG Category: " + json["propertyCategory"]
		
		def expdCategory = "CategorypropertyCategory:"+	propertyId+"-"+ categoryCode 
	
		softAssert.assertTrue(json["website"].replace("http://","") == newwebsite , "Website not updated correctly in atg!! \n Expected: $newwebsite , actual: " +json["website"])
//		softAssert.assertTrue(json["propertyCategory"] == expdCategory, "PropertyCategory not updated correctly in ATG!!\n Expected: $expdCategory, Actual: " + json["propertyCategory"]  )
		
		softAssert.assertAll()
		where:
		row << getExcelRowList(file)
	}
	
	def cleanup(){
		openContentPage()
		updatePropertyWebSite(oldWebSite)
		updatePropertyCategory(oldCategory)
		
		sleep(1*90*1000)
		pushData()
		sleep(5000)
		
	}


}
