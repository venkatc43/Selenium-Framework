package com.kuoni.automation.geb.page

import geb.Page;

class InternalPropertyLoginPage extends Page {
	static url = "https://internal.test.gta-travel.com/gs/auth/securelogin?targetUri=/admin/propertyShell/"
	static content = {
        webId(wait: true) { $("#qualifier") }
		userName { $("#username") }
		password { $("#password") }
		
        loginButton { $("#login") }
    }
	
	void login(String webIdStr, String userNameStr, String passwordStr){
		webId.value webIdStr
		userName.value userNameStr
		password.value passwordStr
		loginButton.click()
	}
}
