package com.kuoni.automation.geb.tests

import org.testng.asserts.SoftAssert;

import com.gta.nova.roomsupplement.model.RoomSupplement
import com.kuoni.qa.automation.common.properties.EnvironmentProperties;
import com.kuoni.qa.automation.common.util.ExcelUtil
import static com.kuoni.qa.automation.util.GetCoherenceObject.*
import static com.kuoni.qa.automation.util.TestUtil.*
import spock.lang.Shared;
import spock.lang.Unroll;

class Update_Contract_RoomSupplement_CB7487 extends GCContract{
	
	
	
	@Shared
	def file = "//src//test//groovy//com//kuoni//automation//geb//data//GC_TestData_For_Property_38.xlsx"
	SoftAssert softAssert = new SoftAssert()
	
	def static oldroomSuppType = "1st Extra Person"
	def static oldroomSuppAgeMin = 2
	def static oldroomSuppAgeMax = 18
	def static oldroomSuppPrice = 25
	def static roomSuppId
	def static roomSuppType
	def static roomSuppAgeMin
	def static roomSuppAgeMax
	def static roomSuppPrice
	EnvironmentProperties envprop = new EnvironmentProperties()
	def sheetName = envprop.getValueForProperty("excelSheetName")
	
	@Unroll
	def "Verify Contract Room Supplement in DynAdmin"(){
		
	
	given: "The Contract Room Supplement details are  updated in GC"
	
	def excelDataFilePath =System.getProperty("user.dir")+ "//src//test//groovy//com//kuoni//automation//geb//data//GC_TestData_For_Property_38.xlsx"
	
	ExcelUtil excelUtil = new ExcelUtil(excelDataFilePath)
	country = excelUtil.getCellAsString(sheetName, row, "country").toString().trim()
	roomId = excelUtil.getCellAsString(sheetName, row, "roomId").toString().trim()
	propertyName= excelUtil.getCellAsString(sheetName, row, "hotel").toString().trim()
	contractId =  excelUtil.getCellAsString(sheetName, row, "Contract").toString().trim()
	def propertyId = excelUtil.getCellAsString(sheetName, row, "propertyId")
	roomSuppId= excelUtil.getCellAsString(sheetName, row, "roomSuppId")
	
	 roomSuppType=	excelUtil.getCellAsString(sheetName, row, "roomSuppType").toString().trim()
	 roomSuppAgeMin = excelUtil.getCell(sheetName, row, "roomSuppAgeMin").getNumericCellValue().intValue()
	 roomSuppAgeMax=	excelUtil.getCell(sheetName, row, "roomSuppAgeMax").getNumericCellValue().intValue()
	 roomSuppPrice = excelUtil.getCell(sheetName, row, "roomSuppPrice").getNumericCellValue()
	

	when: "Update Contract Room Supplement in GC Connect"
		
	openContractPage()
	
	editContractRoomSupplement(contractId,roomSuppType,roomSuppAgeMin,roomSuppAgeMax,roomSuppPrice,roomSuppId)
	
	println "GC Old roomSuppType : " + oldroomSuppType
	println "GC old roomSuppAgeMin : " + oldroomSuppAgeMin
	println "GC Old roomSuppAgeMax : " + oldroomSuppAgeMax
	println "GC old roomSuppPrice : " + oldroomSuppPrice
	
	
	sleep(1*90*1000)
	and:"Invoke Dataloader to push data"
	pushData()
	sleep(5000)
	
	def json = getJson("roomSupplement" , "roomSupplementId CONTAINS \""+roomSuppId+"\"")
	
	println json
	
	then: "verify Contract Room Supplement loaded in atg"
	
	
	println "Atg RoomSupplement Type : " + json["type"]
	println "Atg RoomSupplement Min Age : " + json["ageFrom"]
	println "Atg RoomSupplement Max Age : " + json["ageTo"]
	println "Atg RoomSupplement Price : " + json["price"]
	
	softAssert.assertTrue(json["type"] == roomSuppType.replaceAll(" ","") , "Contract roomSupp Type not updated  in atg!! \n Expected: $roomSuppType , actual: " +json["type"])
	softAssert.assertTrue(json["ageFrom"] == roomSuppAgeMin.toString() , "Contract roomSup Min Age not updated  in atg!! \n Expected: $roomSuppAgeMin , actual: " +json["ageFrom"])
	softAssert.assertTrue(json["ageTo"] == roomSuppAgeMax.toString() , "Contract roomSup MaxAge not updated  in atg!! \n Expected: $roomSuppAgeMax , actual: " +json["ageTo"])
	softAssert.assertTrue(json["price"] == roomSuppPrice.toString() , "Contract roomSup Price not updated  in atg!! \n Expected: $roomSuppPrice , actual: " +json["price"])
	
	softAssert.assertAll()
	where:
	row << getExcelRowList(file)
}
	
	def verifyCoherenceData() {
		given: "Data is pushed to Coherence"
		incrementalPushtoCoherence()
		println "\n Cohernece Validation \n"
		RoomSupplement roomSupplement =	getCoherenceRoomSuppDetails(contractId,roomSuppId)
		
		softAssert.assertEquals(roomSuppAgeMin.toString(), roomSupplement.getMinimumAge().toString(), "RoomSupplement Min Age not updated  in Coherence!! \n Expected: $roomSuppAgeMin , actual: " +roomSupplement.getMinimumAge().toString())
		println "Coherence Room Supplement Min Age " + roomSupplement.getMinimumAge().toString()
		
		softAssert.assertEquals(roomSuppAgeMax.toString(), roomSupplement.getMaximumAge().toString(), "RoomSupplement Max Age not updated  in Coherence!! \n Expected: $roomSuppAgeMax , actual: " +roomSupplement.getMaximumAge().toString())
		println "Coherence Room Supplement Max Age " + roomSupplement.getMaximumAge().toString()
		
		softAssert.assertEquals(roomSuppPrice.toString(), roomSupplement.getPrice().toString(), "RoomSupplement Price not updated  in Coherence!! \n Expected: $roomSuppPrice , actual: " +roomSupplement.getPrice().toString())
		println "Coherence Room Supplement Price " + roomSupplement.getPrice().toString()
		softAssert.assertAll()
	}

def cleanupData(){
	given: "Data is pushed to Coherence"
	openContractPage()
	editContractRoomSupplement(contractId,oldroomSuppType,oldroomSuppAgeMin,oldroomSuppAgeMax,oldroomSuppPrice,roomSuppId)
	sleep(1*90*1000)
	pushData()
	sleep(5000)
	incrementalPushtoCoherence()
	
}

}
