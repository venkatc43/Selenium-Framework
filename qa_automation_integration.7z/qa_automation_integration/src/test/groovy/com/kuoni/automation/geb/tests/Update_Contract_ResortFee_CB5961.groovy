package com.kuoni.automation.geb.tests

import org.testng.asserts.SoftAssert;

import com.kuoni.qa.automation.common.properties.EnvironmentProperties;
import com.kuoni.qa.automation.common.util.ExcelUtil

import static com.kuoni.qa.automation.util.TestUtil.*
import spock.lang.Shared;
import spock.lang.Unroll;

class Update_Contract_ResortFee_CB5961 extends GCContract {
	
	@Shared
	def file = "//src//test//groovy//com//kuoni//automation//geb//data//GC_TestData_For_Property_38.xlsx"
	SoftAssert softAssert = new SoftAssert()
	
	def oldresortPaylocally = "false"
	def oldresortMaxAge = 6
	def oldresortPrice = 100
	def oldresortchargeType = "per stay"
	def resortFeeId
	EnvironmentProperties envprop = new EnvironmentProperties()
	def sheetName = envprop.getValueForProperty("excelSheetName")
	
	@Unroll
	def "Verify Contract Resort Fee in DynAdmin"(){
		
	
	given: "The Contract Resort Fee details are  updated in GC"
	
	def excelDataFilePath =System.getProperty("user.dir")+ file
	
	ExcelUtil excelUtil = new ExcelUtil(excelDataFilePath)
	country = excelUtil.getCellAsString(sheetName, row, "country").toString().trim()
	roomId = excelUtil.getCellAsString(sheetName, row, "roomId").toString().trim()
	propertyName= excelUtil.getCellAsString(sheetName, row, "hotel").toString().trim()
	contractId =  excelUtil.getCellAsString(sheetName, row, "Contract").toString().trim()
	def propertyId = excelUtil.getCellAsString(sheetName, row, "propertyId")
	
	
	def resortPaylocally=	excelUtil.getCellAsString(sheetName, row, "resortPaylocally").toString().trim()
	def resortMaxAge = excelUtil.getCell(sheetName, row, "resortMaxAge").getNumericCellValue().intValue()
	def resortPrice=	excelUtil.getCell(sheetName, row, "resortPrice").getNumericCellValue()
	def resortchargeType = excelUtil.getCellAsString(sheetName, row, "resortchargeType").toString().trim()
	resortFeeId = excelUtil.getCell(sheetName, row, "resortFeeId").getNumericCellValue().intValue()
	

	when: "Update Contract Room Supplement in GC Connect"
		
	openContractPage()
	
	editContractResortFee(contractId,resortPaylocally,resortMaxAge,resortPrice,resortchargeType,resortFeeId)
	
	println "GC  oldresortPaylocally : " + oldresortPaylocally
	println "GC  oldresortMaxAge : " + oldresortMaxAge
	println "GC  oldresortPrice : " + oldresortPrice
	println "GC  oldresortchargeType : " + oldresortchargeType
	
	
	sleep(1*90*1000)
	and:"Invoke Dataloader to push data"
	
	pushData()
	sleep(5000)
	
	def json = getJson("resortFee" , "resortFeeId CONTAINS \""+resortFeeId+"\"")
	
	println json
	
	then: "verify Contract Resort Fee loaded in atg"
	
	
	println "Atg resortPaylocally  : " + json["payLocally"]
	println "Atg resortMaxAge : " + json["ageTo"]
	println "Atg resortPrice  : " + json["price"]
	println "Atg resortchargeType  : " + json["pricePeriod"]
	
	softAssert.assertTrue(json["payLocally"] == resortPaylocally , "Contract resort Pay Locally not updated  in atg!! \n Expected: $resortPaylocally , actual: " +json["payLocally"])
	softAssert.assertTrue(json["ageTo"] == resortMaxAge.toString() , "Contract resort Max Age not updated  in atg!! \n Expected: $resortMaxAge , actual: " +json["ageTo"])
	softAssert.assertTrue(json["price"] == resortPrice.toString() , "Contract Resort Price not updated  in atg!! \n Expected: $resortPrice , actual: " +json["price"])
	softAssert.assertTrue(json["pricePeriod"] == "Night" , "Contract resort Charge type not updated  in atg!! \n Expected: $resortchargeType , actual: " +json["pricePeriod"])
	
	softAssert.assertAll()
	where:
	row << getExcelRowList(file)
}

def cleanup(){
	
	openContractPage()
	editContractResortFee(contractId,oldresortPaylocally,oldresortMaxAge,oldresortPrice,oldresortchargeType,resortFeeId)
	sleep(1*90*1000)
	pushData()
	sleep(5000)
	
}
	
	

}
