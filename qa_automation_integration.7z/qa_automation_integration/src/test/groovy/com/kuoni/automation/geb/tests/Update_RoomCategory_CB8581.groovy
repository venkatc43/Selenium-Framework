package com.kuoni.automation.geb.tests

import org.testng.asserts.SoftAssert;

import com.kuoni.qa.automation.common.properties.EnvironmentProperties;
import com.kuoni.qa.automation.common.util.ExcelUtil

import static com.kuoni.qa.automation.util.TestUtil.*
import spock.lang.Shared;
import spock.lang.Unroll;

class Update_RoomCategory_CB8581 extends GCContent {
	
	@Shared
	def file = "//src//test//groovy//com//kuoni//automation//geb//data//GC_TestData_For_Property_38.xlsx"
	SoftAssert softAssert = new SoftAssert()
	def oldPropertyType
	def oldRoomCat = null
	def newRoomCat = null
	EnvironmentProperties envprop = new EnvironmentProperties()
	def sheetName = envprop.getValueForProperty("excelSheetName")
	
	@Unroll
	def "Verify RoomCategory Type details "(){
		
		
		given: "the property details to update in GC"
		
		def excelDataFilePath =System.getProperty("user.dir")+ "//src//test//groovy//com//kuoni//automation//geb//data//GC_TestData_For_Property_38.xlsx"
		
		ExcelUtil excelUtil = new ExcelUtil(excelDataFilePath)
		country = excelUtil.getCellAsString(sheetName, row, "country").toString().trim()
		roomId = excelUtil.getCellAsString(sheetName, row, "roomId").toString().trim()
		propertyName= excelUtil.getCellAsString(sheetName, row, "hotel").toString().trim()
		def roomskuId =  excelUtil.getCellAsString(sheetName, row, "roomskuId")
		def propertyId = excelUtil.getCellAsString(sheetName, row, "propertyId")
		
		oldRoomCat = excelUtil.getCellAsString(sheetName, row, "oldRoomCat").toString().trim()
		newRoomCat = excelUtil.getCellAsString(sheetName, row, "newRoomCat").toString().trim()
		

		when: "Update Room Category in GC Connect"
			
		openContentPage()
		
		editRoomCategory(roomId,newRoomCat)
		
		println "Old Room Cat : " + oldRoomCat
		sleep(1*90*1000)
		and:"Invoke Dataloader to push data"
		pushData()
		sleep(5000)
		
		def json = getJson("roomSku" , "roomId CONTAINS \""+roomId+"\"")
		
		
		println json
		
		then: "verify Room Details correctly loaded in atg"
		
		println "\n ATG RoomCategory  : " + json["roomCategory"]
		
		println "\n : Category DLX is Deluxe :"
		
		softAssert.assertTrue(json["roomCategory"] == "DLX" , "Room Category not updated  in atg!! \n Expected: $newRoomCat , actual: " +json["roomCategory"])
		
		softAssert.assertAll()
		where:
		row << getExcelRowList(file)
	}
	
	def cleanup(){
		openContentPage()
		editRoomCategory(roomId,oldRoomCat)
		sleep(1*90*1000)
		pushData()
		sleep(5000)
	}


}
