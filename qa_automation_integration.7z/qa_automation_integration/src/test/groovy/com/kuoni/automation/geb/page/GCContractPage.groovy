package com.kuoni.automation.geb.page

import geb.Page

import org.openqa.selenium.WebElement
import org.openqa.selenium.By
import org.openqa.selenium.interactions.Actions
import org.openqa.selenium.support.ui.WebDriverWait
class GCContractPage extends Page {

	
	static at = { title == "GTA Connect" }
	
	static content = {
		
//		selectContracts{$("#propertyContract_14708")}
		selectContractCancellation {$("#cancellation_21500")}
		cancelDaysPrior {$("#contractCancellation-edit-daysPrior")}
		cancelPercentage {$("#contractCancellation-edit-percentage")}
		CancelChargeDuration {$("#contractCancellation-edit-chargeDuration")}
		CancellationUpdateButton {$("input", name:"cancellationEdit")}
		selectContractRestriction {$("#restriction_7458")}
		restrictionDaysPrior{$("#contractRestriction-edit-daysPrior")}
		restrictionUpdateButton{$("#restrictionEdit")}
		selectRatePlan{$("#ratePlan_19391")}
		restrictionMenu{$("#restrictionContentMenuOptions-root")}
		restrictionEdit{$("a", text: "Edit")}
		selectRateplanCancellation{$("#cancellation_21613")}
		rateplanCanceldaysPrior{$("#ratePlanCancellation-edit-daysPrior")}
		rateplanCancelPercentage{$("#ratePlanCancellation-edit-percentage")}
		rateplanUpdateButton{$("#cancellationEdit")}
		selectRPRestriction{$("#restriction_7490")}
		rpRestrictionType{$("#ratePlanRestriction-edit-restrictionType")}
		rpRestrictionDaysprior{$("#ratePlanRestriction-edit-daysPrior")}
		restrictionUpdateButton{$("#restrictionEdit")}
		selectRoomSupplement{$("#roomSupplement_12713")}
		roomSupplementMenu{$("#roomSupplementContentMenuOptions-root")}
		roomSupplementType{$("#roomSupplementUpd-type")}
		roomSuppAgeFrom{$("#roomSupplementUpd-ageFrom")}
		roomSuppAgeTo{$("#roomSupplementUpd-ageTo")}
		roomSupPrice{$("#roomSupplementUpd-price")}
		roomSuppUpdateButton{$("#roomSupplementEdit")}
		resortFeeSelect{$("#resortFee_2545")}
		resortFeePaylocally{$("#payLocally")}
		resortFeeMaxAge{$("#resortFeeEdit-ageTo")}
		resortFeePrice{$("#price")}
		resortFeeRateperiod{$("#ratePeriod")}
		resortFeeUpdateButton{$("#resortFeeEdit")}
		selectContractTax{$("#tax_5924")}
		contractTaxEdit{$("#upd-tax-ctr-tax1")}
		taxUpdateButton{$("#taxEdit")}
		selectRoomSuppTax{$("#tax_5925")}
		selectBaseTaxApplies{$("#upd-tax-sup-baseAppliesNo")}
		editRoomSuppTax{$("#upd-tax-sup-tax1")}
		
	}
	
	def modifyContractTax(contractId,contractTaxPercentage,contractTaxId){
		
		selectContract(contractId)
		
		def contractTax = "#tax_"+contractTaxId
		
		waitFor(5){$(contractTax).displayed}
		$(contractTax).click()
		sleep(2000)
		WebElement menuOptionElement = driver.findElement(By.id("taxContentMenuOptions-root"))
		selectOption(menuOptionElement,"/html/body/div/div/div[7]/div[3]/table/tbody/tr/td/div[2]/div/table/tbody/tr[7]/td/div/div[2]/table/tbody/tr[5]/td/div[1]/span[2]/ul/li/ul/li[4]/a")
		
		contractTaxEdit=contractTaxPercentage
		taxUpdateButton.click()
		
			
	}
	
	def modifyRoomSuppTax(contractId,roomSuppTaxId,newBaseTax,roomSuppTax){
		
		selectContract(contractId)
		
		def contractRoomSuppTax = "#tax_"+roomSuppTaxId
		waitFor(5){$(contractRoomSuppTax).displayed}
		$(contractRoomSuppTax).click()
		sleep(3000)
		
		WebElement menuOptionElement = driver.findElement(By.id("taxContentMenuOptions-root"))
		selectOption(menuOptionElement,"/html/body/div/div/div[7]/div[3]/table/tbody/tr/td/div[2]/div/table/tbody/tr[7]/td/div/div[2]/table/tbody/tr[5]/td/div[1]/span[2]/ul/li/ul/li[4]/a")
		
		selectBaseTaxApplies=newBaseTax
		waitFor(3){editRoomSuppTax.present}
		editRoomSuppTax=roomSuppTax
		taxUpdateButton.click()
		
	}
	
	
	
	def modifyContractResortFee(contractId,resortPaylocally,resortMaxAge,resortPrice,resortchargeType,resortFeeId)
	{
		selectContract(contractId)
		
		def resortFee = "#resortFee_"+resortFeeId
		
		waitFor(5){$(resortFee).displayed}
		$(resortFee).click()
		sleep(3000)
		WebElement menuOptionElement = driver.findElement(By.id("resortFeeContentMenuOptions-root"))
		selectOption(menuOptionElement,"/html/body/div/div/div[7]/div[3]/table/tbody/tr/td/div[2]/div/table/tbody/tr[7]/td/div/div[2]/table/tbody/tr[3]/td/div[1]/span[2]/ul/li/ul/li[4]/a")
		waitFor(5){resortFeePaylocally.present}
		resortFeePaylocally=resortPaylocally
		resortFeeMaxAge=resortMaxAge
		resortFeePrice=resortPrice
		resortFeeRateperiod=resortchargeType
		resortFeeUpdateButton.click()
			
	}
	
	
	def modifyContractRoomSupplement(contractId,roomSuppType,roomSuppAgeMin,roomSuppAgeMax,roomSuppPrice,roomSuppId)
	{
		selectContract(contractId)
		
		def roomSupplement = "#roomSupplement_"+roomSuppId
		waitFor(5){$(roomSupplement).displayed}
		$(roomSupplement).click()
		sleep(5000)
		WebElement menuOptionElement = driver.findElement(By.id("roomSupplementContentMenuOptions-root"))
		selectOption(menuOptionElement,"/html/body/div/div/div[7]/div[3]/table/tbody/tr/td/div[2]/div/table/tbody/tr[7]/td/div/div[2]/table/tbody/tr[2]/td/div[1]/span[2]/ul/li/ul/li[4]/a")
		waitFor(5){roomSupplementType.present}
		roomSupplementType=roomSuppType
		roomSuppAgeFrom=roomSuppAgeMin
		roomSuppAgeTo=roomSuppAgeMax
		roomSupPrice=roomSuppPrice
		roomSuppUpdateButton.click()
		
	}
	
	def selectOption(WebElement element, String option)
	{	
		Actions action = new Actions(driver)
		def test = action.moveToElement(element).build()
		test.perform()
		def mouseover = action.clickAndHold(element)
	//	mouseover.perform()
		WebElement menuOption = driver.findElement(By.xpath(option))
		menuOption.click()
		mouseover.release()
		mouseover.perform()
	}
	
	
	
	def selectOption(String option,WebElement element)
	{
		Actions action = new Actions(driver)
		def test = action.moveToElement(element).build()
		test.perform()
		def mouseover = action.clickAndHold(element)
		//mouseover.perform()
		WebElement menuOption = driver.findElement(By.linkText(option))
		menuOption.click()
		mouseover.release()
		mouseover.perform()
	}
	
	
	def modifyRPrestriction(contractId,ratePlanId,rpRestrictionId,rpRestrictiontype,rpRestrictionDaysPrior)
	{
		selectContract(contractId)
		selectRateplan(ratePlanId)
		
		def rateplanRestriction = "#restriction_"+rpRestrictionId
				
		waitFor(10){$(rateplanRestriction).displayed}
		$(rateplanRestriction).click()
		sleep(2000)
		WebElement menuOptionElement = driver.findElement(By.id("restrictionContentMenuOptions-root"))
		selectOption(menuOptionElement,"/html/body/div/div/div[7]/div[3]/table/tbody/tr/td/div[2]/div/table/tbody/tr[7]/td/div/div[2]/table/tbody/tr/td/div[2]/div[2]/table/tbody/tr[2]/td/div/div[3]/table/tbody/tr[3]/td/div[1]/span[2]/ul/li/ul/li[4]/a")
		waitFor(10){rpRestrictionType.present}
		rpRestrictionType=rpRestrictiontype
		rpRestrictionDaysprior=rpRestrictionDaysPrior
		restrictionUpdateButton.click()
		
		
	}
	
	
	def modifyRateplanCancellation(contractId,ratePlanId,rpCacelId,newrpCanceldays,newrpCancelPercentage)
	{
		selectContract(contractId)
		selectRateplan(ratePlanId)
		
		def rpCancellation = "#cancellation_"+rpCacelId
		
		waitFor(10){$(rpCancellation).displayed}
		$(rpCancellation).click()
		sleep(2000)
		WebElement menuOptionElement = driver.findElement(By.id("cancellationContentMenuOptions-root"))
		selectOption(menuOptionElement,"/html/body/div/div/div[7]/div[3]/table/tbody/tr/td/div[2]/div/table/tbody/tr[7]/td/div/div[2]/table/tbody/tr/td/div[2]/div[2]/table/tbody/tr[2]/td/div/div[3]/table/tbody/tr[2]/td/div[1]/span[2]/ul/li/ul/li[4]/a")
		waitFor(5){rateplanCanceldaysPrior.present}
		rateplanCanceldaysPrior=newrpCanceldays
		rateplanCancelPercentage=newrpCancelPercentage
		rateplanUpdateButton.click()
		
		
		
		
	}
	
	
	def selectRateplan(ratePlanId)
	{
		def ratePlan = "#ratePlan_"+ratePlanId
		
		waitFor(10){$(ratePlan).displayed}
		$(ratePlan).click()
	}
	
	def modifyContractRestriction(contractId,contract_restrictionDays,contractRestrictionId)
	{
		selectContract(contractId)
		sleep(3000)
		
		contractRestrictionId = "#restriction_"+contractRestrictionId
		$(contractRestrictionId).click()
		sleep(2000)
		WebElement menuOptionElement = driver.findElement(By.id("restrictionContentMenuOptions-root"))
		selectOption(menuOptionElement,"/html/body/div/div/div[7]/div[3]/table/tbody/tr/td/div[2]/div/table/tbody/tr[7]/td/div/div[2]/table/tbody/tr[4]/td/div[1]/span[2]/ul/li/ul/li[3]/a")
		waitFor{restrictionDaysPrior.present}
		restrictionDaysPrior=contract_restrictionDays
		restrictionUpdateButton.click()
		
	}
	
	
	def clickOnHeader(String headerName){
		$("a" , text: headerName).click()
	}
	
	def selectContract(def contractId)
	{
		contractId = "#propertyContract_"+contractId
		//waitFor(10){$(contractId).present}
		waitFor(10){$(contractId).displayed}
		$(contractId).click()
	}
	
	def selectCCancellation(ccancelId)
	{
//		waitFor{$("#cancellation_"+ccancelId).present}
		
		waitFor(10){$("#cancellation_"+ccancelId).displayed}
		$("#cancellation_"+ccancelId).click()
	}
	
	def modifyContractCancellation(contractId,newCCDays,newCCPercentage,newCCNights,ccancelId)
	{
		selectContract(contractId)
		selectCCancellation(ccancelId)
		sleep(3000)
		WebElement menuOptionElement = driver.findElement(By.id("cancellationContentMenuOptions-root"))
		selectOption(menuOptionElement,"/html/body/div/div/div[7]/div[3]/table/tbody/tr/td/div[2]/div/table/tbody/tr[7]/td/div/div[2]/table/tbody/tr[3]/td/div[1]/span[2]/ul/li/ul/li[3]/a")
		waitFor{cancelDaysPrior.present}
		cancelDaysPrior=newCCDays
		cancelPercentage=newCCPercentage
		CancelChargeDuration=newCCNights
		CancellationUpdateButton.click()
		
		
	}	
}
