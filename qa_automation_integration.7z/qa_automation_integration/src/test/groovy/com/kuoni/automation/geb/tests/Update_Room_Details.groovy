package com.kuoni.automation.geb.tests

import org.testng.asserts.SoftAssert;

import static com.kuoni.qa.automation.util.TestUtil.*
import static com.kuoni.qa.automation.util.GetCoherenceObject.*
import com.gta.nova.coherence.property.model.Room
import com.kuoni.qa.automation.common.properties.EnvironmentProperties;
import com.kuoni.qa.automation.common.util.ExcelUtil

import static com.kuoni.qa.automation.util.GcTestsHelper_toget_Atg_Ids.*
import spock.lang.Shared;
import spock.lang.Unroll;

class Update_Room_Details extends GCContent {
	
	@Shared
	def file = "//src//test//groovy//com//kuoni//automation//geb//data//GC_TestData_For_Property_38.xlsx"
	SoftAssert softAssert = new SoftAssert()
	
	def static oldBeds = 2
	def static oldMaxOccupancy = 3
	def static oldRateBasis = 2
	def static oldExtraBeds = 1
	def static oldCots = 1
	def static propertyId
	def static beds
	def static maxOccupancy
	def static rateBasis
	def static extraBeds
	def static cots
	EnvironmentProperties envprop = new EnvironmentProperties()
	def sheetName = envprop.getValueForProperty("excelSheetName")
	
	
	
	@Unroll
	def "Verify Property Room Details "(){
		
		given: "the Room exists i in GC"
		
		def excelDataFilePath =System.getProperty("user.dir")+file
		
		ExcelUtil excelUtil = new ExcelUtil(excelDataFilePath)
		country = excelUtil.getCellAsString(sheetName, row, "country").toString().trim()
		city = excelUtil.getCellAsString(sheetName, row, "city").toString().trim()
		propertyName= excelUtil.getCellAsString(sheetName, row, "hotel").toString().trim()
		roomId = excelUtil.getCellAsString(sheetName, row, "roomId").toString().trim()
		propertyId = excelUtil.getCellAsString(sheetName, row, "propertyId")
//		def roomskuId =  excelUtil.getCellAsString(sheetName, row, "roomskuId")
		beds = excelUtil.getCell(sheetName, row, "beds").getNumericCellValue().intValue()
		maxOccupancy = excelUtil.getCell(sheetName, row, "maxOccupancy").getNumericCellValue().intValue()
		rateBasis = excelUtil.getCell(sheetName, row, "rateBasis").getNumericCellValue().intValue()
		extraBeds = excelUtil.getCell(sheetName, row, "extraBeds").getNumericCellValue().intValue()
		cots = excelUtil.getCell(sheetName, row, "cots").getNumericCellValue().intValue()

		
		when: "Update Room details in GC Connect"
			
		openContentPage()
		
		println "Existing Beds : "	+ oldBeds
		println "Existing Max Occupancy : "	+ oldMaxOccupancy
		println "Existing RateBasis : "	+ oldRateBasis
		println "Existing Extra Beds : "	+ oldExtraBeds
		println "Existing Cots : "	+ oldCots
		
		updateRoomDetails(roomId,beds,maxOccupancy,rateBasis,extraBeds,cots)
		
		sleep(1*90*1000)
		and:"Invoke Dataloader to push data"
		pushData()
		sleep(5000)
		
//		def roomSkuID = getRoomSkuId(roomId)
		def json = getJson("roomSku" , "roomId CONTAINS \""+roomId+"\"")
		
		
		println json
		
		then: "verify Room Details  loaded in atg"
		
		println "\n ATG Beds : " + json["beds"]
		println "ATG Max Occupancy: " + json["maxOccupancy"]
		println "\n ATG RateBasis : " + json["rateBasis"]
		println "ATG  Extra Beds: " + json["extraBed"]
		println "ATG Cots : " + json["cots"]
		
		softAssert.assertTrue(json["beds"] == beds.toString() , "Beds not updated correctly in atg!! \n Expected: $beds , actual: " +json["beds"])
		softAssert.assertTrue(json["maxOccupancy"] == maxOccupancy.toString(), "Max Occupancy not updated correctly in ATG!!\n Expected: $maxOccupancy, Actual: " + json["maxOccupancy"]  )
		softAssert.assertTrue(json["rateBasis"] == rateBasis.toString() , "RateBasis not updated correctly in atg!! \n Expected: $rateBasis , actual: " +json["rateBasis"])
		softAssert.assertTrue(json["extraBed"] == extraBeds.toString(), "ExtraBed not updated correctly in ATG!!\n Expected: $extraBeds, Actual: " + json["extraBed"]  )
		softAssert.assertTrue(json["cots"] == cots.toString(), "Cots not updated correctly in ATG!!\n Expected: $cots, Actual: " + json["cots"]  )
		
		softAssert.assertAll()
		
		
		where:
		row << getExcelRowList(file)
	}
	
	def verifyCoherenceData() {
		given: "Data is pushed to Coherence"
		incrementalPushtoCoherence()
		println "\n Cohernece Validation \n"
		Room room =	getCohPropertyRoomDetails(propertyId.toString(),roomId.toInteger())
		
		softAssert.assertEquals(beds, room.getNumberOfBeds(), "Room Bedsnot updated  in Coherence!! \n Expected: $beds , actual: " +room.getNumberOfBeds())
		println "Coherence Room Beds " + room.getNumberOfBeds()
		
		softAssert.assertEquals(maxOccupancy, room.getMaxOccupancy(), "Room Max Occupancy not updated  in Coherence!! \n Expected: $maxOccupancy , actual: " +room.getMaxOccupancy())
		println "Coherence Room Max Occupancy " + room.getMaxOccupancy()
		
		softAssert.assertEquals(extraBeds, room.getNumberOfExtraBeds(), "Room Extra Beds not updated  in Coherence!! \n Expected: $extraBeds , actual: " +room.getNumberOfExtraBeds())
		println "Coherence Room ExtraBeds " + room.getNumberOfExtraBeds()
		
		softAssert.assertEquals(rateBasis, room.getRateBasis(), "Room Rate Basis not updated  in Coherence!! \n Expected: $rateBasis , actual: " +room.getRateBasis())
		println "Coherence Room Rate Basis " + room.getRateBasis()
		
		softAssert.assertAll()
	}
	
	def cleanupData(){
		given: "Data is pushed to Coherence"
		openContentPage()
		updateRoomDetails(roomId,oldBeds,oldMaxOccupancy,oldRateBasis,oldExtraBeds,oldCots)
		sleep(1*90*1000)
		pushData()
		sleep(5000)
		
	}


}
