package com.kuoni.automation.geb.tests

import org.testng.asserts.SoftAssert;
import static com.kuoni.qa.automation.util.GetCoherenceObject.*
import com.gta.nova.propertycontract.model.PropertyContract
import com.kuoni.qa.automation.common.properties.EnvironmentProperties;
import com.kuoni.qa.automation.common.util.ExcelUtil

import static com.kuoni.qa.automation.util.TestUtil.*
import spock.lang.Shared;
import spock.lang.Unroll;
import static com.kuoni.qa.automation.util.GcTestsHelper_toget_Atg_Ids.*
class Update_Contract_Margin_CB5948 extends GCContract{
	
	
	
	@Shared
	def file = "//src//test//groovy//com//kuoni//automation//geb//data//GC_TestData_For_Property_38.xlsx"
	SoftAssert softAssert = new SoftAssert()
	def static oldPropertyType
	def static oldMargin
	def static newMargin
	EnvironmentProperties envprop = new EnvironmentProperties()
	def sheetName = envprop.getValueForProperty("excelSheetName")
	
	@Unroll
	def "Verify ContractMargin in DynAdmin"(){
		
	
	given: "The Contract Margin details are  updated in GC"
	
	def excelDataFilePath =System.getProperty("user.dir")+ file
	
	ExcelUtil excelUtil = new ExcelUtil(excelDataFilePath)
	country = excelUtil.getCellAsString(sheetName, row, "country").toString().trim()
	roomId = excelUtil.getCellAsString(sheetName, row, "roomId").toString().trim()
	propertyName= excelUtil.getCellAsString(sheetName, row, "hotel").toString().trim()
	contractId =  excelUtil.getCellAsString(sheetName, row, "Contract")
	def marginId =excelUtil.getCellAsString(sheetName, row, "marginId").toString().trim()
	def propertyId = excelUtil.getCellAsString(sheetName, row, "propertyId")
	
	
	oldMargin=	excelUtil.getCellAsString(sheetName, row, "oldMargin")
	newMargin = excelUtil.getCellAsString(sheetName, row, "newMargin")

//	oldMargin = 50
//	newMargin = 60

	when: "Update Contract Margin in GC Connect"
		
	openContractPage()
	
	editContractMargin(contractId,newMargin)
	
	println "GC Old Margin : " + oldMargin
	println "GC New Margin : " + newMargin
	sleep(1*90*1000)
	and:"Invoke Dataloader to push data"
	pushData()
	sleep(5000)
	
	def contractMarginId = getContMarginId(contractId)
	
	def json = getJson("margin" , "id CONTAINS \""+contractMarginId+"\"")
	
	println json
	
	then: "verify Margin correctly loaded in atg"
	
	println "\n ATG Margin  : " + json["percentage"]
	
	
	softAssert.assertEquals(json["percentage"],newMargin.toString() , "Contract Margin not updated  in atg!! \n Expected: $newMargin , actual: " +json["percentage"])
	softAssert.assertAll()
	
	where:
	row << getExcelRowList(file)
}
	
	def verifyCoherenceData() {
		given: "Data is pushed to Coherence"
		incrementalPushtoCoherence()
		println "\n Cohernece Validation \n"
		PropertyContract propertyContract =	verifyCoherenceContractsandRateplans(contractId)
		softAssert.assertEquals(newMargin, propertyContract.getMargin().toString(), "Contract Margin not updated  in Coherence!! \n Expected: $newMargin , actual: " +propertyContract.getMargin())
		println "Coherence Contract Margin : " + propertyContract.getMargin()
		softAssert.assertAll()
	}

def cleanupData(){
	given: "Data is Changed in ATG "
	openContractPage()
	editContractMargin(contractId,oldMargin)
	sleep(1*90*1000)
	pushData()
	sleep(5000)
	incrementalPushtoCoherence()
	
}

}
