package com.kuoni.qa.automation.gc.testcases

import spock.lang.IgnoreIf
import spock.lang.Specification
import spock.lang.Stepwise;

import com.kuoni.qa.automation.datacreate.test.helper.PropertyFacilitiesAndServicesTestHelper
import com.kuoni.qa.automation.datacreate.test.helper.PropertyTestHelper
import com.kuoni.qa.constants.CommonConstants
import com.kuoni.qa.util.CommonUtil
import com.kuoni.qa.util.ConfigProperties
import com.kuoni.qa.util.TestSuiteProperties

@Stepwise
class PropertyMainAddressTest_CB_4232 extends Specification{

	PropertyTestHelper helper = new PropertyTestHelper()
	PropertyFacilitiesAndServicesTestHelper dataLoadHelper = new PropertyFacilitiesAndServicesTestHelper()
	boolean executionFlag1 = false
	
	@IgnoreIf({TestSuiteProperties.getVlaue("Ignore_PropertyMainAddressTest_CB_4232").equals("true")? true : false})
	def "edit property main address"(){
		
		when:"edit property main address from gc application"
		assert helper.editPropertyMainAddress("CB-4232-Update"), "error occurred while editing property main address from gc application"
		
		then:"Wait for the MEessage to appear on the Queue"
		sleep(Integer.parseInt(ConfigProperties.getVlaue("pollingInterval")))
		assert dataLoadHelper.loadDataintoAtg(),"Data Load to ATG Failed"
		
		then:"validate the data against ATG Database"
		sleep(5000)
		helper.verifyAddressDetails("CB-4232-Update")
		
	}
	
	@IgnoreIf({TestSuiteProperties.getVlaue("Ignore_PropertyMainAddressTest_CB_4232").equals("true")? true : false})
	def "revert back property main address"(){
		
		when:"edit property main address from gc application"
		assert helper.editPropertyMainAddress("CB-4232-Revert"), "error occurred while editing property main address from gc application"
		
		then:"Wait for the Message to appear on the Queue"
		sleep(Integer.parseInt(ConfigProperties.getVlaue("pollingInterval")))
		assert dataLoadHelper.loadDataintoAtg(),"Data Load to ATG Failed"
		
		then:"validate the data against ATG Database"
		sleep(5000)
		helper.verifyAddressDetails("CB-4232-Revert")
	}
	
	@IgnoreIf({TestSuiteProperties.getVlaue("Ignore_CloseWebdrver").equals("true")? true : false})
	def "close webdriver"(){
		
		when:""
		if(CommonConstants.webDriver != null){
			CommonConstants.webDriver.quit()
		}
		then:""
	}
	
}