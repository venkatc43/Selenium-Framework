package com.kuoni.qa.automation.dao

import com.kuoni.qa.automation.dto.ProductRoomsDTO

import java.sql.Connection
import java.sql.ResultSet
import java.sql.Statement

class GetProductDBdata {
	
	GetDatabaseConn db = null
	
		def ProductRoomsDTO getRoomdata(int roomId) {
	
			db = new GetDatabaseConn()
			Connection conn = db.getDBconnection()
			ProductRoomsDTO data = new ProductRoomsDTO()
			ResultSet rs = null
	
			try {
				
				Statement statement = conn.createStatement()
				String sql = "select ROOM_CATEGORY_CODE,ROOM_TYPE,ROOM_VIEW_CODE,MAX_OCCUPANCY,COTS,BEDS,EXTRA_BED,RATE_BASIS,EXISTING_BED,TWIN_BED,DOUBLE_BED,SINGLE_BED,TRIPLE_BED,QUAD_BED,TWIN_SOLE_USE,DOUBLE_SOLE_USE,BATH_SHOWER,ACTIVE from FIT_ROOMS where ROOM_ID="+roomId
	
				rs = statement.executeQuery(sql);
	
				while(rs.next()) {
	
					data.setRoomCategory(rs.getString("ROOM_CATEGORY_CODE"))
					data.setRoomType(rs.getString("ROOM_TYPE"))
					//data.setcountryDefaultCrncy(rs.getString("ROOM_VIEW"))
					data.setMaximumOccupcy(rs.getInt("MAX_OCCUPANCY"))
					data.setCots(rs.getInt("COTS"))
					data.setBeds(rs.getInt("BEDS"))
					data.setExtraBed(rs.getInt("EXTRA_BED"))
					data.setRateBasis(rs.getInt("RATE_BASIS"))
					data.setExistingBed(rs.getInt("EXISTING_BED"))
					data.setTwinBed(rs.getInt("TWIN_BED"))
					data.setDoubleBed(rs.getInt("DOUBLE_BED"))
					data.setSingleBed(rs.getInt("SINGLE_BED"))
					data.setTripleBed(rs.getInt("TRIPLE_BED"))
					data.setQuadBed(rs.getInt("QUAD_BED"))
					data.setTwinSoleUse(rs.getInt("TWIN_SOLE_USE"))
					data.setDoubleSoleUse(rs.getInt("DOUBLE_SOLE_USE"))
					data.setBathAndShower(rs.getInt("BATH_SHOWER"))
					data.setRoomActive(rs.getInt("ACTIVE"))
	
	
				}
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	
			finally{
	
				rs.close();
				conn.close();
			}
			return data
		}
	

}
