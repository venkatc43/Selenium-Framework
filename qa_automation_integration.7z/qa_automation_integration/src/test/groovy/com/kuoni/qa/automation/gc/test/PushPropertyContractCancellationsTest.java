//package com.kuoni.qa.automation.gc.test;

//public class PushPropertyContractCancellationsTest {

//}


package com.kuoni.qa.automation.gc.test;
import java.util.HashMap;
import java.util.Map;

import com.gta.travel.page.object.common.TopLinksPage;
import com.gta.travel.page.base.GSTestBase;
import com.gta.travel.page.object.contract.rateplans.RatePlanDetailsSectionPage;
import com.gta.travel.page.object.contract.rateplans.RatePlanStandardRateSectionPage;
import com.gta.travel.page.object.contract.search.ContractSearchPage;
import com.gta.travel.page.object.contract.search.ContractSearchResultsPage;
import com.kuoni.qa.automation.page.object.common.HomePageSub;
import com.kuoni.qa.automation.page.object.common.LoginPageSub;
import com.kuoni.qa.constants.CommonConstants;
import com.mediaocean.qa.framework.utils.ExcelUtil;




import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.SearchContext;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.gta.travel.page.object.contract.generaldetails.GeneralDetailsCancellationSectionPage;
import com.mediaocean.qa.framework.selenium.ui.controls.Button;
import com.mediaocean.qa.framework.selenium.ui.controls.ComboBox;
import com.mediaocean.qa.framework.selenium.ui.controls.Link;
import com.mediaocean.qa.framework.selenium.ui.controls.RadioButton;
import com.mediaocean.qa.framework.selenium.ui.controls.Table;
import com.mediaocean.qa.framework.selenium.ui.controls.TextBox;

public class PushPropertyContractCancellationsTest extends GSTestBase {

	private String userName;
	private String password;
	private String webId;

	private static String sheetName = null;

	private ContractSearchPage contractSearchPage;
	private ContractSearchResultsPage contractSearchResultsPage;
	private RatePlanStandardRateSectionPage rpDetailsSectionPage;
	private RatePlanDetailsSectionPage DetailsSectionPage;
	private GeneralDetailsCancellationSectionPage generalDetailsCancellations;
	private ExcelUtil excelData;
	private By driver;

	public PushPropertyContractCancellationsTest ( String driverSheetPath, String dataSheetPath, String sheetName ) {
		this.sheetName = sheetName;
		init(driverSheetPath, dataSheetPath);
	}

	public void init ( String driverSheetPath, String dataSheetPath ) {
		excelData = new ExcelUtil(dataSheetPath);

		if (driverSheetPath != null) {

			setDriverSheetAbsolutePath(driverSheetPath);
		} else {
			setDriverSheetFileName("Driver_Sheet.xls");
		}
		initialiseEnvironmentAndTest();
		openBrowser();
		setLoginInfo();
		if(CommonConstants.webDriver != null){
			CommonConstants.webDriver = getDriver();
		}
	}

	private void setLoginInfo ( ) {
		webId = excelUtil.getKeyValue(ENVIRONMENT, "webId");
		userName = excelUtil.getKeyValue(ENVIRONMENT, "userName");
		password = excelUtil.getKeyValue(ENVIRONMENT, "password");
	}

	public void executeDataScriptForCreate ( ) {
		executeLoginPageFlow();
		executeSearchScreenFlow();
		clickGeneraltab();
		clickCreateCancellation();
	}

	public void executeDataScriptForEdit ( ) {
		executeLoginPageFlow();
		executeSearchScreenFlow();
		clickGeneraltab();
		clickEditCancellation();
	}	

	public void executeDataScriptForDelete ( ) {
		executeLoginPageFlow();
		executeSearchScreenFlow();
		clickGeneraltab();
		executeDeleteCancellationSecPage();
	}	
	
	public void executeDataScriptForAllDataDelete() {
		generalDetailsCancellations = GeneralDetailsCancellationSectionPage.getInstance();
		generalDetailsCancellations.resetData();
	}
	
	private void executeLoginPageFlow ( ) {
		LoginPageSub loginPage = new LoginPageSub();
		HomePageSub homePage = loginPage.login(webId, userName, password);
		contractSearchPage = homePage.selectContract();
		contractSearchPage.sleep(2);
	}

	private void executeSearchScreenFlow ( ) {
		Map<String, String> searchDataMap = new HashMap<String, String>();
		// Set the search data to the map here.
		searchDataMap.put("Country", excelData.getKeyValue(sheetName, "Country"));
		searchDataMap.put("City", excelData.getKeyValue(sheetName, "City"));
		searchDataMap.put("Property Name", excelData.getKeyValue(sheetName, "Property Name"));
		contractSearchResultsPage = contractSearchPage.search(searchDataMap);
		contractSearchResultsPage.sleep(3);
		contractSearchResultsPage.selectFirstRowFromTheResults();
	}
	
	private void sleep(int seconds) {
		try {
			Thread.sleep(seconds * 1000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	private void clickGeneraltab() {
		TopLinksPage link = new TopLinksPage();
		link.clickGeneralDetailsTab();
		sleep(3);
	}
	
	public void clickCreateCancellation(){
		generalDetailsCancellations = GeneralDetailsCancellationSectionPage.getInstance();
		generalDetailsCancellations.selectCancellationOptions("Create");
		executeCreateCancellationSecPage();
		generalDetailsCancellations.saveCancellation();
	}
	
	public void clickEditCancellation() {
		generalDetailsCancellations = GeneralDetailsCancellationSectionPage.getInstance();
		Map<String, String> map = new HashMap<String, String>();
		map.put("all rates", excelData.getKeyValue(sheetName, "all rates"));
		map.put("days prior", excelData.getKeyValue(sheetName, "days prior"));
		Map<String, String> cancellationRecordMap = new HashMap<String, String>();
		cancellationRecordMap.put("Rate Type", excelData.getKeyValue(sheetName, "Rate Type"));
		cancellationRecordMap.put("Day/Time Prior", excelData.getKeyValue(sheetName, "Day/Time Prior"));
		cancellationRecordMap.put("Charge Condition",excelData.getKeyValue(sheetName, "Charge Condition"));
		generalDetailsCancellations.selectCancellationOptions("Refresh");
		generalDetailsCancellations.selectCancellation(cancellationRecordMap);
		generalDetailsCancellations.selectCancellationOptions("Edit");
		generalDetailsCancellations.editCancellation(map);
		generalDetailsCancellations.updateCancellation();
	}

	public void executeDeleteCancellationSecPage() {
		generalDetailsCancellations = GeneralDetailsCancellationSectionPage.getInstance();
		Map<String, String> cancellationRecordMap = new HashMap<String, String>();
		cancellationRecordMap.put("Rate Type", excelData.getKeyValue(sheetName, "Rate Type"));
		cancellationRecordMap.put("Day/Time Prior", excelData.getKeyValue(sheetName, "Day/Time Prior"));
		cancellationRecordMap.put("Charge Condition",excelData.getKeyValue(sheetName, "Charge Condition"));
		generalDetailsCancellations.selectCancellationOptions("Refresh");
		generalDetailsCancellations.selectCancellation(cancellationRecordMap);
		generalDetailsCancellations.selectCancellationOptions("Delete");
		generalDetailsCancellations.deleteCancellationWithOK();
	}	
	
	private void executeCreateCancellationSecPage() {
		Map<String, String> map = new HashMap<String, String>();
		map.put("days prior",
				excelData.getKeyValue(sheetName, "days prior"));
//		map.put("arrival time", excelData.getKeyValue(sheetName, "arrival time"));
		map.put("percentage",
				excelData.getKeyValue(sheetName, "percentage"));
		map.put("charge duration",
				excelData.getKeyValue(sheetName, "charge duration"));
		map.put("all rates", 
				excelData.getKeyValue(sheetName, "all rates"));
//		map.put("peak rates",	excelData.getKeyValue(sheetName, "peak rates"));
		generalDetailsCancellations.createCancellation(map);
	}
	
	private void executeEditCancellationSecPage() {
		Map<String, String> map = new HashMap<String, String>();
		map.put("days prior", 
				excelData.getKeyValue(sheetName, "days prior"));
		map.put("arrival time",
				excelData.getKeyValue(sheetName, "arrival time"));
		map.put("percentage", 
				excelData.getKeyValue(sheetName, "percentage"));
		map.put("charge duration",
				excelData.getKeyValue(sheetName, "charge duration"));
		map.put("all rates", 
				excelData.getKeyValue(sheetName, "all rates"));
		map.put("peak rates", 
				excelData.getKeyValue(sheetName, "peak rates"));
		generalDetailsCancellations.editCancellation(map);
	}
	
}
