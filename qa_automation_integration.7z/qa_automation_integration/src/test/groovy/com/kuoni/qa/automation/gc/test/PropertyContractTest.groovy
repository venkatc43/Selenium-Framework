package com.kuoni.qa.automation.gc.test

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;


import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.WebDriver

import com.gta.travel.page.base.GSTestBase
import com.gta.travel.page.object.common.HomePage;
import com.gta.travel.page.object.common.LoginPage;
import com.gta.travel.page.object.common.TopLinksPage;
import com.gta.travel.page.object.content.facilitiesandservices.CheckInDetailsPage;
import com.gta.travel.page.object.content.search.ContentSearchPage;
import com.gta.travel.page.object.content.search.ContentSearchResultsPage;
import com.kuoni.qa.automation.page.object.content.CategoryDetailsPage;
import com.kuoni.qa.automation.page.object.content.FacilitiesAndServicesDetailsPage;
import com.kuoni.qa.automation.page.object.content.PropertyMainAddressPage;
import com.kuoni.qa.automation.page.object.contracts.GeneralDetailsTaxSectionPageCustom
import com.kuoni.qa.constants.CommonConstants;
import com.mediaocean.qa.framework.selenium.ui.controls.Link;
import com.mediaocean.qa.framework.utils.ExcelUtil;

class PropertyContractTest extends GSTestBase {
	
	private LoginPage loginPage;
	private HomePage homePage;
	private ContentSearchPage contentSearchPage;
	private ContentSearchResultsPage contentSearchResultsPage;
	private FacilitiesAndServicesDetailsPage facilitiesAndServicesDetailsPage;
	private CategoryDetailsPage categoryDetailsPage;
	private PropertyMainAddressPage propertyMainAddressPage;
	private TopLinksPage topLinksPage;
	private CheckInDetailsPage checkInDetailsPage;
	private GeneralDetailsTaxSectionPageCustom generalDetailsTaxSectionPage;
	
	
	private String userName;
	private String password;
	private String webId;
	
	ExcelUtil data = null;
	private static String sheetName = null;
	
	
	public PropertyContractTest(String driverSheetPath, String dataSheetPath, String sheetName){
		this.sheetName = sheetName;
		init(driverSheetPath, dataSheetPath);
	}
	
	public void init(String driverSheetPath, String dataSheetPath){
		data = new ExcelUtil(dataSheetPath);
		if (driverSheetPath != null){
			setDriverSheetAbsolutePath(driverSheetPath);
		}
		initialiseEnvironmentAndTest();
		openBrowser();
		setLoginInfo();
		CommonConstants.webDriver = getDriver();
	}
	
	private void setLoginInfo() {
		webId = excelUtil.getKeyValue(ENVIRONMENT, "webId");
		userName = excelUtil.getKeyValue(ENVIRONMENT, "userName");
		password = excelUtil.getKeyValue(ENVIRONMENT, "password");
	}
	
		public executeDataScriptsForUpdateContractRSP()
		{
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSearchResultsScreenFlow();
		executeUpdateContractRSP();
		
		
		}
		
		
		public executeDataScriptsForcreateContractTax()
		{
			executeLoginPageFlow();
			executeSearchScreenFlow();
			executeSearchResultsScreenFlow();
			executeCreateTax();
		}
	
	
		private void executeLoginPageFlow(){
		loginPage = new LoginPage(getDriver());
		homePage = loginPage.login(webId, userName, password);
		contentSearchPage = homePage.selectContent();
		contentSearchPage.sleep(2);
	}
	
	private void executeSearchScreenFlow(){
		
		Map<String, String> searchDataMap = new HashMap<String, String>();
		searchDataMap.put("Country", data.getKeyValue(sheetName, "Country"));
		searchDataMap.put("City", data.getKeyValue(sheetName, "City"));
		searchDataMap.put("Property Name",data.getKeyValue(sheetName,"Property Name") );
		contentSearchResultsPage = contentSearchPage.search(searchDataMap);
		contentSearchResultsPage.sleep(2);
	}
	
	
	private void executeCreateTax(){
		topLinksPage.selectContractTab();
		topLinksPage.clickGeneralDetailsTab();
		Map<String, String> createDataMap = new HashMap<String, String>();
		createDataMap.put("Country", data.getKeyValue(sheetName, "Country"));
		createDataMap.put("City", data.getKeyValue(sheetName, "City"));
		createDataMap.put("Property Name",data.getKeyValue(sheetName,"Property Name") );
		contentSearchResultsPage = contentSearchPage.search(createDataMap);
		contentSearchResultsPage.sleep(2);
		generalDetailsTaxSectionPage.createTax(createDataMap);
	}
	
	private void executeSearchResultsScreenFlow(){
		
		Map<String, String> searchResultsDataMap = new HashMap<String, String>();
		searchResultsDataMap.put("Country", data.getKeyValue(sheetName, "Country"));
		searchResultsDataMap.put("City", data.getKeyValue(sheetName, "City"));
		searchResultsDataMap.put("Property Name", data.getKeyValue(sheetName, "Property Name"));
		topLinksPage = contentSearchResultsPage.selectRecordFromSearchResults(searchResultsDataMap);
		topLinksPage.sleep(3);

	}
	
	
	private void executeUpdateContractRSP()
	{
		topLinksPage.selectContractTab();
		topLinksPage.clickGeneralDetailsTab();
		WebDriver drvr = getDriver();
		drvr.findElement(By.id("propertyContract_14708")).click();
		
	}
	
	
	
	
	private void executeEditGeneralAttributesFromFacilitiesSection(){
		topLinksPage.clickFacilitiesAndServices();
		topLinksPage.sleep(2);
		facilitiesAndServicesDetailsPage = FacilitiesAndServicesDetailsPage.getInstance();
		Map<String, String> map = new HashMap<String, String>();
		map.put("TotalRooms", data.getKeyValue(sheetName, "TotalRooms"));
		map.put("Lifts", data.getKeyValue(sheetName, "Lifts"));
		map.put("CoachDropOff", data.getKeyValue(sheetName, "CoachDropOff"));
		map.put("IndoorPools", data.getKeyValue(sheetName, "IndoorPools"));
		map.put("OutdoorPools", data.getKeyValue(sheetName, "OutdoorPools"));
		map.put("ChildrensPools", data.getKeyValue(sheetName, "ChildrensPools"));
		map.put("EarlierBreakfast", data.getKeyValue(sheetName, "EarlierBreakfast"));
		facilitiesAndServicesDetailsPage.clickEditFacilitiesAndServicesDetails();
		facilitiesAndServicesDetailsPage.editFacilitiesAndServicesDetails(map);
		facilitiesAndServicesDetailsPage.sleep(1);
		facilitiesAndServicesDetailsPage.updateFacilitiesAndServicesDetails();
		facilitiesAndServicesDetailsPage.sleep(1);
	}


		public ExcelUtil getData() {
		return data;
	}
	
	
	

}
