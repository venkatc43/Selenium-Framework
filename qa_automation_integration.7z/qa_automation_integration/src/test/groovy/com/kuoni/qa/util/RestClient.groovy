package com.kuoni.qa.util

class RestClient {
	
	private static String POST = "POST"
	private static String GET = "GET"
	private static String CONTENT_TYPE = "application/xml"
	
	/**
	 * This method to call the restful services for the POST method with XML request
	 * 
	 * @param URL
	 * @param xmlFile
	 * @return
	 */
	public static def sendPOSTRequest(String URL, File xmlFile){
		String responseData = null
		try{
			URL url = new URL(URL)
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true)
			conn.setRequestMethod(POST)
			conn.setRequestProperty("Content-Type", CONTENT_TYPE)
			OutputStream os = conn.getOutputStream();
			if(xmlFile != null){
				os.write(xmlFile.text.getBytes());
				os.flush();
			}
			if(conn.getResponseCode() == 201){
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				responseData = br.readLine()
			}else if(conn.getResponseCode() == 400){
				responseData = "Http response code is 400. It's Bad Request"
			}else if(conn.getResponseCode() == 500){
				responseData = "Http response code is 500. Error while parsing request xml. Missing required elements"
			}
			conn.disconnect()
		}catch(MalformedURLException e){
			e.printStackTrace()
		}catch(IOException e){
			e.printStackTrace()
		}
		return responseData
	}
	
	/**
	 * This method to call the restful service for the GET method.
	 * 
	 * @param URL
	 * @return
	 */
	public static def sendGETRequest(String URL){
		String responseData = null
		try{
			URL url = new URL(URL)
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setDoOutput(true)
			conn.setRequestMethod(GET)
			conn.setRequestProperty("Accept", "application/XML");
			responseData = conn.getResponseCode()
			conn.disconnect()
		}catch(MalformedURLException e){
			e.printStackTrace()
		}catch(IOException e){
			e.printStackTrace()
		}
		return responseData
	}
	
}
