package com.kuoni.qa.automation.dto

class ZoneDTO {
	
	def zoneCount
	//private int zoneId
	def zoneCode
	def zoneDesc

	
}
