package com.kuoni.qa.automation.util

import com.kuoni.qa.automation.dto.ProductRoomsDTO

class ProductXmlUtil {
	
	
	def ProductRoomsDTO readXml(def p, int k)
	{
		
		ProductRoomsDTO xmlData = new ProductRoomsDTO()
		
		xmlData.setRoomActive(p.room[k].@active)
		xmlData.setRoomCategory(p.room[k].@roomCategory)
		xmlData.setRoomType(p.room[k].@roomType)
		xmlData.setTwinBed(p.room[k].roomDetail.twinBed.text())
		xmlData.setDoubleBed(p.room[k].roomDetail.doubleBed.text())
		xmlData.setSingleBed(p.room[k].roomDetail.singleBed.text())
		xmlData.setTripleBed(p.room[k].roomDetail.tripleBed.text())
		xmlData.setQuadBed(p.room[k].roomDetail.quadBed.text())
		xmlData.setTwinSoleUse(p.room[k].roomDetail.twinSoleUse.text())
		xmlData.setDoubleSoleUse(p.room[k].roomDetail.doubleSoleUse.text())
		xmlData.setMaximumOccupcy(p.room[k].roomDetail.maximumOccupancy.text().toInteger())
		xmlData.setCots(p.room[k].roomDetail.cots.text().toInteger())
		xmlData.setBeds(p.room[k].roomDetail.beds.text().toInteger())
		xmlData.setExtraBed(p.room[k].roomDetail.extraBed.text().toInteger())
		xmlData.setRateBasis(p.room[k].roomDetail.rateBasis.text().toInteger())
		xmlData.setExistingBed(p.room[k].roomDetail.existingBed.text())
		xmlData.setBathAndShower(p.room[k].roomDetail.bathAndShower.bathAndShower.text())
		
		return xmlData
		
	}

}
