package com.kuoni.qa.automation.atg.test

import org.testng.asserts.SoftAssert
import static com.kuoni.qa.automation.util.GetCoherenceObject.*
import spock.lang.Shared;
import spock.lang.Specification
import spock.lang.Unroll
import static com.kuoni.qa.automation.util.ReadFilesUtil.getFiles

import com.gta.nova.condition.model.CancellationCondition
import com.gta.nova.rateplan.model.RatePlan
import com.kuoni.qa.automation.common.properties.EnvironmentProperties
import com.kuoni.qa.automation.dao.GetRateplanDBdata
import com.kuoni.qa.automation.dto.RateplanDTO
import com.kuoni.qa.automation.helper.RateplanTestHelper
import com.kuoni.qa.automation.spock.annotation.Regression
import com.kuoni.qa.automation.util.PerformDataLoadUtil
import com.kuoni.qa.automation.util.RateplanXmlUtil

class RateplanDataTest extends Specification{


	@Shared
	EnvironmentProperties envProp = new EnvironmentProperties()

	def setupSpec() {

		def folderLocation = envProp.getValueForProperty("istDataLoc")+"/RatePlan"
		PerformDataLoadUtil dataLoad = new PerformDataLoadUtil()
		dataLoad.changeTestDataReaderLocation(folderLocation)
		dataLoad.importFilesandPerformLoadfromQueue()
		dataLoad.incrementalPushtoCoherence()
	}

	@Regression
	@Unroll
	def "VerifyRateplanXmlData for : #fileEntry.getName()" () {


		given: "XML Test Data for RatePlan is available at the appropriate Location"

		println "test1"

		def envprop = new EnvironmentProperties()
		SoftAssert softAssert = new SoftAssert()
		RateplanDTO dbData,xmlData
		RateplanTestHelper validator = new RateplanTestHelper()
		RateplanXmlUtil getxmlDetails = new RateplanXmlUtil()
		GetRateplanDBdata data = null

		when: "RatePlan xml files are according to the XSD agreed and accessible by the tests"

		//Read the XML File and set the values
		def rateplanXml = new XmlParser().parse(fileEntry)
		xmlData = getxmlDetails.readXml(rateplanXml)

		def ratePlanId = xmlData.getRateplanId()
		def contractId = xmlData.getContractId()
		def cancellationId = xmlData.getCancellationId()
		def restrictionId = xmlData.getRestrictionId()
		data = new GetRateplanDBdata()
		dbData = data.getRateplanData(ratePlanId)
		
		//println "db object : " + dbData

		println "test2"
		//Verifying the xml RatePlan properties with the database

		def properties = xmlData.properties
		println "\n" + "Verifying Data for RatePlan : " + fileEntry.getName() + "\n"
		properties.each {node,val->

			if(("$node") == "contractId")
			{
				def contractIdLength = (xmlData.getContractId()).length()

				softAssert.assertEquals(xmlData.getContractId(), ((dbData.getContractId()).substring(0,contractIdLength)), "\n" + "Xml " + "$node" + ": " + xmlData."$node"+ "	Doesn't Match with "+" DataBase " + "$node" + ": " + dbData."$node" + " For RatePlan : " + ratePlanId+"	in File : "+ fileEntry)
				println "Xml " + "$node" + ": " + xmlData."$node"+ "	::		" + " DataBase " + "$node" + ": " + dbData."$node"
			}
			else if ((xmlData."$node")!=null && ("$node") != "class")
			{
				//println "xml: " + xmlData."$node"
				//println "DB :" + dbData."$node"
				softAssert.assertEquals(xmlData."$node", dbData."$node", "\n" + "Xml " + "$node" + ": " + xmlData."$node"+ "	Doesn't Match with "+" DataBase " + "$node" + ": " + dbData."$node" + " For RatePlan : " + ratePlanId+"	in File : "+ fileEntry)
				println "Xml " + "$node" + ": " + xmlData."$node"+ "	::		" + " DataBase " + "$node" + ": " + dbData."$node"
			}
		}

		//Verify Cancellations and Restrictions.

		validator.verifyCancellations(rateplanXml,dbData,data,ratePlanId,softAssert)
		validator.verifyRestrictions(rateplanXml,dbData,data,ratePlanId,softAssert)

		
		//Verify Xml with Coherence Cache
		
		RatePlan ratePlan = verifyCoherenceRateplans(contractId.toString(), ratePlanId.toString())
		if(cancellationId!=null)
		CancellationCondition cancellationCondition =	verifyCoherenceCancelConditions(contractId.toString(),cancellationId.toString())
		
		println "\n ***Coherence Validation*** \n"
		if(xmlData.getMarginType()!=null && xmlData.getMarginType() == "Nett")
		{
		softAssert.assertEquals(xmlData.getMarginType().toLowerCase(),ratePlan.getRateType().toString().concat("T").toLowerCase(), "Xml Data Rateplan Margin Type doesn't match with Coherence Data")
		println "Xml RP Margin Type :" + xmlData.getMarginType().toLowerCase() + ": " + "Coherence Margin Type : " + ratePlan.getRateType().toString().concat("T").toLowerCase()
		}
		else if (xmlData.getMarginType()!=null)
		{
		softAssert.assertEquals(xmlData.getMarginType().toLowerCase(),ratePlan.getRateType().toString().toLowerCase(), "Xml Data Rateplan Margin Type doesn't match with Coherence Data")
		println "Xml RP Margin Type :" + xmlData.getMarginType().toLowerCase() + ": " + "Coherence Margin Type : " + ratePlan.getRateType().toString().toLowerCase()
		}
		
		
		softAssert.assertAll()
		then: "The XML Data for RatePlans should Match with the Database"

		where:
		fileEntry << getFiles("/RatePlan")

	}


}
