package com.kuoni.qa.automation.atg.test


import static com.kuoni.qa.automation.util.ReadFilesUtil.getFiles

import org.testng.asserts.SoftAssert;

import spock.lang.Shared;
import spock.lang.Specification
import spock.lang.Unroll

import com.kuoni.atg.jaxbclasses.ChangerecordsType
import com.kuoni.atg.jaxbclasses.DescriptionType
import com.kuoni.atg.jaxbclasses.RoomTypeDescriptionsRecord
import com.kuoni.qa.automation.common.properties.EnvironmentProperties;
import com.kuoni.qa.automation.dao.GetReferenceDataDescription;
import com.kuoni.qa.automation.dto.ReferenceDataDTO
import com.kuoni.qa.automation.helper.JaxbHelper
import com.kuoni.qa.automation.spock.annotation.Regression
import com.kuoni.qa.automation.util.PerformDataLoadUtil

class VerifyRoomTypeDescRefData_CB6597 extends Specification {

	SoftAssert softAssert = new SoftAssert()
	GetReferenceDataDescription roomTypeDesc = new GetReferenceDataDescription()

	@Shared
	EnvironmentProperties envProp = new EnvironmentProperties()

	def setupSpec() {

		def folderLocation = envProp.getValueForProperty("istDataLoc")+"/RoomTypeDescriptionsRecord"
		PerformDataLoadUtil dataLoad = new PerformDataLoadUtil()
		dataLoad.changeTestDataReaderLocation(folderLocation)
		dataLoad.importFilesandPerformLoadfromQueue()
	}

	@Regression
	@Unroll
	public "verifyReferenceData for : #xmlFile.getName()"() {


		given: "The XmLs are available at the desired Location"
		ReferenceDataDTO data
		JaxbHelper jaxbObj = new JaxbHelper()

		ChangerecordsType xml = jaxbObj.buildRequestJaxbClass(xmlFile)

		RoomTypeDescriptionsRecord recordNode = xml.recordset.get(0).record.get(0)

		String roomTypeCode = recordNode.getRoomTypeDescriptions().getAt("code")

		List<DescriptionType> roomTypeDescList =  recordNode.getRoomTypeDescriptions().getDescription()


		println "\n xml File : " + xmlFile.getName()
		println "Code : " + roomTypeCode
		int languageCount = recordNode.getRoomTypeDescriptions().getDescription().size()
		println "Xml Language Count :  " + languageCount
		when:"The data can be read from XML and Database"
		for(DescriptionType roomTypeDescriptionsType: roomTypeDescList) {
			String language = roomTypeDescriptionsType.getLanguage().value()
			String roomTypeDescription = roomTypeDescriptionsType.getText()
			data = roomTypeDesc.getOfferDesc(roomTypeCode,language,303)

			//println "DB Language Count : " + data.getLanguageCount()
			if(languageCount == data.getLanguageCount())

			{
				println "\n Language::" + language + "::"
				println "xmlroomTypeDescDescription :  " + roomTypeDescription
				println "\n Database roomTypeDesc Desc : " +  data.getDataDescription()

				softAssert.assertEquals(roomTypeDescription, data.getDataDescription(),"RoomTypeDescription "+roomTypeDescription+" Doesnot Match with Database "+ data.getDataDescription())

			}

			else
				softAssert.assertEquals(languageCount,data.getLanguageCount(),"The Language count doesn't match with Database")

		}

		softAssert.assertAll()
		then:"The XML Descriptions should match with Database"

		where:

		xmlFile << getFiles("/RoomTypeDescriptionsRecord")


	}

}
