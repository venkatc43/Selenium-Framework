package com.kuoni.qa.automation.gc.testcases

import spock.lang.IgnoreIf
import spock.lang.Specification
import spock.lang.Stepwise;

import com.kuoni.qa.automation.datacreate.test.helper.PropertyFacilitiesAndServicesTestHelper
import com.kuoni.qa.constants.CommonConstants
import com.kuoni.qa.util.CommonUtil
import com.kuoni.qa.util.ConfigProperties
import com.kuoni.qa.util.TestSuiteProperties

@Stepwise
class PropertyMaidServiceTest_CB_5912 extends Specification{
	
	PropertyFacilitiesAndServicesTestHelper helper = new PropertyFacilitiesAndServicesTestHelper()
	
	@IgnoreIf({TestSuiteProperties.getVlaue("Ignore_PropertyMaidServiceTest_CB_5912").equals("true")? true : false})
	def "update property room service"(){
		
		given: "The GC Connect, HornetQueue and IST Database are working"
		when:"Property Maid service is updated"
		assert helper.executeMaidServiceFromFacilitiesAndServices("CB-5912-Update"), "error occurred while updating maid service from gc application"

		then:"Wait for the Message to Appear on the Queue"
		sleep(Integer.parseInt(ConfigProperties.getVlaue("pollingInterval")))
		
		then:"Load the Message to ATG"
		assert helper.loadDataintoAtg(), "error occurred while Loading xml to ATG"
		
		sleep(5000)
		then:"Verify the GC Changes against the ATG"
		assert helper.verifyPropertyMaidService("CB-5912-Update"),"Maid Service Validation Failed"
	}
	
	@IgnoreIf({TestSuiteProperties.getVlaue("Ignore_PropertyMaidServiceTest_CB_5912").equals("true")? true : false})
	def "delete property maid service"(){
		
		given: "The GC Connect, HornetQueue and IST Database are working"
		when:"Property Maid service details are Reverted"
		assert helper.executeMaidServiceFromFacilitiesAndServices("CB-5912-Delete"), "error occurred while deleting room service from gc application"
		
		then:"Wait for the Message to Appear onthe Queue"
		sleep(Integer.parseInt(ConfigProperties.getVlaue("pollingInterval")))
		
		then:"Load the Message to ATG"
		assert helper.loadDataintoAtg(), "error occurred while Loading xml to ATG"
		
		then:"Verify the GC CHanges with ATG"
		assert helper.verifyPropertyMaidService("CB-5912-Delete"),"Maid Service Validation Failed"
	}
	
	@IgnoreIf({TestSuiteProperties.getVlaue("Ignore_CloseWebdrver").equals("true")? true : false})
	def "close webdriver"(){
		
		when:""
		if(CommonConstants.webDriver != null){
			CommonConstants.webDriver.quit()
		}
		then:""
	}
	
	def cleanupSpec()
	{
		CommonConstants.webDriver.quit()
	}
}
