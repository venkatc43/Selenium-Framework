package com.kuoni.qa.automation.gc.test;

import java.util.HashMap;
import java.util.Map;

import com.gta.travel.page.base.GSTestBase;
import com.gta.travel.page.object.contract.rateplans.RatePlanDetailsSectionPage;
import com.gta.travel.page.object.contract.rateplans.RatePlanValidMarketsSectionPage;
import com.gta.travel.page.object.contract.search.ContractSearchPage;
import com.gta.travel.page.object.contract.search.ContractSearchResultsPage;
import com.kuoni.qa.automation.page.object.common.HomePageSub;
import com.kuoni.qa.automation.page.object.common.LoginPageSub;
import com.mediaocean.qa.framework.utils.ExcelUtil;

/**
 * Class to Execute Automation on GC Content
 * @author hmirza
 *
 */
public class RateValidMarketTest extends GSTestBase {

	private String userName;
	private String password;
	private String webId;

	private String sheetName = null;

	private ContractSearchPage contractSearchPage;
	private ContractSearchResultsPage contractSearchResultsPage;
	private RatePlanDetailsSectionPage DetailsSectionPage;
	private RatePlanValidMarketsSectionPage validMarketsSectionPage;

	private ExcelUtil excelData;

	public RateValidMarketTest(String driverSheetPath, String dataSheetPath,
			String sheetName) {
		this.sheetName = sheetName;
		init(driverSheetPath, dataSheetPath);
	}

	/**
	 * Initialize the driver sheet and data sheet 
	 * @param driverSheetPath
	 * @param dataSheetPath
	 */
	public void init(String driverSheetPath, String dataSheetPath) {
		excelData = new ExcelUtil(dataSheetPath);
		if (driverSheetPath != null) {
			setDriverSheetAbsolutePath(driverSheetPath);
		} else {
			setDriverSheetFileName("Driver_Sheet.xls");
		}
		initialiseEnvironmentAndTest();
		openBrowser();
		setLoginInfo();
	}

	/**
	 * Set logging info for GC Content
	 */
	private void setLoginInfo() {
		webId = excelUtil.getKeyValue(ENVIRONMENT, "webId");
		userName = excelUtil.getKeyValue(ENVIRONMENT, "userName");
		password = excelUtil.getKeyValue(ENVIRONMENT, "password");
	}

	/**
	 * Method to execute the Script to run automation on GC Contect
	 */
	public void executeDataScriptForCreateRateValidMarket() {
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSelectRatePlan();
		executeCreateRateValidMarketFlow();
		// getDriver().quit();
	}

	/**
	 * Method to execute the login page on GC Content  
	 */
	private void executeLoginPageFlow() {
		LoginPageSub loginPage = new LoginPageSub();
		HomePageSub homePage = loginPage.login(webId, userName, password);
		contractSearchPage = homePage.selectContract();
		contractSearchPage.sleep(2);
	}

	/**
	 * Method to execute Contract Search on GC Content 
	 */
	private void executeSearchScreenFlow() {

		Map<String, String> searchDataMap = new HashMap<String, String>();
		// Set the search data to the map here.
		searchDataMap.put("Country",
				excelData.getKeyValue(sheetName, "Country"));
		searchDataMap.put("City", excelData.getKeyValue(sheetName, "City"));
		searchDataMap.put("Property Name",
				excelData.getKeyValue(sheetName, "Property Name"));
		contractSearchResultsPage = contractSearchPage.search(searchDataMap);
		contractSearchResultsPage.sleep(3);
		contractSearchResultsPage.selectFirstRowFromTheResults();
	}

	/**
	 * Method to execute Select the rate plan on GC Content 
	 */
	private void executeSelectRatePlan() {
		DetailsSectionPage = RatePlanDetailsSectionPage.getInstance();
		Map<String, String> map = new HashMap<String, String>();
		map.put("Rate Plan Code",
				excelData.getKeyValue(sheetName, "Rate Plan Code"));
		// DetailsSectionPage.selectRatePlan(map);
		DetailsSectionPage.selectRatePlanFromTheList(map);
	}

	/**
	 * Method to set Input Data in Map and execute the Automation on Valid market section
	 */
	private void executeCreateRateValidMarketFlow() {
		validMarketsSectionPage = RatePlanValidMarketsSectionPage.getInstance();
		Map<String, String> map = new HashMap<String, String>();
		if (excelData.getKeyValue(sheetName, "world wide") != null
				&& !excelData.getKeyValue(sheetName, "world wide").equals("")) {
			map.put("world wide",
					excelData.getKeyValue(sheetName, "world wide"));
		}
		if (excelData.getKeyValue(sheetName, "market name") != null
				&& !excelData.getKeyValue(sheetName, "market name").equals("")) {
			map.put("market name",
					excelData.getKeyValue(sheetName, "market name"));
		}
		if (excelData.getKeyValue(sheetName, "zone openers") != null
				&& !excelData.getKeyValue(sheetName, "zone openers").equals("")) {
			map.put("zone openers",
					excelData.getKeyValue(sheetName, "zone openers"));
		}
		if (excelData.getKeyValue(sheetName, "cb zones") != null
				&& !excelData.getKeyValue(sheetName, "cb zones").equals("")) {
			map.put("cb zones", excelData.getKeyValue(sheetName, "cb zones"));
		}
		if (excelData.getKeyValue(sheetName, "countries") != null
				&& !excelData.getKeyValue(sheetName, "countries").equals("")) {
			map.put("countries", excelData.getKeyValue(sheetName, "countries"));
		}
		validMarketsSectionPage.clickEditValidMarkets();
		validMarketsSectionPage.editValidMarkets(map);
		if (sheetName.contains("Create")) {
			validMarketsSectionPage.saveEditValidMarkets("Yes");
		} else {
			validMarketsSectionPage.saveEditValidMarkets("");
		}
	}

}
