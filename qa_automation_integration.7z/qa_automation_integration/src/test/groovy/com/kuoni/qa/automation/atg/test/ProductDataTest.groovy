package com.kuoni.qa.automation.atg.test

import org.testng.asserts.SoftAssert
import static com.kuoni.qa.automation.util.GetCoherenceObject.*
import spock.lang.Shared;
import spock.lang.Specification
import spock.lang.Unroll

import com.gta.nova.coherence.property.model.Room
import com.kuoni.qa.automation.common.properties.EnvironmentProperties
import com.kuoni.qa.automation.dao.GetProductDBdata
import com.kuoni.qa.automation.dto.ProductRoomsDTO
import com.kuoni.qa.automation.spock.annotation.Regression
import com.kuoni.qa.automation.util.PerformDataLoadUtil
import com.kuoni.qa.automation.util.ProductXmlUtil

import static com.kuoni.qa.automation.util.ReadFilesUtil.getFiles

class ProductDataTest extends Specification{

	@Shared
	EnvironmentProperties envProp = new EnvironmentProperties()

	def setupSpec() {

		def folderLocation = envProp.getValueForProperty("istDataLoc")+"/Product"
		PerformDataLoadUtil dataLoad = new PerformDataLoadUtil()
		dataLoad.changeTestDataReaderLocation(folderLocation)
		dataLoad.importFilesandPerformLoadfromQueue()
		dataLoad.incrementalPushtoCoherence()
	}

	@Regression
	@Unroll
	def "VerifyProductRoommldata for : #fileEntry.getName()"() {


		given: "XML Test Data for Product is available at the appropriate Location"
		when: "Product xml files are according to the XSD agreed and accesible by the tests"

		SoftAssert softAssert = new SoftAssert()
		ProductRoomsDTO xmlData,dbData
		ProductXmlUtil xml = new ProductXmlUtil()
		GetProductDBdata data2 = new GetProductDBdata()
		EnvironmentProperties envProp = new EnvironmentProperties()

		//URL url = ProductDataTest.class.getClass().getResource("/Product")
		def i = 1, k=0


		//parse the XMl File
		def productXml = new XmlParser().parse(fileEntry)
		def p = productXml.recordset.record.product
		def noofRooms = productXml.recordset.record.product.room.size()

		println "\n" + "Verifying Data for Product : " + fileEntry.getName() + "\n"
		println "No of Rooms: " + noofRooms


		//looping inside a file up to the number of rooms available for that property/product
		for(k=0; k < noofRooms;k++)
		{
			def roomId = p.room[k].@roomId.toInteger()
			def propertyId = p.room[k].@propertyId.toString()
			//Get room xml details for the room
			xmlData = xml.readXml(p,k)

			//get Database details for the room
			dbData = data2.getRoomdata(roomId)
			println "Verifying Data for Room : " +"'" +roomId +"'"

			println "*****"

			//verifying the xml details with datbase
			println "** ATG Validation **"
			def properties = xmlData.properties
			properties.each {node,val->

				if("$node" != "class" )
				{
					softAssert.assertEquals(xmlData."$node", dbData."$node", "\n" + "Xml " + "$node" + ": " + xmlData."$node"+ "	Doesn't Match with "+" DataBase " + "$node" + ": " + dbData."$node" + " For Room : " + roomId+"	in File : "+ fileEntry)
					println "Xml " + "$node" + ": " + xmlData."$node"+ "	::		" + " DataBase " + "$node" + ": " + dbData."$node"
				}
			}

			println "*****"
			
			//Validate Coherence Details
			println "** COHERENCE Validation ** \n"
			Room room = getCohPropertyRoomDetails(propertyId,roomId)
			
			softAssert.assertEquals(xmlData.getBeds(),room.getNumberOfBeds(),"Coherence Beds doesn't match with Xml, Expected :" + xmlData.getBeds() + " actual : " + room.getNumberOfBeds())
			println " Xml Beds : " + xmlData.getBeds() + " Coherence Beds : " + room.getNumberOfBeds()
			
			softAssert.assertEquals(xmlData.getMaximumOccupcy(),room.getMaxOccupancy(),"Coherence Max Occupancy doesn't match with Xml, Expected :" + xmlData.getMaximumOccupcy() + " actual : " + room.getMaxOccupancy())
			println " Xml MaximumOccupancy : " + xmlData.getMaximumOccupcy() + " Coherence Max Occupancy : " + room.getMaxOccupancy()
			
			softAssert.assertEquals(xmlData.getRateBasis(),room.getRateBasis(),"Coherence RateBasis doesn't match with Xml, Expected :" + xmlData.getRateBasis() + " actual : " + room.getRateBasis())
			println " Xml RateBasis : " + xmlData.getRateBasis() + " Coherence RateBasis : " + room.getRateBasis()
			
			softAssert.assertEquals(xmlData.getExtraBed(),room.getNumberOfExtraBeds(),"Coherence Extra Beds doesn't match with Xml, Expected :" + xmlData.getExtraBed() + " actual : " + room.getNumberOfExtraBeds())
			println " Xml Extra Beds : " + xmlData.getExtraBed() + " Coherence Extra Beds : " + room.getNumberOfExtraBeds()
			
			softAssert.assertEquals(xmlData.getExistingBed(),room.isHasExistingBeds().toString(),"Coherence Existing Beds doesn't match with Xml, Expected :" + xmlData.getExistingBed() + " actual : " + room.isHasExistingBeds().toString())
			println " Xml Existing Beds : " + xmlData.getExistingBed() + " Coherence Existing Beds : " + room.isHasExistingBeds().toString()
			
			
			if(xmlData.getRoomActive() == "true")
			{
			softAssert.assertEquals("ACTIVE",room.getRoomStatus().toString(),"Coherence Status doesn't match with Xml, Expected : ACTIVE actual : " + room.getRoomStatus())
			println "Xml Status : " + xmlData.getRoomActive() + " Coherence Status : " +room.getRoomStatus()
			}
			else
			{
				softAssert.assertEquals("INACTIVE",room.getRoomStatus().toString(),"Coherence Status doesn't match with Xml, Expected : INACTIVE actual : " + room.getRoomStatus())
				println "\n Xml Status : " + xmlData.getRoomActive() + " Coherence Status : " +room.getRoomStatus()
			}
			
					
	
		}

		softAssert.assertAll()
		then: "The XML Data for Products should Match with the Database"
		
		
		
		
		where:
		fileEntry << getFiles("/Product")
	}
}

