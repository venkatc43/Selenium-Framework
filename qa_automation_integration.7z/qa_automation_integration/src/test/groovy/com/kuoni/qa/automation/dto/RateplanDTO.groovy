package com.kuoni.qa.automation.dto

class RateplanDTO {

	def rateplanId
	def rateplanStatus
	def rateplanCode
	def rateplanName
	def contractId
	
	def marginType
	def marginPercentage
	
	def restrictionId
	def restrictionType
	def resStartDate
	def resEndDate
	def resDaysPrior
	def restrictionCount
	
	
	
	def cancelCount
	def cancellationId
	def cancellationType
	def cancelStart
	def cancelEnd
	def cancel_time
	def canceldaysPrior
	def cancelPercentage
	def cancelduration
	
	
	
	/*def mealBasisCode
	def mealBasisType
	def mealBasisDesc
	
	
	
	
	
	*/
	
	
	public String getCancellationType()
	{
		if (cancellationType=="1")
		return "Standard"
		else if (cancellationType=="2")
		return "Peak"
	}
	
	public String getRateplanStatus()
	{
		if(rateplanStatus == "Live" || rateplanStatus== "1001" )
		return "Live"
		else if (rateplanStatus == "Pending" || rateplanStatus== "1002" )
		return "Pending"
		else if (rateplanStatus == "Suspended" || rateplanStatus== "1003" )
		return "Suspended"
		else if (rateplanStatus == "Cancelled" || rateplanStatus== "1004" )
		return "Cancelled"
	}
	
	
	public String getMarginType()
	{
		if(marginType=="Nett" || marginType=="2001")
		return "Nett"
		else if (marginType =="Gross" || marginType =="2002")
		return "Gross"
	}
	
	
}
