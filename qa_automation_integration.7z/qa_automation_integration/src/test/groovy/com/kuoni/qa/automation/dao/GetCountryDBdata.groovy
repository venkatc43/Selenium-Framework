package com.kuoni.qa.automation.dao

import com.kuoni.qa.automation.dto.CountryDTO;


import java.sql.Connection
import java.sql.ResultSet
import java.sql.Statement

class GetCountryDBdata {

	GetDatabaseConn db = null
	
		def CountryDTO getCountrydata(int countryId) {
	
			db = new GetDatabaseConn()
			Connection conn = db.getDBconnection()
			CountryDTO data = new CountryDTO()
			ResultSet rs = null
			Statement statement = null
	
			try {
	
				statement = conn.createStatement()
				String sql = "select count(*) COUNT from FIT_COUNTRY"
				rs = statement.executeQuery(sql);
	
				if(rs.next()){
	
					data.setCountryCount(rs.getInt("COUNT"))
				}
	
				if(rs.getInt("COUNT")>0) {
					sql = "SELECT country.CODE,  country.DESCRIPTION,  country.DEFAULT_PAYMENT_CURRENCY,  country.ZONE_CODE,  country.Description from  FIT_COUNTRY country where country.COUNTRY_ID ="+ countryId+" and ROWNUM=1"
					rs = statement.executeQuery(sql);
					while(rs.next()) {
	
						data.setCountryCode(rs.getString("CODE"))
						//data.setregionDesc(rs.getString("DESCRIPTION"))
						data.setCountryDefaultCrncy(rs.getString("DEFAULT_PAYMENT_CURRENCY"))
						data.setZoneCode(rs.getString("ZONE_CODE"))
						data.setZoneDesc(rs.getString("Description"))
	
					}
				}
			}catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	
			finally{
				statement.close()
				rs.close();
				conn.close();
			}
			return data
		}
	
}
