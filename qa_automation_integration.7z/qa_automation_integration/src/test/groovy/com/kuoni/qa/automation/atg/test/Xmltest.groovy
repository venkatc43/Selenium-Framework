package com.kuoni.qa.automation.atg.test

import com.kuoni.qa.automation.common.util.XmlUtil

class Xmltest {
	
	static void main (def args)
	{
		
	def xmld = new XmlParser().parse("C:\\Users\\104336\\Desktop\\test.xml")
	
	//println xmld
	
	println xmld.propertyTypes.propertyType.address.type.text()
	
	def xmls = new XmlParser().parse("C:\\Kuoni_Docs\\TestData\\HotelDataSet v2.0\\City\\City_3293_1398777138001.xml")
	
	println xmls.propertyTypes.propertyType.address.type.text()
	
	//println xmls.recordset.record.city.countryId.text()
	
	}

}