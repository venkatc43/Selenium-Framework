package com.kuoni.qa.automation.page.object.cities;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.gta.travel.page.base.GSPageBase;
import com.mediaocean.qa.framework.selenium.ui.controls.Table;

public class CityResultListPage extends GSPageBase{


	public CityResultListPage() {
		super(getDriver());
	}
	
	
	public ViewCityPage selectRecordFromSearchResults(Map<String, String> inputMap){
		
		WebElement parentElement = waitForElement(By.id("searchList"));
		sleep(3);
		Table resultsTable = new Table(parentElement, 1);
		for (int i=1;i<resultsTable.getRowCount();i++){
			boolean isRecordFound = true;
			for (String key : inputMap.keySet()){
				String value = inputMap.get(key);
				WebElement cellElement = resultsTable.getCell(i, key);
				if (!cellElement.getText().trim().equalsIgnoreCase(value.trim())){
					isRecordFound = false;
					break;
				}
			}
			if (isRecordFound){
				resultsTable.clickOnRow(i);
			}
		}
		sleep(2);
		return PageFactory.initElements(getDriver(), ViewCityPage.class);
		
	}

}
