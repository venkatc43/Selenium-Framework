package com.kuoni.qa.automation.atg.test

import org.testng.asserts.SoftAssert;
import static com.kuoni.qa.automation.util.ReadFilesUtil.getFiles
import spock.lang.Shared;
import spock.lang.Specification
import spock.lang.Unroll;

import com.kuoni.atg.jaxbclasses.ChangerecordsType
import com.kuoni.atg.jaxbclasses.LandmarkRecord
import com.kuoni.qa.automation.common.properties.EnvironmentProperties;
import com.kuoni.qa.automation.dao.GetReferenceDataDescription;
import com.kuoni.qa.automation.dto.ReferenceDataDTO
import com.kuoni.qa.automation.helper.JaxbHelper
import com.kuoni.qa.automation.spock.annotation.Regression;
import com.kuoni.qa.automation.util.PerformDataLoadUtil

class VerifyLandMarktypeRefdata_CB9714 extends Specification{
	
	
	SoftAssert softAssert = new SoftAssert()
	GetReferenceDataDescription offerDesc = new GetReferenceDataDescription()

	@Shared
	EnvironmentProperties envProp = new EnvironmentProperties()

	def setupSpec() {

		def folderLocation = envProp.getValueForProperty("istDataLoc")+"/Landmark"
		PerformDataLoadUtil dataLoad = new PerformDataLoadUtil()
		dataLoad.changeTestDataReaderLocation(folderLocation)
		dataLoad.importFilesandPerformLoadfromQueue()
	}

	@Regression
	@Unroll
	public "verifyReferenceData for : #xmlFile.getName()"() {

		given: "The XmLs are available at the desired Location"
		ReferenceDataDTO data
		JaxbHelper jaxbObj = new JaxbHelper()

		ChangerecordsType xml = jaxbObj.buildRequestJaxbClass(xmlFile)

		LandmarkRecord recordNode = xml.recordset.get(0).record.get(0)

		String landmarkId = recordNode.getLandmark().getLandmarkId()
		String latitude = recordNode.getLandmark().getLatitude()
		String longitude = recordNode.getLandmark().getLongitude()
		String landmarkCode = recordNode.getLandmark().getCode()
		
//		String errataTypeCode = recordNode.getErrataTypeDescriptions().getAt("type")

		println "\n xml File : " + xmlFile.getName()
		when:"The data can be read from XML and Database"
		
			data = offerDesc.getLandmarkData(landmarkId)

			//println "DB Language Count : " + data.getLanguageCount()
		
				println "\n xml Code ::" + landmarkCode + "::"
				println "xml Longitude :  " + latitude
				println "\n xml Longitude : " +  longitude

				softAssert.assertEquals(landmarkCode, data.getLandmarkCode(),"LandMarkCode Doesnot Match with Database")
				softAssert.assertEquals(latitude, data.getLandmarkLatitude(),"LandMark Latitude Doesnot Match with Database")
				softAssert.assertEquals(longitude, data.getLandmarkLongitude(),"Longitude Doesnot Match with Database")
		

		softAssert.assertAll()
		then:"The XML LandMark Details should match with Database"

		where:

		xmlFile << getFiles("/Landmark")


	}


}
