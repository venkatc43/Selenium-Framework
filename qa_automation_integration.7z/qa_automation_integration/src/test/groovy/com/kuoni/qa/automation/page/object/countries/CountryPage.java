package com.kuoni.qa.automation.page.object.countries;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.gta.travel.page.base.GSPageBase;
import com.mediaocean.qa.framework.selenium.ui.controls.Button;

public class CountryPage extends GSPageBase{

	public CountryPage(WebDriver driver) {
		super(getDriver());
	}
	
	public void createCountry(Map<String, String> data){
		waitForElement(By.name("code"));
		applyDataForCountryPage(data);
		sleep(1);
		Button saveCity = new Button("Save");
		saveCity.click();
		sleep(1);
	}
	
	public void editCountry(Map<String, String> data){
		waitForElement(By.id("name"));
		applyDataForCountryPage(data);
		sleep(4);
		Button saveCity = new Button("Save");
		saveCity.click();
		sleep(5);
	}
	
	public void applyDataForCountryPage(Map<String, String> data){
		if(data.get("Code") != null){
			clearAndType(By.id("code"),data.get("Code"));
		}
		if(data.get("Description") != null){
			clearAndType(By.id("name"),data.get("Description"));
		}
	}
	
	
}
