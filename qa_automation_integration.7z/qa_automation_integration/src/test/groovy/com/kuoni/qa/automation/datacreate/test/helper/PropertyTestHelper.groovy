package com.kuoni.qa.automation.datacreate.test.helper

import com.kuoni.qa.automation.dao.GetPropertyDBdata
import com.kuoni.qa.automation.dto.PropertyDTO
import com.kuoni.qa.automation.gc.test.PropertyNameMainAddressTest
import com.kuoni.qa.util.ConfigProperties
import com.mediaocean.qa.framework.utils.ExcelUtil

import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement
import org.testng.asserts.SoftAssert


class PropertyTestHelper {

	private ExcelUtil excelData
	SoftAssert softAssert = null
	PropertyDTO dbData = null
	 GetPropertyDBdata properyDBdata = null

	public def editPropertyNameFromGCApplication(String sheetName){
		boolean executionFlag = false
		try{
			PropertyNameMainAddressTest test = new PropertyNameMainAddressTest(ConfigProperties.getVlaue("driverSheetPath"),ConfigProperties.getVlaue("dataSheetPath"),sheetName)
			test.execueteDataScriptForNameEdit()
			executionFlag = true
		}catch(Exception e){
			println e
		}
		return executionFlag
	}

	public def editPropertyMainAddress(String sheetName){
		boolean executionFlag = false
		try{
			PropertyNameMainAddressTest test = new PropertyNameMainAddressTest(ConfigProperties.getVlaue("driverSheetPath"),ConfigProperties.getVlaue("dataSheetPathSprint4"),sheetName)
			excelData = test.getData()
			test.execueteDataScriptForMainAddressEdit()
			executionFlag = true
		}catch(Exception e){
			println e
		}
		return executionFlag
	}
	

	public void verifyAddressDetails(String sheetName)
	{
		softAssert = new SoftAssert()
		
		properyDBdata = new GetPropertyDBdata();
		int propertyId = Integer.parseInt(excelData.getKeyValue(sheetName,"PropertyId"));
		PropertyDTO dbData =  properyDBdata.getPropertyData(propertyId);
				
		softAssert.assertEquals((dbData.getAddressL1()),excelData.getKeyValue(sheetName,"Street1"),"AddressLine1 Doesnt match with Database")
		println "Excel Address1 : " + excelData.getKeyValue(sheetName, "Street1") + "::" + "Database Value : " + dbData.getAddressL1()
		
		softAssert.assertEquals((dbData.getAddressL2()),excelData.getKeyValue(sheetName,"Street2"),"AddressLine2 Doesnt Match with Database")
		println "Excel Address2 : " + excelData.getKeyValue(sheetName, "Street2") + "::" + "Database Value : " + dbData.getAddressL2()
		
		softAssert.assertEquals((dbData.getPostCode()),excelData.getKeyValue(sheetName,"Zip/PostalCode"),"PostCode Doesnt Match with Database")
		println "Excel PostCode : " + excelData.getKeyValue(sheetName, "Zip/PostalCode") + "::" + "Database Value : " + dbData.getPostCode()
	}
	
	

}
