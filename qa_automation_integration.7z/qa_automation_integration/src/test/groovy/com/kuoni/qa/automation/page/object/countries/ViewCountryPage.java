package com.kuoni.qa.automation.page.object.countries;

import org.openqa.selenium.support.PageFactory;

import com.gta.travel.page.base.GSPageBase;
import com.mediaocean.qa.framework.selenium.ui.controls.Button;

public class ViewCountryPage extends GSPageBase{

	public ViewCountryPage() {
		super(getDriver());
	}

	public CountryPage clickEdit(){
		Button edit = new Button("Edit");
		sleep(1);
		edit.click();
		return PageFactory.initElements(getDriver(), CountryPage.class);
	}
	
	public CountryPage clickCopy(){
		Button edit = new Button("Copy");
		sleep(1);
		edit.click();
		return PageFactory.initElements(getDriver(), CountryPage.class);
	}	
	
	public void clickDelete(){
		Button delete = new Button("Delete");
		sleep(1);
		delete.click();
		sleep(2);
		getDriver().switchTo().alert().accept();
		sleep(2);
	}	
}
