package com.kuoni.qa.automation.datacreate.test.helper

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.asserts.SoftAssert

import com.gta.nova.coherence.property.model.Property
import com.kuoni.automation.geb.tests.GCContract
import com.kuoni.qa.automation.coh.tests.GetCoherenceProperty
import com.kuoni.qa.automation.common.properties.EnvironmentProperties
import com.kuoni.qa.automation.dao.GetPropertyDBdata;
import com.kuoni.qa.automation.dto.PropertyDTO;
import com.kuoni.qa.automation.gc.test.PropertyFacilitiesAndServicesTest
import com.kuoni.qa.constants.CommonConstants;
import com.kuoni.qa.util.ConfigProperties
import com.kuoni.qa.util.DataImportandLoadUtil
import com.mediaocean.qa.framework.utils.ExcelUtil
import com.gta.nova.coherence.property.model.Property
import com.kuoni.qa.automation.spock.annotation.Sanity
import com.kuoni.qa.automation.util.PerformDataLoadUtil
//import com.kuoni.qa.automation.test.util.PropertyPriceAvailabilityRequestBuilder
import com.tangosol.net.CacheFactory
import com.tangosol.net.NamedCache
class PropertyFacilitiesAndServicesTestHelper {
	
	private ExcelUtil excelData
	GetPropertyDBdata properyDBdata = null
	PerformDataLoadUtil dataLoader = new PerformDataLoadUtil()
	SoftAssert softAssert =  new SoftAssert()
	EnvironmentProperties envprop = new EnvironmentProperties()
	Property  cProperty=null	
	def driversheetPath = System.getProperty("dirver-sheet-path")
	
	public def updateGeneralAttributes(String sheetName){
		boolean executionFlag = false		
		//driversheetPath
		PropertyFacilitiesAndServicesTest test = new PropertyFacilitiesAndServicesTest(driversheetPath,ConfigProperties.getVlaue("dataSheetPathSprint4"),sheetName)
		excelData = test.getData()
		test.executeDataScriptsForUpdateGenralAttributesFromFecilitiesSection()
		executionFlag = true
		return executionFlag
	}
	
	public def updateCategoryDetails(String sheetName){
		boolean executionFlag = false		
		PropertyFacilitiesAndServicesTest test = new PropertyFacilitiesAndServicesTest(driversheetPath,ConfigProperties.getVlaue("dataSheetPathSprint4"),sheetName)
		excelData = test.getData()
		test.executeDataScriptsForUpdateCategoryDetails()
		executionFlag = true
		return executionFlag
	}
	
	public def updatePhoneWebSite(String sheetName){
		boolean executionFlag = false
		PropertyFacilitiesAndServicesTest test = new PropertyFacilitiesAndServicesTest(driversheetPath,ConfigProperties.getVlaue("dataSheetPathSprint4"),sheetName)
		excelData = test.getData()
		test.executeDataScriptsForUpdatePhoneWebsite()
		executionFlag = true
		return executionFlag
	}

	public def executeRoomServiceFromFacilitiesAndServices(String sheetName){
		boolean executionFlag = false
		PropertyFacilitiesAndServicesTest test = new PropertyFacilitiesAndServicesTest(driversheetPath,ConfigProperties.getVlaue("dataSheetPathSprint4"),sheetName)
		excelData = test.getData()
		if(sheetName.equalsIgnoreCase("CB-5911-Update")){
			test.executeDataScriptsForUpdateRoomServiceFromFecilitiesSection()
		}else{
			test.executeDataScriptsForDeleteRoomServiceFromFecilitiesSection()
		}
		executionFlag = true
		return executionFlag
	}
	
	public def executeMaidServiceFromFacilitiesAndServices(String sheetName){
		boolean executionFlag = false
		PropertyFacilitiesAndServicesTest test = new PropertyFacilitiesAndServicesTest(driversheetPath,ConfigProperties.getVlaue("dataSheetPathSprint4"),sheetName)
		excelData = test.getData()
		if(sheetName.equalsIgnoreCase("CB-5912-Update")){
			test.executeDataScriptsForUpdateMaidServiceFromFecilitiesSection()
		}else{
			test.executeDataScriptsForDeleteMaidServiceFromFecilitiesSection()
		}
		executionFlag = true
		return executionFlag
	}
	
	public def updateCheckInCheckOutDetails(String sheetName){
		boolean executionFlag = false
		//def driversheetPath = System.getProperty("driverSheetPath")
		PropertyFacilitiesAndServicesTest test = new PropertyFacilitiesAndServicesTest(driversheetPath,ConfigProperties.getVlaue("dataSheetPathSprint4"),sheetName)
		excelData = test.getData()
		test.executeDataScriptsForUpdateCheckInCheckOutDeatils()
		executionFlag = true
		return executionFlag
	}
	
	public def updateStyleAssignments(String sheetName){
		boolean executionFlag = false
		PropertyFacilitiesAndServicesTest test = new PropertyFacilitiesAndServicesTest(driversheetPath,ConfigProperties.getVlaue("dataSheetPathSprint4"),sheetName)
		excelData = test.getData()
		test.executeDataScriptsForStyleAssignmentsUpdate()
		executionFlag = true
		return executionFlag
	}
	
	
	
	public def getExcelData(String sheetName)
	{
		boolean executionFlag = false
		PropertyFacilitiesAndServicesTest test = new PropertyFacilitiesAndServicesTest(driversheetPath,ConfigProperties.getVlaue("dataSheetPathSprint4"),sheetName)
		excelData = test.getData()
		executionFlag = true
		return excelData
		

	}
	
	
	//Load data using the JSP
/*	public def loadDataintoAtg()
	{
		boolean executionFlag = false
		WebDriver driver = CommonConstants.webDriver;
		driver.get("http://longwlg05a.emea.kuoni.int:8180/test/load/loader.jsp#");
		WebElement loadButton = driver.findElement(By.id("action-perform-load"));
		loadButton.click();
		executionFlag = true
		return executionFlag
		

	}*/
	
	
	//Get Coherence Data
	
	def Property verifyCohPropertyDetails (String propertyIdCoh) {
		
		
		def final expectedResult = 50;
		NamedCache propertyCache = CacheFactory.getCache("Property");

		def actualResult =  propertyCache.size()

		//verify new fields
		Long conPropId = Long.parseLong(propertyIdCoh)
		Property cProperty1 = (Property) propertyCache.get(conPropId)

		//println cProperty.getStarRating()

		return cProperty1

	 }
	
	

	// Load data using DynAdmin
	
	public def loadDataintoAtg()
	{	
		
		boolean executionFlag = false
		/*WebDriver driver = CommonConstants.webDriver;
		
		driver.get(envprop.getValueForProperty("performDataLoadURL"));
		WebElement loadButton = driver.findElement(By.name("submit"));
		loadButton.click(); */
		
		dataLoader.perfomDataLoadfromtheQueue()
		
		executionFlag = true
		return executionFlag
		
		
		

	}
	
	
	public def loadDatatoCEC()
	{	
		WebDriver driver = CommonConstants.webDriver;
		boolean executionFlag = false
		/*driver.get(envprop.getValueForProperty("postDataLoadURL"));
		WebElement loadButton = driver.findElement(By.name("submit"));
		loadButton.click();*/
		dataLoader.pushToDownStream()
		executionFlag = true
		return executionFlag
	}
	
	public Boolean verifyATGProperyGenericdata(String sheetName)
	{
		PropertyFacilitiesAndServicesTest test = new PropertyFacilitiesAndServicesTest(driversheetPath,ConfigProperties.getVlaue("dataSheetPathSprint4"),sheetName)
		excelData = test.getData()
		
		boolean executionFlag = false
		properyDBdata = new GetPropertyDBdata();
		int propertyId = Integer.parseInt(excelData.getKeyValue(sheetName,"PropertyId"))
		PropertyDTO dbData =  properyDBdata.getPropertyData(propertyId)
		

		softAssert.assertEquals((dbData.getCoachDrop()),excelData.getKeyValue(sheetName,"CoachDropOff"),"CoachDrop Doesnt match with Database")
		println "GC COACH DropOff : " + excelData.getKeyValue(sheetName, "CoachDropOff") + "::" + "Database Value : " + dbData.getCoachDrop()
		
		softAssert.assertEquals((dbData.getTotalRooms()),Integer.parseInt(excelData.getKeyValue(sheetName,"TotalRooms")),"Total Rooms Doesnt Match with Database")
		println "GC TOTAL Rooms  : " + excelData.getKeyValue(sheetName, "TotalRooms") + "::" + "Database Value : " + dbData.getTotalRooms()
		
		softAssert.assertEquals((dbData.getStarRating()),excelData.getKeyValue(sheetName,"StarRatingCode"),"StarRating Doesnt match with Database")
		println "GC Star Rating : " + excelData.getKeyValue(sheetName, "StarRatingCode") + "::" + "Database Value : " + dbData.getStarRating()
		
		softAssert.assertEquals((dbData.getMinAge().toString()),excelData.getKeyValue(sheetName,"MinimumAge"),"Min Age Doesnt Match with Database")
		println "GC Minimum Age : " + excelData.getKeyValue(sheetName, "MinimumAge") + "::" + "Database Value : " + dbData.getMinAge().toString()
		
		softAssert.assertEquals((dbData.getEarliestBreakFast().toString()),excelData.getKeyValue(sheetName,"EarlierBreakfast"),"EarlierBreakfast Doesnt Match with Database")
		println "GC EarliestBreakFast : " + excelData.getKeyValue(sheetName, "EarlierBreakfast") + "::" + "Database Value : " + dbData.getEarliestBreakFast().toString()
			
		softAssert.assertAll()
		executionFlag = true
		return executionFlag
	}
	
	
	
	public Boolean verifyCOHProperyGenericdata(String sheetName)
	
	{
				
		PropertyFacilitiesAndServicesTest test = new PropertyFacilitiesAndServicesTest(driversheetPath,ConfigProperties.getVlaue("dataSheetPathSprint4"),sheetName)
		excelData = test.getData()
		
		boolean executionFlag = false
		String propertyId = excelData.getKeyValue(sheetName,"PropertyId")
		
		//Long cohPropId = Long.valueOf(propertyId)
		//println propertyId
		Property cohData =  verifyCohPropertyDetails(propertyId)
		println cohData.getStarRating()
		
		
		softAssert.assertEquals((cohData.getStarRating()),excelData.getKeyValue(sheetName,"StarRatingCode"),"StarRating Doesnt match with Coherence")
		println "GC Star Rating : " + excelData.getKeyValue(sheetName, "StarRatingCode") + "::" + "Coherence Value : " + cohData.getStarRating()
		
		softAssert.assertEquals((cohData.getMinimumAge().toString()),excelData.getKeyValue(sheetName,"MinimumAge"),"Min Age Doesnt Match with Coherence")
		println "GC Minimum Age : " + excelData.getKeyValue(sheetName, "MinimumAge") + "::" + "Coherence Value : " + cohData.getMinimumAge().toString()
		
					
		softAssert.assertAll()
		executionFlag = true
		return executionFlag
	}
	
	
	public Boolean verifyPhoneNwebsite(String sheetName)
	{
		boolean executionFlag = false
		properyDBdata = new GetPropertyDBdata();
		int propertyId = Integer.parseInt(excelData.getKeyValue(sheetName,"PropertyId"))
		PropertyDTO dbData =  properyDBdata.getPropertyData(propertyId)
		

		softAssert.assertEquals(dbData.getTelephone(),excelData.getKeyValue(sheetName,"Telephone Number"),"Telephone Number Doesnt match with Database")
		println "GC Telephone Number : " + excelData.getKeyValue(sheetName, "Telephone Number") + "::" + "Database Value : " + dbData.getTelephone()
		
		softAssert.assertEquals((dbData.getWebsite()).replace("http://",""),excelData.getKeyValue(sheetName,"website"),"Website Doesnt Match with Database")
		println "GC Website  : " + excelData.getKeyValue(sheetName, "website") + "::" + "Database Value : " + dbData.getWebsite()
		
		
		softAssert.assertAll()
		executionFlag = true
		return executionFlag
	}
	
	public Boolean verifyPropertyRoomService(String sheetName)
	{	
		boolean executionFlag = false
		properyDBdata = new GetPropertyDBdata();
		int propertyId = Integer.parseInt(excelData.getKeyValue(sheetName,"PropertyId"));
		PropertyDTO dbData = properyDBdata.getRoomServiceData(propertyId)
		
		
		softAssert.assertEquals(dbData.getRoomServiceRequired(),excelData.getKeyValue(sheetName,"RoomService"),"Room Service doens't match for the Property : " + propertyId )
		println "GC Room Service Required : " + excelData.getKeyValue(sheetName,"RoomService") + "::" + "Database Value : " + dbData.getRoomServiceRequired()
		
		
		if(sheetName == "CB-5911-Update")
		{
		softAssert.assertEquals(dbData.getAvailableAllDay(),excelData.getKeyValue(sheetName,"RoomServiceTwentyFourHour"),"Room Service 24Hr doens't match for the Property : " + propertyId )
		println "GC Room Service AllDay : " + excelData.getKeyValue(sheetName,"RoomServiceTwentyFourHour") + "::" + "Database Value : " + dbData.getAvailableAllDay()
		
		softAssert.assertEquals(dbData.getTimeRange().substring(0, 5),excelData.getKeyValue(sheetName,"TimesFrom"),"Room Service StartTime doens't match for the Property : " + propertyId )
		println "GC Room Service Times : " + excelData.getKeyValue(sheetName,"TimesFrom") + "::" + "Database Value : " + dbData.getTimeRange().substring(0, 5)
		
		softAssert.assertEquals(dbData.getTimeRange().substring(6, 11),excelData.getKeyValue(sheetName,"TimesTo"),"Room Service EndTime doens't match for the Property : " + propertyId )
		println "GC Room Service Times : " + excelData.getKeyValue(sheetName,"TimesTo") + "::" + "Database Value : " + dbData.getTimeRange().substring(6, 11)
		}
		
		else{
			
			softAssert.assertEquals(dbData.getAvailableAllDay(),excelData.getKeyValue(sheetName,"RoomServiceTwentyFourHour"),"Room Service 24Hr doens't match for the Property : " + propertyId )
			println "GC Room Service AllDay : " + excelData.getKeyValue(sheetName,"RoomServiceTwentyFourHour") + "::" + "Database Value : " + dbData.getAvailableAllDay()
			
			
			println "GC Room Service Times : " + excelData.getKeyValue(sheetName,"Times") + "::" + "Database Value : " + dbData.getTimeRange()
		}
		softAssert.assertAll()
		executionFlag = true
		return executionFlag
		
				
			
	}	
	
	
	public boolean verifyPropertyMaidService(String sheetName)
	{
		boolean executionFlag = false
		properyDBdata = new GetPropertyDBdata();
		int propertyId = Integer.parseInt(excelData.getKeyValue(sheetName,"PropertyId"));
		PropertyDTO dbData = properyDBdata.getMaidServiceData(propertyId)
		
		
		softAssert.assertEquals(dbData.getMaidServiceRequired(),excelData.getKeyValue(sheetName,"MaidService"),"Maid Service doens't match for the Property : " + propertyId )
		println "GC Maid Service Required : " + excelData.getKeyValue(sheetName,"MaidService") + "::" + "Database Value : " + dbData.getMaidServiceRequired()
		
			
		softAssert.assertEquals(dbData.getChargeApplies(),excelData.getKeyValue(sheetName,"ServiceCharge"),"Maid Service Charge doens't match for the Property : " + propertyId )
		println "GC Maid Service Charges : " + excelData.getKeyValue(sheetName,"ServiceCharge") + "::" + "Database Value : " + dbData.getChargeApplies()
		
		if(sheetName == "CB-5912-Update")
		{
		softAssert.assertEquals(dbData.getFrequency(),excelData.getKeyValue(sheetName,"Frequency"),"Maid Service Frequency doens't match for the Property : " + propertyId )
		println "GC Maid Service Frequency : " + excelData.getKeyValue(sheetName,"Frequency") + "::" + "Database Value : " + dbData.getFrequency()
		}
		
		else
		{
			println "GC Maid Service Frequency : " + excelData.getKeyValue(sheetName,"Frequency") + "::" + "Database Value : " + dbData.getFrequency()
		}
		
		
		
		
		softAssert.assertAll()
		executionFlag = true
		return executionFlag
			
	}
	public void verifyCheckinCheckoutDetails(String sheetName)
	{
		softAssert = new SoftAssert()
		
		properyDBdata = new GetPropertyDBdata();
		int propertyId = Integer.parseInt(excelData.getKeyValue(sheetName,"PropertyId"));
		PropertyDTO dbData =  properyDBdata.getPropertyData(propertyId);
				
		softAssert.assertEquals((dbData.getCheckinTime()),excelData.getKeyValue(sheetName,"CheckInTime"),"CheckIn Doesnt match with Database")
		println "GC CheckIn : " + excelData.getKeyValue(sheetName, "CheckInTime") + "::" + "Database Value : " + dbData.getCheckinTime()
		
		softAssert.assertEquals((dbData.getCheckoutTime()),excelData.getKeyValue(sheetName,"CheckOutTime"),"CheckOut Doesnt Match with Database")
		println "GC CheckOut : " + excelData.getKeyValue(sheetName, "CheckOutTime") + "::" + "Database Value : " + dbData.getCheckoutTime()
		
		softAssert.assertAll()
	}
	
	public void verifyPropertyStyles(String sheetName)
	{
		softAssert = new SoftAssert()
		
		properyDBdata = new GetPropertyDBdata();
		int propertyId = Integer.parseInt(excelData.getKeyValue(sheetName,"PropertyId"));
		PropertyDTO dbData =  properyDBdata.getPropertyData(propertyId); dbData.g
				
		softAssert.assertEquals((dbData.getCheckinTime()),excelData.getKeyValue(sheetName,"CheckInTime"),"CheckIn Doesnt match with Database")
		println "GC CheckIn : " + excelData.getKeyValue(sheetName, "CheckInTime") + "::" + "Database Value : " + dbData.getCheckinTime()
		
		softAssert.assertEquals((dbData.getCheckoutTime()),excelData.getKeyValue(sheetName,"CheckOutTime"),"CheckOut Doesnt Match with Database")
		println "GC CheckOut : " + excelData.getKeyValue(sheetName, "CheckOutTime") + "::" + "Database Value : " + dbData.getCheckoutTime()
		
	}
	
}
