package com.kuoni.qa.automation.page.object.contracts;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.gta.travel.page.base.GSPageBase;
import com.kuoni.qa.automation.page.object.cities.ViewCityPage;
import com.mediaocean.qa.framework.selenium.ui.controls.ComboBox;
import com.mediaocean.qa.framework.selenium.ui.controls.RadioButton;
import com.mediaocean.qa.framework.selenium.ui.controls.Table;
import com.mediaocean.qa.framework.selenium.ui.controls.TextBox;

public class ExtraAndSuppPage extends GSPageBase {

	public ExtraAndSuppPage() {
		super(getDriver());
	}

	public void selectResortFeeFromResults(Map<String, String> inputMap) {

		WebElement parentElement = waitForElement(By.id("resortFee_list"));
		sleep(3);
		Table resultsTable = new Table(parentElement, 1);
		for (int i = 1; i < resultsTable.getRowCount(); i++) {
			boolean isRecordFound = true;
			for (String key : inputMap.keySet()) {
				String value = inputMap.get(key);
				WebElement cellElement = resultsTable.getCell(i, key);
				if (!cellElement.getText().trim()
						.equalsIgnoreCase(value.trim())) {
					isRecordFound = false;
					break;
				}
			}
			if (isRecordFound) {
				resultsTable.clickOnRow(i);
				break;
			}
		}
		sleep(2);

	}

	public void createResortFee(Map<String, String> inputMap) {
		sleep(1);
		if (inputMap.containsKey("travel start day")) {
			ComboBox startDayCB = new ComboBox(
					By.id("resortFee-travelStart_day"));
			startDayCB.select(inputMap.get("travel start day"));
		}

		if (inputMap.containsKey("travel start month")) {
			ComboBox startMonthCB = new ComboBox(
					By.id("resortFee-travelStart_months"));
			startMonthCB.select(inputMap.get("travel start month"));
		}

		if (inputMap.containsKey("travel start year")) {
			ComboBox startYearCB = new ComboBox(
					By.id("resortFee-travelStart_years"));
			startYearCB.select(inputMap.get("travel start year"));
		}

		if (inputMap.containsKey("travel end day")) {
			ComboBox endDayCB = new ComboBox(By.id("resortFee-travelEnd_day"));
			endDayCB.select(inputMap.get("travel end day"));
		}

		if (inputMap.containsKey("travel end month")) {
			ComboBox endMonthCB = new ComboBox(
					By.id("resortFee-travelEnd_months"));
			endMonthCB.select(inputMap.get("travel end month"));
		}

		if (inputMap.containsKey("travel end year")) {
			ComboBox endYearCB = new ComboBox(
					By.id("resortFee-travelEnd_years"));
			endYearCB.select(inputMap.get("travel end year"));
		}

		if (inputMap.containsKey("pay locally")) {
			String value = inputMap.get("pay locally");
			if (value.equalsIgnoreCase("yes")) {
				RadioButton payLocallyYesRB = new RadioButton(
						By.id("payLocally"), "true");
				payLocallyYesRB.select();
			} else {
				RadioButton payLocallyNoRB = new RadioButton(
						By.id("payLocally"), "false");
				payLocallyNoRB.select();
			}
		}
		if (inputMap.containsKey("age limits")) {
			String value = inputMap.get("age limits");
			if (value.equalsIgnoreCase("yes")) {
				RadioButton ageLmtYesRB = new RadioButton(
						By.id("resortFee-onAgeLimitYes"));
				ageLmtYesRB.select();
				executeIEFireEventJS("resortFee-onAgeLimitYes", "onclick");
				sleepms(500l);
				if (inputMap.containsKey("age from")) {
					ComboBox ageFromCB = new ComboBox(
							By.id("resortFee-ageFrom"));
					ageFromCB.select(inputMap.get("age from"));
				}
				if (inputMap.containsKey("age to")) {
					ComboBox ageFromCB = new ComboBox(By.id("resortFee-ageTo"));
					ageFromCB.select(inputMap.get("age to"));
				}
			} else {
				RadioButton ageLmtNoRB = new RadioButton(
						By.id("resortFee-onAgeLimitNo"));
				ageLmtNoRB.select();
				executeIEFireEventJS("resortFee-onAgeLimitNo", "onclick");
				sleepms(500l);
			}
		}

		if (inputMap.containsKey("usd")) {
			TextBox pricePerNightTB = new TextBox(By.id("price"));
			pricePerNightTB.setText(inputMap.get("usd"));
		}
		if (inputMap.containsKey("per person/room")) {
			ComboBox endYearCB = new ComboBox(By.id("rateMultiple"));
			endYearCB.select(inputMap.get("per person/room"));
		}

		if (inputMap.containsKey("per night/stay")) {
			ComboBox endYearCB = new ComboBox(By.id("ratePeriod"));
			endYearCB.select(inputMap.get("per night/stay"));
		}
	}

}
