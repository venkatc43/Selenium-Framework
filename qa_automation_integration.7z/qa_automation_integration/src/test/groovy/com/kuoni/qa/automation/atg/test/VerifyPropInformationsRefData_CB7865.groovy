package com.kuoni.qa.automation.atg.test

import org.testng.asserts.SoftAssert;

import spock.lang.Shared;
import spock.lang.Specification
import spock.lang.Unroll;
import static com.kuoni.qa.automation.util.ReadFilesUtil.getFiles

import com.kuoni.atg.jaxbclasses.ChangerecordsType
import com.kuoni.atg.jaxbclasses.DescriptionType
import com.kuoni.atg.jaxbclasses.PropertyInformationDescriptionsRecord
import com.kuoni.qa.automation.common.properties.EnvironmentProperties;
import com.kuoni.qa.automation.dao.GetReferenceDataDescription;
import com.kuoni.qa.automation.dto.ReferenceDataDTO
import com.kuoni.qa.automation.helper.JaxbHelper
import com.kuoni.qa.automation.spock.annotation.Regression;
import com.kuoni.qa.automation.util.PerformDataLoadUtil

class VerifyPropInformationsRefData_CB7865 extends Specification{


	SoftAssert softAssert = new SoftAssert()
	GetReferenceDataDescription offerDesc = new GetReferenceDataDescription()

	@Shared
	EnvironmentProperties envProp = new EnvironmentProperties()

	def setupSpec() {

		def folderLocation = envProp.getValueForProperty("istDataLoc")+"/PropertyInformationDescriptionsRecord"
		PerformDataLoadUtil dataLoad = new PerformDataLoadUtil()
		dataLoad.changeTestDataReaderLocation(folderLocation)
		dataLoad.importFilesandPerformLoadfromQueue()
	}

	@Regression
	@Unroll
	public "verifyReferenceData for : #xmlFile.getName()"() {

		given: "The XmLs are available at the desired Location"
		ReferenceDataDTO data
		JaxbHelper jaxbObj = new JaxbHelper()

		ChangerecordsType xml = jaxbObj.buildRequestJaxbClass(xmlFile)

		xml.recordset.get(0).record.get(0)

		PropertyInformationDescriptionsRecord recordNode = xml.recordset.get(0).record.get(0)

		String informationCode = recordNode.getPropertyInformationDescriptionsRecord().getCode().value()

		List<DescriptionType> informDescList =  recordNode.getPropertyInformationDescriptionsRecord().getInformationDescriptions().getInformationDescription()



		println "\n xml File : " + xmlFile.getName()
		println "Code : " + informationCode
		int languageCount = recordNode.getPropertyInformationDescriptionsRecord().getInformationDescriptions().getInformationDescription().size()
		println "Xml Language Count :  " + languageCount
		when:"The data can be read from XML and Database"
		for(DescriptionType informationDescriptions: informDescList) {
			String language = informationDescriptions.getLanguage().value()
			String informationDescription = informationDescriptions.getText()
			data = offerDesc.getOfferDesc(informationCode,language,312)

			//println "DB Language Count : " + data.getLanguageCount()
			if(languageCount == data.getLanguageCount())

			{
				println "\n Language::" + language + "::"
				println "xml Information Description :  " + informationDescription
				println "\n Database Information Desc : " +  data.getDataDescription()

				softAssert.assertEquals(informationDescription, data.getDataDescription(),"Information Description : "+informationDescription+ "Doesnot Match with Database"+ data.getDataDescription() )

			}

			else
				softAssert.assertEquals(languageCount,data.getLanguageCount(),"The Language count doesn't match with Database")

		}

		softAssert.assertAll()
		then:"The XML Descriptions should match with Database"

		where:

		xmlFile << getFiles("/PropertyInformationDescriptionsRecord")


	}


}
