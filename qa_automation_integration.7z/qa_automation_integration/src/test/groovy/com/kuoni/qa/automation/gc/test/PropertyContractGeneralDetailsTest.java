package com.kuoni.qa.automation.gc.test;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.By;

import com.gta.travel.page.base.GSTestBase;
import com.gta.travel.page.object.common.TopLinksPage;
import com.gta.travel.page.object.contract.generaldetails.GeneralDetailsSourceMarketSectionPage;
import com.gta.travel.page.object.contract.search.ContractSearchPage;
import com.gta.travel.page.object.contract.search.ContractSearchResultsPage;
import com.kuoni.qa.automation.page.object.common.HomePageSub;
import com.kuoni.qa.automation.page.object.common.LoginPageSub;
import com.kuoni.qa.automation.page.object.contracts.GeneralDetailsProviderSectionPageCustom;
import com.mediaocean.qa.framework.utils.ExcelUtil;

/**
 * Class to Execute Automation on GC Content
 * @author suryakumar.surendran
 *
 */
public class PropertyContractGeneralDetailsTest extends GSTestBase {

	private String userName;
	private String password;
	private String webId;

	private String sheetName = null;

	private ContractSearchPage contractSearchPage;
	private ContractSearchResultsPage contractSearchResultsPage;
	private GeneralDetailsProviderSectionPageCustom generalDetailsPage;
	
	private TopLinksPage topLinksPage;

	private ExcelUtil excelData;

	public PropertyContractGeneralDetailsTest(String driverSheetPath, String dataSheetPath,
			String sheetName) {
		this.sheetName = sheetName;
		init(driverSheetPath, dataSheetPath);
	}

	/**
	 * Initialize the driver sheet and data sheet 
	 * @param driverSheetPath
	 * @param dataSheetPath
	 */
	public void init(String driverSheetPath, String dataSheetPath) {
		excelData = new ExcelUtil(dataSheetPath);
		if (driverSheetPath != null) {
			setDriverSheetAbsolutePath(driverSheetPath);
		} else {
			setDriverSheetFileName("Driver_Sheet.xls");
		}
		initialiseEnvironmentAndTest();
		openBrowser();
		setLoginInfo();
	}

	/**
	 * Set logging info for GC Content
	 */
	private void setLoginInfo() {
		webId = excelUtil.getKeyValue(ENVIRONMENT, "webId");
		userName = excelUtil.getKeyValue(ENVIRONMENT, "userName");
		password = excelUtil.getKeyValue(ENVIRONMENT, "password");
	}

	/**
	 * Method to execute the Script to run automation on GC Content
	 */
	public void executeDataScriptForCreateContract() {
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSelectGeneralDetails();
		createContractFlow();
		getDriver().quit();
	}
	
	/**
	 * Method to execute the Script to run automation on GC Content
	 */
	public void executeDataScriptForUpdateContract() {
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSelectGeneralDetails();
		editContractFlow();
		getDriver().quit();
	}
	
	
	public void executeDataScriptForUpdateContractMarketsExcluded() {
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSelectGeneralDetails();
		editContractFlowMarketsExcluded();
		getDriver().quit();
	}
	
	public void executeDataScriptForUpdateContractMarketsNotExcluded() {
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSelectGeneralDetails();
		editContractFlowMarketsNotExcluded();
		getDriver().quit();
	}
	
	/**
	 * Method to execute the Script to run automation on GC Content
	 */
	public void executeDataScriptForDeleteContract() {
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSelectGeneralDetails();
		deleteContractFlow();
		getDriver().quit();
	}
	
	
	/**
	 * Method to execute the login page on GC Content  
	 */
	private void executeLoginPageFlow() {
		LoginPageSub loginPage = new LoginPageSub();
		HomePageSub homePage = loginPage.login(webId, userName, password);
		contractSearchPage = homePage.selectContract();
		contractSearchPage.sleep(2);
	}
	
	private void executeSelectGeneralDetails() {
		topLinksPage = TopLinksPage.getInstance();
		topLinksPage.clickGeneralDetailsTab();
	}

	/**
	 * Method to execute Contract Search on GC Content 
	 */
	private void executeSearchScreenFlow() {

		Map<String, String> searchDataMap = new HashMap<String, String>();
		// Set the search data to the map here.
		searchDataMap.put("Country",
				excelData.getKeyValue(sheetName, "Country"));
		searchDataMap.put("City", excelData.getKeyValue(sheetName, "City"));
		searchDataMap.put("Property Name",
				excelData.getKeyValue(sheetName, "Property Name"));
		contractSearchResultsPage = contractSearchPage.search(searchDataMap);
		contractSearchResultsPage.sleep(3);
		contractSearchResultsPage.selectFirstRowFromTheResults();
	}
	

	
	
	private Map<String, String> loadDataIntoMap(){
		Map<String, String> map = new HashMap<String, String>();

		if (excelData.getKeyValue(sheetName, "provider") != null
				&& !excelData.getKeyValue(sheetName, "provider").equals("")) {
			map.put("provider",
					excelData.getKeyValue(sheetName, "provider"));
		}
		
		if (excelData.getKeyValue(sheetName, "business type") != null
				&& !excelData.getKeyValue(sheetName, "business type").equals("")) {
			map.put("business type",
					excelData.getKeyValue(sheetName, "business type"));
		}
		
		if (excelData.getKeyValue(sheetName, "margin amount") != null
				&& !excelData.getKeyValue(sheetName, "margin amount").equals("")) {
			map.put("margin amount",
					excelData.getKeyValue(sheetName, "margin amount"));
		}
		
		if (excelData.getKeyValue(sheetName, "model") != null
				&& !excelData.getKeyValue(sheetName, "model").equals("")) {
			map.put("model",
					excelData.getKeyValue(sheetName, "model"));
		}
		
		if (excelData.getKeyValue(sheetName, "channel") != null
				&& !excelData.getKeyValue(sheetName, "channel").equals("")) {
			map.put("channel",
					excelData.getKeyValue(sheetName, "channel"));
		}
		
		if (excelData.getKeyValue(sheetName, "inventory style") != null
				&& !excelData.getKeyValue(sheetName, "inventory style").equals("")) {
			map.put("inventory style",
					excelData.getKeyValue(sheetName, "inventory style"));
		}
		
		if (excelData.getKeyValue(sheetName, "inventory release time") != null
				&& !excelData.getKeyValue(sheetName, "inventory release time").equals("")) {
			map.put("inventory release time",
					excelData.getKeyValue(sheetName, "inventory release time"));
		}
		
		if (excelData.getKeyValue(sheetName, "currency") != null
				&& !excelData.getKeyValue(sheetName, "currency").equals("")) {
			map.put("currency",
					excelData.getKeyValue(sheetName, "currency"));
		}
		
		return map;

	}
	
	private void createContractFlow(){
		Map<String, String> map = loadDataIntoMap();
		
		generalDetailsPage = GeneralDetailsProviderSectionPageCustom.getInstance();
		
		generalDetailsPage.selectProviderOptions("Create");
		generalDetailsPage.createProvider(map);
		generalDetailsPage.sleep(2);
		generalDetailsPage.saveNewProvider();	
	}
	
	private void editContractFlow(){
		
		
		
		Map<String, String> map = loadDataIntoMap();
		
		generalDetailsPage = GeneralDetailsProviderSectionPageCustom.getInstance();
		
		Map<String, String> selectMap = new HashMap<String, String>();
		selectMap.put("Provider", excelData.getKeyValue(sheetName, "Provider"));
		selectMap.put("Model", excelData.getKeyValue(sheetName, "Model"));
		selectMap.put("Inventory Style", excelData.getKeyValue(sheetName, "inventory style").equalsIgnoreCase("Room")?"Category":"Room");
		generalDetailsPage.selectFromCOntract(selectMap);
		
		
		generalDetailsPage.selectProviderOptions("Edit");
		generalDetailsPage.editProvider(map);
		generalDetailsPage.updateEditProvider();	
	}
	
	private void editContractFlowMarketsExcluded(){
		
		generalDetailsPage = GeneralDetailsProviderSectionPageCustom.getInstance();
		
		Map<String, String> selectMap = new HashMap<String, String>();
		selectMap.put("Model", excelData.getKeyValue(sheetName, "Model"));
		generalDetailsPage.selectFromCOntract(selectMap);
		
		GeneralDetailsSourceMarketSectionPage generalDetailsSourceMarketSectionPage = GeneralDetailsSourceMarketSectionPage.getInstance();
		generalDetailsSourceMarketSectionPage.clickEditOnSourceMarket();
		generalDetailsSourceMarketSectionPage.selectMarketsOption("false");
		generalDetailsSourceMarketSectionPage.checkAllSourceMarketsForCountry(By.id("zoneOpener-US"), By.name("country.US"));
		
		
		generalDetailsSourceMarketSectionPage.updateSourceMarket("Save");
		
	
	}
	
	private void editContractFlowMarketsNotExcluded(){
		
		generalDetailsPage = GeneralDetailsProviderSectionPageCustom.getInstance();
		
		Map<String, String> selectMap = new HashMap<String, String>();
		selectMap.put("Model", excelData.getKeyValue(sheetName, "Model"));
		generalDetailsPage.selectFromCOntract(selectMap);
		
		GeneralDetailsSourceMarketSectionPage generalDetailsSourceMarketSectionPage = GeneralDetailsSourceMarketSectionPage.getInstance();
		generalDetailsSourceMarketSectionPage.clickEditOnSourceMarket();
		generalDetailsSourceMarketSectionPage.selectMarketsOption("true");

		generalDetailsSourceMarketSectionPage.updateSourceMarket("Save");
		
	
	}
	
	private void deleteContractFlow(){
		Map<String, String> selectMap = new HashMap<String, String>();
		selectMap.put("Model", excelData.getKeyValue(sheetName, "Model"));
		generalDetailsPage = GeneralDetailsProviderSectionPageCustom.getInstance();
		generalDetailsPage.selectFromCOntract(selectMap);
	
		generalDetailsPage = GeneralDetailsProviderSectionPageCustom.getInstance();		
		generalDetailsPage.selectProviderOptions("Delete");
		generalDetailsPage.deleteAndOKProvider();
	}
	
	
}
