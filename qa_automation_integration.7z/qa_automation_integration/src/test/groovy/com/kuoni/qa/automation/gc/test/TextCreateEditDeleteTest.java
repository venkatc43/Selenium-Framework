package com.kuoni.qa.automation.gc.test;

import java.util.HashMap;
import java.util.Map;

import com.gta.travel.page.base.GSTestBase;
import com.kuoni.qa.automation.page.object.common.HomePageSub;
import com.kuoni.qa.automation.page.object.common.LoginPageSub;
import com.kuoni.qa.automation.page.object.text.TextListPage;
import com.kuoni.qa.automation.page.object.text.TextPage;
import com.kuoni.qa.automation.page.object.text.TextResultListPage;
import com.kuoni.qa.automation.page.object.text.ViewTextPage;
import com.kuoni.qa.constants.CommonConstants;
import com.mediaocean.qa.framework.utils.ExcelUtil;

public class TextCreateEditDeleteTest extends GSTestBase{

	private String userName;
	private String password;
	private String webId;
	
	private static String sheetName = null;
	
	private TextListPage textListPage;
	private TextResultListPage textResultListPage;
	private ViewTextPage viewTextPage;
	private TextPage textPage;
	private ExcelUtil excelData;
	
	public TextCreateEditDeleteTest(String driverSheetPath, String dataSheetPath, String sheetName){
		this.sheetName = sheetName;
		init(driverSheetPath, dataSheetPath);		
	}
	
	public void init(String driverSheetPath, String dataSheetPath){
		excelData = new ExcelUtil(dataSheetPath);
		if (driverSheetPath != null){
			setDriverSheetAbsolutePath(driverSheetPath);
		}
		initialiseEnvironmentAndTest();
		openBrowser();
		setLoginInfo();
		CommonConstants.webDriver = getDriver();
	}

	private void setLoginInfo(){
		webId = excelUtil.getKeyValue(ENVIRONMENT, "webId");
		userName = excelUtil.getKeyValue(ENVIRONMENT, "userName");
		password = excelUtil.getKeyValue(ENVIRONMENT, "password");
	}
	
	public void executeDataScriptForCreate(){
		executeLoginPageFlow();
		executeSearcTextFlowForCreate();
		executeCreateTextFlow();
//		getDriver().quit();
	}
	
	public void executeDataScriptForEdit(){
		executeLoginPageFlow();
		executeSearcTextFlowForEdit();
		executeEditTextFlow();
//		getDriver().quit();
	}
	
	public void executeDataScriptForDelete(){
		executeLoginPageFlow();
		executeSearcTextFlowForDelete();
//		getDriver().quit();
	}
	
	private void executeLoginPageFlow() {
		LoginPageSub loginPage = new LoginPageSub();
		HomePageSub homePage = loginPage.login(webId, userName, password);
		textListPage = homePage.selectTexts();			
	}

	private void executeSearcTextFlowForCreate() {
		Map<String, String> searchDataMap = new HashMap<String, String>();
		searchDataMap.put("Category", excelData.getKeyValue(sheetName, "Category"));
		textResultListPage = textListPage.serachCategory(searchDataMap);
		textPage  = textListPage.selectCreateText();
		textPage.sleep(2);
	}
	
	private void executeSearcTextFlowForEdit() {
		Map<String, String> searchDataMap = new HashMap<String, String>();
		searchDataMap.put("Category", excelData.getKeyValue(sheetName, "Category"));
		searchDataMap.put("Code", excelData.getKeyValue(sheetName, "Code"));
		if(!excelData.getKeyValue(sheetName, "Language").trim().equals("")){
			searchDataMap.put("Language", excelData.getKeyValue(sheetName, "Language"));
		}			
		searchDataMap.put("Text", excelData.getKeyValue(sheetName, "Text"));
		textResultListPage = textListPage.serachCategory(searchDataMap);
		textResultListPage.sleep(3);
		viewTextPage = textResultListPage.selectRecordFromSearchResults(searchDataMap);
		textPage = viewTextPage.clickEdit();
		textPage.sleep(1);
	}

	private void executeSearcTextFlowForDelete() {
		Map<String, String> searchDataMap = new HashMap<String, String>();
		searchDataMap.put("Category", excelData.getKeyValue(sheetName, "Category"));
		searchDataMap.put("Code", excelData.getKeyValue(sheetName, "Code"));
		if(!excelData.getKeyValue(sheetName, "Language").trim().equals("")){
			searchDataMap.put("Language", excelData.getKeyValue(sheetName, "Language"));
		}			
		searchDataMap.put("Text", excelData.getKeyValue(sheetName, "Text"));
		textResultListPage = textListPage.serachCategory(searchDataMap);
		textResultListPage.sleep(2);
		viewTextPage = textResultListPage.selectRecordFromSearchResults(searchDataMap);
		viewTextPage.clickDelete();
		viewTextPage.sleep(2);
	}
	
	private void executeCreateTextFlow() {
		Map<String, String> data = new HashMap<String, String>();
		data.put("Code", excelData.getKeyValue(sheetName, "Code"));
		if(!excelData.getKeyValue(sheetName, "Language").trim().equals("")){
			data.put("Language", excelData.getKeyValue(sheetName, "Language"));
		}		
		data.put("Text", excelData.getKeyValue(sheetName, "Text"));
		textPage.createText(data);
		textPage.sleep(2);
	}	

	private void executeEditTextFlow() {
		Map<String, String> data = new HashMap<String, String>();
		if(!(excelData.getKeyValue(sheetName, "CodeEdit").trim().equals(""))){
			data.put("Code", excelData.getKeyValue(sheetName, "CodeEdit"));
		}
		data.put("Text", excelData.getKeyValue(sheetName, "TextEdit"));
		textPage.createText(data);
		textPage.sleep(2);
	}

	public ExcelUtil getExcelData() {
		return excelData;
	}	
	
}
