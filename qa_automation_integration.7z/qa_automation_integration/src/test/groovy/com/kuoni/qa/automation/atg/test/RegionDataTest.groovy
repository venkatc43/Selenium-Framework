package com.kuoni.qa.automation.atg.test

import org.testng.asserts.SoftAssert

import spock.lang.Shared;
import spock.lang.Specification
import spock.lang.Unroll
import static com.kuoni.qa.automation.util.ReadFilesUtil.getFiles

import com.kuoni.qa.automation.common.properties.EnvironmentProperties
import com.kuoni.qa.automation.dao.GetRegionDBdata
import com.kuoni.qa.automation.dto.RegionDTO
import com.kuoni.qa.automation.spock.annotation.Regression
import com.kuoni.qa.automation.util.PerformDataLoadUtil

class RegionDataTest extends Specification {

	@Shared
	EnvironmentProperties envProp = new EnvironmentProperties()

	def setupSpec() {

		def folderLocation = envProp.getValueForProperty("istDataLoc")+"/Region"
		PerformDataLoadUtil dataLoad = new PerformDataLoadUtil()
		dataLoad.changeTestDataReaderLocation(folderLocation)
		dataLoad.importFilesandPerformLoadfromQueue()
	}

	@Regression
	@Unroll
	def "VerifyRegionXmldata for : #fileEntry.getName()"() {

		given: "Region Xmls are available at specified location and are according to Required XSD"
		SoftAssert softAssert = new SoftAssert()

		when: "Region xml files are according to the XSD agreed and accesible by the tests"
		RegionDTO xmlData = new RegionDTO()
		EnvironmentProperties envProp = new EnvironmentProperties()

		//parse the xml file and read the values for required nodes
		def regionXml = new XmlParser().parse(fileEntry)
		def r = regionXml.recordset.record.region
		def regionId = r.@regionId[0]
		xmlData.setRegionCode( r.@code[0])
		xmlData.setRegionDesc(r.regionDescriptions.regionDescription[0].text.text())
		xmlData.setCountryId(r.countryId.text().toInteger())

		GetRegionDBdata data = new GetRegionDBdata()

		RegionDTO dbData = data.getRegiondata(regionId)

		println "\n" + "Verifying Data for Region : " + fileEntry.getName() + "\n"

		//validate xml values with the database
		def properties = xmlData.properties
		properties.each {node,val->
			if("$node"!="class")
			{
				softAssert.assertEquals(xmlData."$node", dbData."$node", "\n" + "xml " + "$node" + ":" + xmlData."$node" +" Doesnot Match with Database " + "$node" +":" + dbData."$node")
				println "Xml" + "$node" + ": " + xmlData."$node"+ " DataBase" + "$node" + ": " + dbData."$node"
			}
		}


		softAssert.assertAll()
		then: "The XML Data for Regions should Match with the Database"

		where:
		fileEntry << getFiles("/Region")
	}
}
