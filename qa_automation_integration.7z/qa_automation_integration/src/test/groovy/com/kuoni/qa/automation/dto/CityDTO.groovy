package com.kuoni.qa.automation.dto

class CityDTO {
	
	def cityCount
	def cityCode
	def timeZone
	def regionId
	def countryId
	

}
