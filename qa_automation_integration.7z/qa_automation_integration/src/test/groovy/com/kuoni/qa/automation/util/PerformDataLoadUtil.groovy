package com.kuoni.qa.automation.util

import com.kuoni.qa.automation.common.properties.EnvironmentProperties

class PerformDataLoadUtil {
	
		
	def host
	def auth
	
		def	envprops = new EnvironmentProperties()
			
			def perfomDataLoadfromtheQueue() {
		//		browser.clearCookies()
				performDataLoadRequest()
			}
			
			
			def importFilesandPerformLoadfromQueue()
			{
				pushToQueueRequest()
				performDataLoadRequest()
			}
			
			def incrementalPushtoCoherence()
			{	
				println "Pushing data to Coherence using Coherence Clinet Service..."
				host =envprops.getValueForProperty("esb.host.url")
				auth = envprops.getValueForProperty("esb.host.auth")
				def pushDataCmd = "curl -u ${auth} ${host}/dyn/admin/nucleus/fit/etl/deployment/FITDeploymentManager/?invokeMethod=executeIncrementalDeployment"
				Process proc = pushDataCmd.execute()
				proc.waitForOrKill(10000L)
				println "Coherence Update Completed..."
			}
			
			
			def changeTestDataReaderLocation(String folderLoc)
			{
				host =envprops.getValueForProperty("esb.host.url")
				auth = envprops.getValueForProperty("esb.host.auth")
//				curl -u admin:weblogic1 -d "propertyName=sourceDirectoriesPaths" -d "newValue=/tmp/hotels-data/Property"http://longwlg05a.emea.kuoni.int:8180/dyn/admin/nucleus/fit/commerce/catalog/loader/TestDataReaderProperty/
				def pushDataCmd = "curl -u ${auth} -d propertyName=sourceDirectoriesPaths -d newValue=${folderLoc} ${host}/dyn/admin/nucleus/fit/commerce/catalog/loader/TestDataReaderProperty/"
				Process proc = pushDataCmd.execute()
//				proc.waitFor()
				println "TestData Reader Location Changed..."
				
				
			}
	
		
			def pushToQueueRequest() {
				host =envprops.getValueForProperty("esb.host.url")
				auth = envprops.getValueForProperty("esb.host.auth")
				def pushDataCmd = "curl -u ${auth} ${host}/dyn/admin/nucleus/fit/commerce/catalog/loader/TestDataReaderProperty/?invokeMethod=processImportFromDirectory"
				Process proc = pushDataCmd.execute()
//				proc.waitFor()
				proc.waitForOrKill(20000L)
				if(proc.waitFor()!=0)
				println "ImportFiles Failed...."
				
				
				println "\n * XML Files are Imported to the DataLoader Queue * "
			}
		
			def pushToDownStream() {
			 host =envprops.getValueForProperty("esb.host.url")
			 auth = envprops.getValueForProperty("esb.host.auth")
			 def pushDataCmd = "curl -u ${auth} ${host}/dyn/admin/nucleus/fit/etl/deployment/FITDeploymentManager/?invokeMethod=executeIncrementalDeployment"
			 Process proc = pushDataCmd.execute()
			proc.waitForOrKill(10000L)
			 }
			
		
			def performDataLoadRequest() {
				
				println "Starting Perform DATA LOAD Process...."
				host =envprops.getValueForProperty("esb.host.url")
				auth = envprops.getValueForProperty("esb.host.auth")
				def dataLoadCmd = "curl -u ${auth} ${host}/dyn/admin/nucleus/fit/commerce/catalog/loader/CatalogImportManager/?invokeMethod=doPerformDataLoad"
				
				Process proc = dataLoadCmd.execute()
				proc.waitForOrKill(10000L)
				sleep(5000)
				if(proc.waitFor()!=0)
				println "PerformDataLoad Failed...."
				println "\n * DataLoad Process Completed..... "
			}

}
