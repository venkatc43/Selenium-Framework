package com.kuoni.qa.automation.gc.test;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.By;

import com.gta.travel.page.base.GSTestBase;
import com.gta.travel.page.object.common.TopLinksPage;
import com.gta.travel.page.object.contract.manageavailability.ManageAvailabilitySearchAndResultsSectionPage;
import com.gta.travel.page.object.contract.rateplans.RatePlanDetailsSectionPage;
import com.gta.travel.page.object.contract.rateplans.RatePlanSmartFillRateSectionPage;
import com.gta.travel.page.object.contract.rateplans.RatePlanStandardRateSectionPage;
import com.gta.travel.page.object.contract.search.ContractSearchPage;
import com.gta.travel.page.object.contract.search.ContractSearchResultsPage;
import com.kuoni.qa.automation.page.object.common.HomePageSub;
import com.kuoni.qa.automation.page.object.common.LoginPageSub;
import com.kuoni.qa.automation.page.object.contracts.RatePlanStandardRateSectionPageCustom;
import com.kuoni.qa.constants.CommonConstants;
import com.mediaocean.qa.framework.utils.DateUtil;
import com.mediaocean.qa.framework.utils.ExcelUtil;

public class RateRuleContractTest extends GSTestBase {

	private String userName;
	private String password;
	private String webId;

	private static String sheetName = null;

	private ContractSearchPage contractSearchPage;
	private ContractSearchResultsPage contractSearchResultsPage;
	private RatePlanStandardRateSectionPage rpDetailsSectionPage;
	private RatePlanStandardRateSectionPageCustom rpDetailsSectionPage1;
	private RatePlanDetailsSectionPage DetailsSectionPage;
	private RatePlanSmartFillRateSectionPage rpSmartRateSectionPage;
	private ManageAvailabilitySearchAndResultsSectionPage manageSectionPage;
	private TopLinksPage topLinksPage;
	private ExcelUtil excelData;

	// ExcelUtil excelData = null;

	public RateRuleContractTest ( String driverSheetPath, String dataSheetPath, String sheetName ) {
		this.sheetName = sheetName;
		init(driverSheetPath, dataSheetPath);
	}

	public void init ( String driverSheetPath, String dataSheetPath ) {
		excelData = new ExcelUtil(dataSheetPath);

		if (driverSheetPath != null) {

			setDriverSheetAbsolutePath(driverSheetPath);
		} else {
			setDriverSheetFileName("Driver_Sheet.xls");
		}
		initialiseEnvironmentAndTest();
		openBrowser();
		setLoginInfo();
		if (CommonConstants.webDriver != null) {
			CommonConstants.webDriver = getDriver();
		}
	}

	private void setLoginInfo ( ) {
		webId = excelUtil.getKeyValue(ENVIRONMENT, "webId");
		userName = excelUtil.getKeyValue(ENVIRONMENT, "userName");
		password = excelUtil.getKeyValue(ENVIRONMENT, "password");
	}

	public void executeDataScriptForCreate ( ) {
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSelectRatePlan();
		executeCreateRatePlanFlow();
		// getDriver().quit();
	}

	public void executeDataScriptForEdit ( ) {
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSelectRatePlan();
		executeEditRatePlanFlow();
		// getDriver().quit();
	}

	public void executeDataScriptForDelete ( ) {
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSelectRatePlan();
		executeDeleteRatePlanFlow();
		// getDriver().quit();
	}

	public void executeRoomRateStaticForCreate ( ) {
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSelectRatePlan();
		executeCreateRoomRateStaticFlow();
		// getDriver().quit();
	}

	public void executeRoomRateStaticForEdit ( ) {
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSelectRatePlan();
		executeEditRoomRateStaticFlow();
		// getDriver().quit();
	}

	public void executeRoomRateStaticForDelete ( ) {
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSelectRatePlan();
		executeDeleteRoomRateStaticFlow();
		// getDriver().quit();
	}

	public void executeRoomRateMarginForCreate ( ) {
		executeLoginPageFlow();
		executeSearchMarginFlow();
		executeSelectRatePlan();
		executeCreateRoomRateMarginFlow();
		// executeEditRoomRateMarginFlow();
		// getDriver().quit();
	}

	public void executeRoomRateMarginForEdit ( ) {
		executeLoginPageFlow();
		executeSearchMarginFlow();
		executeSelectRatePlan();
		executeEditRoomRateMarginFlow();
		// getDriver().quit();
	}

	public void executeRoomRateMarginForDelete ( ) {
		executeLoginPageFlow();
		executeSearchMarginFlow();
		executeSelectRatePlan();
		executeDeleteRoomRateMarginFlow();
		// getDriver().quit();
	}

	public void executeRateRuleMarginForCreate ( ) {
		executeLoginPageFlow();
		executeSearchMarginFlow();
		executeSelectRatePlan();
		executeCreateRatePlanMarginFlow();
		// getDriver().quit();
	}

	public void executeRateRuleMarginForEdit ( ) {
		executeLoginPageFlow();
		executeSearchMarginFlow();
		executeSelectRatePlan();
		executeEditRatePlanMarginFlow();
		// getDriver().quit();
	}

	public void executeRateRuleMarginForDelete ( ) {
		executeLoginPageFlow();
		executeSearchMarginFlow();
		executeSelectRatePlan();
		executeDeleteRatePlanMarginFlow();
		// getDriver().quit();
	}

	private void executeLoginPageFlow ( ) {
		LoginPageSub loginPage = new LoginPageSub();
		HomePageSub homePage = loginPage.login(webId, userName, password);
		contractSearchPage = homePage.selectContract();
		contractSearchPage.sleep(2);
	}

	private void executeSearchScreenFlow ( ) {

		Map<String, String> searchDataMap = new HashMap<String, String>();
		// Set the search data to the map here.
		searchDataMap.put("Country", excelData.getKeyValue(sheetName, "Country"));
		searchDataMap.put("Model", excelData.getKeyValue(sheetName, "Model"));
		contractSearchResultsPage = contractSearchPage.search(searchDataMap);
		contractSearchResultsPage.sleep(3);
		contractSearchResultsPage.selectFirstRowFromTheResults();
	}

	private void executeSearchMarginFlow ( ) {

		Map<String, String> searchDataMap = new HashMap<String, String>();
		// Set the search data to the map here.
		searchDataMap.put("Country", excelData.getKeyValue(sheetName, "Country"));
		searchDataMap.put("Model", excelData.getKeyValue(sheetName, "Model"));
		contractSearchResultsPage = contractSearchPage.search(searchDataMap);
		contractSearchResultsPage.sleep(3);
		contractSearchResultsPage.selectFirstRowFromTheResults();
	}

	private void executeSelectRatePlan ( ) {
		DetailsSectionPage = RatePlanDetailsSectionPage.getInstance();
		Map<String, String> map = new HashMap<String, String>();
		map.put("Rate Plan Code", excelData.getKeyValue(sheetName, "Rate Plan Code"));
		// DetailsSectionPage.selectRatePlan(map);
		DetailsSectionPage.selectRatePlanFromTheList(map);
	}

	private void executeCreateRatePlanFlow ( ) {

		rpDetailsSectionPage = RatePlanStandardRateSectionPage.getInstance();
		rpDetailsSectionPage1 = RatePlanStandardRateSectionPageCustom.getInstance();
		Map<String, String> map = new HashMap<String, String>();

		String todayDay = Integer.toString(DateUtil.getDay(new Date()));
		String todayMonth = DateUtil.getMonthName(new Date());
		String todayYear = Integer.toString(DateUtil.getYear(new Date()));
		Date futureDate = DateUtil.addDays(new Date(), 20);
		String endDay = Integer.toString(DateUtil.getDay(futureDate));
		String endMonth = DateUtil.getMonthName(futureDate);
		String endYear = Integer.toString(DateUtil.getYear(futureDate));

		map.put("start day", todayDay);
		map.put("start month", todayMonth);
		map.put("start year", todayYear);
		map.put("end day", endDay);
		map.put("end month", endMonth);
		map.put("end year", endYear);
		map.put("days", excelData.getKeyValue(sheetName, "days"));
		map.put("minimum nights", excelData.getKeyValue(sheetName, "minimum nights"));
		map.put("minimum passengers", excelData.getKeyValue(sheetName, "minimum passengers"));
		map.put("rate type", excelData.getKeyValue(sheetName, "rate type"));
		map.put("more rules", excelData.getKeyValue(sheetName, "more rules"));
		map.put("stay full period", excelData.getKeyValue(sheetName, "stay full period"));

		rpDetailsSectionPage.createOptionClick();
		rpDetailsSectionPage1.createStandardRates(map);
		rpDetailsSectionPage.sleep(2);
		rpDetailsSectionPage.saveCreateRateRules();
		rpDetailsSectionPage.saveSaveCreateRateRules();
		rpDetailsSectionPage.sleep(2);
	}

	private void executeEditRatePlanFlow ( ) {
		rpDetailsSectionPage = RatePlanStandardRateSectionPage.getInstance();
		rpDetailsSectionPage1 = RatePlanStandardRateSectionPageCustom.getInstance();

		Map<String, String> map = new HashMap<String, String>();
		// map.put("standard room type net", "110");
		// map.put("room type edit", "no");
		Date startDate = DateUtil.getDate();
		Date futureDate = DateUtil.addDays(new Date(), 20);
		String startDateStr = DateUtil.convertDateToGTAFormat(startDate);
		String endDateStr = DateUtil.convertDateToGTAFormat(futureDate);

		String travelDates = startDateStr + " - " + endDateStr;

		Map<String, String> selectMap = new HashMap<String, String>();
		selectMap.put("Days", excelData.getKeyValue(sheetName, "days"));
		selectMap.put("Rate Type", excelData.getKeyValue(sheetName, "rate type"));
		selectMap.put("Min Nights", excelData.getKeyValue(sheetName, "minimum nights"));
		selectMap.put("Min Pax", excelData.getKeyValue(sheetName, "minimum passengers"));
		selectMap.put("Rules", excelData.getKeyValue(sheetName, "more rules"));
		selectMap.put("Travel Dates", travelDates);

		map.put("stay full period", excelData.getKeyValue(sheetName, "stay full period"));

		rpDetailsSectionPage.selectRateRule(selectMap);
		rpDetailsSectionPage.selectRateRuleOptions("Edit");
		rpDetailsSectionPage1.editRateRules(map);
		rpDetailsSectionPage.updateEditRateRules();
		rpDetailsSectionPage.refreshOptionClick();

	}

	private void executeDeleteRatePlanFlow ( ) {

		rpDetailsSectionPage = RatePlanStandardRateSectionPage.getInstance();
		rpDetailsSectionPage1 = RatePlanStandardRateSectionPageCustom.getInstance();
		Map<String, String> selectMap = new HashMap<String, String>();

		Date startDate = DateUtil.getDate();
		Date futureDate = DateUtil.addDays(new Date(), 20);
		String startDateStr = DateUtil.convertDateToGTAFormat(startDate);
		String endDateStr = DateUtil.convertDateToGTAFormat(futureDate);

		String travelDates = startDateStr + " - " + endDateStr;

		selectMap.put("Days", excelData.getKeyValue(sheetName, "days"));
		selectMap.put("Rate Type", excelData.getKeyValue(sheetName, "rate type"));
		selectMap.put("Min Nights", excelData.getKeyValue(sheetName, "minimum nights"));
		selectMap.put("Min Pax", excelData.getKeyValue(sheetName, "minimum passengers"));
		selectMap.put("Rules", excelData.getKeyValue(sheetName, "more rules"));
		selectMap.put("Travel Dates", travelDates);
		// selectMap.put("Description", "Superior Deluxe");

		rpDetailsSectionPage.refreshOptionClick();
		int countBefore = rpDetailsSectionPage.getRateRuleTableRowCount();
		rpDetailsSectionPage.selectRateRule(selectMap);
		rpDetailsSectionPage.selectRateRuleOptions("Delete");
		rpDetailsSectionPage.deleteRateRuleWithOK();
		assertTrue(rpDetailsSectionPage.verifyRecordUpdatedMessage(By.id("rateRuleContent"),
				"Record deleted"));
		int countAfter = rpDetailsSectionPage.getRateRuleTableRowCount();
		assertTrue(countBefore == countAfter + 1);
	}

	private void executeCreateRoomRateStaticFlow ( ) {

		rpDetailsSectionPage = RatePlanStandardRateSectionPage.getInstance();
		rpDetailsSectionPage1 = RatePlanStandardRateSectionPageCustom.getInstance();
		Map<String, String> map = new HashMap<String, String>();

		String todayDay = Integer.toString(DateUtil.getDay(new Date()));
		String todayMonth = DateUtil.getMonthName(new Date());
		String todayYear = Integer.toString(DateUtil.getYear(new Date()));
		Date futureDate = DateUtil.addDays(new Date(), 21);
		String endDay = Integer.toString(DateUtil.getDay(futureDate));
		String endMonth = DateUtil.getMonthName(futureDate);
		String endYear = Integer.toString(DateUtil.getYear(futureDate));

		map.put("start day", todayDay);
		map.put("start month", todayMonth);
		map.put("start year", todayYear);
		map.put("end day", endDay);
		map.put("end month", endMonth);
		map.put("end year", endYear);
		map.put("days", excelData.getKeyValue(sheetName, "days"));
		map.put("minimum nights", excelData.getKeyValue(sheetName, "minimum nights"));
		map.put("minimum passengers", excelData.getKeyValue(sheetName, "minimum passengers"));
		map.put("rate type", excelData.getKeyValue(sheetName, "rate type"));
		map.put("more rules", excelData.getKeyValue(sheetName, "more rules"));
		map.put("stay full period", excelData.getKeyValue(sheetName, "stay full period"));
		map.put("Standard Room", excelData.getKeyValue(sheetName, "Standard Room"));
		map.put("Standard Room net", excelData.getKeyValue(sheetName, "Standard Room net"));
		map.put("Standard Room rsp", excelData.getKeyValue(sheetName, "Standard Room rsp"));
		map.put("Standard Single", excelData.getKeyValue(sheetName, "Standard Single"));
		map.put("Standard Single net", excelData.getKeyValue(sheetName, "Standard Single net"));
		map.put("Standard Single rsp", excelData.getKeyValue(sheetName, "Standard Single rsp"));

		rpDetailsSectionPage.createOptionClick();
		rpDetailsSectionPage1.createStandardRates(map);
		rpDetailsSectionPage.sleep(2);
		rpDetailsSectionPage.saveCreateRateRules();
		rpDetailsSectionPage.saveSaveCreateRateRules();
		rpDetailsSectionPage.sleep(2);
	}

	private void executeEditRoomRateStaticFlow ( ) {
		rpDetailsSectionPage = RatePlanStandardRateSectionPage.getInstance();
		rpDetailsSectionPage1 = RatePlanStandardRateSectionPageCustom.getInstance();

		Map<String, String> map = new HashMap<String, String>();
		// map.put("standard room type net", "110");
		// map.put("room type edit", "no");
		Date startDate = DateUtil.getDate();
		Date futureDate = DateUtil.addDays(new Date(), 21);
		String startDateStr = DateUtil.convertDateToGTAFormat(startDate);
		String endDateStr = DateUtil.convertDateToGTAFormat(futureDate);

		String travelDates = startDateStr + " - " + endDateStr;

		Map<String, String> selectMap = new HashMap<String, String>();
		selectMap.put("Days", excelData.getKeyValue(sheetName, "days"));
		selectMap.put("Rate Type", excelData.getKeyValue(sheetName, "rate type"));
		selectMap.put("Min Nights", excelData.getKeyValue(sheetName, "minimum nights"));
		selectMap.put("Min Pax", excelData.getKeyValue(sheetName, "minimum passengers"));
		selectMap.put("Rules", excelData.getKeyValue(sheetName, "more rules"));
		selectMap.put("Travel Dates", travelDates);

		map.put("stay full period", excelData.getKeyValue(sheetName, "stay full period"));
		map.put("Standard Single", excelData.getKeyValue(sheetName, "Standard Single"));
		map.put("Standard Single net", excelData.getKeyValue(sheetName, "Standard Single net"));
		map.put("Standard Single rsp", excelData.getKeyValue(sheetName, "Standard Single rsp"));

		rpDetailsSectionPage.selectRateRule(selectMap);
		rpDetailsSectionPage.selectRateRuleOptions("Edit");
		rpDetailsSectionPage1.editRateRules(map);
		rpDetailsSectionPage1.updateEditRateRules();
		rpDetailsSectionPage.refreshOptionClick();

	}

	private void executeDeleteRoomRateStaticFlow ( ) {

		rpDetailsSectionPage = RatePlanStandardRateSectionPage.getInstance();
		rpDetailsSectionPage1 = RatePlanStandardRateSectionPageCustom.getInstance();
		Map<String, String> selectMap = new HashMap<String, String>();

		Date startDate = DateUtil.getDate();
		Date futureDate = DateUtil.addDays(new Date(), 21);
		String startDateStr = DateUtil.convertDateToGTAFormat(startDate);
		String endDateStr = DateUtil.convertDateToGTAFormat(futureDate);

		String travelDates = startDateStr + " - " + endDateStr;

		selectMap.put("Days", excelData.getKeyValue(sheetName, "days"));
		selectMap.put("Rate Type", excelData.getKeyValue(sheetName, "rate type"));
		selectMap.put("Min Nights", excelData.getKeyValue(sheetName, "minimum nights"));
		selectMap.put("Min Pax", excelData.getKeyValue(sheetName, "minimum passengers"));
		selectMap.put("Rules", excelData.getKeyValue(sheetName, "more rules"));
		selectMap.put("Travel Dates", travelDates);
		// selectMap.put("Description", "Superior Deluxe");

		rpDetailsSectionPage.refreshOptionClick();
		// int countBefore = rpDetailsSectionPage.getRateRuleTableRowCount();
		rpDetailsSectionPage.selectRateRule(selectMap);
		rpDetailsSectionPage.selectRateRuleOptions("Delete");
		rpDetailsSectionPage.deleteRateRuleWithOK();
		assertTrue(rpDetailsSectionPage.verifyRecordUpdatedMessage(By.id("rateRuleContent"),
				"Record deleted"));
		// int countAfter = rpDetailsSectionPage.getRateRuleTableRowCount();
		// assertTrue(countBefore == countAfter + 1);
	}

	private void executeCreateRoomRateMarginFlow ( ) {
		rpSmartRateSectionPage = RatePlanSmartFillRateSectionPage.getInstance();
		rpDetailsSectionPage1 = RatePlanStandardRateSectionPageCustom.getInstance();
		Date startDate = DateUtil.addDays(new Date(), 84);
		String todayDay = Integer.toString(DateUtil.getDay(startDate));
		String todayMonth = DateUtil.getMonthName(startDate);
		String todayYear = Integer.toString(DateUtil.getYear(startDate));
		Date futureDate = DateUtil.addDays(new Date(), 90);
		String endDay = Integer.toString(DateUtil.getDay(futureDate));
		String endMonth = DateUtil.getMonthName(futureDate);
		String endYear = Integer.toString(DateUtil.getYear(futureDate));

		Map<String, String> map = new HashMap<String, String>();
		map.put("start day", todayDay);
		map.put("start month", todayMonth);
		map.put("start year", todayYear);
		map.put("end day", endDay);
		map.put("end month", endMonth);
		map.put("end year", endYear);

		map.put("minimum nights", excelData.getKeyValue(sheetName, "minimum nights"));
		// map.put("more rules", "no");

		map.put("days", excelData.getKeyValue(sheetName, "days"));
		map.put("Business Twin", excelData.getKeyValue(sheetName, "Business Twin"));
		map.put("Business Twin net", excelData.getKeyValue(sheetName, "Business Twin net"));
		rpSmartRateSectionPage.clickCreateLink();
		rpDetailsSectionPage1.editRates(map);
		// rpDetailsSectionPage1.editRateRules(map);
		rpSmartRateSectionPage.saveEditRates();
		assertTrue(rpSmartRateSectionPage.verifyRecordUpdatedMessage());
	}

	private void executeEditRoomRateMarginFlow ( ) {
		rpDetailsSectionPage = RatePlanStandardRateSectionPage.getInstance();
		rpDetailsSectionPage1 = RatePlanStandardRateSectionPageCustom.getInstance();

		Map<String, String> map = new HashMap<String, String>();
		// map.put("standard room type net", "110");
		// map.put("room type edit", "no");
		Date startDate = DateUtil.getDate();
		Date futureDate = DateUtil.addDays(new Date(), 21);
		String startDateStr = DateUtil.convertDateToGTAFormat(startDate);
		String endDateStr = DateUtil.convertDateToGTAFormat(futureDate);

		String travelDates = startDateStr + " - " + endDateStr;

		Map<String, String> selectMap = new HashMap<String, String>();
		selectMap.put("Days", excelData.getKeyValue(sheetName, "days"));
		selectMap.put("Rate Type", excelData.getKeyValue(sheetName, "rate type"));
		selectMap.put("Min Nights", excelData.getKeyValue(sheetName, "minimum nights"));
		selectMap.put("Min Pax", excelData.getKeyValue(sheetName, "minimum passengers"));
		selectMap.put("Rules", excelData.getKeyValue(sheetName, "more rules"));
		selectMap.put("Travel Dates", travelDates);

		map.put("stay full period", excelData.getKeyValue(sheetName, "stay full period"));
		map.put("Beachfront 1 Bedroom Suite",
				excelData.getKeyValue(sheetName, "Beachfront 1 Bedroom Suite"));
		map.put("Beachfront 1 Bedroom Suite net",
				excelData.getKeyValue(sheetName, "Beachfront 1 Bedroom Suite net"));
		map.put("Beachfront 1 Bedroom Suite rsp",
				excelData.getKeyValue(sheetName, "Beachfront 1 Bedroom Suite rsp"));
		map.put("Standard Room", excelData.getKeyValue(sheetName, "Standard Room"));

		rpDetailsSectionPage.selectRateRule(selectMap);
		rpDetailsSectionPage.selectRateRuleOptions("Edit");
		rpDetailsSectionPage1.editRateRules(map);
		rpDetailsSectionPage.updateEditRateRules();
		rpDetailsSectionPage.refreshOptionClick();

	}

	private void executeDeleteRoomRateMarginFlow ( ) {
		rpSmartRateSectionPage = RatePlanSmartFillRateSectionPage.getInstance();
		DetailsSectionPage = RatePlanDetailsSectionPage.getInstance();
		rpDetailsSectionPage1 = RatePlanStandardRateSectionPageCustom.getInstance();
		Date startDate = DateUtil.addDays(new Date(), 84);
		String todayDay = Integer.toString(DateUtil.getDay(startDate));
		String todayMonth = DateUtil.getMonthName(startDate);
		String todayYear = Integer.toString(DateUtil.getYear(startDate));
		Date futureDate = DateUtil.addDays(new Date(), 90);
		String endDay = Integer.toString(DateUtil.getDay(futureDate));
		String endMonth = DateUtil.getMonthName(futureDate);
		String endYear = Integer.toString(DateUtil.getYear(futureDate));

		Map<String, String> map = new HashMap<String, String>();
		map.put("start day", todayDay);
		map.put("start month", todayMonth);
		map.put("start year", todayYear);
		map.put("end day", endDay);
		map.put("end month", endMonth);
		map.put("end year", endYear);

		map.put("minimum nights", excelData.getKeyValue(sheetName, "minimum nights"));
		// map.put("more rules", "no");

		map.put("days", excelData.getKeyValue(sheetName, "days"));
		map.put("Business Twin", excelData.getKeyValue(sheetName, "Business Twin"));

		// DetailsSectionPage.selectRatePlanOptions("Refresh");
		rpDetailsSectionPage1.clickDeleteLink();
		rpDetailsSectionPage1.DeleteRates(map);
		rpDetailsSectionPage1.deleteSmartFillRateplan();
		DetailsSectionPage.verifyRecordUpdatedMessage("Record deleted");

	}

	private void executeCreateRatePlanMarginFlow ( ) {
		rpSmartRateSectionPage = RatePlanSmartFillRateSectionPage.getInstance();
		rpDetailsSectionPage1 = RatePlanStandardRateSectionPageCustom.getInstance();
		Date startDate = DateUtil.addDays(new Date(), 84);
		String todayDay = Integer.toString(DateUtil.getDay(startDate));
		String todayMonth = DateUtil.getMonthName(startDate);
		String todayYear = Integer.toString(DateUtil.getYear(startDate));
		Date futureDate = DateUtil.addDays(new Date(), 90);
		String endDay = Integer.toString(DateUtil.getDay(futureDate));
		String endMonth = DateUtil.getMonthName(futureDate);
		String endYear = Integer.toString(DateUtil.getYear(futureDate));

		Map<String, String> map = new HashMap<String, String>();
		map.put("start day", todayDay);
		map.put("start month", todayMonth);
		map.put("start year", todayYear);
		map.put("end day", endDay);
		map.put("end month", endMonth);
		map.put("end year", endYear);

		map.put("minimum nights", excelData.getKeyValue(sheetName, "minimum nights"));
		// map.put("more rules", "no");

		map.put("days", excelData.getKeyValue(sheetName, "days"));
		map.put("Keep Existing Rates", excelData.getKeyValue(sheetName, "Keep Existing Rates"));
		map.put("Business Twin", excelData.getKeyValue(sheetName, "Business Twin"));
		map.put("Business Twin net", excelData.getKeyValue(sheetName, "Business Twin net"));

		rpSmartRateSectionPage.clickCreateLink();
		rpDetailsSectionPage1.editRates(map);
		rpDetailsSectionPage1.saveSmartFillRateplan();
		assertTrue(rpSmartRateSectionPage.verifyRecordUpdatedMessage());
	}

	private void executeEditRatePlanMarginFlow ( ) {
	}

	private void executeDeleteRatePlanMarginFlow ( ) {

		DetailsSectionPage = RatePlanDetailsSectionPage.getInstance();
		rpSmartRateSectionPage = RatePlanSmartFillRateSectionPage.getInstance();
		rpDetailsSectionPage1 = RatePlanStandardRateSectionPageCustom.getInstance();
		Date startDate = DateUtil.addDays(new Date(), 84);
		String todayDay = Integer.toString(DateUtil.getDay(startDate));
		String todayMonth = DateUtil.getMonthName(startDate);
		String todayYear = Integer.toString(DateUtil.getYear(startDate));
		Date futureDate = DateUtil.addDays(new Date(), 90);
		String endDay = Integer.toString(DateUtil.getDay(futureDate));
		String endMonth = DateUtil.getMonthName(futureDate);
		String endYear = Integer.toString(DateUtil.getYear(futureDate));

		Map<String, String> map = new HashMap<String, String>();
		map.put("start day", todayDay);
		map.put("start month", todayMonth);
		map.put("start year", todayYear);
		map.put("end day", endDay);
		map.put("end month", endMonth);
		map.put("end year", endYear);

		map.put("minimum nights", excelData.getKeyValue(sheetName, "minimum nights"));
		// map.put("more rules", "no");

		map.put("days", excelData.getKeyValue(sheetName, "days"));
		map.put("Keep Existing Rates", excelData.getKeyValue(sheetName, "Keep Existing Rates"));
		map.put("Business Twin", excelData.getKeyValue(sheetName, "Business Twin"));

		rpDetailsSectionPage1.clickDeleteLink();
		rpDetailsSectionPage1.DeleteRates(map);
		rpDetailsSectionPage1.deleteSmartFillRateplan();
		DetailsSectionPage.verifyRecordUpdatedMessage("Record deleted");

	}

}
