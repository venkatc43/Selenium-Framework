package com.kuoni.qa.automation.gc.test;

import java.util.HashMap;
import java.util.Map;

import com.gta.travel.page.base.GSTestBase;
import com.mediaocean.qa.framework.utils.ExcelUtil;
import com.kuoni.qa.automation.page.object.common.HomePageSub;
import com.kuoni.qa.automation.page.object.common.LoginPageSub;
import com.kuoni.qa.automation.page.object.countries.CountryListPage;
import com.kuoni.qa.automation.page.object.countries.CountryPage;
import com.kuoni.qa.automation.page.object.countries.CountryResultListPage;
import com.kuoni.qa.automation.page.object.countries.ViewCountryPage;
import com.kuoni.qa.constants.CommonConstants;

public class CountryCreateEditDeleteTest extends GSTestBase{
	
	private String userName;
	private String password;
	private String webId;
	
	private static String sheetName = null;
	
	private CountryListPage countryListPage;
	private CountryResultListPage countryResultListPage;
	private ViewCountryPage viewcountryPage;
	private CountryPage countryPage;
	private ExcelUtil excelData;
	
	public CountryCreateEditDeleteTest(String driverSheetPath, String dataSheetPath, String sheetName){
		this.sheetName = sheetName;
		init(driverSheetPath, dataSheetPath);
	}
	
	public void init(String driverSheetPath, String dataSheetPath){
		excelData = new ExcelUtil(dataSheetPath);
		if (driverSheetPath != null){
			setDriverSheetAbsolutePath(driverSheetPath);
		}else{
			setDriverSheetFileName("Driver_Sheet.xls");
		}
		initialiseEnvironmentAndTest();
		openBrowser();
		setLoginInfo();
		if(CommonConstants.webDriver != null){
			CommonConstants.webDriver = getDriver();
		}
	}

	private void setLoginInfo(){
		webId = excelUtil.getKeyValue(ENVIRONMENT, "webId");
		userName = excelUtil.getKeyValue(ENVIRONMENT, "userName");
		password = excelUtil.getKeyValue(ENVIRONMENT, "password");
	}
	
	public void executeDataScriptForCreate(){
		executeLoginPageFlow();
		executeSearcCountriesFlow();
		executeCreateCountryFlow();
//		getDriver().quit();
	}

	public void executeDataScriptForEdit(){
		executeLoginPageFlow();
		executeSearcCountriesFlow();
		executeEditCountryFlow();
//		getDriver().quit();
	}

	public void executeDataScriptForDelete(){
		executeLoginPageFlow();
		executeSearcCountriesFlow();
		executeDeleteCountryFlow();
//		getDriver().quit();
	}
	
	public void executeLoginPageFlow(){
		LoginPageSub loginPage = new LoginPageSub();
		HomePageSub homePage = loginPage.login(webId, userName, password);
		countryListPage = homePage.selectCountries();		
	}
	
	public void executeSearcCountriesFlow(){
		Map<String, String> searchDataMap = new HashMap<String, String>();
		searchDataMap.put("Zone", excelData.getKeyValue(sheetName, "Zone"));
		searchDataMap.put("Country Name", excelData.getKeyValue(sheetName, "Country Name"));
		countryResultListPage = countryListPage.searchCountries(searchDataMap);
		countryResultListPage.sleep(3);
	}
	
	private void executeCreateCountryFlow() {
		Map<String, String> searchData =  new HashMap<String, String>();
		searchData.put("Zone", excelData.getKeyValue(sheetName, "Zone"));
		searchData.put("Country", excelData.getKeyValue(sheetName, "Country Name"));
		viewcountryPage = countryResultListPage.selectRecordFromSearchResults(searchData);
		viewcountryPage.sleep(1);
		countryPage = viewcountryPage.clickCopy();
		countryPage.sleep(1);
		Map<String, String> data = new HashMap<String, String>();
		data.put("Code", excelData.getKeyValue(sheetName, "Code"));
		data.put("Description", excelData.getKeyValue(sheetName, "Description"));
		countryPage.createCountry(data);
		countryPage.sleep(1);
	}
	
	private void executeEditCountryFlow() {
		Map<String, String> searchData =  new HashMap<String, String>();
		searchData.put("Zone", excelData.getKeyValue(sheetName, "Zone"));
		searchData.put("Country", excelData.getKeyValue(sheetName, "Country Name"));
		viewcountryPage = countryResultListPage.selectRecordFromSearchResults(searchData);
		viewcountryPage.sleep(1);
		countryPage = viewcountryPage.clickEdit();
		countryPage.sleep(1);
		Map<String, String> data = new HashMap<String, String>();
		data.put("Description", excelData.getKeyValue(sheetName, "Description"));
		System.out.println(data);
		countryPage.editCountry(data);
		countryPage.sleep(1);
	}
	
	private void executeDeleteCountryFlow() {
		Map<String, String> searchData =  new HashMap<String, String>();
		searchData.put("Zone", excelData.getKeyValue(sheetName, "Zone"));
		searchData.put("Country", excelData.getKeyValue(sheetName, "Country"));
		searchData.put("Code", excelData.getKeyValue(sheetName, "Code"));
		viewcountryPage = countryResultListPage.selectRecordFromSearchResults(searchData);
		viewcountryPage.sleep(2);
		viewcountryPage.clickDelete();
		viewcountryPage.sleep(2);
	}	
}
