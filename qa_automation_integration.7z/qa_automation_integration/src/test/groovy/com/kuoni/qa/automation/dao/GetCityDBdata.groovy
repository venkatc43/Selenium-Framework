package com.kuoni.qa.automation.dao

import com.kuoni.qa.automation.dto.CityDTO;
import java.sql.Connection
import java.sql.ResultSet
import java.sql.Statement

class GetCityDBdata {
	
	GetDatabaseConn db
	def CityDTO getCitydata(String cityId) {
		
				db = new GetDatabaseConn()
				Connection conn = db.getDBconnection()
				CityDTO data = new CityDTO()
				ResultSet rs = null
				Statement statement = null
		
				try {
		
					statement = conn.createStatement()
					String sql = "select count(*) COUNT from FIT_CITY"
					rs = statement.executeQuery(sql);
		
					if(rs.next()){
		
						data.setCityCount(rs.getInt("COUNT"))
					}
		
					if(rs.getInt("COUNT")>0) {
						sql = "select city.CODE,city.TIMEZONE,region.REGION_ID,country.COUNTRY_ID from FIT_CITY city, FIT_REGION region, FIT_COUNTRY country where city.CITY_ID="+cityId+" and city.REGION_ID = region.region_ID and city.COUNTRY_ID = country.country_ID and ROWNUM = 1"
						rs = statement.executeQuery(sql);
					
							while(rs.next()) {
		
							data.setCityCode(rs.getString("CODE"))
							data.setTimeZone(rs.getString("TIMEZONE"))
							data.setRegionId(rs.getInt("REGION_ID"))
							data.setCountryId(rs.getInt("COUNTRY_ID"))
						}
					}
				}catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
		
				finally{
					statement.close()
					rs.close();
					conn.close();
				}
				return data
			}

}
