package com.kuoni.qa.automation.gc.test;

import java.util.HashMap;
import java.util.Map;

import com.gta.travel.page.base.GSTestBase;
import com.gta.travel.page.object.common.HomePage;
import com.gta.travel.page.object.common.LoginPage;
import com.gta.travel.page.object.common.TopLinksPage;
import com.gta.travel.page.object.content.search.ContentSearchPage;
import com.gta.travel.page.object.content.search.ContentSearchResultsPage;
import com.kuoni.qa.automation.page.object.content.FacilitiesAndServicesDetailsPage;
import com.kuoni.qa.constants.CommonConstants;
import com.mediaocean.qa.framework.utils.ExcelUtil;

public class PropertyFeatureAssignmentsTest   extends GSTestBase {

	private LoginPage loginPage;
	private HomePage homePage;
	private ContentSearchPage contentSearchPage;
	private ContentSearchResultsPage contentSearchResultsPage;
	private FacilitiesAndServicesDetailsPage facilitiesAndServicesDetailsPage;
	
	private String userName;
	private String password;
	private String webId;
	
	private ExcelUtil data = null;
	private static String sheetName = null;
	
	public PropertyFeatureAssignmentsTest(String driverSheetPath, String dataSheetPath, String sheetName){
		this.sheetName = sheetName;
		init(driverSheetPath, dataSheetPath);			
	}
	
	public void init(String driverSheetPath, String dataSheetPath){
		data = new ExcelUtil(dataSheetPath);
		if (driverSheetPath != null){
			setDriverSheetAbsolutePath(driverSheetPath);
		}
		initialiseEnvironmentAndTest();
		openBrowser();
		setLoginInfo();
		CommonConstants.webDriver = getDriver();
	}
	
	private void setLoginInfo() {
		webId = excelUtil.getKeyValue(ENVIRONMENT, "webId");
		userName = excelUtil.getKeyValue(ENVIRONMENT, "userName");
		password = excelUtil.getKeyValue(ENVIRONMENT, "password");
	}
	
	public void executeDataScriptsForUpdate(){
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSearchResultsScreenFlow();
		executeEditFeatureAssignments();
//		getDriver().quit();
	}
	
	public void executeDataScriptsForDelete(){
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSearchResultsScreenFlow();
		executeDeleteFeatureAssignments();
//		getDriver().quit();
	}	
	
	private void executeLoginPageFlow(){
		loginPage = new LoginPage(getDriver());
		homePage = loginPage.login(webId, userName, password);
		contentSearchPage = homePage.selectContent();
		contentSearchPage.sleep(2);
	}
	
	private void executeSearchScreenFlow(){
		Map<String, String> searchDataMap = new HashMap<String, String>();
		searchDataMap.put("Country", data.getKeyValue(sheetName, "Country"));
		searchDataMap.put("City", data.getKeyValue(sheetName, "City"));
		contentSearchResultsPage = contentSearchPage.search(searchDataMap);
		contentSearchResultsPage.sleep(2);
	}
	
	private void executeSearchResultsScreenFlow(){
		Map<String, String> searchResultsDataMap = new HashMap<String, String>();
		searchResultsDataMap.put("Country", data.getKeyValue(sheetName, "Country"));
		searchResultsDataMap.put("City", data.getKeyValue(sheetName, "City"));
		searchResultsDataMap.put("Property Name", data.getKeyValue(sheetName, "Property Name"));
		TopLinksPage topLinksPage = contentSearchResultsPage.selectRecordFromSearchResults(searchResultsDataMap);
		topLinksPage.sleep(3);
		topLinksPage.clickFacilitiesAndServices();
		topLinksPage.sleep(2);
	}
	
	private void executeEditFeatureAssignments(){
		facilitiesAndServicesDetailsPage = FacilitiesAndServicesDetailsPage.getInstance();
		Map<String, String> map = new HashMap<String, String>();
		map.put("BabySitting", data.getKeyValue(sheetName, "BabySitting"));
		map.put("BeautyParlour", data.getKeyValue(sheetName, "BeautyParlour"));
		map.put("BeachFront", data.getKeyValue(sheetName, "BeachFront"));
		map.put("CarEssential", data.getKeyValue(sheetName, "CarEssential"));
		map.put("BicycleHire", data.getKeyValue(sheetName, "BicycleHire"));
		map.put("Casino", data.getKeyValue(sheetName, "Casino"));
		facilitiesAndServicesDetailsPage.clickEditFacilitiesAndServicesDetails();
		facilitiesAndServicesDetailsPage.editFacilitiesAndServicesDetails(map);
		facilitiesAndServicesDetailsPage.updateFacilitiesAndServicesDetails();
	}
	
	private void executeDeleteFeatureAssignments(){
		facilitiesAndServicesDetailsPage = FacilitiesAndServicesDetailsPage.getInstance();
		Map<String, String> map = new HashMap<String, String>();
		map.put("BabySitting", data.getKeyValue(sheetName, "BabySitting"));
		map.put("BeautyParlour", data.getKeyValue(sheetName, "BeautyParlour"));
		map.put("BeachFront", data.getKeyValue(sheetName, "BeachFront"));
		map.put("CarEssential", data.getKeyValue(sheetName, "CarEssential"));
		map.put("BicycleHire", data.getKeyValue(sheetName, "BicycleHire"));
		map.put("Casino", data.getKeyValue(sheetName, "Casino"));
		facilitiesAndServicesDetailsPage.clickEditFacilitiesAndServicesDetails();
		facilitiesAndServicesDetailsPage.editFacilitiesAndServicesDetails(map);
		facilitiesAndServicesDetailsPage.updateFacilitiesAndServicesDetails();
	}	
	
	public ExcelUtil getExcelUtil(){
		return data;
	}
}
