package com.kuoni.qa.automation.page.object.text;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.gta.travel.page.base.GSPageBase;
import com.mediaocean.qa.framework.selenium.ui.controls.Button;
import com.mediaocean.qa.framework.selenium.ui.controls.ComboBox;

public class TextListPage extends GSPageBase{

	public TextListPage() {
		super(getDriver());
	}
	
	public static TextListPage getIntsnace(){
		return PageFactory.initElements(getDriver(),TextListPage.class); 
	}
	
	public TextResultListPage serachCategory(Map<String, String> map){
		if (map.containsKey("Category")){
			ComboBox cateogory = new ComboBox(By.id("searchCategory"));
			cateogory.select(map.get("Category"));
		}
		if (map.containsKey("Code")){
			clearAndType(By.id("searchCode"),map.get("Code"));			
		}
		if (map.containsKey("Language")){
			ComboBox language = new ComboBox(By.id("searchLanguage"));
			language.select(map.get("Language"));
		}		
		if (map.containsKey("Text")){
			clearAndType(By.id("searchText"),map.get("Text"));
		}
		sleep(1);
		Button searchButton = new Button("Go");
		searchButton.click();
		sleep(3);
		return PageFactory.initElements(getDriver(), TextResultListPage.class);
	}
	
	public TextPage selectCreateText(){
		WebElement create = waitForElement(By.linkText("Create"));
		create.click();
		sleep(1);
		return PageFactory.initElements(getDriver(), TextPage.class);		
	}
}
