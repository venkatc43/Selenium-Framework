package com.kuoni.qa.automation.gc.test;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.gta.travel.page.base.GSTestBase;
import com.gta.travel.page.object.contract.rateplans.RatePlanDetailsSectionPage;
import com.gta.travel.page.object.contract.search.ContractSearchPage;
import com.gta.travel.page.object.contract.search.ContractSearchResultsPage;
import com.kuoni.qa.automation.page.object.common.HomePageSub;
import com.kuoni.qa.automation.page.object.common.LoginPageSub;
import com.mediaocean.qa.framework.utils.ExcelUtil;

/**
 * Class to Execute Automation on GC Content
 * 
 * @author hmirza
 * 
 */
public class RatePlanDetailsTest extends GSTestBase {

	private String userName;
	private String password;
	private String webId;

	private String sheetName = null;

	private ContractSearchPage contractSearchPage;
	private ContractSearchResultsPage contractSearchResultsPage;
	private RatePlanDetailsSectionPage ratePlanSection;

	private static String[] inputDtaFields = { "Country", "City", "Model",
			"rate plan code", "rate plan name", "meal basis", "enter rate as",
			"margin", "meal breakfast", "meal lunch", "meal dinner" };
	private ExcelUtil excelData;

	public RatePlanDetailsTest(String driverSheetPath, String dataSheetPath,
			String sheetName) {
		this.sheetName = sheetName;
		init(driverSheetPath, dataSheetPath);
	}

	/**
	 * Initialize the driver sheet and data sheet
	 * 
	 * @param driverSheetPath
	 * @param dataSheetPath
	 */
	public void init(String driverSheetPath, String dataSheetPath) {
		excelData = new ExcelUtil(dataSheetPath);
		if (driverSheetPath != null) {
			setDriverSheetAbsolutePath(driverSheetPath);
		} else {
			setDriverSheetFileName("Driver_Sheet.xls");
		}
		initialiseEnvironmentAndTest();
		openBrowser();
		setLoginInfo();
	}

	/**
	 * Set logging info for GC Content
	 */
	private void setLoginInfo() {
		webId = excelUtil.getKeyValue(ENVIRONMENT, "webId");
		userName = excelUtil.getKeyValue(ENVIRONMENT, "userName");
		password = excelUtil.getKeyValue(ENVIRONMENT, "password");
	}

	/**
	 * Method to execute the Script to run automation on GC Connect
	 */
	public void executeDataScriptForCreateRateValidMarket() {
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeRatePlanSection();
		// getDriver().quit();
	}

	/**
	 * Method to execute the login page on GC Content
	 */
	private void executeLoginPageFlow() {
		LoginPageSub loginPage = new LoginPageSub();
		HomePageSub homePage = loginPage.login(webId, userName, password);
		contractSearchPage = homePage.selectContract();
		contractSearchPage.sleep(2);
	}

	/**
	 * Method to execute Contract Search on GC Content
	 */
	private void executeSearchScreenFlow() {

		Map<String, String> searchDataMap = new HashMap<String, String>();
		// Set the search data to the map here.
		searchDataMap.put("Country",
				excelData.getKeyValue(sheetName, "Country"));
		searchDataMap.put("City", excelData.getKeyValue(sheetName, "City"));
		searchDataMap.put("Model", excelData.getKeyValue(sheetName, "Model"));
		contractSearchResultsPage = contractSearchPage.search(searchDataMap);
		contractSearchResultsPage.sleep(3);
		contractSearchResultsPage.selectFirstRowFromTheResults();
	}

	/**
	 * Method to set Input Data in Map and execute the Automation on Rate Plan
	 * section
	 */
	private void executeRatePlanSection() {
		ratePlanSection = RatePlanDetailsSectionPage.getInstance();
		Map<String, String> map = getRatePlanInputDataMap();
		Map<String, String> searchMap = new HashMap<String, String>();
		searchMap.put("Rate Plan Code", excelData.getKeyValue(sheetName, "rate plan code").toUpperCase());
		if (sheetName.contains("Create")) {
			ratePlanSection.selectRatePlanOptions("Create");
			ratePlanSection.createRatePlan(map);
			ratePlanSection.saveCreateRatePlan();
		} else if (sheetName.contains("Delete")) {
			ratePlanSection.selectRatePlanFromTheList(searchMap);
			ratePlanSection.selectRatePlanOptions("Delete");
		} else {
			ratePlanSection.selectRatePlanFromTheList(searchMap);
			ratePlanSection.selectRatePlanOptions("Edit");
			ratePlanSection.editRatePlan(map);
			ratePlanSection.updateEditRatePlan();
		}
	}

	/**
	 * Method to get data from input xml 
	 * @return
	 */
	private Map<String, String> getRatePlanInputDataMap() {
		Map<String, String> map = new HashMap<String, String>();
		for (int i = 0; i < inputDtaFields.length; i++) {
			System.out.println(inputDtaFields[i]);
			if (StringUtils.isNotBlank(excelData.getKeyValue(sheetName,
					inputDtaFields[i]))) {
				map.put(inputDtaFields[i],
						excelData.getKeyValue(sheetName, inputDtaFields[i]));
			}
		}
		return map;
	}

}
