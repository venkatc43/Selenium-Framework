package com.kuoni.qa.automation.gc.test;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.gta.travel.page.base.GSTestBase;
import com.gta.travel.page.object.contract.inventory.InventoryGeneratorSectionPage;
import com.gta.travel.page.object.contract.manageavailability.ManageAvailabilitySearchAndResultsSectionPage;
import com.gta.travel.page.object.contract.rateplans.RatePlanDetailsSectionPage;
import com.gta.travel.page.object.contract.rateplans.RatePlanRestrictionSectionPage;
import com.gta.travel.page.object.contract.rateplans.RatePlanStandardRateSectionPage;
import com.gta.travel.page.object.contract.search.ContractSearchPage;
import com.gta.travel.page.object.contract.search.ContractSearchResultsPage;
import com.kuoni.qa.automation.page.object.common.HomePageSub;
import com.kuoni.qa.automation.page.object.common.LoginPageSub;
import com.mediaocean.qa.framework.selenium.ui.controls.Table;
import com.mediaocean.qa.framework.utils.DateUtil;
import com.mediaocean.qa.framework.utils.ExcelUtil;


public class PushPropertyRestrictionPlan extends GSTestBase{
    
	private static Logger logger = Logger.getLogger(PushPropertyRestrictionPlan.class);
	
	private String userName;
	private String password;
	private String webId;

	private static String sheetName = null;
	private InventoryGeneratorSectionPage Inventory;
	private ContractSearchPage contractSearchPage;
	private ContractSearchResultsPage contractSearchResultsPage;
	private RatePlanStandardRateSectionPage rpDetailsSectionPage;
	private RatePlanDetailsSectionPage DetailsSectionPage;
	private ManageAvailabilitySearchAndResultsSectionPage ManageAvailability;
	private ExcelUtil excelData;
private RatePlanRestrictionSectionPage RateRest;
private RatePlanRestrictionSectionPage RateEdit;	
private RatePlanRestrictionSectionPage rpRestrictionSectionPage;
// ExcelUtil excelData = null;

	public PushPropertyRestrictionPlan(String driverSheetPath, String dataSheetPath, String sheetName) {
		this.sheetName = sheetName;
		init(driverSheetPath, dataSheetPath);
	}

	public void init(String driverSheetPath, String dataSheetPath) {
		excelData = new ExcelUtil(dataSheetPath);

		if (driverSheetPath != null) {

			setDriverSheetAbsolutePath(driverSheetPath);
		} else {
			setDriverSheetFileName("Driver_Sheet.xls");
		}
		initialiseEnvironmentAndTest();
		openBrowser();
		setLoginInfo();
	}

	private void setLoginInfo() {
		webId = excelUtil.getKeyValue(ENVIRONMENT, "webId");
		userName = excelUtil.getKeyValue(ENVIRONMENT, "userName");
		password = excelUtil.getKeyValue(ENVIRONMENT, "password");
	}

	public void execueteDataScriptForDelete() throws InterruptedException{
		executeLoginPageFlow();
		Thread.sleep(3000);
		executeSearchScreenFlow();
		executeSelectRatePlan();	
		ExecuteRateDelete();
	}
	public void executeDataScriptForEdit() throws InterruptedException {
		executeLoginPageFlow();
		Thread.sleep(3000);
		executeSearchScreenFlow();
		executeSelectRatePlan();
		ExecuteRateEdit();
		// executeSelectRatePlan();
		// executeManageAvailabilityFlow();
		// getDriver().quit();
	}
	
	public void executeDataScriptForCreate() throws InterruptedException {
		executeLoginPageFlow();
		Thread.sleep(3000);
		executeSearchScreenFlow();
		executeSelectRatePlan();
		ExecuteRateCreation();
		// executeSelectRatePlan();
		// executeManageAvailabilityFlow();
		// getDriver().quit();
	}
	
	private void executeLoginPageFlow() {
		LoginPageSub loginPage = new LoginPageSub();
		HomePageSub homePage = loginPage.login(webId, userName, password);
		contractSearchPage = homePage.selectContract();
		contractSearchPage.sleep(2);
	}

	private void executeSearchScreenFlow() {
		
		Map<String, String> searchDataMap = new HashMap<String, String>();
		// Set the search data to the map here.
		searchDataMap.put("Country", excelData.getKeyValue(sheetName, "Country"));
		searchDataMap.put("City", excelData.getKeyValue(sheetName, "City"));
		searchDataMap.put("Property Name", excelData.getKeyValue(sheetName, "Property Name"));
		contractSearchResultsPage = contractSearchPage.search(searchDataMap);
		contractSearchResultsPage.sleep(3);
		contractSearchResultsPage.selectFirstRowFromTheResults();
		
	}

	private void executeSelectRatePlan() {
		RatePlanRestrictionSectionPage restr=new RatePlanRestrictionSectionPage();
		DetailsSectionPage = RatePlanDetailsSectionPage.getInstance();
		Map<String, String> map = new HashMap<String, String>();
		map.put("Rate Plan Code", excelData.getKeyValue(sheetName, "Rate Plan Code"));
		// DetailsSectionPage.selectRatePlan(map);
		DetailsSectionPage.selectRatePlanFromTheList(map);
		
	}

	
	private void ExecuteRateCreation() {

		RateRest=RatePlanRestrictionSectionPage.getInstance();

		Map<String, String> map = new HashMap<String, String>();
		map.put("restriction type", excelData.getKeyValue(sheetName, "restriction type"));
		map.put("applicable from",  excelData.getKeyValue(sheetName, "applicable from"));
		
		String todayDay = Integer.toString(DateUtil.getDay(new Date()));
		String todayMonth = DateUtil.getMonthName(new Date());
		String todayYear = Integer.toString(DateUtil.getYear(new Date()));

		map.put("travel start day", excelData.getKeyValue(sheetName, "travel start day"));
		map.put("travel start month", excelData.getKeyValue(sheetName, "travel start month"));
		map.put("travel start year", excelData.getKeyValue(sheetName, "travel start year"));
		
		map.put("travel end day", excelData.getKeyValue(sheetName, "travel end day"));
		map.put("travel end month", excelData.getKeyValue(sheetName, "travel end month"));
		map.put("travel end year", excelData.getKeyValue(sheetName, "travel end year"));


		RateRest.selectRestrictionOptions("Refresh");
		int rowCountBefore = RateRest.getRestrictionTableRowCount();
		RateRest.selectRestrictionOptions("Create");
		RateRest.createRestriction(map);
		RateRest.saveRestriction();

		assertTrue(RateRest.verifyRecordUpdatedMessage(By.id("restriction_list"),"Record created"));
		assertTrue(RateRest.verifyRowcount(rowCountBefore+1));
		
	}
private void ExecuteRateDelete() throws InterruptedException{
	rpRestrictionSectionPage=RatePlanRestrictionSectionPage.getInstance();
	Map<String, String> restrictionRecordMap = new HashMap<String, String>();
	restrictionRecordMap.put("Restriction Type", "Amendment");
	rpRestrictionSectionPage.selectRestriction(restrictionRecordMap);
	rpRestrictionSectionPage.selectRestrictionOptions("Delete");
	rpRestrictionSectionPage.deleteRestrictionWithOK();
}
	
	private void ExecuteRateEdit() throws InterruptedException{
		RateEdit=RatePlanRestrictionSectionPage.getInstance();
		Map<String, String> restrictionRecordMap = new HashMap<String, String>();
		restrictionRecordMap.put("Restriction Type", "Amendment");
		
		RateEdit.selectRestriction(restrictionRecordMap);
		RateEdit.selectRestrictionOptions("Edit");
		restrictionRecordMap.put("Days Prior to Arrival", excelData.getKeyValue(sheetName, "Days Prior to Arrival"));
		RateEdit.editRestriction(restrictionRecordMap);
		RateEdit.updateRestriction();
		
		assertTrue(RateEdit.verifyRecordUpdatedMessage(By.id("restriction_list"),"Record updated"));
	}

	private void selectRatePlan() throws InterruptedException {
		Map<String, String> selectMap = new HashMap<String, String>();
		selectMap.put("rate plan code", ContractSearchPage.excelUtil.getCellAsString("RatePlans", 1, "Rate Plan code"));
		selectMap.put("Description", ContractSearchPage.excelUtil.getCellAsString("RatePlans", 1, "Description"));
		
		rpDetailsSectionPage.selectRateRuleOptions("Refresh");
		selectRatePlanFromTheList(selectMap);
	
	}
	
	/**
	 * This method selects the rate plan from the table.
	 * @param map
	 * @throws InterruptedException 
	 */
	private static void selectRatePlanFromTheList(Map<String, String> map) throws InterruptedException{
		for (int i=0;i<4;i++){
			try{
				if (selectRatePlan(map)){
					break;
				}else{
					Thread.sleep(2000);
				}
			}catch(Exception e){
				Thread.sleep(2000);
				continue;
			}
		}
	}
	
	private static boolean selectRatePlan(Map<String, String> map) throws InterruptedException{
		WebElement parentElement = waitForElement(By.id("ratePlanContent"),5);
		Table rpTable = new Table(parentElement, 1);
		for (int i=1;i<rpTable.getRowCount();i++){
			boolean flag = true;
			for (String key : map.keySet()){
				String value = map.get(key);
				if (rpTable.getCellData(i, key).equalsIgnoreCase(value)){
					continue;
				}else{
					flag = false;
					break;
				}
			}
			if (flag){
				Thread.sleep(2000);
				rpTable.clickOnDataColumn(i, "Rate Plan Code");
				Thread.sleep(2000);
				WebElement parentEl1 = null;
				try{
					parentEl1 = waitForElement(By.id("ratePlan_tr"), 1);
					WebElement parentEl2 = waitForElement(parentEl1,By.id("ratePlan_div"),1);
					WebElement parentEl3 = waitForElement(parentEl2,By.className("dialog"),1);
					waitForElement(parentEl3,By.className("inserted"),1);
					return true;
				}catch(Exception e){
					return false;
				}
			}
		}
		return false;
	}
	
	
	public static WebElement waitForElement(By locator, long timeoutSeconds) {
		logger.info(String.format("waitForElement(%s)", locator));
		WebElement element = null;
		try {
			WebDriverWait wait = new WebDriverWait(getDriver(),  timeoutSeconds);
//			element = wait.until(ExpectedConditions.presenceOfElementLocated(locator));
			element = wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
		} catch (Exception e) {
			logger.warn(e.getMessage());
			throw new RuntimeException(e.getMessage());
		}
		return element;
	}
	
	private static WebElement waitForElement(WebElement parentElement, By locator, long timeoutSeconds){
		long endTime = System.currentTimeMillis() + (1000 * timeoutSeconds);
		WebElement element = null;
		while(endTime > System.currentTimeMillis()){
			try{
				element = parentElement.findElement(locator);
				return element;
			}catch(Exception e){
				long waitTime = System.currentTimeMillis() + 500l;
				while (waitTime <= System.currentTimeMillis()){}
			}
		}
		logger.warn("Element not found in the parent element : "+ locator);
		throw new RuntimeException("Element not found in the parent element"+ locator);
	}
	
	
	}
	

	

