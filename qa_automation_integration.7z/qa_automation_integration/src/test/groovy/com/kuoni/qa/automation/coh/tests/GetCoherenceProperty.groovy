package com.kuoni.qa.automation.coh.tests


import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.kuoni.qa.automation.spock.annotation.Sanity;
import org.springframework.context.support.ClassPathXmlApplicationContext

import spock.lang.Specification

/*import com.gta.nova.api.client.ClientService
import com.gta.nova.api.search.PriceAvailabilityService
import com.gta.nova.api.search.PropertyPriceAvailabilityRequest
import com.gta.nova.api.search.PropertyPriceAvailabilityResponse
import com.gta.nova.coherence.property.model.Property
import com.gta.nova.coherence.property.repository.PropertyRepository
import com.gta.nova.common.DaysOfWeek
import com.gta.nova.propertycontract.repository.PropertyContractRepository*/
import com.gta.nova.coherence.property.model.Property
import com.kuoni.qa.automation.spock.annotation.Sanity
//import com.kuoni.qa.automation.test.util.PropertyPriceAvailabilityRequestBuilder
import com.tangosol.net.CacheFactory
import com.tangosol.net.NamedCache

class GetCoherenceProperty extends Specification {
	
			
		   def Property verifyCohPropertyDetails () {
						 
						 def final expectedResult = 50;
						 NamedCache propertyCache = CacheFactory.getCache("Property");
		   
						 when: "I upload the PropertyLoader CSV file which has 50 Properties"
							   def actualResult =  propertyCache.size()
														   
						 then: " I got the list of properties populated into the cache are 50"
						 and: "Can access Min age, Check In & Check Out days through Cache"
									 /* assert expectedResult <= actualResult
									  println "Number of Records Loaded: " + actualResult*/
							   
							   //verify new fields
							   Property property = (Property) propertyCache.get(38L)
							   
							   println property.getStarRating()
							   
							//return property
							   
							 
				  }
	

}
