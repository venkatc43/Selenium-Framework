package com.kuoni.qa.automation.page.object.text;

import org.openqa.selenium.support.PageFactory;

import com.gta.travel.page.base.GSPageBase;
import com.mediaocean.qa.framework.selenium.ui.controls.Button;

public class ViewTextPage extends GSPageBase{

	public ViewTextPage() {
		super(getDriver());
	}
	
	public TextPage clickEdit(){
		final Button edit = new Button("Edit");
		sleep(3);
		edit.click();
		sleep(3);
		return PageFactory.initElements(getDriver(), TextPage.class);
	}
	
	public void clickDelete(){
		final Button edit = new Button("Delete");
		sleep(2);
		edit.click();
		sleep(1);
		getDriver().switchTo().alert().accept();
	}	
}
