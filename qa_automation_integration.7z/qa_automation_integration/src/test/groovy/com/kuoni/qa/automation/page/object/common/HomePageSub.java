package com.kuoni.qa.automation.page.object.common;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.gta.travel.page.object.common.HomePage;
import com.gta.travel.page.object.content.search.ContentSearchPage;
import com.gta.travel.page.object.contract.search.ContractSearchPage;
import com.kuoni.qa.automation.page.object.cities.CityListPage;
import com.kuoni.qa.automation.page.object.countries.CountryListPage;
import com.kuoni.qa.automation.page.object.text.TextListPage;
import com.mediaocean.qa.framework.selenium.ui.controls.Link;

public class HomePageSub extends HomePage {

	public HomePageSub(WebDriver driver) {
		super(driver);
	}

	public CityListPage selectCities() {
		Link link = new Link("Cities");
		link.clickLink();
		return PageFactory.initElements(getDriver(), CityListPage.class);
	}

	public CountryListPage selectCountries() {
		Link link = new Link("Countries");
		link.clickLink();
		return PageFactory.initElements(getDriver(), CountryListPage.class);
	}

	public TextListPage selectTexts() {
		Link link = new Link("Text");
		link.clickLink();
		return PageFactory.initElements(getDriver(), TextListPage.class);
	}

	public ContentSearchPage selectContent() {
		Link link = new Link("Content");
		link.clickLink();
		return PageFactory.initElements(getDriver(), ContentSearchPage.class);
	}

	public ContractSearchPage selectContract() {
		Link link = new Link("Contracts");
		link.clickLink();
		return PageFactory.initElements(getDriver(), ContractSearchPage.class);

	}
}