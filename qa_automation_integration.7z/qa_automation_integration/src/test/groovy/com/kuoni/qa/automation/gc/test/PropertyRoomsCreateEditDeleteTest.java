package com.kuoni.qa.automation.gc.test;

import java.util.HashMap;
import java.util.Map;

import com.gta.travel.page.base.GSTestBase;
import com.gta.travel.page.object.common.HomePage;
import com.gta.travel.page.object.common.LoginPage;
import com.gta.travel.page.object.common.TopLinksPage;
import com.gta.travel.page.object.content.search.ContentSearchPage;
import com.gta.travel.page.object.content.search.ContentSearchResultsPage;
import com.kuoni.qa.automation.page.object.content.RoomDetailsPage;
import com.kuoni.qa.constants.CommonConstants;
import com.mediaocean.qa.framework.utils.ExcelUtil;

public class PropertyRoomsCreateEditDeleteTest extends GSTestBase{

	private LoginPage loginPage;
	private HomePage homePage;
	private ContentSearchPage contentSearchPage;
	private ContentSearchResultsPage contentSearchResultsPage;
	private RoomDetailsPage roomDetailsPage;
	
	private String userName;
	private String password;
	private String webId;
	
	private ExcelUtil data = null;
	private static String sheetName = null;
	
	public PropertyRoomsCreateEditDeleteTest(String driverSheetPath, String dataSheetPath, String sheetName){
		this.sheetName = sheetName;
		init(driverSheetPath, dataSheetPath);		
	}
	
	public void init(String driverSheetPath, String dataSheetPath){
		data = new ExcelUtil(dataSheetPath);
		if (driverSheetPath != null){
			setDriverSheetAbsolutePath(driverSheetPath);
		}
		initialiseEnvironmentAndTest();
		openBrowser();
		setLoginInfo();
		CommonConstants.webDriver = getDriver();
	}
	
	private void setLoginInfo() {
		webId = excelUtil.getKeyValue(ENVIRONMENT, "webId");
		userName = excelUtil.getKeyValue(ENVIRONMENT, "userName");
		password = excelUtil.getKeyValue(ENVIRONMENT, "password");
	}
	
	public void execueteDataScriptForCreate(){
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSearchResultsScreenFlow();
		executeCreateRoomType();
//		getDriver().quit();
	}

	public void execueteDataScriptForEdit(){
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSearchResultsScreenFlow();
		executeEditRoomType();
//		getDriver().quit();
	}
	
	public void execueteDataScriptForDelete(){
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSearchResultsScreenFlow();
		executeDeleteRoomType();
//		getDriver().quit();
	}
	
	public void executeDataScriptsForEditRoomFacilities(){
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSearchResultsScreenFlow();
		editRoomFecilities();
//		getDriver().quit();
	}
	
	private void executeLoginPageFlow(){
		loginPage = new LoginPage(getDriver());
		homePage = loginPage.login(webId, userName, password);
		contentSearchPage = homePage.selectContent();
		contentSearchPage.sleep(2);
	}
	
	private void executeSearchScreenFlow(){
		Map<String, String> searchDataMap = new HashMap<String, String>();
		searchDataMap.put("Country", data.getKeyValue(sheetName, "Country"));
		searchDataMap.put("City", data.getKeyValue(sheetName, "City"));	
		searchDataMap.put("Property Name", data.getKeyValue(sheetName,"Property Name"));
		contentSearchResultsPage = contentSearchPage.search(searchDataMap);
		contentSearchResultsPage.sleep(2);
	}
	
	private void executeSearchResultsScreenFlow(){
		Map<String, String> searchResultsDataMap = new HashMap<String, String>();
		searchResultsDataMap.put("Country", data.getKeyValue(sheetName, "Country"));
		searchResultsDataMap.put("City", data.getKeyValue(sheetName, "City"));
		searchResultsDataMap.put("Property Name", data.getKeyValue(sheetName, "Property Name"));
		TopLinksPage topLinksPage = contentSearchResultsPage.selectRecordFromSearchResults(searchResultsDataMap);
		topLinksPage.sleep(3);
		topLinksPage.clickRoomTypesTab();
		topLinksPage.sleep(2);
	}
	
	private void executeCreateRoomType(){
		roomDetailsPage = RoomDetailsPage.getInstance();
		Map<String, String> map = new HashMap<String, String>();
		map.put("RoomCategory", data.getKeyValue(sheetName, "RoomCategory"));
		map.put("RoomType", data.getKeyValue(sheetName, "RoomType"));
		map.put("RoomCode", data.getKeyValue(sheetName, "RoomCode"));
		map.put("NumberOfBeds", data.getKeyValue(sheetName, "NumberOfBeds"));
		map.put("MaximumOccupancy", data.getKeyValue(sheetName, "MaximumOccupancy"));
		map.put("RateBasis", data.getKeyValue(sheetName, "RateBasis"));
		map.put("NumberOfExtraBedsPossible", data.getKeyValue(sheetName, "NumberOfExtraBedsPossible"));
		map.put("ExtraBeds", data.getKeyValue(sheetName, "ExtraBeds"));
		map.put("RoomTypes", data.getKeyValue(sheetName, "RoomTypes"));
		map.put("BathShower", data.getKeyValue(sheetName, "BathShower"));
		map.put("AllRooms", data.getKeyValue(sheetName, "AllRooms"));
		roomDetailsPage.clickCreateRoomDetails();
		roomDetailsPage.enterRoomDetails(map);
		roomDetailsPage.sleep(2);
		roomDetailsPage.saveRoomDetails();
		roomDetailsPage.sleep(2);
	}

	private void executeEditRoomType(){
		roomDetailsPage = RoomDetailsPage.getInstance();
		Map<String, String> selectRecordMap = new HashMap<String, String>();
		selectRecordMap.put("Room Type", data.getKeyValue(sheetName, "Room Type"));
		roomDetailsPage.clickRefreshRoomDetails();
		roomDetailsPage.selectRoom(selectRecordMap);
		roomDetailsPage.selectRoomDetailsOptions("Edit");
		Map<String, String> map = new HashMap<String, String>();
		map.put("RoomCategory", data.getKeyValue(sheetName, "RoomCategory"));
		map.put("RoomType", data.getKeyValue(sheetName, "RoomType"));
		map.put("RoomCode", data.getKeyValue(sheetName, "RoomCode"));		
		roomDetailsPage.enterRoomDetails(map);
		roomDetailsPage.updateRoomDetails();
	}
	
	private void executeDeleteRoomType(){
		roomDetailsPage = RoomDetailsPage.getInstance();
		Map<String, String> roomRecordMap = new HashMap<String, String>();
		roomRecordMap.put("Room Type", data.getKeyValue(sheetName, "Room Type"));
		roomDetailsPage.clickRefreshRoomDetails();
		roomDetailsPage.selectRoom(roomRecordMap);
		roomDetailsPage.selectRoomDetailsOptions("Delete");
		getDriver().switchTo().alert().accept();
	}
	
	private void editRoomFecilities(){
		roomDetailsPage = RoomDetailsPage.getInstance();
		Map<String, String> selectRecordMap = new HashMap<String, String>();
		selectRecordMap.put("Room Type", data.getKeyValue(sheetName, "Room Type"));
		roomDetailsPage.clickRefreshRoomDetails();
		roomDetailsPage.selectRoom(selectRecordMap);
		roomDetailsPage.selectRoomDetailsOptions("Edit");
		
		Map<String, String> map = new HashMap<String, String>();
		map.put("Air Conditioned", data.getKeyValue(sheetName, "Air Conditioned"));
		map.put("CD Player", data.getKeyValue(sheetName, "CD Player"));
		map.put("DVD", data.getKeyValue(sheetName, "DVD"));
		map.put("Hairdryer", data.getKeyValue(sheetName, "Hairdryer"));
		map.put("In-house Film", data.getKeyValue(sheetName, "In-house Film"));
		map.put("Internet", data.getKeyValue(sheetName, "Internet"));
		map.put("Ironing", data.getKeyValue(sheetName, "Ironing"));
		map.put("Kitchenette", data.getKeyValue(sheetName, "Kitchenette"));
		map.put("Laundry", data.getKeyValue(sheetName, "Laundry"));
		map.put("Microwave", data.getKeyValue(sheetName, "Microwave"));
		map.put("Mini Bar", data.getKeyValue(sheetName, "Mini Bar"));
		map.put("Non-Smoking", data.getKeyValue(sheetName, "Non-Smoking"));
		map.put("Safe", data.getKeyValue(sheetName, "Safe"));
		map.put("Satellite TV", data.getKeyValue(sheetName, "Satellite TV"));
		map.put("Smoking", data.getKeyValue(sheetName, "Smoking"));
		map.put("Tea & Coffee Making Facilities", data.getKeyValue(sheetName, "Tea & Coffee Making Facilities"));
		map.put("Washing Machine", data.getKeyValue(sheetName, "Washing Machine"));
		map.put("Television", data.getKeyValue(sheetName, "Television"));

		roomDetailsPage.enterRoomDetails(map);
		roomDetailsPage.updateRoomDetails();		
	}
	
	private void editRoomService(){
		roomDetailsPage = RoomDetailsPage.getInstance();
		Map<String, String> selectRecordMap = new HashMap<String, String>();
		selectRecordMap.put("Room Type", data.getKeyValue(sheetName, "Room Type"));
		roomDetailsPage.clickRefreshRoomDetails();
		roomDetailsPage.selectRoom(selectRecordMap);
		roomDetailsPage.selectRoomDetailsOptions("Edit");
		
		Map<String, String> map = new HashMap<String, String>();
		map.put("Air Conditioned", data.getKeyValue(sheetName, "Air Conditioned"));
	}

	public ExcelUtil getData() {
		return data;
	}
	
}
