package com.kuoni.qa.automation.page.object.content;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.gta.travel.page.base.GSPageBase;
import com.mediaocean.qa.framework.selenium.ui.controls.Button;
import com.mediaocean.qa.framework.selenium.ui.controls.CheckBox;
import com.mediaocean.qa.framework.selenium.ui.controls.Link;
import com.mediaocean.qa.framework.selenium.ui.controls.RadioButton;
import com.mediaocean.qa.framework.selenium.ui.controls.TextBox;

public class FacilitiesAndServicesDetailsPage  extends GSPageBase {

	public FacilitiesAndServicesDetailsPage() {
		super(getDriver());
	}
	
	/**
	 * This method returns the page factory object for the Facilities And Services Details Page
	 * @return static
	 */
	public static FacilitiesAndServicesDetailsPage getInstance(){
		return PageFactory.initElements(getDriver(),  FacilitiesAndServicesDetailsPage.class);
	}
	
	/**
	 * This method clicks on the edit link of the facilities and services section
	 */
	public void clickEditFacilitiesAndServicesDetails() {
		WebElement parentElement = waitForElement(By.id("propertyFacilitiesContentMenuOptions"));
		Link editLink = new Link(parentElement, "Edit");
		editLink.clickLink();	
		waitForVisibilityOfElement((By.id("FEATURES-1")), 40);
	}
	
	/**
	 * This method verifies the error message for the Total Rooms 
	 * @return String
	 */
	public String verifyValidationMessageForNumberOfRooms() {
		WebElement parentElement = waitForElement(By.id("totalRooms-errors"));
		return parentElement.getText();
	}
	

	public void editFacilitiesAndServicesDetails(Map<String, String> inputMap) {
		
		if (inputMap.containsKey("TotalRooms")){
			TextBox totalRooms = new TextBox(By.id("totalRooms"));
			totalRooms.setText("");
			totalRooms.setText(inputMap.get("TotalRooms"));
		}
		
		if (inputMap.containsKey("Lifts")){
			TextBox lifts = new TextBox(By.id("lifts"));
			lifts.setText("");
			lifts.setText(inputMap.get("Lifts"));
		}
		
		String value = null;
		if (inputMap.containsKey("Porterage")){
			value = inputMap.get("Porterage");
			if (value.equalsIgnoreCase("true")){
				sleep(2);
				RadioButton porterageRB = new RadioButton(By.name("porterage.radio"), "true");
				if (!porterageRB.isSelected())
					porterageRB.select();
			}else{
				RadioButton porterageRB = new RadioButton(By.name("porterage.radio"), "false");
				if (!porterageRB.isSelected())
					porterageRB.select();
			}
		}
		
		if (inputMap.containsKey("PorterageTwentyFourHour")){
			value = inputMap.get("PorterageTwentyFourHour");
			if (value.equalsIgnoreCase("true")){
				RadioButton porterageTwentyFourRB = new RadioButton(By.name("porterage.twentyfour.radio"), "true");
				porterageTwentyFourRB.select();
			}else{
				RadioButton porterageTwentyFourRB = new RadioButton(By.name("porterage.twentyfour.radio"), "false");
				porterageTwentyFourRB.select();
				waitForVisibilityOfElement(By.id("porterageFromTime"), 20);
			}
		}
		
		if (inputMap.containsKey("PorterageTimesFrom")){
			TextBox porterageTimesFrom = new TextBox(By.id("porterageFromTime"));
			porterageTimesFrom.setText("");
			porterageTimesFrom.setText(inputMap.get("PorterageTimesFrom"));
		}
		
		if (inputMap.containsKey("PorterageTimesTo")){
			TextBox porterageTimesTo = new TextBox(By.id("porterageToTime"));
			porterageTimesTo.setText("");
			porterageTimesTo.setText(inputMap.get("PorterageTimesTo"));
		}
		
		if (inputMap.containsKey("RoomService")){
			value = inputMap.get("RoomService");
			if (value.equalsIgnoreCase("true")){
				RadioButton roomServiceRB = new RadioButton(By.name("roomService.radio"), "true");
				roomServiceRB.select();
			}else{
				RadioButton roomServiceRB = new RadioButton(By.name("roomService.radio"), "false");
				roomServiceRB.select();
			}
		}
		
		if (inputMap.containsKey("RoomServiceTwentyFourHour")){
			value = inputMap.get("RoomServiceTwentyFourHour");
			if (value.equalsIgnoreCase("true")){
				RadioButton roomServiceTwentyFourRB = new RadioButton(By.name("roomService.twentyfour.radio"), "true");
				roomServiceTwentyFourRB.select();
			}else{
				RadioButton roomServiceTwentyFourRB = new RadioButton(By.name("roomService.twentyfour.radio"), "false");
				roomServiceTwentyFourRB.select();
				waitForVisibilityOfElement(By.id("roomServiceFromTime"), 20);
			}
		}
		
		if (inputMap.containsKey("TimesFrom")){
			TextBox timesFrom = new TextBox(By.id("roomServiceFromTime"));
			timesFrom.setText("");
			timesFrom.setText(inputMap.get("TimesFrom"));
		}
		
		if (inputMap.containsKey("TimesTo")){
			TextBox timesTo = new TextBox(By.id("roomServiceToTime"));
			timesTo.setText("");
			timesTo.setText(inputMap.get("TimesTo"));
		}
		
		if (inputMap.containsKey("EarlierBreakfast")){
			TextBox earlierBreakfast = new TextBox(By.id("earliestBreakfast"));
			earlierBreakfast.setText("");
			earlierBreakfast.setText(inputMap.get("EarlierBreakfast"));
		}
		
		if (inputMap.containsKey("MaidService")){
			value = inputMap.get("MaidService");
			if (value.equalsIgnoreCase("true")){
				RadioButton maidServiceRB = new RadioButton(By.name("maidService.radio"), "true");
				maidServiceRB.select();
			}else{
				RadioButton maidServiceRB = new RadioButton(By.name("maidService.radio"), "false");
				maidServiceRB.select();
			}
		}
		
		if (inputMap.containsKey("MaidServiceFrequency")){
			value = inputMap.get("MaidServiceFrequency");
			if (value.equalsIgnoreCase("true")){
				RadioButton maidServiceFrequencyRB = new RadioButton(By.name("maidService.frequency.radio"), "true");
				maidServiceFrequencyRB.select();
			}else{
				RadioButton maidServiceFrequencyRB = new RadioButton(By.name("maidService.frequency.radio"), "false");
				maidServiceFrequencyRB.select();
			}
			
			if(inputMap.containsKey("ServiceCharge")){
				value = inputMap.get("ServiceCharge");
				CheckBox maidServiceCharge = new CheckBox(By.id("maidServiceCharge"));
				if (value.equalsIgnoreCase("true")){
					maidServiceCharge.check();
				}else{
					maidServiceCharge.uncheck();
				}
			}
		}
		
		sleep(5);

		
		if (inputMap.containsKey("Airport")){
			value = inputMap.get("Airport");
			if (value.equalsIgnoreCase("true")){
				RadioButton airportRB = new RadioButton(By.name("propertyService.1.radio"), "true");
				airportRB.select();
			}else{
				RadioButton airportRB = new RadioButton(By.name("propertyService.1.radio"), "false");
				airportRB.select();
			}
		}
		
		if (inputMap.containsKey("AirportCharge")){
			value = inputMap.get("AirportCharge");
			try {
				CheckBox airportCharge = new CheckBox(By.id("propertyService.1.chargeable"));
				if (value.equalsIgnoreCase("true")){
					airportCharge.check();
				}else{
					airportCharge.uncheck();
				}
			}catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("Centre")){
			value = inputMap.get("Centre");
			if (value.equalsIgnoreCase("true")){
				RadioButton centreRB = new RadioButton(By.name("propertyService.2.radio"), "true");
				centreRB.select();
			}else{
				RadioButton centreRB = new RadioButton(By.name("propertyService.2.radio"), "false");
				centreRB.select();
			}
		}
		
		if (inputMap.containsKey("CentreCharge")){
			
			value = inputMap.get("CentreCharge");
			try {
				CheckBox centreCharge = new CheckBox(By.id("propertyService.2.chargeable"));
				if (value.equalsIgnoreCase("true")){
					centreCharge.check();
				}else{
					centreCharge.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("Car")){
			value = inputMap.get("Car");
			if (value.equalsIgnoreCase("true")){
				RadioButton carRB = new RadioButton(By.name("propertyService.3.radio"), "true");
				carRB.select();
			}else{
				RadioButton carRB = new RadioButton(By.name("propertyService.3.radio"), "false");
				carRB.select();
			}
		}
		
		if (inputMap.containsKey("CarCharge")){
			value = inputMap.get("CarCharge");
			try {
				CheckBox carCharge = new CheckBox(By.id("propertyService.3.chargeable"));
				if (value.equalsIgnoreCase("true")){
					carCharge.check();
				}else{
					carCharge.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		if (inputMap.containsKey("Coach")){
			value = inputMap.get("Coach");
			if (value.equalsIgnoreCase("true")){
				RadioButton coachRB = new RadioButton(By.name("propertyService.4.radio"), "true");
				coachRB.select();
			}else{
				RadioButton coachRB = new RadioButton(By.name("propertyService.4.radio"), "false");
				coachRB.select();
			}
		}
		
		if (inputMap.containsKey("CoachCharge")){
			value = inputMap.get("CoachCharge");
			try {
				CheckBox coachCharge = new CheckBox(By.id("propertyService.4.chargeable"));
				if (value.equalsIgnoreCase("true")){
					coachCharge.check();
				}else{
					coachCharge.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("Valet")){
			value = inputMap.get("Valet");
			if (value.equalsIgnoreCase("true")){
				RadioButton valetRB = new RadioButton(By.name("propertyService.5.radio"), "true");
				valetRB.select();
			}else{
				RadioButton valetRB = new RadioButton(By.name("propertyService.5.radio"), "false");
				valetRB.select();
			}
		}
		
		if (inputMap.containsKey("ValetCharge")){
			value = inputMap.get("ValetCharge");
			try {
				CheckBox valetCharge = new CheckBox(By.id("propertyService.5.chargeable"));
				if (value.equalsIgnoreCase("true")){
					valetCharge.check();
				}else{
					valetCharge.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}

		}
		
		if (inputMap.containsKey("CoachDropOff")){
			value = inputMap.get("CoachDropOff");
			if (value.equalsIgnoreCase("true")){
				RadioButton coachDropOffRB = new RadioButton(By.name("coachDropOff"), "true");
				coachDropOffRB.select();
			}else{
				RadioButton coachDropOffRB = new RadioButton(By.name("coachDropOff"), "false");
				coachDropOffRB.select();
			}
		}
		
		if (inputMap.containsKey("IndoorPools")){
			TextBox indoorPools = new TextBox(By.id("indoorPools"));
			indoorPools.setText("");
			indoorPools.setText(inputMap.get("IndoorPools"));
		}
		
		if (inputMap.containsKey("OutdoorPools")){
			TextBox outdoorPools = new TextBox(By.id("outdoorPools"));
			outdoorPools.setText("");
			outdoorPools.setText(inputMap.get("OutdoorPools"));
		}
		
		if (inputMap.containsKey("ChildrensPools")){
			TextBox childrensPools = new TextBox(By.id("childrensPools"));
			childrensPools.setText("");
			childrensPools.setText(inputMap.get("ChildrensPools"));
		}
		
		if (inputMap.containsKey("PropertyFacilities")) {

			sleep(2);
			waitForVisibilityOfElement(By.name("FEATURES"), 20);
			CheckBox.uncheckAll(By.name("FEATURES"));
			sleep(2);
			waitForVisibilityOfElement(By.id("FEATURES-20"), 20);

		}
		
		if (inputMap.containsKey("BabySitting")){
			value = inputMap.get("BabySitting");
			try {
				CheckBox babySitting = new CheckBox(By.id("FEATURES-1"));
				if (value.equalsIgnoreCase("true")){
					babySitting.check();
				}else{
					babySitting.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		if (inputMap.containsKey("BeautyParlour")){			
			value = inputMap.get("BeautyParlour");
			try {
				CheckBox beautyParlour = new CheckBox(By.id("FEATURES-5"));
				if (value.equalsIgnoreCase("true")){
					beautyParlour.check();
				}else{
					beautyParlour.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("BusinessCentre")){
			value = inputMap.get("BusinessCentre");
			try {
				CheckBox businessCentre = new CheckBox(By.id("FEATURES-81"));
				if (value.equalsIgnoreCase("true")){
					businessCentre.check();
				}else{
					businessCentre.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("Concierge")){
			value = inputMap.get("Concierge");
			try {
				CheckBox concierge = new CheckBox(By.id("FEATURES-4"));
				if (value.equalsIgnoreCase("true")){
					concierge.check();
				}else{
					concierge.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("DisabledFacilities")){
			value = inputMap.get("DisabledFacilities");
			try {
				CheckBox disabledFacilities = new CheckBox(By.id("FEATURES-2"));
				if (value.equalsIgnoreCase("true")){
					disabledFacilities.check();
				}else{
					disabledFacilities.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("HairSalon")){
			value = inputMap.get("HairSalon");
			try {
				CheckBox hairSalon = new CheckBox(By.id("FEATURES-7"));
				if (value.equalsIgnoreCase("true")){
					hairSalon.check();
				}else{
					hairSalon.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("HighSpeedInternet")){
			value = inputMap.get("HighSpeedInternet");
			try {
				CheckBox highSpeedInternet = new CheckBox(By.id("FEATURES-6"));
				if (value.equalsIgnoreCase("true")){
					highSpeedInternet.check();
				}else{
					highSpeedInternet.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("InternetWiredChargeable")){
			value = inputMap.get("InternetWiredChargeable");
			try {
				CheckBox internetWiredChargeable = new CheckBox(By.id("FEATURES-8"));
				if (value.equalsIgnoreCase("true")){
					internetWiredChargeable.check();
				}else{
					internetWiredChargeable.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("InternetWiredComplimentary")){
			value = inputMap.get("InternetWiredComplimentary");
			try {
				CheckBox internetWiredComplimentary = new CheckBox(By.id("FEATURES-9"));
				if (value.equalsIgnoreCase("true")){
					internetWiredComplimentary.check();
				}else{
					internetWiredComplimentary.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("InternetWirelessChargeable")){
			value = inputMap.get("InternetWirelessChargeable");
			try {
				CheckBox internetWirelessChargeable = new CheckBox(By.id("FEATURES-10"));
				if (value.equalsIgnoreCase("true")){
					internetWirelessChargeable.check();
				}else{
					internetWirelessChargeable.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("InternetWirelessComplimentary")){
			value = inputMap.get("InternetWirelessComplimentary");
			try {
				CheckBox internetWirelessComplimentary = new CheckBox(By.id("FEATURES-11"));
				if (value.equalsIgnoreCase("true")){
					internetWirelessComplimentary.check();
				}else{
					internetWirelessComplimentary.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("PrivateBeach")){
			value = inputMap.get("PrivateBeach");
			try {
				CheckBox privateBeach = new CheckBox(By.id("FEATURES-12"));
				if (value.equalsIgnoreCase("true")){
					privateBeach.check();
				}else{
					privateBeach.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}

		}
		
		if (inputMap.containsKey("PublicBeach")){
			value = inputMap.get("PublicBeach");
			try {
				CheckBox publicBeach = new CheckBox(By.id("FEATURES-13"));
				if (value.equalsIgnoreCase("true")){
					publicBeach.check();
				}else{
					publicBeach.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}

		}
		
		if (inputMap.containsKey("SuperMarket")){
			value = inputMap.get("SuperMarket");
			try {
				CheckBox superMarket = new CheckBox(By.id("FEATURES-14"));
				if (value.equalsIgnoreCase("true")){
					superMarket.check();
				}else{
					superMarket.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		if (inputMap.containsKey("WheelChairAccess")){
			value = inputMap.get("WheelChairAccess");
			try {
				CheckBox wheelChairAccess = new CheckBox(By.id("FEATURES-3"));
				if (value.equalsIgnoreCase("true")){
					wheelChairAccess.check();
				}else{
					wheelChairAccess.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}

		}
		
		if (inputMap.containsKey("BeachFront")){
			value = inputMap.get("BeachFront");
			try {
				CheckBox beachFront = new CheckBox(By.id("FEATURES-18"));
				if (value.equalsIgnoreCase("true")){
					beachFront.check();
				}else{
					beachFront.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("CarEssential")){
			value = inputMap.get("CarEssential");
			try {
				CheckBox carEssential = new CheckBox(By.id("FEATURES-15"));
				if (value.equalsIgnoreCase("true")){
					carEssential.check();
				}else{
					carEssential.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("NoCredtiCards")){
			value = inputMap.get("NoCredtiCards");
			try {
				CheckBox noCredtiCards = new CheckBox(By.id("FEATURES-16"));
				if (value.equalsIgnoreCase("true")){
					noCredtiCards.check();
				}else{
					noCredtiCards.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		if (inputMap.containsKey("NonSmokingProperty")){
			value = inputMap.get("NonSmokingProperty");
			try {
				CheckBox nonSmokingProperty = new CheckBox(By.id("FEATURES-17"));
				if (value.equalsIgnoreCase("true")){
					nonSmokingProperty.check();
				}else{
					nonSmokingProperty.uncheck();
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("PetsAllowed")){
			value = inputMap.get("PetsAllowed");
			try {
				CheckBox petsAllowed = new CheckBox(By.id("FEATURES-19"));
				if (value.equalsIgnoreCase("true")){
					petsAllowed.check();
				}else{
					petsAllowed.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("BicycleHire")){
			value = inputMap.get("BicycleHire");
			try {
				CheckBox bicycleHire = new CheckBox(By.id("FEATURES-21"));
				if (value.equalsIgnoreCase("true")){
					bicycleHire.check();
				}else{
					bicycleHire.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}

		}
		
		if (inputMap.containsKey("Casino")){
			value = inputMap.get("Casino");
			try {
				CheckBox casino = new CheckBox(By.id("FEATURES-23"));
				if (value.equalsIgnoreCase("true")){
					casino.check();
				}else{
					casino.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("CookeryClasses")){
			value = inputMap.get("CookeryClasses");
			try {
				CheckBox cookeryClasses = new CheckBox(By.id("FEATURES-24"));
				if (value.equalsIgnoreCase("true")){
					cookeryClasses.check();
				}else{
					cookeryClasses.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		if (inputMap.containsKey("DiscoNightclub")){
			value = inputMap.get("DiscoNightclub");
			try {
				CheckBox discoNightclub = new CheckBox(By.id("FEATURES-25"));
				if (value.equalsIgnoreCase("true")){
					discoNightclub.check();
				}else{
					discoNightclub.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		if (inputMap.containsKey("Diving")){
			value = inputMap.get("Diving");
			
			try {
				CheckBox diving = new CheckBox(By.id("FEATURES-38"));
				if (value.equalsIgnoreCase("true")){
					diving.check();
				}else{
					diving.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
			
		}
		
		if (inputMap.containsKey("FitnessCentre")){
			value = inputMap.get("FitnessCentre");
			try {
				CheckBox fitnessCentre = new CheckBox(By.id("FEATURES-28"));
				if (value.equalsIgnoreCase("true")){
					fitnessCentre.check();
				}else{
					fitnessCentre.uncheck();
				}
			}
			catch(Exception e){
				e.printStackTrace();
			}

		}
		
		if (inputMap.containsKey("Golf")){
			value = inputMap.get("Golf");
			try {
				CheckBox golf = new CheckBox(By.id("FEATURES-26"));
				if (value.equalsIgnoreCase("true")){
					golf.check();
				}else{
					golf.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}

		}
		
		if (inputMap.containsKey("JetSkiing")){
			value = inputMap.get("JetSkiing");
			try {
				CheckBox jetSkiing = new CheckBox(By.id("FEATURES-35"));
				if (value.equalsIgnoreCase("true")){
					jetSkiing.check();
				}else{
					jetSkiing.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("KidsClub")){
			value = inputMap.get("KidsClub");
			try {
				CheckBox kidsClub = new CheckBox(By.id("FEATURES-31"));
				if (value.equalsIgnoreCase("true")){
					kidsClub.check();
				}else{
					kidsClub.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("Massage")){
			value = inputMap.get("Massage");
			try {
				CheckBox massage = new CheckBox(By.id("FEATURES-29"));
				if (value.equalsIgnoreCase("true")){
					massage.check();
				}else{
					massage.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("MiniGolf")){
			value = inputMap.get("MiniGolf");
			try {
				CheckBox miniGolf = new CheckBox(By.id("FEATURES-32"));
				if (value.equalsIgnoreCase("true")){
					miniGolf.check();
				}else{
					miniGolf.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("MotorisedWaterSports")){
			value = inputMap.get("MotorisedWaterSports");
			try {
				CheckBox motorisedWaterSports = new CheckBox(By.id("FEATURES-46"));
				if (value.equalsIgnoreCase("true")){
					motorisedWaterSports.check();
				}else{
					motorisedWaterSports.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("NaturalHotSpring")){
			value = inputMap.get("NaturalHotSpring");
			try {
				CheckBox naturalHotSpring = new CheckBox(By.id("FEATURES-39"));
				if (value.equalsIgnoreCase("true")){
					naturalHotSpring.check();
				}else{
					naturalHotSpring.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("NightlyEntertainment")){
			value = inputMap.get("NightlyEntertainment");
			try {
				CheckBox nightlyEntertainment = new CheckBox(By.id("FEATURES-33"));
				if (value.equalsIgnoreCase("true")){
					nightlyEntertainment.check();
				}else{
					nightlyEntertainment.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("NonMotorisedWaterSports")){
			value = inputMap.get("NonMotorisedWaterSports");
			try {
				CheckBox nonMotorisedWaterSports = new CheckBox(By.id("FEATURES-47"));
				if (value.equalsIgnoreCase("true")){
					nonMotorisedWaterSports.check();
				}else{
					nonMotorisedWaterSports.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("Sailing")){
			value = inputMap.get("Sailing");
			try {
				CheckBox sailing = new CheckBox(By.id("FEATURES-34"));
				if (value.equalsIgnoreCase("true")){
					sailing.check();
				}else{
					sailing.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}

		}
		
		if (inputMap.containsKey("Sauna")){
			value = inputMap.get("Sauna");
			try {
				CheckBox sauna = new CheckBox(By.id("FEATURES-30"));
				if (value.equalsIgnoreCase("true")){
					sauna.check();
				}else{
					sauna.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("Snorkelling")){
			value = inputMap.get("Snorkelling");
			try {
				CheckBox snorkelling = new CheckBox(By.id("FEATURES-36"));
				if (value.equalsIgnoreCase("true")){
					snorkelling.check();
				}else{
					snorkelling.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("Spa")){
			value = inputMap.get("Spa");
			try {
				CheckBox spa = new CheckBox(By.id("FEATURES-27"));
				if (value.equalsIgnoreCase("true")){
					spa.check();
				}else{
					spa.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("TableTennis")){
			value = inputMap.get("TableTennis");
			try {
				CheckBox tableTennis = new CheckBox(By.id("FEATURES-42"));
				if (value.equalsIgnoreCase("true")){
					tableTennis.check();
				}else{
					tableTennis.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("Tennis")){
			value = inputMap.get("Tennis");
			try {
				CheckBox tennis = new CheckBox(By.id("FEATURES-41"));
				if (value.equalsIgnoreCase("true")){
					tennis.check();
				}else{
					tennis.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("ThemePark")){
			value = inputMap.get("ThemePark");
			try {
				CheckBox themePark = new CheckBox(By.id("FEATURES-22"));
				if (value.equalsIgnoreCase("true")){
					themePark.check();
				}else{
					themePark.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("TurkishBaths")){
			value = inputMap.get("TurkishBaths");
			try {
				CheckBox turkishBaths = new CheckBox(By.id("FEATURES-40"));
				if (value.equalsIgnoreCase("true")){
					turkishBaths.check();
				}else{
					turkishBaths.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("Volleyball")){
			value = inputMap.get("Volleyball");
			try {
				CheckBox volleyball = new CheckBox(By.id("FEATURES-43"));
				if (value.equalsIgnoreCase("true")){
					volleyball.check();
				}else{
					volleyball.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("WaterPark")){
			value = inputMap.get("WaterPark");
			try {
				CheckBox waterPark = new CheckBox(By.id("FEATURES-37"));
				if (value.equalsIgnoreCase("true")){
					waterPark.check();
				}else{
					waterPark.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("WaterSports")){
			value = inputMap.get("WaterSports");
			try {
				CheckBox waterSports = new CheckBox(By.id("FEATURES-45"));
				if (value.equalsIgnoreCase("true")){
					waterSports.check();
				}else{
					waterSports.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("Windsurfing")){
			value = inputMap.get("Windsurfing");
			try {
				CheckBox windsurfing = new CheckBox(By.id("FEATURES-44"));
				if (value.equalsIgnoreCase("true")){
					windsurfing.check();
				}else{
					windsurfing.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (inputMap.containsKey("WineTasting")){
			value = inputMap.get("WineTasting");
			try {
				CheckBox wineTasting = new CheckBox(By.id("FEATURES-20"));
				if (value.equalsIgnoreCase("true")){
					wineTasting.check();
				}else{
					wineTasting.uncheck();
				}
			}
			catch (Exception e) {
				e.printStackTrace();
			}
		}		
		
	}
	
	/**
	 * This method clicks on the cancel button in the facilities and services section
	 */
	public void cancelFacilitiesAndServicesDetails() {
		WebElement parentElement = waitForElement(By.id("propertyFacilitiesContent"));
		Button cancelButton = new Button(parentElement, "Cancel");
		cancelButton.click();
		waitForVisibilityOfElement((By.id("facilities_totalRooms_value")), 40);
	}
	
	/**
	 * This method clicks on the update button of the facilities and services section
	 */
	public void updateFacilitiesAndServicesDetails() {
		Button updateButton = new Button("propertyFacilitiesEdit");
		updateButton.click();
		waitForVisibilityOfElement(By.id("facilities_totalRooms_value"),20);
	}
	
	/**
	 * This method clicks on the update button of the facilities and services section
	 */
	public void updateFacilitiesAndServicesDetailsForInvalidNoOfRooms() {
		Button updateButton = new Button("propertyFacilitiesEdit");
		updateButton.click();
		sleep(2);
		waitForVisibilityOfElement(By.id("totalRooms-errors"),20);
	}
	
	/**
	 * This method verifies the record updated message and returns false upon
	 * failure
	 * @param parentLocator
	 * @param message
	 * @return boolean
	 */
	public boolean verifyRecordUpdatedMessage(By parentLocator, String message){
		WebElement parentEl = waitForElement(parentLocator);
		waitForElement(parentEl, By.className("message"));
		if (getElement(parentEl, By.className("message")).getText().contains(message)){
			return true;
		}
		return false;
	}

}
