package com.kuoni.qa.automation.dao


import com.kuoni.qa.automation.dao.GetDatabaseConn
import com.kuoni.qa.automation.dto.ProductRoomsDTO
import com.kuoni.qa.automation.dto.PropertyDTO
import java.sql.Connection
import java.sql.ResultSet
import java.sql.Statement

class GetPropertyDBdata {

	GetDatabaseConn db = new GetDatabaseConn()
	PropertyDTO fdata = new PropertyDTO()

	def PropertyDTO getPropertyData(int propertyId) {


		Connection conn = db.getDBconnection()
		PropertyDTO data = new PropertyDTO()
		ResultSet rs =null
		Statement statement = null

		try {

			statement = conn.createStatement()
			String sql = "select count(*) COUNT from FIT_DCS_PRODUCT"
			rs = statement.executeQuery(sql)

			if(rs.next()){

				data.setPropertyCount(rs.getInt("COUNT"))
			}



			if(rs.getInt("COUNT")>0) {

				sql = """select 
						--(select count(0) from FIT_facility f2 ,fit_dcs_product p,FIT_facilities f1 where p.EXTERNAL_REFERENCE_ID=""" + propertyId +""" and p.PRODUCT_ID=f1.PRODUCT_ID and f1.FACILITY_ID = f2.ID) FCOUNT,--
						--(select count(0) from FIT_PROP_INFORMATIONS f1 ,fit_dcs_product p where p.EXTERNAL_REFERENCE_ID=""" + propertyId +""" and p.PRODUCT_ID=f1.PRODUCT_ID ) ICOUNT,--
						--(select count(0) from FIT_SWIMMING_POOL f2 ,fit_dcs_product p,FIT_SWIMMING_POOLS f1 where p.EXTERNAL_REFERENCE_ID=1212 and p.PRODUCT_ID=f1.PRODUCT_ID and f1.SWIMMING_POOL_ID = f2.ID) SWCOUNT,--
						--(select count(0) from FIT_PROP_ACTIVITIES f2 ,fit_dcs_product p where p.EXTERNAL_REFERENCE_ID=""" + propertyId +""" and p.PRODUCT_ID=f2.PRODUCT_ID ) ACOUNT,--
						--(select count(0) from FIT_PROP_STYLES f2 ,fit_dcs_product p where p.EXTERNAL_REFERENCE_ID=""" + propertyId +""" and p.PRODUCT_ID=f2.PRODUCT_ID ) SCOUNT,--
						--(select count(0) from FIT_DCS_PRODUCT a , FIT_PROPERTY_PROVISIONS b where a.EXTERNAL_REFERENCE_ID =""" + propertyId + """and a.PRODUCT_ID = b.PRODUCT_ID) PROVCOUNT,--
						--(select count(0) from FIT_RESTRICTION f2 ,fit_dcs_product p,FIT_PROPERTY_RESTRICTIONS f1 where p.EXTERNAL_REFERENCE_ID="""+propertyId+""" and p.PRODUCT_ID=f1.PRODUCT_ID and f1.RESTRICTION_ID = f2.RESTRICTION_ID) RESCOUNT,--

						address.address_TYPE,address.address_ID,address.ADDRESS_LINE1,address.ADDRESS_LINE2,address.ACTIVE,address.ADDRESS_LINE3,address.postcode,
						country.country_id,hotel.website,
						hotel.earliest_bf_time,
						hotel.NUMBER_OF_ROOMS TOTALROOMS,hotel.CHECK_IN_TIME checkin,hotel.CHECK_OUT_TIME checkout,hotel.MINIMUM_AGE minage,
						hotel.COACH_DROP_OFF coach,hotel.TELEPHONE,
						product.location_code,geo.latitude,geo.longitude,city.CITY_ID,city.CODE,
						--legacy.property_code,--
						DCS_PRODUCT.DISPLAY_NAME,product.STAR_RATING 

						FROM

						FIT_DCS_PRODUCT product,
						FIT_PRODUCT_HOTEL hotel,FIT_PROPERTY_ADDRESS address ,FIT_GEO_CODE geo,
						--FIT_LEGACY_PROPERTY legacy,--
						FIT_CITY city , FIT_COUNTRY country, DCS_PRODUCT 
						
						WHERE 

						product.geo_code= geo.ID and 
						--product.legacy_property=legacy.ID and--
						address.city=city.city_ID and 
						product.address = address.ID and 
						address.country = country.country_id  and 
						DCS_PRODUCT.PRODUCT_ID = product.PRODUCT_ID and 
						product.PRODUCT_ID = hotel.PRODUCT_ID and 
						product.EXTERNAL_REFERENCE_ID="""+ propertyId +""" and ROWNUM=1"""

				rs = statement.executeQuery(sql);

				while(rs.next()) {

					data.setAddressId(rs.getInt("ADDRESS_ID"))
					data.setAddressType(rs.getString("ADDRESS_TYPE"))
					data.setAddressL1(rs.getString("ADDRESS_LINE1"))
					data.setAddressL2(rs.getString("ADDRESS_LINE2"))
					data.setAddressL3(rs.getString("ADDRESS_LINE3"))
					//data.setcountryDefaultCrncy(rs.getString("ROOM_VIEW"))
					data.setPostCode(rs.getString("POSTCODE"))
					data.setLocationCode(rs.getString("LOCATION_CODE"))
					data.setGeoLatitude(rs.getFloat("LATITUDE"))
					data.setGeoLongitude(rs.getFloat("LONGITUDE"))
					//data.setLegCityCode(rs.getString("CODE"))
					//data.setLegPropertyCode(rs.getString("PROPERTY_CODE"))
					data.setPropertyName(rs.getString("DISPLAY_NAME"))
					data.setCountryId(rs.getInt("COUNTRY_ID"))
					data.setCityId(rs.getInt("CITY_ID"))
					data.setAddressActive(rs.getInt("ACTIVE"))
					data.setStarRating(rs.getString("STAR_RATING"))
					/*data.setFacilityCount(rs.getInt("FCOUNT"))
					 data.setInformationCount(rs.getInt("ICOUNT"))
					 data.setActivityCount(rs.getInt("ACOUNT"))
					 data.setStyleCount(rs.getInt("SCOUNT"))*/
					data.setTotalRooms(rs.getInt("TOTALROOMS"))
					data.setCheckinTime(rs.getString("checkin"))
					data.setCheckoutTime(rs.getString("checkout"))
					data.setMinAge(rs.getInt("minage"))
					data.setCoachDrop(rs.getInt("coach"))
					data.setTelephone(rs.getString("TELEPHONE"))
					/*data.setSwimmingCount(rs.getInt("SWCOUNT"))
					 data.setRestrictionsCount(rs.getInt("RESCOUNT"))
					 data.setProvisionsCount(rs.getInt("PROVCOUNT"))*/
					data.setEarliestBreakFast(rs.getString("EARLIEST_BF_TIME"))
					data.setWebsite(rs.getString("website"))




				}
			}
		}catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		finally{
			statement.close()
			rs.close();
			conn.close();
		}
		return data
	}

	// Facilities

	def boolean getFacilities(int propertyId, String facilityCode) {

		Connection conn = db.getDBconnection()
		ResultSet rs = null
		Statement statement = null
		def facilityCount


		try{
			statement = conn.createStatement()

			String sql = "select count(0) as COUNT from FIT_PROP_facilities f1 ,fit_dcs_product p where p.EXTERNAL_REFERENCE_ID= " + propertyId + " and p.PRODUCT_ID=f1.PRODUCT_ID and f1.FACILITY_CODE = " + "'" + facilityCode +"'"

			rs = statement.executeQuery(sql)
			while(rs.next()) {
				facilityCount = rs.getInt("COUNT")
			}

			if(facilityCount==1)
				return true
			else
				return false
			return fdata
		}catch (Exception e)
		{
			e.printStackTrace()
		}

		finally{

			statement.close()
			rs.close();
			conn.close();

		}
	}

	def boolean getInformations(int propertyId, String facilityCode) {


		Connection conn = db.getDBconnection()
		ResultSet rs = null
		Statement statement = null
		def infCount

		try{
			statement = conn.createStatement()

			String sql = "select count(0) as COUNT from FIT_PROP_INFORMATIONs f1 ,fit_dcs_product p where p.EXTERNAL_REFERENCE_ID= " + propertyId + " and p.PRODUCT_ID=f1.PRODUCT_ID and f1.INFORMATION_CODE =" + "'" + facilityCode +"'"

			rs = statement.executeQuery(sql)
			while(rs.next()) {
				infCount= rs.getInt("COUNT")
			}

			if(infCount==1)
				return true
			else
				return false
		}

		catch (Exception e)
		{
			e.printStackTrace()
		}

		finally{

			statement.close()
			rs.close();
			conn.close();

		}
	}

	def boolean getActivities(int propertyId, String facilityCode) {


		Connection conn = db.getDBconnection()
		ResultSet rs = null
		Statement statement = null
		def actCount
		try{
			statement = conn.createStatement()

			String sql = "select count(0) as COUNT from FIT_PROP_ACTIVITIES f1 ,fit_dcs_product p where p.EXTERNAL_REFERENCE_ID= " + propertyId + " and p.PRODUCT_ID=f1.PRODUCT_ID and f1.ACTIVITY_CODE = " + "'" + facilityCode +"'"

			rs = statement.executeQuery(sql)
			while(rs.next()) {
				actCount= rs.getInt("COUNT")
			}


			if(actCount==1)
				return true
			else
				return false

		}

		catch (Exception e)
		{
			e.printStackTrace()
		}

		finally{

			statement.close()
			rs.close();
			conn.close();

		}
	}

	def boolean getStyles(int propertyId, String facilityCode) {


		Connection conn = db.getDBconnection()
		ResultSet rs = null
		Statement statement = null
		def styleCount
		try{
			statement = conn.createStatement()

			String sql = "select count(0) as COUNT from FIT_PROP_STYLES f1 ,fit_dcs_product p where p.EXTERNAL_REFERENCE_ID= " + propertyId + " and p.PRODUCT_ID=f1.PRODUCT_ID and f1.STYLE_CODE = " + "'" + facilityCode +"'"

			rs = statement.executeQuery(sql)
			while(rs.next()) {
				styleCount = rs.getInt("COUNT")
			}


			if(styleCount==1)
				return true
			else
				return false

		}

		catch (Exception e)
		{
			e.printStackTrace()
		}

		finally{

			statement.close()
			rs.close();
			conn.close();

		}
	}

	def PropertyDTO getSwimmingPools(int propertyId, String facilityCode) {


		Connection conn = db.getDBconnection()
		ResultSet rs = null
		Statement statement = null

		try{
			statement = conn.createStatement()

			String sql = "select f1.NUM_OF_POOLS as spools from FIT_SWIMMING_POOLS f1 ,fit_dcs_product p where p.EXTERNAL_REFERENCE_ID=" +propertyId + " and p.PRODUCT_ID=f1.PRODUCT_ID and f1.POOL_TYPE = UPPER(" + "'"+ facilityCode +"'"+")"

			rs = statement.executeQuery(sql)
			if(rs.next()) {
				fdata.setPoolTypeCount(rs.getInt("spools"))
			}


			return fdata

		}

		catch (Exception e)
		{
			e.printStackTrace()
		}

		finally{

			statement.close()
			rs.close();
			conn.close();

		}
	}


	def PropertyDTO getRestrictions(int propertyId, String facilityCode) {


		Connection conn = db.getDBconnection()
		ResultSet rs = null
		Statement statement = null

		try{
			statement = conn.createStatement()
			String sql = "select f2.RESTRICTION_TYPE,f2.TRAVEL_START,f2.TRAVEL_END  from FIT_RESTRICTION f2 ,fit_dcs_product p,FIT_PROPERTY_RESTRICTIONS f1 where p.EXTERNAL_REFERENCE_ID=" +propertyId + " and p.PRODUCT_ID=f1.PRODUCT_ID and f1.RESTRICTION_ID = f2.ID and f2.RESTRICTION_ID = " + "'"+ facilityCode +"'"

			rs = statement.executeQuery(sql)

			while(rs.next()) {

				fdata.setRestrictionType(rs.getString("RESTRICTION_TYPE"))
				fdata.setResStartDate((rs.getString("TRAVEL_START")).substring(0, 10))
				fdata.setResEndDate((rs.getString("TRAVEL_END")).substring(0,10))
			}


			return fdata

		}

		catch (Exception e)
		{
			e.printStackTrace()
		}

		finally{

			statement.close()
			rs.close();
			conn.close();

		}
	}


	def PropertyDTO getRoomServiceData(int propertyId) {
		Connection conn = db.getDBconnection()
		ResultSet rs = null
		Statement statement = null



		try {

			statement = conn.createStatement()

			String sql = """SELECT a.room_Service_Required,
						a.available_All_Day,
						a.time_Range

						FROM FIT_ROOM_SERVICE a ,
						FIT_DCS_PRODUCT b,
						FIT_PRODUCT_HOTEL c

						WHERE b.PRODUCT_ID         = c.PRODUCT_ID
						AND c.ROOM_SERVICE         =a.ID
						AND b.External_Reference_Id = """ + propertyId

			rs = statement.executeQuery(sql)
			if(rs.next()) {
				fdata.setRoomServiceRequired(rs.getInt("room_Service_Required"))
				fdata.setAvailableAllDay(rs.getInt("available_All_Day"))
				fdata.setTimeRange(rs.getString("time_Range"))
			}


			return fdata
		}
		catch (Exception e) {
			e.printStackTrace();
		}

		finally {
			statement.close()
			rs.close();
			conn.close();
		}
	}


	def PropertyDTO getMaidServiceData(int propertyId) {
		Connection conn = db.getDBconnection()
		ResultSet rs = null
		Statement statement = null



		try {

			statement = conn.createStatement()

			String sql = """SELECT a.MAID_Service_Required,
						a.CHARGE_APPLIES,
						a.FREQUENCY

						FROM FIT_MAID_SERVICE a ,
						FIT_DCS_PRODUCT b,
						FIT_PRODUCT_HOTEL c

						WHERE b.PRODUCT_ID         = c.PRODUCT_ID
						AND c.MAID_SERVICE         =a.ID
						AND b.External_Reference_Id = """ + propertyId + "and ROWNUM=1"

			rs = statement.executeQuery(sql)

			if(rs.next()) {
				fdata.setMaidServiceRequired(rs.getInt("maid_Service_Required"))
				fdata.setChargeApplies(rs.getInt("charge_Applies"))
				fdata.setFrequency(rs.getString("frequency"))
			}


			return fdata
		} catch (Exception e) {
			e.printStackTrace();
		}

		finally {
			statement.close()
			rs.close();
			conn.close();
		}
	}
}
