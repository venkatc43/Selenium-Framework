package com.kuoni.qa.automation.util

import java.text.SimpleDateFormat

class PropertyUtil {

	static boolean requireAssert(def expected) {
		boolean output
		def ignorevalues = [
			"propertyName",
			"propertyId",
			"propertyCount",
			"facilityName",
			"facilityCount",
			"informationName",
			"informationCount",
			"swimmingCount",
			"activityName",
			"activityCount",
			"styleName",
			"styleCount",
			"class",
			"swimmingCount",
			"legCityCode",
			"legPropertyCode",
			"restrictionsCount",
			"restrictionId",
			"restrictionType",
			"resStartDate",
			"resEndDate",
			"provisionsCount",
			"addressType",
			"addressActive",
			"roomServiceRequired",
			"availableAllDay",
			"timeRange",
			"maidServiceRequired",
			"chargeApplies",
			"frequency",
			"earliestBreakFast"
		]

		for(int i=0; i < ignorevalues.size();i++) {

			if(expected.equals(ignorevalues[i])) {
				output = false
				break
			}
			else{

				output = true
			}

			//if(output==false)

			//break


		}
		return output
	}



	//To format the date into Required Format
	static String getDate(String oldDate)
	{

		String newS = oldDate.substring(0, 10)
		String newString = newS.replace("T", " ")
		return newString

	}
}

