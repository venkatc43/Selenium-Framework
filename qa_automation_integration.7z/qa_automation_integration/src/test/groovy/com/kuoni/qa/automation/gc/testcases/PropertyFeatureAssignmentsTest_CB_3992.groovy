package com.kuoni.qa.automation.gc.testcases

import spock.lang.IgnoreIf
import spock.lang.Specification
import spock.lang.Stepwise;

import com.kuoni.qa.automation.datacreate.test.helper.PropertyFeatureAssignmentsTestHelper
import com.kuoni.qa.constants.CommonConstants
import com.kuoni.qa.util.CommonUtil
import com.kuoni.qa.util.ConfigProperties
import com.kuoni.qa.util.TestSuiteProperties

@Stepwise
class PropertyFeatureAssignmentsTest_CB_3992 extends Specification{
	
	PropertyFeatureAssignmentsTestHelper helper = new PropertyFeatureAssignmentsTestHelper()
	
	@IgnoreIf({TestSuiteProperties.getVlaue("Ignore_PropertyFeatureAssignmentsTest_CB_3992").equals("true")? true : false})
	def "update property features"(){
		
		when:"update property features from gc apllication"
		assert helper.updatePropertyFeaturesFromGC("CB-3992-Update"), "error occurred while updating property features from gc application"
		
		then:"read canonical xml from input Q"
		sleep(Integer.parseInt(ConfigProperties.getVlaue("pollingInterval")))
		assert helper.readXMLFromQ(ConfigProperties.getVlaue("propertyFeatureAssignmentsUpdateXMLPath"), ConfigProperties.getVlaue("outputQ"),"CB-3992-Update"),"error occurred while reading canonical xml from output Q"

		then:"validate canonical xml against xsd"
		assert CommonUtil.validateCanonicalXML(ConfigProperties.getVlaue("cdmXsdPath"), ConfigProperties.getVlaue("propertyFeatureAssignmentsUpdateXMLPath")), "error occurred while validating CDM output xml to XSD"
		
		then:"validate canonical xml data"
		assert helper.validatePropertyFeaturesAssignmentsOutputXML("CB-3992-Update", ConfigProperties.getVlaue("propertyFeatureAssignmentsUpdateXMLPath")), "invalid data with  CDM output xmls"
	}
	
	@IgnoreIf({TestSuiteProperties.getVlaue("Ignore_PropertyFeatureAssignmentsTest_CB_3992").equals("true")? true : false})
	def "delete property features"(){
		
		when:"delete property features from gc apllication"
		assert helper.updatePropertyFeaturesFromGC("CB-3992-Delete"), "error occurred while deleting property features from gc application"
		
		then:"read canonical xml from input Q"
		sleep(Integer.parseInt(ConfigProperties.getVlaue("pollingInterval")))
		assert helper.readXMLFromQ(ConfigProperties.getVlaue("propertyFeatureAssignmentsDeleteXMLPath"), ConfigProperties.getVlaue("outputQ"),"CB-3992-Delete"),"error occurred while reading canonical xml from output Q"
		
		then:"validate canonical xml against xsd"
		assert CommonUtil.validateCanonicalXML(ConfigProperties.getVlaue("cdmXsdPath"), ConfigProperties.getVlaue("propertyFeatureAssignmentsDeleteXMLPath")), "error occurred while validating CDM output xml to XSD"
		
		then:"validate canonical xml data"
		assert helper.validatePropertyFeaturesAssignmentsOutputXML("CB-3992-Delete", ConfigProperties.getVlaue("propertyFeatureAssignmentsDeleteXMLPath")), "invalid data with  CDM output xmls"
	}
	
	@IgnoreIf({TestSuiteProperties.getVlaue("Ignore_CloseWebdrver").equals("true")? true : false})
	def "close webdriver"(){
		
		when:""
		if(CommonConstants.webDriver != null){
			CommonConstants.webDriver.quit()
		}
		then:""
	}
}