package com.kuoni.qa.automation.page.object.countries;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.gta.travel.page.base.GSPageBase;
import com.mediaocean.qa.framework.selenium.ui.controls.Button;
import com.mediaocean.qa.framework.selenium.ui.controls.ComboBox;

public class CountryListPage extends GSPageBase {

	public CountryListPage(WebDriver driver) {
		super(getDriver());
	}
	
	public static CountryListPage getIntance(){
		return PageFactory.initElements(getDriver(),CountryListPage.class); 
	}
	
	public CountryResultListPage searchCountries(Map<String, String> map){
		
		if (map.containsKey("Zone")){
			ComboBox propTypeComboBox = new ComboBox(By.id("searchZone"));
			propTypeComboBox.select(map.get("Zone"));
		}
		if (map.containsKey("Country Name")){
			clearAndType(By.id("countryName"),map.get("Country Name"));
		}
		
		Button searchButton = new Button("search");
		searchButton.click();
		
		return PageFactory.initElements(getDriver(), CountryResultListPage.class);
	}

}
