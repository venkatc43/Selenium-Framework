package com.kuoni.qa.automation.util

import com.kuoni.qa.automation.dto.ContractDTO

class ContractXmlUtil {

	ContractDTO xml = new ContractDTO()
	
	
	def ContractDTO readXml(contractXml)
	
	{
	
	def c = contractXml.recordset.record
	
	xml.setContractId(c.contract.@id[0].toInteger())
	xml.setContractType(c.contract.@type[0])
	xml.setContractModel(c.contract.@model[0])
	xml.setContractStatus(c.contract.@status[0])
	if(c.contract.@providerId[0]!=null)
	xml.setProviderId(c.contract.@providerId[0].toInteger())
	else
	xml.setProviderId(c.contract.@providerId[0])
	
	if(c.contract.propertyId[0]!=null)
	xml.setPropertyId(c.contract.propertyId[0].toInteger())
	else
	xml.setPropertyId(c.contract.propertyId[0])
	xml.setOnSale(c.contract.@onSale[0])
	xml.setAllowOnRequest(c.contract.@allowOnRequest[0])
	xml.setValidFrom(c.contract.@validFrom[0])
	xml.setLegacyCityCode(c.contract.@legacyCityCode[0])
	xml.setLegacyPropertyCode(c.contract.@legacyPropertyCode[0])
	
	
	return xml
	
	
	}
	
	
	
}
