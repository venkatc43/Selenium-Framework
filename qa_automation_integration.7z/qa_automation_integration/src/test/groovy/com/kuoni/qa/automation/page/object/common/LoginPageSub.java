package com.kuoni.qa.automation.page.object.common;

import org.openqa.selenium.By;
import org.openqa.selenium.support.PageFactory;

import com.gta.travel.page.base.GSPageBase;

public class LoginPageSub extends GSPageBase {

	public LoginPageSub() {
		super(getDriver());
	}
	
	public HomePageSub login(String webId, String userName, String password){
		waitForElementToBeClickable(By.id("login"));
		clearAndType(By.id("qualifier"), webId);
		clearAndType(By.id("username"), userName);
		clearAndType(By.id("password"), password);
		waitAndClick(By.id("login"));
		
	    waitForPageElement(By.linkText("Contracts"));
    	return PageFactory.initElements(getDriver(), HomePageSub.class);
	}

}
