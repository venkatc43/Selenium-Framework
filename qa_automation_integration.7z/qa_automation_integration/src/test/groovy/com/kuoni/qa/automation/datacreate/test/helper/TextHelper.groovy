package com.kuoni.qa.automation.datacreate.test.helper

import javax.xml.transform.stream.StreamSource
import javax.xml.validation.SchemaFactory

import com.kuoni.qa.automation.gc.test.TextCreateEditDeleteTest
import com.kuoni.qa.util.CommonUtil
import com.kuoni.qa.util.ConfigProperties
import com.mediaocean.qa.framework.utils.ExcelUtil


class TextHelper {

	private ExcelUtil excelData = null
	public def executeLocationFromGCApplication(String SheetName){
		boolean executionFlag = false
		try{
			TextCreateEditDeleteTest test = new TextCreateEditDeleteTest(ConfigProperties.getVlaue("driverSheetPath"),ConfigProperties.getVlaue("dataSheetPath"),SheetName)
			if(SheetName.equalsIgnoreCase("CB-3388-Create")){
				test.executeDataScriptForCreate()
			}else if(SheetName.equalsIgnoreCase("CB-3388-Edit")){
				test.executeDataScriptForEdit()
			}else{
				test.executeDataScriptForDelete()
			}
			executionFlag = true
		}catch(Exception e){
			println e
		}
		return executionFlag
	}

	public def executeFeatureFromGCApplication(String sheetName){
		boolean executionFlag = false
		try{
			TextCreateEditDeleteTest test = new TextCreateEditDeleteTest(ConfigProperties.getVlaue("driverSheetPath"),ConfigProperties.getVlaue("dataSheetPath"),sheetName)
			excelData = test.getExcelData()
			if(sheetName.equalsIgnoreCase("CB-3989-Create")){
				test.executeDataScriptForCreate()
			}else if(sheetName.equalsIgnoreCase("CB-3989-Edit")){
				test.executeDataScriptForEdit()
			}else{
				test.executeDataScriptForDelete()
			}
			executionFlag = true
		}catch(Exception e){
			println e
		}
		return executionFlag
	}

	public def executeStyleDescriptionFromGCApplication(String sheetName){
		boolean executionFlag = false
		try{
			TextCreateEditDeleteTest test = new TextCreateEditDeleteTest(ConfigProperties.getVlaue("driverSheetPath"),ConfigProperties.getVlaue("dataSheetPath"),sheetName)
			excelData = test.getExcelData()
			if(sheetName.equalsIgnoreCase("CB-3990-Create")){
				test.executeDataScriptForCreate()
			}else if(sheetName.equalsIgnoreCase("CB-3990-Edit")){
				test.executeDataScriptForEdit()
			}else{
				test.executeDataScriptForDelete()
			}
			executionFlag = true
		}catch(Exception e){
			println e
		}
		return executionFlag
	}

	public def executeRoomDescriptionReferenceData(String sheetName){
		boolean executionFlag = false
		try{
			TextCreateEditDeleteTest test = new TextCreateEditDeleteTest(ConfigProperties.getVlaue("driverSheetPath"),ConfigProperties.getVlaue("dataSheetPath"),sheetName)
			if(sheetName.equalsIgnoreCase("CB-3597-Create")){
				test.executeDataScriptForCreate()
			}else if(sheetName.equalsIgnoreCase("CB-3597-Edit")){
				test.executeDataScriptForEdit()
			}else{
				test.executeDataScriptForDelete()
			}
			executionFlag = true
		}catch(Exception e){
			println e
		}
		return executionFlag
	}

}
