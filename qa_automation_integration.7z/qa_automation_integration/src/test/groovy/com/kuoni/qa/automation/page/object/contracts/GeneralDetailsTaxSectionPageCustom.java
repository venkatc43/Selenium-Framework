package com.kuoni.qa.automation.page.object.contracts;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.gta.travel.page.base.GSPageBase;
import com.mediaocean.qa.framework.selenium.ui.controls.Button;
import com.mediaocean.qa.framework.selenium.ui.controls.ComboBox;
import com.mediaocean.qa.framework.selenium.ui.controls.Link;
import com.mediaocean.qa.framework.selenium.ui.controls.RadioButton;
import com.mediaocean.qa.framework.selenium.ui.controls.Table;
import com.mediaocean.qa.framework.selenium.ui.controls.TextBox;

public class GeneralDetailsTaxSectionPageCustom extends GSPageBase{

	public GeneralDetailsTaxSectionPageCustom(){
		super(getDriver());
	}
	
	public boolean isCancelled(){
		return !isElementPresent(By.id("tax-isInclusiveYes"));
	}
	
	public static GeneralDetailsTaxSectionPageCustom getInstance(){
		return PageFactory.initElements(getDriver(), GeneralDetailsTaxSectionPageCustom.class);
	}
	
	public boolean verifyModifiedData(Map<String, String> inputMap){
		Table table = new Table(By.id("taxTable"));
		List<WebElement> rowList = table.getRowElements();
		for (WebElement row : rowList){
			List<WebElement> colList = table.getColumnElements(row);
			String colValue = colList.get(0).getText();
			if (inputMap.containsKey(colValue)){
				String value = inputMap.get(colList.get(0).getText());
				if (colValue != value){
					return false;
				}
				
			}
		}
		return true;
	}
	
	public boolean verifyRecordUpdatedMessage(By parentLocator, String message){
		waitForElement(By.className("message"));
		WebElement parentEl = waitForElement(parentLocator);
		sleep(1);
		if (getElement(parentEl, By.className("message")).getText().contains(message)){
			return true;
		}
		return false;
	}
	
	public boolean isMessageDisplayed(){
		return isElementPresent(By.className("message"));
	}
	
	public int getTaxTableRowCount(){
		sleep();
		WebElement parentEl = waitForElement(By.id("tax_list"));
		Table table = new Table(parentEl, 1);
		return table.getRowCount()-1;
	}
	
	public boolean selectTax(Map<String, String> inputMap){
		WebElement parentEl = waitForElement(By.id("tax_list"));
		Table table = new Table(parentEl, 1);
		for (int i=1;i<table.getRowCount();i++){
			for (String key : inputMap.keySet()){
				String value = inputMap.get(key);
				if (value.trim().equalsIgnoreCase(table.getCellData(i, key).trim())){
					table.getCell(i, "Tax Type").click();
					return true;
				}
			}
			
		}
		return false;
	}
	

	public boolean hasTax(Map<String, String> inputMap){
		WebElement parentEl = waitForElement(By.id("tax_list"));
		Table table = new Table(parentEl, 1);
		for (int i=1;i<table.getRowCount();i++){
			for (String key : inputMap.keySet()){
				String value = inputMap.get(key);
				if (value.trim().equalsIgnoreCase(table.getCellData(i, key).trim())){
					return true;
				}
			}
		}
		return false;
	}
	/**
	 * This method deletes all the Tax records
	 */
	public void resetData(){
		deleteAllTaxes();
	}
	
	private void deleteAllTaxes(){
		int count = getTaxTableRowCount();
		int recordsCannotBeDeletedCount = 1;
		while(count >= recordsCannotBeDeletedCount){
			WebElement parentEl = waitForElement(By.id("tax_list"));
			Table table = new Table(parentEl, 1);
			table.getCell(recordsCannotBeDeletedCount, "Tax Type").click();
			waitForElement(By.id("tax_tr"),20);
			
			WebElement menuElement = waitForElement(By.id("taxContentMenuOptions"));
			waitForElement(menuElement, By.linkText("Select Option"));
			Link slectOptionLink = new Link(menuElement,"Select Option");
			slectOptionLink.clickLink();
			menuElement = waitForElement(By.id("taxContentMenuOptions"));
			waitForElement(menuElement, By.linkText("Delete"), 5);
			if (getElementIfItIsPresent(menuElement, By.linkText("Delete")) != null){
				Link optionLink = new Link(menuElement, "Delete");
				optionLink.clickLink();
				deleteTaxWithOK();
			}else{
				recordsCannotBeDeletedCount++;
			}
			count = getTaxTableRowCount();
		}
	}
	
	/**
	 * This method selects the tax radio button based on the value passed
	 * @param value
	 */
	public void clickYesInTax(String value) {
		
		if (value.equalsIgnoreCase("true")){
			sleep(2);
			RadioButton taxRB = new RadioButton(By.id("tax-isInclusiveYes"), "true");
			if (!taxRB.isSelected())
				taxRB.select();
		}else{
			RadioButton taxRB = new RadioButton(By.id("tax-isInclusiveNo"), "false");
			if (!taxRB.isSelected())
				taxRB.select();
		}
	}
	
	public void deleteTaxWithOK(){
		acceptAlert();
		sleep(2);
	}
	public void deleteTaxWithCancel(){
		dismissAlert();
		sleep(2);
	}
	
	public void selectTaxOptions(String optionName){
		sleep(1);
		WebElement menuElement = waitForElement(By.id("taxContentMenuOptions"));
		if (Link.isLinkVisible(menuElement,"Select Option")){
			Link slectOptionLink = new Link(menuElement,"Select Option");
			slectOptionLink.clickLink();
		}

		waitForElement(By.linkText(optionName));
		Link optionLink = new Link(menuElement, optionName);
		optionLink.clickLink();
		sleep(1);
		
		if (optionName.equalsIgnoreCase("Create")){
			waitForElement(By.id("taxCreateCancel"));
		}
		if (optionName.equalsIgnoreCase("Edit")){
			waitForElement(By.id("taxEdit"));
		}
	}
	
	public void createTax(Map<String, String> inputMap){
		
		
		if (inputMap.containsKey("is tax included")){
			String value = inputMap.get("is tax included");
			String rbId = "";
			if (value.equals("true")){
				rbId = "tax-isInclusiveYes";
			}else{
				rbId = "tax-isInclusiveNo";
			}
			RadioButton isTaxIncRB = new RadioButton(By.id(rbId));
			isTaxIncRB.select();
		}
		if (inputMap.containsKey("tax type")){
			
			ComboBox taxTypeCB = new ComboBox(By.id("tax-typeId"));
			taxTypeCB.select(inputMap.get("tax type"));
		}

		if (inputMap.containsKey("base tax applies")){
			String value = inputMap.get("base tax applies");
			String baseTaxAppId = "";
			if (value.equals("true")){
				baseTaxAppId = "crt-tax-sup-baseAppliesYes";
			}else{
				baseTaxAppId = "crt-tax-sup-baseAppliesNo";
			}
			RadioButton baseTaxAppRB = new RadioButton(By.id(baseTaxAppId));
			baseTaxAppRB.select();
		}

		
		
		if (inputMap.containsKey("tax is")){
			String value = inputMap.get("tax is");
			String taxIsRBId = "";
			if (value.equals("Total")){
				taxIsRBId = "crt-tax-ctr-isCumulativeNo";
			}else{
				taxIsRBId = "crt-tax-ctr-isCumulativeYes";
			}
			RadioButton taxIsRB = new RadioButton(By.id(taxIsRBId));
			taxIsRB.select();
		}
		
		if (inputMap.containsKey("amount for supplement room")){
			TextBox amountTB = new TextBox(By.id("crt-tax-sup-tax1"));
			amountTB.setText(inputMap.get("amount for supplement room"));
		}
		
		if (inputMap.containsKey("amount")){
			TextBox amountTB = new TextBox(By.id("crt-tax-ctr-tax1"));
			amountTB.setText(inputMap.get("amount"));
		}

		if (inputMap.containsKey("tax2")){
			TextBox tax2TB = new TextBox(By.id("tax2"));
			tax2TB.setText(inputMap.get("tax2"));
		}
		if (inputMap.containsKey("tax3")){
			TextBox tax3TB = new TextBox(By.id("tax3"));
			tax3TB.setText(inputMap.get("tax3"));
		}
		if (inputMap.containsKey("tax4")){
			TextBox tax4TB = new TextBox(By.id("tax4"));
			tax4TB.setText(inputMap.get("tax4"));
		}
			
		if (inputMap.containsKey("travel start day")){
			ComboBox startDayCB = new ComboBox(By.id("crt-tax-ctr-startDate_day"));
			startDayCB.select(inputMap.get("travel start day"));
		}
		if (inputMap.containsKey("travel start month")){
			ComboBox startMonthCB = new ComboBox(By.id("crt-tax-ctr-startDate_months"));
			startMonthCB.select(inputMap.get("travel start month"));
		}
		if (inputMap.containsKey("travel start year")){
			ComboBox startYearCB = new ComboBox(By.id("crt-tax-ctr-startDate_years"));
			startYearCB.select(inputMap.get("travel start year"));
		}
		if (inputMap.containsKey("travel end day")){
			ComboBox endDayCB = new ComboBox(By.id("crt-tax-ctr-endDate_day"));
			endDayCB.select(inputMap.get("travel end day"));
		}
		if (inputMap.containsKey("travel end month")){
			ComboBox endMonthCB = new ComboBox(By.id("crt-tax-ctr-endDate_months"));
			endMonthCB.select(inputMap.get("travel end month"));
		}
		if (inputMap.containsKey("travel end year")){
			ComboBox endYearCB = new ComboBox(By.id("crt-tax-ctr-endDate_years"));
			endYearCB.select(inputMap.get("travel end year"));
		}
	}
	
	public void cancelCreateTax(){
		WebElement parentElement = waitForElement(By.id("tax_create"));
		Button cancelButton = new Button(parentElement, "Cancel");
		cancelButton.click();
		sleep(1);
	}
	
	public void saveCreateTax(){
		WebElement parentElement = waitForElement(By.id("tax_create"));
		Button saveButton = new Button(parentElement, "Save");
		saveButton.click();
		sleep();
	}
	
	public void editTax(Map<String, String> inputMap){

		if (inputMap.containsKey("tax type")){
			ComboBox taxTypeCB = new ComboBox(By.id("tax-typeId"));
			taxTypeCB.select(inputMap.get("tax type"));
		}

		if (inputMap.containsKey("base tax applies")){
			String value = inputMap.get("base tax applies");
			String baseTaxAppId = "";
			if (value.equals("true")){
				baseTaxAppId = "upd-tax-sup-baseAppliesYes";
			}else{
				baseTaxAppId = "upd-tax-sup-baseAppliesNo";
			}
			waitForElement(By.id(baseTaxAppId));
			RadioButton baseTaxAppRB = new RadioButton(By.id(baseTaxAppId));
			baseTaxAppRB.select();
			sleep(1);
		}

		if (inputMap.containsKey("tax is")){
			String value = inputMap.get("tax is");
			String taxIsRBId = "";
			if (value.equals("Total")){
				taxIsRBId = "upd-tax-ctr-isCumulativeNo";
			}else{
				taxIsRBId = "upd-tax-ctr-isCumulativeYes";
			}
			RadioButton taxIsRB = new RadioButton(By.id(taxIsRBId));
			taxIsRB.select();
		}

		if (inputMap.containsKey("amount for supplement room")){
			TextBox amountTB = new TextBox(By.id("upd-tax-sup-tax1"));
			amountTB.setText(inputMap.get("amount for supplement room"));
		}
		
		if (inputMap.containsKey("amount")){
			TextBox amountTB = new TextBox(By.id("upd-tax-ctr-tax1"));
			amountTB.setText(inputMap.get("amount"));
		}

		if (inputMap.containsKey("tax2")){
			TextBox tax2TB = new TextBox(By.id("tax2"));
			tax2TB.setText(inputMap.get("tax2"));
		}
		if (inputMap.containsKey("tax3")){
			TextBox tax3TB = new TextBox(By.id("tax3"));
			tax3TB.setText(inputMap.get("tax3"));
		}
		if (inputMap.containsKey("tax4")){
			TextBox tax4TB = new TextBox(By.id("tax4"));
			tax4TB.setText(inputMap.get("tax4"));
		}
		
		if (inputMap.containsKey("travel start day")){
			ComboBox startDayCB = new ComboBox(By.id("upd-tax-ctr-startDate_day"));
			startDayCB.select(inputMap.get("travel start day"));
		}
		if (inputMap.containsKey("travel start month")){
			ComboBox startMonthCB = new ComboBox(By.id("upd-tax-ctr-startDate_months"));
			startMonthCB.select(inputMap.get("travel start month"));
		}
		if (inputMap.containsKey("travel start year")){
			ComboBox startYearCB = new ComboBox(By.id("upd-tax-ctr-startDate_years"));
			startYearCB.select(inputMap.get("travel start year"));
		}
		if (inputMap.containsKey("travel end day")){
			ComboBox endDayCB = new ComboBox(By.id("upd-tax-ctr-endDate_day"));
			endDayCB.select(inputMap.get("travel end day"));
		}
		if (inputMap.containsKey("travel end month")){
			ComboBox endMonthCB = new ComboBox(By.id("upd-tax-ctr-endDate_months"));
			endMonthCB.select(inputMap.get("travel end month"));
		}
		if (inputMap.containsKey("travel end year")){
			ComboBox endYearCB = new ComboBox(By.id("upd-tax-ctr-endDate_years"));
			endYearCB.select(inputMap.get("travel end year"));
		}
		
	}
	
	public void cancelEditTax(){
		WebElement parentElement = waitForElement(By.id("tax_list"));
		Button cancelButton = new Button(parentElement, "Cancel");
		cancelButton.click();
		sleep();
	}
	
	public void updateTax(){
		WebElement parentElement = waitForElement(By.id("tax_list"));
		Button updateButton = new Button(parentElement, "Update");
		updateButton.click();
		sleep();
	}
	
	public void searchHistory(Map<String, String> inputMap){
		if (inputMap.containsKey("history day")){
			ComboBox endYearCB = new ComboBox(By.id("taxHistoricalDate_day"));
			endYearCB.select(inputMap.get("history day"));
		}
		if (inputMap.containsKey("history month")){
			ComboBox endYearCB = new ComboBox(By.id("taxHistoricalDate_months"));
			endYearCB.select(inputMap.get("history month"));
		}
		if (inputMap.containsKey("history year")){
			ComboBox endYearCB = new ComboBox(By.id("taxHistoricalDate_years"));
			endYearCB.select(inputMap.get("history year"));
		}
	}
	
	public void goSearch(){
		Button goButton = new Button(By.id("taxSearch"));
		goButton.click();
		sleep(2);
	}
	
	public void cancelSearch(){
		WebElement parentElement = waitForElement(By.id("tax_history"));
		Button updateButton = new Button(parentElement, "Cancel");
		updateButton.click();
		sleep(1);
	}	
	
	public void deleteTaxAndOK(){
		acceptAlert();
	}
	
	public void deleteTaxAndCancel(){
		dismissAlert();
	}

	public boolean sortOnTaxType(){
		return sort(0, "String");
	}
	
	public boolean sortOnTravelDates(){
		return sort(3, "Date");
	}

	private boolean sort(int colNum, String objectType){

		boolean result = true;

		WebElement tableDivEl = waitForElement(By.id("tax_list"));
		WebElement chainEl = getElements(tableDivEl,By.tagName("th")).get(colNum);
		getElement(chainEl,By.tagName("a")).click();
		
		sleep(2);
		
		// Need to load the below objects again as the above click() funtion reload the div element.
		tableDivEl = waitForElement(By.id("tax_list"));
		chainEl = getElements(tableDivEl,By.tagName("th")).get(colNum);
		String href = getElement(chainEl,By.tagName("a")).getAttribute("href");
		String sortOrder = "asc";
		
		if (href.contains("=desc")){
			sortOrder = "desc";
		}
		
		result = verifySortOrder(sortOrder, tableDivEl,colNum, objectType);
		if (result){
		
			getElement(chainEl,By.tagName("a")).click();
			
			sleep(2);
			
			// Need to load the below objects again as the above click() funtion reload the div element.
			tableDivEl = waitForElement(By.id("tax_list"));
			chainEl = getElements(tableDivEl,By.tagName("th")).get(colNum);
			href = getElement(chainEl,By.tagName("a")).getAttribute("href");
			sortOrder = "asc";
			
			if (href.contains("order=desc")){
				sortOrder = "desc";
			}
			result = verifySortOrder(sortOrder, tableDivEl, colNum, objectType);
		}
		return result;
	}	
	private boolean verifySortOrder(String sortOrder, WebElement tableDivEl, int colNum, String objectType){
		boolean result = true;
		List<WebElement> trList = getTableRowsListFromDiv(tableDivEl);
		String prevValue = null;
		String currentValue = null;
		for (int i=1;i<trList.size();i++){
			WebElement tr = trList.get(i);
			List<WebElement> tdList = getElements(tr,By.tagName("td"));
			if (i==1){
				currentValue = tdList.get(colNum).getText();
			}else{
				prevValue = currentValue;
				currentValue = tdList.get(colNum).getText();
				if (sortOrder.equals("asc")){
					if (objectType.equals("String") && prevValue.compareToIgnoreCase(currentValue)<0){
						result = false;
						break;
					}else if (objectType.equals("Date")){
						if (!compareSortOrderOnDateObjects(prevValue, currentValue, sortOrder)){
							result = false;
							break;
						}
					}
				}else{
					if (objectType.equals("String") && currentValue.compareToIgnoreCase(prevValue)<0){
						result = false;
						break;
					}else if (objectType.equals("Date")){
						if (!compareSortOrderOnDateObjects(prevValue, currentValue, sortOrder)){
							result = false;
							break;
						}
					}
				}
			}
		}
		return result;
	}	
	private boolean compareSortOrderOnDateObjects(String prevValue, String currentValue, String sortOrder){
		String prevDateStr = prevValue.split("-")[0];
		String currentDateStr = currentValue.split("-")[0];
		
		String prevDateStrFormat = prevDateStr.substring(0,2) + "-" + prevDateStr.substring(2,5) + "-" + prevDateStr.substring(5);
		String currentDateStrFormat = currentDateStr.substring(0,2) + "-" + currentDateStr.substring(2,5) + "-" + currentDateStr.substring(5);
		
		SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yy");
		try {
			Date prevDateObj = format.parse(prevDateStrFormat);
			Date currentDateObj = format.parse(currentDateStrFormat);
			
			if (sortOrder.equals("asc")){
				if (prevDateObj.compareTo(currentDateObj)<0){
					return false;
				}
			}else{
				if (currentDateObj.compareTo(prevDateObj)<0){
					return false;
				}
			}
		} catch (ParseException e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
//	public boolean verifyHistoryRecordsWithDate(int expectedTotalCount, String date, String month, String year){
	public boolean verifyHistoryRecordsWithDate(String date, String month, String year){

		WebElement resultsDivEl = null;
		try{
			resultsDivEl = waitForElement(By.id("tax_list"));
		}catch(Exception e){
			return false;
		}
		List<WebElement> trList = getTableRowsListFromDiv(resultsDivEl);
//		int actualTotalCount = 0;
//		if (trList != null && trList.size() > 0){
//			actualTotalCount = trList.size();
//		}
//		if (actualTotalCount != expectedTotalCount){
//			return false;
//		}
		
		for (int i=0;i<trList.size();i++){
			WebElement tr = trList.get(i);
			WebElement dateTdEl = getElements(tr,By.tagName("td")).get(2);
			String validityDate = getElementText(dateTdEl);
			if (validityDate == null || validityDate.equals("")){
				continue;
			}
			String[] hisDatesArray = validityDate.split("-");
			String hisStartDate = hisDatesArray[0];
			String hisDate = hisStartDate.substring(0, 2);
			String hisMonth = hisStartDate.substring(2,5);
			String hisYear = hisStartDate.substring(5);
			
			Date hisDateObj = formatDate(hisDate,hisMonth,hisYear);
			Date searchDateObj = formatDate(date,month,year);
			
			if (hisDateObj.compareTo(searchDateObj) <0){
				return false;
			}
		}
		return true;
	}
	
	private Date formatDate(String date, String month, String year){
		SimpleDateFormat format = new SimpleDateFormat("dd-MMM-yy");
		Date dateObj = null;;
		try {
			dateObj = format.parse(date+ "-" +month+ "-" + year);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return dateObj;
	}	
	
	
	
}
