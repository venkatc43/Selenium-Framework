package com.kuoni.qa.automation.helper

import javax.xml.bind.JAXBContext
import javax.xml.bind.JAXBElement
import javax.xml.bind.Unmarshaller

import com.kuoni.atg.jaxbclasses.ChangerecordsType
import com.kuoni.atg.jaxbclasses.RecordsetType

class JaxbHelper {
	
	public ChangerecordsType buildRequestJaxbClass(File xmlFile) throws Exception{
		ChangerecordsType xmlObject = null;
		try{
			JAXBContext jaxbContext = JAXBContext.newInstance(ChangerecordsType.class);
			Unmarshaller unmarshaller =	jaxbContext.createUnmarshaller();
			JAXBElement  jaxbElement =  unmarshaller.unmarshal(xmlFile);
			xmlObject = (ChangerecordsType) jaxbElement.getValue()
//			request = (ChangerecordsType)unmarshaller.unmarshal(new File(filePath));
		}catch(Exception e){
			throw e;
		}
		return xmlObject;
	}


	
}
