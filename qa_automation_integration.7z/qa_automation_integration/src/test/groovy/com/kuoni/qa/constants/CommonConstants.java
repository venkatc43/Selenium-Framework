package com.kuoni.qa.constants;

import org.openqa.selenium.WebDriver;

public class CommonConstants {

	public static WebDriver webDriver = null;
}
