package com.kuoni.qa.automation.util

import com.kuoni.qa.automation.common.util.ExcelHelper

class TestUtil {
	
	static def getExcelRowList(def fileName){
		def excelDataFile = 	new ExcelHelper(System.getProperty("user.dir")
			+ fileName)
		def dataRows = []
		println excelDataFile.rowCount()
		//for (int row = 1; row<excelDataFile.rowCount(); row++){
		for(row in 1..excelDataFile.rowCount()-1){
			if (excelDataFile.getCellValue(row ,1)=="yes"){
				dataRows<< row 
			}
		}
		println dataRows
		return dataRows
	}

}
