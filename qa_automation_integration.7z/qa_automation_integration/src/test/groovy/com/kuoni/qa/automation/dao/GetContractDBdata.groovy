package com.kuoni.qa.automation.dao

import com.kuoni.qa.automation.dto.ContractDTO
import java.sql.Connection
import java.sql.ResultSet
import java.sql.Statement

class GetContractDBdata {
	GetDatabaseConn db = new GetDatabaseConn()
	ContractDTO data =null

	def ContractDTO getContractData(contractId) {
		data = new ContractDTO()
		Connection conn
		conn=db.getDBconnection()
		Statement statement = null
		ResultSet rs = null
		def count =0

		try{

			statement = conn.createStatement()
			String sql = "SELECT COUNT(0) COUNT FROM FIT_CONTRACT"
			rs = statement.executeQuery(sql)
			if(rs.next())
				count=	rs.getInt("COUNT")

			if(count>0) {
				sql = """SELECT 
			 			(SELECT count(0) from FIT_CONTRACT ctr,FIT_CONTRACT_CHANNELS chnl where ctr.PROPERTY_CONTRACT_GROUP_ID = chnl.PROPERTY_CONTRACT_GROUP_ID and ctr.Id= """+"'" +contractId+"'" + """) CHCOUNT,
						 (SELECT count(0) from FIT_CONTRACT ctr,FIT_CONTRACT_RESTRICTIONS res where ctr.PROPERTY_CONTRACT_GROUP_ID = res.PROPERTY_CONTRACT_GROUP_ID and ctr.Id= """+"'" +contractId+"'" + """) RSTCOUNT,
						 (SELECT count(0) from FIT_CONTRACT ctr,FIT_CONTRACT_EXCL_COUNTRIES cntry where ctr.PROPERTY_CONTRACT_GROUP_ID = cntry.PROPERTY_CONTRACT_GROUP_ID and ctr.Id= """+"'" +contractId+"'" + """) CNTYCOUNT,
						 (SELECT count(0) FROM FIT_CONTRACT a, FIT_CONTRACT_CANCELLATIONS b, FIT_CANCELLATION c WHERE a.PROPERTY_CONTRACT_GROUP_ID=b.PROPERTY_CONTRACT_GROUP_ID AND b.CONTRACT_CANCELLATION_ID=c.ID 	AND a.ID = """+"'" +contractId+"'" + """) CANCELCOUNT,
			 			ctr.CONTRACT_TYPE,
			 			atr.MODEL,
			 			atr.STATUS,
			 			atr.PROVIDER_ID,
			 			atr.PROPERTY_ID,
			 			atr.ON_SALE,
			 			atr.ALLOW_ON_REQUEST,
			 			atr.PROVIDER_VALID_FROM,
			 			lgcy.PROPERTY_CODE legacyPropertyCode,
			 			city.CODE legacyCityCode
			 			FROM FIT_CONTRACT ctr,FIT_PROPERTY_CONTRACT_ATTRIB atr,FIT_DCS_PRODUCT pdt,FIT_LEGACY_PROPERTY lgcy,FIT_CITY city
			 		
			 		WHERE ctr.PROPERTY_CONTRACT_ATTRIB_ID = atr.PROPERTY_CONTRACT_ATTRIB_ID (+)  
			 		--atr.LEGACY_PROPERTY=pdt.EXTERNAL_REFERENCE_ID (+) and--
			 		--atr.LEGACY_PROPERTY = lgcy.PROPERTY_CODE (+) and 
			 		--lgcy.CITY = city.CODE (+)     
			 		and ctr.ID = """+"'" +contractId+"'" + "and rownum =1"

				rs = statement.executeQuery(sql)
				while (rs.next()) {
					data.setAllowOnRequest(rs.getString("ALLOW_ON_REQUEST"))
					data.setContractModel(rs.getString("MODEL"))
					data.setContractType(rs.getString("CONTRACT_TYPE"))
					data.setContractStatus(rs.getString("STATUS"))
					data.setOnSale(rs.getString("ON_SALE"))
					data.setValidFrom(rs.getString("PROVIDER_VALID_FROM").substring(0, 10))
					data.setLegacyPropertyCode(rs.getString("legacyPropertyCode"))
					data.setLegacyCityCode(rs.getString("legacyCityCode"))
					data.setPropertyId(rs.getInt("PROPERTY_ID"))
					data.setProviderId(rs.getInt("PROVIDER_ID"))
					data.setChannelCount(rs.getInt("CHCOUNT"))
					data.setRestrictionCount(rs.getInt("RSTCOUNT"))
					data.setCountryCount(rs.getInt("CNTYCOUNT"))
					data.setCancelCount(rs.getInt("CANCELCOUNT"))
				}

				return data
			}
		}
		catch (Exception e1) {
			e1.printStackTrace()
		}

		finally {
			rs.close()
			statement.close()
			conn.close()
		}
	}


	//Restrictions
	def ContractDTO getContractRestrictionsData(contractId,restrictionId)
	{
		Connection conn
		conn=db.getDBconnection()
		Statement statement = null
		ResultSet rs = null
		data = new ContractDTO()
		try{

			statement = conn.createStatement()

			String	 sql = """SELECT res1.RESTRICTION_TYPE,
			 		res1.TRAVEL_START,
					res1.TRAVEL_END,
					res1.DAYS_PRIOR
					FROM FIT_CONTRACT ctr,
					FIT_RESTRICTION res1,
					FIT_CONTRACT_RESTRICTIONS res2
					WHERE ctr.PROPERTY_CONTRACT_GROUP_ID = res2.PROPERTY_CONTRACT_GROUP_ID
					AND res2.RESTRICTION_ID     = res1.ID
					AND res1.RESTRICTION_ID     = """+"'"+restrictionId+"'"+"""
					AND ctr.Id                          = """+"'" +contractId+"'"


			rs = statement.executeQuery(sql)
			while (rs.next())
			{
				data.setRestrictionStart(rs.getString("TRAVEL_START").substring(0, 10))
				data.setRestrictionEnd(rs.getString("TRAVEL_END"))
				//have to include substring when data is loaded for END_DATE
				data.setRestrictionType(rs.getString("RESTRICTION_TYPE"))
				data.setRestrictionDaysPrior(rs.getString("DAYS_PRIOR"))
			}

			return data
		}



		catch (Exception e1)
		{
			e1.printStackTrace()
		}

		finally {
			rs.close()
			statement.close()
			conn.close()

		}

	}


	//Cancellations
	def getContractCancellationsData(contractId,cancellationId)
	{
		Connection conn
		conn=db.getDBconnection()
		Statement statement = null
		ResultSet rs = null

		try{

			statement = conn.createStatement()
			
			String	sql = """SELECT c.CANCELLATION_TYPE,
				   c.TRAVEL_START,
				   c.TRAVEL_END,
				   c.CANCEL_TIME,
				   c.DAYS_PRIOR,
				   c.CHARGES,
           
				   c.DURATION
				
				FROM FIT_CONTRACT a,
				  FIT_CONTRACT_CANCELLATIONS b,
				  FIT_CANCELLATION c

				WHERE a.PROPERTY_CONTRACT_GROUP_ID=b.PROPERTY_CONTRACT_GROUP_ID
				AND b.CONTRACT_CANCELLATION_ID=c.ID
				AND a.ID = """+"'" +contractId+"'"+"""
				AND c.ID = """+"'"+ cancellationId +"'" + "and ROWNUM=1"

				
				rs = statement.executeQuery(sql)
				while (rs.next())
				{
					data.setCancellationType(rs.getString("CANCELLATION_TYPE"))
					data.setCancelStart((rs.getString("TRAVEL_START")).substring(0, 10))
					
					if((rs.getString("TRAVEL_END"))!= null)
					{
					data.setCancelTime((rs.getString("TRAVEL_END")).substring(0, 10))
					}
					
					data.setCancelDaysPrior(rs.getString("DAYS_PRIOR"))
					data.setCancelchargePercentage(rs.getDouble("CHARGES"))
					data.setCancelDuration(rs.getString("DURATION"))
					data.setCancelTime(rs.getString("CANCEL_TIME"))

				}

				return data
		}
		catch (Exception e1)
		{
			e1.printStackTrace()
		}

		finally {
			rs.close()
			statement.close()
			conn.close()

		}
	}


	//RatePlans
	def getContractRatePlansData()
	{
		Connection conn
		conn=db.getDBconnection()
		Statement statement = null
		ResultSet rs = null

		try{

			statement = conn.createStatement()
			String sql = "select * from FIT_RATEPLAN"
			rs = statement.executeQuery(sql)
			if(rs.next())
				def count=	rs.getInt("COUNT")

			if(count>0)
			{
				sql = "select a.RESTRICTION_TYPE,a.START_DATE,a.END_DATE,a.DAYS_PRIOR from FIT_CONTRACT_RESTRICTIN a, FIT_CONTRACT_RESTRICTIONS b where a.contract_restriction_id = b.property_Contract_group_id"
				rs = statement.executeQuery(sql)
				while (rs.next())
				{
					data.setRestrictionStart(rs.getString("START_DATE"))
					data.setRestrictionEnd(rs.getString("END_DATE"))
					data.setRestrictionType(rs.getString("RESTRICTION_TYPE"))
					data.setRestrictionDaysPrior(rs.getString("DAYS_PRIOR"))
				}

				return data
			}


		}
		catch (Exception e1)
		{
			e1.printStackTrace()
		}

		finally {
			rs.close()
			statement.close()
			conn.close()

		}
	}


	//ExcludedCountries
	def getContractCountries(contractId)
	{
		Connection conn
		conn=db.getDBconnection()
		Statement statement = null
		ResultSet rs = null
		List countries = new ArrayList()

		try{

			statement = conn.createStatement()

			String sql = """SELECT chnl.CONTRACT_CHANNEL CODE from FIT_CONTRACT ctr,FIT_CONTRACT_CHANNELS chnl
			 		where ctr.PROPERTY_CONTRACT_GROUP_ID = chnl.PROPERTY_CONTRACT_GROUP_ID and ctr.Id= """+"'" +contractId+"'"
			rs = statement.executeQuery(sql)
			while (rs.next())
			{


				data = new ContractDTO()
				data.setCountryCode(rs.getString("CODE"))
				countries.add(data)

			}

			return countries
		}



		catch (Exception e1)
		{
			e1.printStackTrace()
		}

		finally {
			rs.close()
			statement.close()
			conn.close()

		}
	}



	//Channels
	def List getContractChannels(contractId)
	{
		Connection conn
		conn=db.getDBconnection()
		Statement statement = null
		ResultSet rs = null
		List channels = new ArrayList()

		try{

			statement = conn.createStatement()

			String sql = """SELECT chnl.CONTRACT_CHANNEL CODE from FIT_CONTRACT ctr,FIT_CONTRACT_CHANNELS chnl
			 		where ctr.PROPERTY_CONTRACT_GROUP_ID = chnl.PROPERTY_CONTRACT_GROUP_ID and ctr.Id= """+"'" +contractId+"'"
			rs = statement.executeQuery(sql)
			while (rs.next())
			{


				data = new ContractDTO()
				data.setChannelCode(rs.getString("CODE"))
				channels.add(data)

			}

			return channels
		}



		catch (Exception e1)
		{
			e1.printStackTrace()
		}

		finally {
			rs.close()
			statement.close()
			conn.close()

		}
	}

}
