package com.kuoni.qa.automation.util

import com.kuoni.qa.automation.common.properties.EnvironmentProperties

class ReadFilesUtil {

	static def List getFiles(String folderPath) {
		println "Folder for xml files : " +folderPath
		EnvironmentProperties envprop = new EnvironmentProperties()
		String fileLoc = envprop.getValueForProperty("jenkinsTestDataLoc")+folderPath
		println "Files location : " + fileLoc
		File folder = new File(fileLoc)
//		return Arrays.asList(folder.listFiles)
		println "Number of Files to Test: " + folder.listFiles().size()
		return folder.listFiles()
	}
}
