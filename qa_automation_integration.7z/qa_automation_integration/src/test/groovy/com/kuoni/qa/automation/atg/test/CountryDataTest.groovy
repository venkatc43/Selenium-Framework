package com.kuoni.qa.automation.atg.test

import static com.kuoni.qa.automation.util.ReadFilesUtil.getFiles

import org.testng.asserts.SoftAssert
import static com.kuoni.qa.automation.util.GetCoherenceObject.*
import spock.lang.Shared;
import spock.lang.Specification
import spock.lang.Unroll

import com.gta.nova.country.model.Country
import com.kuoni.qa.automation.common.properties.EnvironmentProperties
import com.kuoni.qa.automation.dao.GetCountryDBdata
import com.kuoni.qa.automation.dto.CountryDTO
import com.kuoni.qa.automation.spock.annotation.Regression
import com.kuoni.qa.automation.util.PerformDataLoadUtil

class CountryDataTest extends Specification{


	@Shared
	EnvironmentProperties envProp = new EnvironmentProperties()

	def setupSpec() {

		def folderLocation = envProp.getValueForProperty("istDataLoc")+"/Country"
		PerformDataLoadUtil dataLoad = new PerformDataLoadUtil()
		dataLoad.changeTestDataReaderLocation(folderLocation)
		dataLoad.importFilesandPerformLoadfromQueue()
		dataLoad.incrementalPushtoCoherence()
	}

	@Regression
	@Unroll
	def "VerifyCountryXmldata for : #fileEntry.getName()"() {

		given: "XML Test Data for Country is available at the appropriate Location"

		SoftAssert softAssert = new SoftAssert()
		Set countryCount = new HashSet()
		CountryDTO dbData = null
		EnvironmentProperties envProp = new EnvironmentProperties()

		when: "Country xml files are according to the XSD agreed and accesible by the tests"

		//URL url = CountryDataTest.class.getClass().getResource("/Country")

		def countryXml = new XmlParser().parse(fileEntry)
		def cy = countryXml.recordset.record.country

		//println "XML Validation with XSD is: "+ XmlUtil.validateXMLSchema(xsdFile,xmlFile)

		def countryId = cy.@countryId[0].toInteger()
		def countryCode = cy.@code[0]
		def countryDesc = cy.countryDescriptions.countryDescription[0].text.text()
		def countryDefaultCrncy = cy.defaultPaymentCurrency.text()
		def zoneDesc = cy.countryDescriptions.countryDescription[0].text.text()
		def zoneCode=cy.zoneCode.text()

		//adding countryId to "set" to count the number of countries
		countryCount.add(countryId)
		GetCountryDBdata data = new GetCountryDBdata()

		//get the databse values for the country Id
		dbData = data.getCountrydata(countryId)

		println "\n" + "Verifying Data for Country : " + fileEntry.getName() + "\n"
		//validate the xml values with the Database
		softAssert.assertEquals(countryCode, dbData.getCountryCode(),"\n"+"countryCode " + countryCode + " : Doesnt Match with dataBase :" + dbData.getCountryCode()+" In file :"+ fileEntry)
		println "Xml countryCode :" + countryCode + ": DataBase countryCode :" + dbData.getCountryCode() +":"

		softAssert.assertEquals(countryDefaultCrncy, dbData.getCountryDefaultCrncy(),"\n"+"countryDefaultCrncy " + countryDefaultCrncy + " : Doesnt Match with dataBase :" + dbData.getCountryDefaultCrncy()+" In file :"+fileEntry)
		println "Xml DefaultPaymentCurrency  :" + countryDefaultCrncy + ": DataBase countryDefault Currency :" + dbData.getCountryDefaultCrncy()+":"

		softAssert.assertEquals(zoneCode, dbData.getZoneCode(),"\n"+"zoneCode " + zoneCode + " : Doesnt Match with dataBase :" + dbData.getZoneCode() +" In file :"+ fileEntry)
		println "Xml zoneCode  :" + zoneCode + ": DataBase ZoneCode :" + dbData.getZoneCode()+":"

		softAssert.assertEquals(zoneDesc, dbData.getZoneDesc(),"\n"+"countryDesc " + zoneDesc + " : Doesnt Match with dataBase :" + dbData.getZoneDesc() +" In file :"+ fileEntry)
		println "Xml countryDesc  :" + zoneDesc + ": DataBase countryDesc :" + dbData.getZoneDesc()+":"

		
		
		//validate xml with Coherence Cache
		
				Country country = verifyCoherenceCountryDetails(countryId)
				println "\n ***Coherence Validation*** \n"
				softAssert.assertEquals(countryCode,country.getCountryCode(), "Xml Data Country Code doesn't match with Coherence Data")
				println "Xml CountryCode :" + countryCode + ": " + "Coherence CountryCode : " + country.getCountryCode()
				
				softAssert.assertEquals(zoneCode,country.getZoneCode(), "Xml Data Zone Code doesn't match with Coherence Data")
				println "Xml ZoneCode :" + zoneCode + ": " + "Coherence ZoneCode : " + country.getZoneCode()
				
				softAssert.assertAll()
				then: "The XML Data for Country should Match with the Database"
				println "\n" + "***Test complete***"

		where:
		fileEntry << getFiles("/Country")
	}
}
