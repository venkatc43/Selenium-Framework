package com.kuoni.qa.util

import groovy.sql.Sql
import groovy.util.slurpersupport.Node

import javax.xml.XMLConstants
import javax.xml.transform.stream.StreamSource
import javax.xml.validation.Schema
import javax.xml.validation.SchemaFactory
import javax.xml.validation.Validator

import org.xml.sax.SAXException

import com.mediaocean.qa.framework.utils.ExcelUtil

class CommonUtil {

	public static def DBConfig

	public static def readXMLFromQ(String filePath, String inputQName, String messageIdentifier){
		boolean executionFlag = false
		File file = null
		String message = null
		boolean messageIdentifierFalg = false
		HornetQUtil hornetQUtil = null
		while(!messageIdentifierFalg){
			hornetQUtil = HornetQUtil.getInstance()
			message  = hornetQUtil.subscribeMessage(inputQName)
			if(message != null){
				messageIdentifierFalg = message.contains(messageIdentifier)
			}else{
				break
			}
		}
		println "---------------------------------------------------------------------"
		println ""
		println message
		println ""
		println "---------------------------------------------------------------------"
		if(message != null){
			file  = new File(filePath).write(message)
			executionFlag = true
		}
		return executionFlag
	}
	
	public def readcdmOutputXMLFromOutputQ(String filePath, String outputQName){
		boolean executionFlag = false
		File file = null
		String message = null
		HornetQUtil hornetQUtil = HornetQUtil.getInstance()
		message  = hornetQUtil.subscribeMessage(outputQName)
		file  = new File(filePath).write(message)
		executionFlag = true
		return executionFlag
	}

	public def parseXml(groovy.util.slurpersupport.Node contentrecords, String k, String v){

		contentrecords.childNodes().each { child ->

			if(child.name.equalsIgnoreCase(k)){

				def value = child.text()
				assert value.equalsIgnoreCase(v), "data is not maching"
				if(value.equalsIgnoreCase(v)){
					println "inputData: " +value  + ' & '  + " outputData: " + v  + "   " + " both match "
				}
			}
			parseXml(child, k, v)
		}
	}

	public def parseXmlBoolVals(groovy.util.slurpersupport.Node contentrecords, String k, String v){
		def match = true
		contentrecords.childNodes().each { child ->

			if(child.name.equalsIgnoreCase(k)){

				def val = v.tokenize(',')

				child.attributes().each{ it ->
					println it.key +"==" + it.value
					for(e in 0 .. val.size()-1) {
						if(it.key == val[e]){
							if(it.value != "true"){
								match = false
							}
						}
					}
				}
				//}
				if(match)
					println "Data match......"
				else
					println "Data don't match......."
			}

			parseXmlBoolVals(child, k, v)
		}
	}

	public def parseXmlforENUMs(groovy.util.slurpersupport.Node contentrecords, String k, String v){
		boolean match
		contentrecords.childNodes().each { child ->

			if(child.name.equalsIgnoreCase(k)){

				def value = child.text()
				if(v.equalsIgnoreCase("french") && value.equalsIgnoreCase("fr")){
					match = true
				}
				if(v.equalsIgnoreCase("english") && value.equalsIgnoreCase("en")){
					match = true
				}
				assert match, "data is not maching"
				if(match){
					println "inputData: " +value  + ' & '  + " outputData: " + v  + "   " + " both match "
				}
			}
			parseXmlforENUMs(child, k, v)
		}
	}

	public def parseXmlAttributeMulti(groovy.util.slurpersupport.Node contentrecords, List k, String v){

		contentrecords.childNodes().each { child ->
			child.attributes()
			child.attributes().each{ it ->
				it.key +"==" + it.value
				if(it.key.equalsIgnoreCase(k[1])){
					if(child.name().equalsIgnoreCase(k[0])){
						def value = it.value
						assert value.equalsIgnoreCase(v), "data is not maching"
						if(value.equalsIgnoreCase(v)){
							println value + ' & ' + v + " both match "
						}
					}
				}
			}
			parseXmlAttributeMulti(child, k, v)
		}
	}

	public def parseXmlAttributeSameTag(groovy.util.slurpersupport.Node contentrecords, List k, List v){

		contentrecords.childNodes().each { child ->
			child.attributes()
			child.attributes().each{ it ->
				it.key +"==" + it.value
				if(it.key.equalsIgnoreCase(k[1])){
					if(child.name().equalsIgnoreCase(k[0])){
						def value = it.value
						for(e in 0 .. v.size()-1){

							if(v[e].equalsIgnoreCase(value)){
								println v[e] + ' & ' + value + " both match "
								assert v[e].equalsIgnoreCase(value), "data is not maching"
							}
							continue
						}
					}
				}
			}
			parseXmlAttributeSameTag(child, k, v)
		}
	}

	public def parseXmlAttribute(groovy.util.slurpersupport.Node contentrecords, String k, String v){

		contentrecords.childNodes().each { child ->
			child.attributes()
			child.attributes().each{ it ->
				it.key +"==" + it.value
				if(it.key.equalsIgnoreCase(k)){

					def value = it.value
					assert value.equalsIgnoreCase(v), "data is not maching"
					if(value.equalsIgnoreCase(v)){
						println value + ' & ' + v + " both match "
					}
				}
			}
			parseXmlAttribute(child, k, v)
		}
	}

	public def validateXmlFileWithXlsValues(Map<String, String> data, String xmlPath){
		def xmlFile = new File(xmlPath)
		def contentrecords = new XmlSlurper().parse(xmlFile)
		data.each{ k, v ->
			println "${k}:${v}"
			def key = k.value.toString()
			def value = v.value.toString()
			contentrecords.childNodes().each { child ->
				child.name
				parseXml(child, key, value)
			}
		}
	}

	public def validateXmlFileWithXlsValuesEnums(Map<String, String> data, String xmlPath){
		def xmlFile = new File(xmlPath)
		def contentrecords = new XmlSlurper().parse(xmlFile)
		data.each{ k, v ->
			println "${k}:${v}"
			def key = k.value.toString()
			def value = v.value.toString()
			contentrecords.childNodes().each { child ->
				child.name
				parseXmlforENUMs(child, key, value)
			}
		}
	}

	public def validateXmlFileWithXlsValuesAttrs(Map<String, String> data, String xmlPath){
		def xmlFile = new File(xmlPath)
		def contentrecords = new XmlSlurper().parse(xmlFile)
		data.each{ k, v ->
			println "${k}:${v}"
			def key = k.value.toString()
			def value = v.value.toString()
			contentrecords.childNodes().each { child ->
				parseXmlAttribute(child, key, value)
			}
		}
	}

	public def validateXmlFileWithXlsValuesAttrsMultiTag(Map<String, String> data, String xmlPath){
		def xmlFile = new File(xmlPath)
		def contentrecords = new XmlSlurper().parse(xmlFile)
		data.each{ k, v ->
			println "${k}:${v}"
			def key = k.value.toString().tokenize(',')
			def value = v.value.toString()
			contentrecords.childNodes().each { child ->
				parseXmlAttributeMulti(child, key, value)
			}
		}
	}

	public def validateXmlFileWithXlsValuesAttrsSameTag(Map<String, List> data, String xmlPath){
		def xmlFile = new File(xmlPath)
		def contentrecords = new XmlSlurper().parse(xmlFile)
		data.each{ k, v ->
			println "${k}:${v}"
			def key = k.value.toString().tokenize(',')

			//def value = v.value.toString()

			contentrecords.childNodes().each { child ->
				parseXmlAttributeSameTag(child, key, v)
			}
		}
	}

	public def validateXmlFileWithXlsChBxBoolVals(Map<String, String> data, String xmlPath){
		def xmlFile = new File(xmlPath)
		def contentrecords = new XmlSlurper().parse(xmlFile)
		data.each{ k, v ->
			println "${k}:${v}"
			def key = k.value.toString()
			def value = v.value.toString()
			contentrecords.childNodes().each { child ->
				child.name
				parseXmlBoolVals(child, key, value)
			}
		}
	}

	public static def  boolean validateCanonicalXML(String xsdFilePath, String  xmlPath){

		try {
			def xsdFile = new File(xsdFilePath)
			def xmlFile = new File(xmlPath)
			SchemaFactory factory =
					SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI)
			Schema schema = factory.newSchema(xsdFile)
			Validator validator = schema.newValidator()
			validator.validate(new StreamSource(xmlFile))
		}
		catch (IOException | SAXException e) {
			System.out.println("Exception: "+ e.getMessage())
			return false
		}
		return true
	}

	public def validateWithDBValues(String query, String  colName){

		def data1 = executeDBQuery(query, colName)
		def data= data1.toString()
		return data
	}

	public def executeDBQuery(String query, String colName){

		readDBProperties()
		def value
		def sql = Sql.newInstance(DBConfig.url, DBConfig.username, DBConfig.password, DBConfig.driver)
		try {
			sql.eachRow(query){  row ->
				println row
				value = row.getAt(colName)


			}
		} finally {
			sql.close()
		}
		return value
	}

	def static readDBProperties(){

		def java.util.Properties props = new Properties()

		File propsFile = new File("src//test//resources//DataBase.properties")
		props.load(propsFile.newDataInputStream())
		DBConfig = new ConfigSlurper().parse(props)

	}
}



