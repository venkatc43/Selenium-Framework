package com.kuoni.qa.automation.datacreate.test.helper

import groovy.util.slurpersupport.Node

import javax.xml.XMLConstants
import javax.xml.transform.stream.StreamSource
import javax.xml.validation.Schema
import javax.xml.validation.SchemaFactory
import javax.xml.validation.Validator

import org.xml.sax.SAXException

import com.kuoni.qa.automation.gc.test.PropertyRoomsCreateEditDeleteTest
import com.kuoni.qa.util.CommonUtil
import com.kuoni.qa.util.ConfigProperties
import com.kuoni.qa.util.HornetQUtil
import com.mediaocean.qa.framework.utils.ExcelUtil

class PropertyRoomsTestHelper {
	
	private ExcelUtil excelData 
	
	public def editPropertyRoomFacilities(String sheetName){
		boolean executionFlag = false
		try{
			PropertyRoomsCreateEditDeleteTest test = new PropertyRoomsCreateEditDeleteTest(ConfigProperties.getVlaue("driverSheetPath"),ConfigProperties.getVlaue("dataSheetPathSprint4"),sheetName)
			excelData = test.getData()
			test.executeDataScriptsForEditRoomFacilities()
			executionFlag = true
		}catch(Exception e){
			println e
		}
		return executionFlag
	}
	
	public def validateCreatePropertyRoomInputXML(){
		boolean executionFlag = false
		try{
			def xmlFile = new File(ConfigProperties.getVlaue("propertyRoomDescriptionInputXMLPathForCreate"))
			def contentrecords = new XmlParser().parse(xmlFile)
			def record = contentrecords.recordset.record[0]
			executionFlag = true
		}catch(Exception e){
			println e
		}
		return executionFlag
	}
	
	public def validateEditPropertyRoomInputXML(){
		boolean executionFlag = false
		try{
			def xmlFile = new File(ConfigProperties.getVlaue("propertyRoomDescriptionInputXMLPathForEdit"))
			def contentrecords = new XmlParser().parse(xmlFile)
			def record = contentrecords.recordset.record[0]
			executionFlag = true
		}catch(Exception e){
			println e
		}
		return executionFlag
	}
	
	public def validateDeletePropertyRoomInputXML(){
		boolean executionFlag = false
		try{
			def xmlFile = new File(ConfigProperties.getVlaue("propertyRoomDescriptionInputXMLPathForDelete"))
			def contentrecords = new XmlParser().parse(xmlFile)
			def record = contentrecords.recordset.record[0]
			executionFlag = true
		}catch(Exception e){
			println e
		}
		return executionFlag
	}
	
	public def readInputXMLFromInputQ(String filePath, String inputQName){
		boolean executionFlag = false
		File file = null
		String message = null;
		HornetQUtil hornetQUtil = HornetQUtil.getInstance()
		message  = hornetQUtil.subscribeMessage(inputQName)
		file  = new File(filePath).write(message)
		executionFlag = true
		return executionFlag
	}
	
	public def readcdmOutputXMLFromOutputQ(String filePath, String outputQName){
		boolean executionFlag = false
		File file = null
		String message = null
		HornetQUtil hornetQUtil = HornetQUtil.getInstance()
		message  = hornetQUtil.subscribeMessage(outputQName)
		file  = new File(filePath).write(message)
		executionFlag = true
		return executionFlag
 }
	
	public def  boolean validateCanonicalXML(String xsdFilePath, String  xmlPath){
		
				try {
					def xsdFile = new File(xsdFilePath)
					def xmlFile = new File(xmlPath)
					SchemaFactory factory =
							SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI)
					Schema schema = factory.newSchema(xsdFile)
					Validator validator = schema.newValidator()
					validator.validate(new StreamSource(xmlFile))
				}
				catch (IOException | SAXException e) {
					System.out.println("Exception: "+ e.getMessage())
					return false
				}
				return true
			}
		
	public def parseXmlAttribute(groovy.util.slurpersupport.Node contentrecords, String k, String v){
		
				contentrecords.childNodes().each { child ->
					child.attributes()
					child.attributes().each{ it ->
						it.key +"==" + it.value
						if(it.key.equalsIgnoreCase(k)){
		
							def value = it.value
							assert value.equalsIgnoreCase(v), "data is not maching"
							if(value.equalsIgnoreCase(v)){
								println value + ' & ' + v + " both match "
							}
						}
					}
					parseXmlAttribute(child, k, v)
		
		
				}
			}
	
	public def parseXmlforENUMs(groovy.util.slurpersupport.Node contentrecords, String k, String v){
		boolean match
		contentrecords.childNodes().each { child ->

			if(child.name.equalsIgnoreCase(k)){

				def value = child.text()
				if(v.equalsIgnoreCase("french") && value.equalsIgnoreCase("fr")){
					match = true
				}
				if(v.equalsIgnoreCase("english") && value.equalsIgnoreCase("en")){
					match = true
				}
				if(v.equalsIgnoreCase("false") && value.equalsIgnoreCase("1")){
					match = true
				}
				assert match, "data is not maching"
				if(match){
					println "inputData: " +v  + ' & '  + " outputData: " + value  + "   " + " both match "
				}
			}
			parseXmlforENUMs(child, k, v)

		}
	}
	public def parseXml(groovy.util.slurpersupport.Node contentrecords, String k, String v){
		
				contentrecords.childNodes().each { child ->
		
					if(child.name.equalsIgnoreCase(k)){
		
						def value = child.text()
					/*	String v=new String(str);
						println(v.trim());*/
						assert value.equalsIgnoreCase(v), "data is not maching"
						if(value.equalsIgnoreCase(v)){
							println "inputData: " +value  + ' & '  + " outputData: " + v  + "   " + " both match "
						}
					}
					parseXml(child, k, v)
		
				}
			}
	public def validateXmlFileWithXlsValues(Map<String, String> data, String xmlPath){
		def xmlFile = new File(xmlPath)
		def contentrecords = new XmlSlurper().parse(xmlFile)
		data.each{ k, v ->
			println "${k}:${v}"
			def key = k.value.toString()
			def value = v.value.toString()
			contentrecords.childNodes().each { child ->
				child.name
				parseXml(child, key, value)
			}
		}
	}

	public def validateXmlFileWithXlsValuesEnums(Map<String, String> data, String xmlPath){
		def xmlFile = new File(xmlPath)
		def contentrecords = new XmlSlurper().parse(xmlFile)
		data.each{ k, v ->
			println "${k}:${v}"
			def key = k.value.toString()
			def value = v.value.toString()
			contentrecords.childNodes().each { child ->
				child.name
				parseXmlforENUMs(child, key, value)
			}
		}
	}

	public def validateXmlFileWithXlsValuesAttrs(Map<String, String> data, String xmlPath){
		def xmlFile = new File(xmlPath)
		def contentrecords = new XmlSlurper().parse(xmlFile)
		data.each{ k, v ->
			println "${k}:${v}"
			def key = k.value.toString()
			def value = v.value.toString()
			contentrecords.childNodes().each { child ->
				parseXmlAttribute(child, key, value)
			}
		}
	}
	public def validateRoomDetailsOutputXML(String sheetName,String xmlPath ){
		boolean executionFlag = false
		Map<String, String> data = new HashMap<String,String>()
		Map<String, String> data1 = new HashMap<String,String>()
//		Map<String, String> data2 = new HashMap<String,String>()
		excelData = new ExcelUtil(ConfigProperties.getVlaue("dataSheetPath"))
		try{
			data.put("supplierRoomCode", excelData.getKeyValue(sheetName, "RoomCode"))
//			if(sheetName.equalsIgnoreCase("CB-3597-Create")){
//				data.put("text", excelData.getKeyValue(sheetName, "Text"))
//			}else if(sheetName.equalsIgnoreCase("CB-3597-Edit")){
//				data.put("text", excelData.getKeyValue(sheetName, "TextEdit"))
//			}else{
//				data.put("text", excelData.getKeyValue(sheetName, "Text"))
//			}
			data.put("ROOM_TYPE", excelData.getKeyValue(sheetName, "Room Type"))
			data1.put("extraBed", excelData.getKeyValue(sheetName, "ExtraBeds"))
			//data2.put("code", excelData.getKeyValue(sheetName, "Code"))
			validateXmlFileWithXlsValues(data, xmlPath)
			validateXmlFileWithXlsValuesEnums(data1, xmlPath)
//			validateXmlFileWithXlsValuesAttrs(data2, xmlPath)
			executionFlag = true
		}catch(Exception e){
			println e
		}
		return executionFlag

	}
	
	public def validatePropertyRoomFacilities(String sheetName,String xmlPath ){
		
		boolean executionFlag = false
//		excelData = new ExcelUtil(ConfigProperties.getVlaue("dataSheetPathSprint4"))
		def xmlFile = new File(xmlPath)
		def changerecords = new XmlParser().parse(xmlFile)
		String code = null
		def value = null
		
		try{
			
			value  = changerecords.recordset.record.product.room.facilities.facility.find{it.@code == excelData.getKeyValue(sheetName, "Air Conditioned Code")}
			assert value != null, "Air Conditioned room facility code is not exist in canonical xml"
	
			value  = changerecords.recordset.record.product.room.facilities.facility.find{it.@code == excelData.getKeyValue(sheetName, "CD Player Code")}
			assert value != null, "CD Player room facility code is not exist in canonical xml"
			
			value  = changerecords.recordset.record.product.room.facilities.facility.find{it.@code == excelData.getKeyValue(sheetName, "DVD Code")}
			assert value != null, "DVD room facility code is not exist in canonical xml"
			
			value  = changerecords.recordset.record.product.room.facilities.facility.find{it.@code == excelData.getKeyValue(sheetName, "Hairdryer Code")}
			assert value != null, "Hairdryer room facility code is not exist in canonical xml"
			
			value  = changerecords.recordset.record.product.room.facilities.facility.find{it.@code == excelData.getKeyValue(sheetName, "In-house Film Code")}
			assert value != null, "In-house Film room facility code is not exist in canonical xml"
			
			value  = changerecords.recordset.record.product.room.facilities.facility.find{it.@code == excelData.getKeyValue(sheetName, "Internet Code")}
			assert value != null, "Internet room facility code is not exist in canonical xml"
			
			value  = changerecords.recordset.record.product.room.facilities.facility.find{it.@code == excelData.getKeyValue(sheetName, "Ironing Code")}
			assert value != null, "Ironing room facility code is not exist in canonical xml"
			
			value  = changerecords.recordset.record.product.room.facilities.facility.find{it.@code == excelData.getKeyValue(sheetName, "Kitchenette Code")}
			assert value != null, "Kitchenette room facility code is not exist in canonical xml"
			
			value  = changerecords.recordset.record.product.room.facilities.facility.find{it.@code == excelData.getKeyValue(sheetName, "Laundry Code")}
			assert value != null, "Laundry room facility code is not exist in canonical xml"
			
			value  = changerecords.recordset.record.product.room.facilities.facility.find{it.@code == excelData.getKeyValue(sheetName, "Microwave Code")}
			assert value != null, "Microwave room facility code is not exist in canonical xml"
			
			value  = changerecords.recordset.record.product.room.facilities.facility.find{it.@code == excelData.getKeyValue(sheetName, "Mini Bar Code")}
			assert value != null, "Mini Bar room facility code is not exist in canonical xml"
			
			value  = changerecords.recordset.record.product.room.facilities.facility.find{it.@code == excelData.getKeyValue(sheetName, "Non-Smoking Code")}
			assert value != null, "Non-Smoking room facility code is not exist in canonical xml"
			
			value  = changerecords.recordset.record.product.room.facilities.facility.find{it.@code == excelData.getKeyValue(sheetName, "Safe Code")}
			assert value != null, "Safe room facility code is not exist in canonical xml"
			
			value  = changerecords.recordset.record.product.room.facilities.facility.find{it.@code == excelData.getKeyValue(sheetName, "Satellite TV Code")}
			assert value != null, "Satellite TV room facility code is not exist in canonical xml"
			
			value  = changerecords.recordset.record.product.room.facilities.facility.find{it.@code == excelData.getKeyValue(sheetName, "Smoking Code")}
			assert value != null, "Smoking room facility code is not exist in canonical xml"
			
			value  = changerecords.recordset.record.product.room.facilities.facility.find{it.@code == excelData.getKeyValue(sheetName, "Tea & Coffee Making Facilities Code")}
			assert value != null, "Tea & Coffee Making Facilities room facility code is not exist in canonical xml"
			
			value  = changerecords.recordset.record.product.room.facilities.facility.find{it.@code == excelData.getKeyValue(sheetName, "Television Code")}
			assert value != null, "Television room facility code is not exist in canonical xml"
			
			value  = changerecords.recordset.record.product.room.facilities.facility.find{it.@code == excelData.getKeyValue(sheetName, "Washing Machine Code")}
			assert value != null, "Washing Machine room facility code is not exist in canonical xml"
			
			executionFlag = true
		}catch(java.lang.AssertionError e){
			println e
			executionFlag = false
		}catch(Exception e){
			println e
			executionFlag = false
		}
		excelData = null
		changerecords = null
		return executionFlag
	}
	
	public def readXMLFromQ(String filePath, String inputQName, String sheetName){
		boolean executionFlag = false
		def value = null
		String propertyId = excelData.getKeyValue(sheetName, "PropertyId")
		executionFlag = CommonUtil.readXMLFromQ(filePath,inputQName, propertyId)
		return executionFlag
	}
}
