package com.kuoni.qa.automation.util
import com.gta.nova.coherence.property.model.Property
import com.gta.nova.coherence.property.model.Room
import com.tangosol.net.CacheFactory
import com.tangosol.net.NamedCache
import com.gta.nova.city.model.City
import com.gta.nova.common.CompositeBiPartIdentifier
import com.gta.nova.condition.model.CancellationCondition
import com.gta.nova.country.model.Country
import com.gta.nova.propertycontract.model.PropertyContract
import com.gta.nova.rateplan.model.RatePlan
import com.gta.nova.restrictionpolicy.model.RestrictionPolicy
import com.gta.nova.roomsupplement.model.RoomSupplement
import com.gta.nova.tax.model.Tax

class GetCoherenceObject {

	def static Room getCohPropertyRoomDetails (String propertyIdCoh,int roomId) {

		Property cProperty1 = (Property) getCoherenceCache("Property").get(getLongValue(propertyIdCoh))
		Set rooms = new HashSet()
		rooms = cProperty1.getRooms()

		Iterator iterator = rooms.iterator()

		while(iterator.hasNext()) {
			Room room  =   iterator.next()
			if(room.getRoomId()== roomId)
				return room
		}


		return cProperty1
	}

	def static Long getLongValue(String id) {
		Long longValue = Long.parseLong(id)
		return longValue
	}

	def  static City getCoherenceCityDetails (String cityId) {

		City city = (City) getCoherenceCache("City").get(getLongValue(cityId))

		return city
	}

	def static Tax getCoherenceTaxDetails(String contractid,String taxId) {
		Tax tax = (Tax) getCoherenceCache("Tax").get(getCompositeKey(contractid, taxId))
		return tax
	}

	def static RoomSupplement getCoherenceRoomSuppDetails(String contractid,String roomSuppId) {

		RoomSupplement roomSupplement = (RoomSupplement) getCoherenceCache("RoomSupplement").get(getCompositeKey(contractid, roomSuppId))
		return roomSupplement
	}

	def static CompositeBiPartIdentifier getCompositeKey(String id1, String id2) {
		CompositeBiPartIdentifier<Long, Long> compositeKey = new CompositeBiPartIdentifier<>(getLongValue(id1), getLongValue(id2))
		return compositeKey
	}





	def static PropertyContract verifyCoherenceContractsandRateplans(def contractId) {
		PropertyContract propertyContract = (PropertyContract) getCoherenceCache("PropertyContract").get(getLongValue(contractId))

		return propertyContract
	}

	def static RatePlan verifyCoherenceRateplans(def contractId, def rateplanId) {
		PropertyContract propertyContract = (PropertyContract) getCoherenceCache("PropertyContract").get(getLongValue(contractId))

		Set rateplanSet = new HashSet()
		rateplanSet = propertyContract.getRatePlans()
		Iterator itr = rateplanSet.iterator()
		while(itr.hasNext()) {
			RatePlan rateplan = itr.next()
			if (rateplan.getIdentifier()==getLongValue(rateplanId)) {
				return rateplan
			}
		}

		return propertyContract
	}

	def static NamedCache getCoherenceCache(String cacheName) {
		NamedCache coherenceCache = CacheFactory.getCache(cacheName)
		return coherenceCache
	}


	def static Country verifyCoherenceCountryDetails(def countryId) {
		Long cohCountryId = countryId.longValue()
		Country country = (Country) getCoherenceCache("Country").get(cohCountryId)

		return country
	}

	def static CancellationCondition verifyCoherenceCancelConditions(def contractId,def cancelId) {
		CancellationCondition cancellationCondition = (CancellationCondition) getCoherenceCache("Condition").get(getCompositeKey(contractId, cancelId))

		return cancellationCondition
	}
	
	def static RestrictionPolicy verifyCoherenceRestrictions(contractId,restrictionId) {
		RestrictionPolicy restrictionPolicy = (RestrictionPolicy) getCoherenceCache("RestrictionPolicy").get(getCompositeKey(contractId, restrictionId))

		return restrictionPolicy
	}
}
