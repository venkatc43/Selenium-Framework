package com.kuoni.qa.automation.dao

import com.kuoni.qa.automation.dto.RegionDTO;


import java.sql.Connection
import java.sql.ResultSet
import java.sql.Statement

class GetRegionDBdata {
	
	GetDatabaseConn db 		
	
		def RegionDTO getRegiondata(String regionId) {
	
			db = new GetDatabaseConn()
			Connection conn = db.getDBconnection()
			RegionDTO data = null
			ResultSet rs = null
	
			try {
				data = new RegionDTO()
				Statement statement = conn.createStatement()
				String sql = "select reg.CODE, reg.DESCRIPTION,country.COUNTRY_ID from FIT_REGION reg, FIT_COUNTRY country where reg.region_ID ="+ regionId+"and reg.COUNTRY_ID = country.country_ID"
	
				rs = statement.executeQuery(sql);
	
				while(rs.next()) {
	
					data.setRegionCode(rs.getString("CODE"))
					data.setRegionDesc(rs.getString("DESCRIPTION"))
					data.setCountryId(rs.getInt("COUNTRY_ID"))
				}
			} catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
	
			finally{
	
				rs.close();
				conn.close();
			}
			return data
		}

}
