package com.kuoni.qa.util

import java.io.File

class HornetQUtil {




  //def  providerURL = "jnp://localhost:1099";
  //def  connectionFactoryJNDIName = "/ConnectionFactory";
  def  receiveWait = 1000;
  def context
  //def  clientID = "jms_client";
  def  cf, conn, session

  private static HornetQUtil  hornetQUtil = null
  public static def QConfig

  private def  HornetQUtil(){
    readConfig()
    def props = new java.util.Properties();

    props.put(javax.naming.Context.INITIAL_CONTEXT_FACTORY,
        "org.jnp.interfaces.NamingContextFactory");
    props.put(javax.naming.Context.URL_PKG_PREFIXES,"org.jboss.naming:org.jnp.interfaces");
    props.put(javax.naming.Context.PROVIDER_URL, QConfig.providerURL);
    context = new javax.naming.InitialContext(props);
    cf = context.lookup(QConfig.connectionFactoryJNDIName);
    conn = cf.createConnection();
    conn.setClientID(QConfig.clientID);
    session = conn.createSession(false, javax.jms.Session.AUTO_ACKNOWLEDGE);

  }

  def static readConfig(){

    def java.util.Properties props = new Properties();

    File propsFile = new File("src//test//resources//JNDI.properties")
    props.load(propsFile.newDataInputStream())
    QConfig = new ConfigSlurper().parse(props)

  }

  def public static getInstance()
  {
    /*if (hornetQUtil == null)
     {*/
    hornetQUtil = new HornetQUtil()
    //}


  }


  def publishMessage(String queueName, File f){

    String fileContents = f.text
    try {
      def destination = context.lookup(queueName);
      def producer = session.createProducer(destination);
      producer.send(session.createTextMessage(fileContents));
      producer.close();

    }

    finally {
      try {
        //conn.close();
      } catch (Exception e) {
        println("Error in the InputXML"+e )
      }
    }
  }

  def subscribeMessage(String queueName){

    try{
      conn.start();
      def destination = context.lookup(queueName);
      def consumer = session.createConsumer(destination);
      def Qmessage = consumer.receive(receiveWait);
      consumer.close();
      session.close();
      if (Qmessage == null)
      {
        println("There are no messages in the output queue")

      }
      else
      {
        def xml = Qmessage.getText();
        return xml;
      }
    } finally {
      try {
        conn.close();
      } catch (Exception e1)   {
        println("Error while invoking the InputXML:"+e1 )
      }
    }


  }
}
