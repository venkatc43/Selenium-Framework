package com.kuoni.qa.automation.atg.test;

import org.testng.asserts.SoftAssert

import spock.lang.Shared;
import spock.lang.Specification
import spock.lang.Unroll
import static com.kuoni.qa.automation.util.ReadFilesUtil.getFiles

import com.kuoni.atg.jaxbclasses.ChangerecordsType
import com.kuoni.atg.jaxbclasses.DescriptionType
import com.kuoni.atg.jaxbclasses.OfferDescriptionsRecord
import com.kuoni.qa.automation.common.properties.EnvironmentProperties;
import com.kuoni.qa.automation.dao.GetReferenceDataDescription
import com.kuoni.qa.automation.dto.ReferenceDataDTO
import com.kuoni.qa.automation.helper.JaxbHelper
import com.kuoni.qa.automation.spock.annotation.Regression
import com.kuoni.qa.automation.util.PerformDataLoadUtil

public class VerifyOfferDescriptionRefData_CB6590 extends Specification {

	SoftAssert softAssert = new SoftAssert()
	GetReferenceDataDescription offerDesc = new GetReferenceDataDescription()

	@Shared
	EnvironmentProperties envProp = new EnvironmentProperties()

	def setupSpec() {

		def folderLocation = envProp.getValueForProperty("istDataLoc")+"/OfferDescriptionsRecord"
		PerformDataLoadUtil dataLoad = new PerformDataLoadUtil()
		dataLoad.changeTestDataReaderLocation(folderLocation)
		dataLoad.importFilesandPerformLoadfromQueue()
	}
	@Regression
	@Unroll
	public "verifyReferenceData for : #xmlFile.getName()"() {

		given: "The XmLs are available at the desired Location"
		ReferenceDataDTO data
		JaxbHelper jaxbObj = new JaxbHelper()

		ChangerecordsType xml = jaxbObj.buildRequestJaxbClass(xmlFile)

		OfferDescriptionsRecord recordNode = xml.recordset.get(0).record.get(0)

		String offerCode = recordNode.getOfferDescriptions().getAt("code")

		List<DescriptionType> offerDescList =  recordNode.getOfferDescriptions().getOfferDescription()


		println "\n xml File : " + xmlFile.getName()
		println "Code : " + offerCode
		int languageCount = recordNode.getOfferDescriptions().getOfferDescription().size()
		println "Xml Language Count :  " + languageCount
		when:"The data can be read from XML and Database"

		for(DescriptionType offerDescriptionsType: offerDescList) {
			String language = offerDescriptionsType.getLanguage().value()
			String offerDescription = offerDescriptionsType.getText()
			data = offerDesc.getOfferDesc(offerCode,language,316)

			if(languageCount == data.getLanguageCount()) {
				println "\n Language::" + language + "::"
				println "xmlOfferDesc :  " + offerDescription
				println "\n Database Desc : " +  data.getDataDescription()

				softAssert.assertEquals(offerDescription,data.getDataDescription(),"OfferDescription :"+offerDescription+" Doesnot Match with Database :"+data.getDataDescription())
			}

			else
				softAssert.assertEquals(languageCount,data.getLanguageCount(),"The Language count doesn't match with Database")
		}

		softAssert.assertAll()
		then:"The XML Descriptions should match with Database"

		where:

		xmlFile << getFiles("/OfferDescriptionsRecord")
	}
}
