package com.kuoni.qa.automation.datacreate.test.helper

import org.openqa.selenium.WebDriver

import org.openqa.selenium.WebElement
import org.openqa.selenium.By
import org.testng.asserts.SoftAssert;
import com.kuoni.qa.util.ConfigProperties
import com.kuoni.qa.automation.dao.GetPropertyDBdata;
import com.kuoni.qa.automation.dto.PropertyDTO
import com.kuoni.qa.automation.gc.test.PropertyContractTest
import com.mediaocean.qa.framework.utils.ExcelUtil;
import com.kuoni.qa.constants.CommonConstants;

class PropertyContractsTestHelper {
	
	
	private ExcelUtil excelData
	GetPropertyDBdata properyDBdata = null
	SoftAssert softAssert =  new SoftAssert()
	
	
	
	public def static main(def args)
	{
		PropertyContractsTestHelper  propertyContractsTestHelper = new PropertyContractsTestHelper();
//		propertyContractsTestHelper.updateContractRsp("CB-6627-RSP_update");
		println "hello"
	}

	public def updateContractRsp(String sheetName){
		boolean executionFlag = false
		PropertyContractTest test = new PropertyContractTest(ConfigProperties.getVlaue("driverSheetPath"),ConfigProperties.getVlaue("dataSheetPathSprintR3S2"),sheetName)
		excelData = test.getData()
		test.executeDataScriptsForUpdateContractRSP()
		executionFlag = true
		return executionFlag
	}
	
	
	
	//Create a Contract Tax
	public def createContractTax(String sheetName){
		boolean executionFlag = false
		PropertyContractTest test = new PropertyContractTest(ConfigProperties.getVlaue("driverSheetPath"),ConfigProperties.getVlaue("DataSheet_R3S2"),sheetName)
		excelData = test.getData()
		test.executeDataScriptsForcreateContractTax()
		executionFlag = true
		return executionFlag
	}
	
	
		
	
	// Load data using DynAdmin
	
	public def loadDataintoAtg()
	{
		boolean executionFlag = false
		WebDriver driver = CommonConstants.webDriver;
		driver.get("http://admin:weblogic1@longwlg05a.emea.kuoni.int:8180/dyn/admin/nucleus/fit/commerce/catalog/loader/CatalogImportManager/?shouldInvokeMethod=performDataLoad");
		WebElement loadButton = driver.findElement(By.name("submit"));
		loadButton.click();
		executionFlag = true
		return executionFlag
		

	}
	
	public def verifyContractRSPdetails(String sheetName)
	{
		boolean executionFlag = false
		properyDBdata = new GetPropertyDBdata();
		int propertyId = Integer.parseInt(excelData.getKeyValue(sheetName,"PropertyId"))
		PropertyDTO dbData =  properyDBdata.getPropertyData(propertyId)
		

		softAssert.assertEquals(dbData.getTelephone(),excelData.getKeyValue(sheetName,"Telephone Number"),"Telephone Number Doesnt match with Database")
		println "GC Telephone Number : " + excelData.getKeyValue(sheetName, "Telephone Number") + "::" + "Database Value : " + dbData.getTelephone()
		
		/*softAssert.assertEquals((dbData.getWebsite()),Integer.parseInt(excelData.getKeyValue(sheetName,"website")),"Website Doesnt Match with Database")
		println "GC Website  : " + excelData.getKeyValue(sheetName, "website") + "::" + "Database Value : " + dbData.getWebsite()*/
		
		
		softAssert.assertAll()
		executionFlag = true
		return executionFlag
	}

}
