package com.kuoni.qa.automation.atg.test

import org.testng.asserts.SoftAssert;

import spock.lang.Shared;
import spock.lang.Specification
import spock.lang.Unroll;
import static com.kuoni.qa.automation.util.ReadFilesUtil.getFiles

import com.kuoni.atg.jaxbclasses.ChangerecordsType
import com.kuoni.atg.jaxbclasses.DescriptionType
import com.kuoni.atg.jaxbclasses.ErrataTypeDescriptionsRecord
import com.kuoni.qa.automation.common.properties.EnvironmentProperties;
import com.kuoni.qa.automation.dao.GetReferenceDataDescription;
import com.kuoni.qa.automation.dto.ReferenceDataDTO
import com.kuoni.qa.automation.helper.JaxbHelper
import com.kuoni.qa.automation.spock.annotation.Regression;
import com.kuoni.qa.automation.util.PerformDataLoadUtil

class VerifyErrataTypeDescRefData_CB6592 extends Specification {

	SoftAssert softAssert = new SoftAssert()
	GetReferenceDataDescription offerDesc = new GetReferenceDataDescription()

	@Shared
	EnvironmentProperties envProp = new EnvironmentProperties()

	def setupSpec() {

		def folderLocation = envProp.getValueForProperty("istDataLoc")+"/ErrataTypeDescriptionsRecord"
		PerformDataLoadUtil dataLoad = new PerformDataLoadUtil()
		dataLoad.changeTestDataReaderLocation(folderLocation)
		dataLoad.importFilesandPerformLoadfromQueue()
	}

	@Regression
	@Unroll
	public "verifyReferenceData for : #xmlFile.getName()"() {

		given: "The XmLs are available at the desired Location"
		ReferenceDataDTO data
		JaxbHelper jaxbObj = new JaxbHelper()

		ChangerecordsType xml = jaxbObj.buildRequestJaxbClass(xmlFile)

		ErrataTypeDescriptionsRecord recordNode = xml.recordset.get(0).record.get(0)

		String errataTypeCode = recordNode.getErrataTypeDescriptions().getAt("type")

		List<DescriptionType> erratTypeDescList =  recordNode.getErrataTypeDescriptions().getErrataTypeDescription()


		println "\n xml File : " + xmlFile.getName()
		println "Code : " + errataTypeCode
		int languageCount = recordNode.getErrataTypeDescriptions().getErrataTypeDescription().size()
		println "Xml Language Count :  " + languageCount
		when:"The data can be read from XML and Database"
		for(DescriptionType errataTypeDescriptions: erratTypeDescList) {
			String language = errataTypeDescriptions.getLanguage().value()
			String ErrataTypeDescription = errataTypeDescriptions.getText()
			data = offerDesc.getOfferDesc(errataTypeCode,language,313)

			//println "DB Language Count : " + data.getLanguageCount()
			if(languageCount == data.getLanguageCount())

			{
				println "\n Language::" + language + "::"
				println "xmlErrataTypeDescription :  " + ErrataTypeDescription
				println "\n Database ErratType Desc : " +  data.getDataDescription()

				softAssert.assertEquals(ErrataTypeDescription, data.getDataDescription(),"ErrataTypeDescription : "+ ErrataTypeDescription + "Doesnot Match with Database :"+data.getDataDescription() )

			}

			else
				softAssert.assertEquals(languageCount,data.getLanguageCount(),"The Language count doesn't match with Database")

		}

		softAssert.assertAll()
		then:"The XML Descriptions should match with Database"

		where:

		xmlFile << getFiles("/ErrataTypeDescriptionsRecord")


	}

}
