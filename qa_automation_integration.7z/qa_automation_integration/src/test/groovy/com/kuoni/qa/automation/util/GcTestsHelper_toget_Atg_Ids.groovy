package com.kuoni.qa.automation.util

import com.kuoni.qa.automation.dao.GetDatabaseConn
import java.sql.Connection
import java.sql.ResultSet
import java.sql.Statement

class GcTestsHelper_toget_Atg_Ids {
	
	
	 static def getRpMarginId(def rateplanId)
	{
		GetDatabaseConn dbconn= new GetDatabaseConn()
		Connection conn = dbconn.getDBconnection()
		Statement statement = null
		ResultSet rs = null
		def marginId
		try{
			statement = conn.createStatement()

			String sql = "select margin as MARGINID from FIT_RATE_PLAN where RATE_PLAN_ID =" + rateplanId 

			rs = statement.executeQuery(sql)
			while(rs.next()) {
				marginId = rs.getString("MARGINID")
			}

			
			return marginId
		}catch (Exception e)
		{
			e.printStackTrace()
		}

		finally{

			statement.close()
			rs.close();
			conn.close();

		}
	}
	
	
	static def getContMarginId(def contractId)
	{
		GetDatabaseConn dbconn= new GetDatabaseConn()
		Connection conn = dbconn.getDBconnection()
		Statement statement = null
		ResultSet rs = null
		def marginId
		try{
			statement = conn.createStatement()

			String sql = "select b.margin as MARGINID from FIT_CONTRACT a, FIT_PROPERTY_CONTRACT_GROUP b where a.ID =" + contractId+" and a.PROPERTY_CONTRACT_GROUP_ID=b.PROPERTY_CONTRACT_GROUP_ID"

			rs = statement.executeQuery(sql)
			while(rs.next()) {
				marginId = rs.getString("MARGINID")
			}

			
			return marginId
		}catch (Exception e)
		{
			e.printStackTrace()
		}

		finally{

			statement.close()
			rs.close();
			conn.close();

		}
	}
	
	static def getRpRestrictionId(def rateplanId)
	{
		GetDatabaseConn dbconn= new GetDatabaseConn()
		Connection conn = dbconn.getDBconnection()
		Statement statement = null
		ResultSet rs = null
		def market_restrictionID
		try{
			statement = conn.createStatement()

			String sql = "select MARKET_RESTRICTION_ID from FIT_RATE_PLAN where RATE_PLAN_ID =" + rateplanId

			rs = statement.executeQuery(sql)
			while(rs.next()) {
				market_restrictionID = rs.getString("MARKET_RESTRICTION_ID")
			}

			
			return market_restrictionID
		}catch (Exception e)
		{
			e.printStackTrace()
		}

		finally{

			statement.close()
			rs.close();
			conn.close();

		}
	}
	
	
	static def getRoomSkuId(def roomId)
	{
		GetDatabaseConn dbconn= new GetDatabaseConn()
		Connection conn = dbconn.getDBconnection()
		Statement statement = null
		ResultSet rs = null
		def roomSkuID
		try{
			statement = conn.createStatement()

			String sql = "select ID from FIT_ROOMS where ROOM_ID =" + roomId

			rs = statement.executeQuery(sql)
			while(rs.next()) {
				roomSkuID = rs.getString("ID")
			}

			
			return roomSkuID
		}catch (Exception e)
		{
			e.printStackTrace()
		}

		finally{

			statement.close()
			rs.close();
			conn.close();

		}
	}
		
		
		
	}


