package com.kuoni.qa.automation.page.object.content;

import java.util.List;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.gta.travel.page.base.GSPageBase;
import com.mediaocean.qa.framework.selenium.ui.controls.Button;
import com.mediaocean.qa.framework.selenium.ui.controls.ComboBox;
import com.mediaocean.qa.framework.selenium.ui.controls.Link;
import com.mediaocean.qa.framework.selenium.ui.controls.RadioButton;
import com.mediaocean.qa.framework.selenium.ui.controls.Table;
import com.mediaocean.qa.framework.selenium.ui.controls.TextBox;

public class ProviderDetailsSectionPage extends GSPageBase {

	GSPageBase gsPageBase = new GSPageBase(getDriver());

	/**
	 * Default Constructor
	 */
	public ProviderDetailsSectionPage() {
		super(getDriver());
	}

	public static ProviderDetailsSectionPage getInstance() {
		return PageFactory.initElements(getDriver(),ProviderDetailsSectionPage.class);
	}

	public void selectProviderDetailsOptions(String optionName) {
		WebElement menuElement = waitForElement(By.id("providerContentMenuOptions"));
		waitForElement(menuElement, By.linkText("Select Option"));
		if (Link.isLinkVisible(menuElement, "Select Option")) {
			Link slectOptionLink = new Link(menuElement, "Select Option");
			slectOptionLink.clickLink();
		}

		waitForElement(By.linkText(optionName));
		Link optionLink = new Link(menuElement, optionName);
		optionLink.clickLink();
		if (optionName.equalsIgnoreCase("Create")) {
			waitForElement(By.id("provider_create"));
			WebElement parentElement = waitForElement(By.id("provider_create"));
			waitForElement(parentElement, By.id("providerCreateCancel"));
		}
		if (optionName.equalsIgnoreCase("Refresh")) {
			sleep(3);
		}

		if (optionName.equals("Edit")) {
			waitForElement(By.id("providerUpd-supplierType"), 5);
		}
	}

	public void createProviderDetails(Map<String, String> map) {

		if (map.containsKey("Provider Type")) {
			String providerdetailsTypeValue = map.get("Provider Type");
			waitForElement(By.id("providerCrt-supplierType"));
			ComboBox providerTypeCB = new ComboBox(By.id("providerCrt-supplierType"));
			providerTypeCB.select(providerdetailsTypeValue);
			executeIEFireEventJS("providerCrt-supplierType", "onchange");

		}
		if (map.containsKey("Business Type")) {
			String providerdetailsTypeValue = map.get("Business Type");
			waitForElement(By.id("providerCrt-businessType"));
			ComboBox providerTypeCB = new ComboBox(By.id("providerCrt-businessType"));
			providerTypeCB.select(providerdetailsTypeValue);
			executeIEFireEventJS("providerCrt-businessType", "onchange");

		}

		if (map.containsKey("Provider Name")) {
			String ProviderName = map.get("Provider Name");
			WebElement parentEl = waitForElement(By.id("provider_create"));
			waitForElement(parentEl, By.id("providerCrt-supplier-name-text"));
			String AppProviderName = getElement(parentEl,By.id("providerCrt-supplier-name-text")).getText();
		}

		if (map.containsKey("On Sale")) {
			String onSaleValue = map.get("On Sale");
			if (onSaleValue.equalsIgnoreCase("Yes")) {
				RadioButton onSaleRB = new RadioButton(By.name("onSale"),"true");
				onSaleRB.select();
			} else {
				RadioButton onSaleRB = new RadioButton(By.name("onSale"),"false");
				onSaleRB.select();
			}
		}
		
		if (map.containsKey("Legacy City ID")) {

			TextBox fitReservationTB = new TextBox(By.id("providerCrt-legacyCity"));
			fitReservationTB.setText(map.get("Legacy City ID"));
		}
		
		if (map.containsKey("Legacy Property ID")) {

			TextBox fitReservationTB = new TextBox(By.id("providerCrt-legacyProperty"));
			fitReservationTB.setText(map.get("Legacy Property ID"));
		}
		
		if (map.containsKey("FIT Reservations Via")) {
			TextBox fitReservationTB = new TextBox(By.id("providerCrt-reserveViaFITsupplier-name"));
			fitReservationTB.setText(map.get("FIT Reservations Via"));
		}

		if (map.containsKey("Group Reservations Via")) {

			TextBox groupReservationTB = new TextBox(By.id("providerCrt-reserveViaGroupsupplier-name"));
			groupReservationTB.setText(map.get("Group Reservations Via"));

		}

		if (map.containsKey("Invoice Via")) {

			TextBox invoiceViaTB = new TextBox(By.id("providerCrt-invoiceViasupplier-name"));
			invoiceViaTB.setText(map.get("Invoice Via"));

		}

		if (map.containsKey("FIT Communications")) {
			String fitCommunicationsTypeValue = map.get("FIT Communications");
			sleep(3);
			waitForElement(By.id("providerCrt-commsFIT"));
			ComboBox fitCommunicationsType = new ComboBox(By.id("providerCrt-commsFIT"));
			fitCommunicationsType.select(fitCommunicationsTypeValue);
			executeIEFireEventJS("providerCrt-commsFIT", "onchange");
		}

		if (map.containsKey("Group Communications")) {
			String groupCommunicationsTypeValue = map.get("Group Communications");
			sleep(4);
			waitForElement(By.id("providerCrt-commsGroup"));
			ComboBox groupCommunicationsType = new ComboBox(By.id("providerCrt-commsGroup"));
			groupCommunicationsType.select(groupCommunicationsTypeValue);
			executeIEFireEventJS("providerCrt-commsGroup", "onchange");

		}

	}

	public void clearSearchFields() {

		TextBox fitReservationViaTextBox = new TextBox(By.id("providerCrt-reserveViaFITsupplier-name"));
		fitReservationViaTextBox.setText("");

		TextBox groupReservationsViaTextBox = new TextBox(By.id("providerCrt-reserveViaGroupsupplier-name"));
		groupReservationsViaTextBox.setText("");

		TextBox invoiceViaTextBox = new TextBox(By.id("providerCrt-invoiceViasupplier-name"));
		invoiceViaTextBox.setText("");
	}

	public void clearFITReservationsSearchFields() {

		TextBox fitReservationViaTextBox = new TextBox(By.id("providerUpd-reserveViaFITsupplier-name-td"));
		fitReservationViaTextBox.setText("");

	}

	public boolean savePropertyProvider() {
		WebElement parentElement = waitForElement(By.id("provider_create"));
		Button saveButton = new Button(parentElement, "Save");
		saveButton.click();

		if (waitForElement(By.id("provider_create")) != null) {
			return true;
		}
		return false;

	}

	public boolean cancelProvider() {
		WebElement parentElement = waitForElement(By.id("provider_create"));
		Button cancelButton = new Button(parentElement, "Cancel");
		cancelButton.click();

		if (waitForElement(By.id("providerContent")) != null) {
			return true;
		}
		return false;

	}

	public boolean verifyRecordErrorMessage(By parentLocator, String message) {
		WebElement parentEl = waitForElement(parentLocator);
		waitForElement(parentEl, By.id("providerCrt-expiry-error-msg"));

		if (getElement(parentEl, By.id("providerCrt-expiry-error-msg")).getText().contains(message)) {
			return true;
		}
		return false;
	}

	public boolean verifyDateRecordErrorMessage(String message) {
		WebElement parentEl = waitForElement(By.id("provider_create"), 5);
		sleep(1);
		waitForElement(parentEl, By.id("providerCrt-expiry-error-msg"));
		if (getElement(parentEl, By.id("providerCrt-expiry-error-msg")).getText().contains(message)) {
			return true;
		}
		return false;
	}

	public void selectProviderFromTheList(Map<String, String> map) {
		for (int i = 0; i < 1; i++) {
			try {
				if (selectProvider(map)) {
					break;
				} else {
					sleep(2);
				}
			} catch (Exception e) {
				sleep(2);
				continue;
			}
		}
	}

	private boolean selectProvider(Map<String, String> map) {
		
		WebElement parentElement = waitForElement(By.id("provider_list"), 5);
		Table rpTable = new Table(parentElement, 1);
		for (int i = 1; i < rpTable.getRowCount(); i++) {
			boolean flag = true;
			for (String key : map.keySet()) {
				String value = map.get(key);
				if (rpTable.getCellData(i, key).equalsIgnoreCase(value)) {
					continue;
				} else {
					flag = false;
					break;
				}
			}
			if (flag) {
				sleep(3);
				rpTable.clickOnDataColumn(i, "Provider Type");
				sleep(10);
				WebElement parentEl1 = null;
				try {
					parentEl1 = waitForElement(By.id("provider_tr"), 1);
					WebElement parentEl2 = waitForElement(parentEl1,By.id("provider_div"), 1);
					WebElement parentEl3 = waitForElement(parentEl2,By.className("dialog"), 1);
					waitForElement(parentEl3, By.className("inserted"), 1);
					return true;
				} catch (Exception e) {
					return false;
				}
			}
		}
		return false;
	}

	public void editProviderDetails(Map<String, String> editMap) {

		if (editMap.containsKey("On Sale")) {
			String onSaleValue = editMap.get("On Sale");
			if (onSaleValue.equalsIgnoreCase("No")) {
				RadioButton onSaleRB = new RadioButton(By.name("onSale"),"false");
				onSaleRB.select();
			} else {
				RadioButton onSaleRB = new RadioButton(By.name("onSale"),"true");
				onSaleRB.select();
			}
		}

		if (editMap.containsKey("Allow On Request")) {
			String onRequestValue = editMap.get("Allow On Request");
			if (onRequestValue.equalsIgnoreCase("No")) {
				RadioButton onRequestRB = new RadioButton(By.name("onRequest"),"false");
				onRequestRB.select();
			} else {
				RadioButton onRequestRB = new RadioButton(By.name("onRequest"),"true");
				onRequestRB.select();
			}
		}

		if (editMap.containsKey("Allow Overbooking")) {
			String overBookingValue = editMap.get("Allow Overbooking");
			if (overBookingValue.equalsIgnoreCase("Yes")) {
				RadioButton overBookingRB = new RadioButton(By.name("overbooking"), "true");
				overBookingRB.select();
			} else {
				RadioButton overBookingRB = new RadioButton(By.name("overbooking"), "false");
				overBookingRB.select();
			}
		}

		if (editMap.containsKey("Legacy City ID")) {
			clearAndType(By.id("providerUpd-legacyCity"),editMap.get("Legacy City ID"));
		}
		
		if (editMap.containsKey("Legacy Property ID")) {
			clearAndType(By.id("providerUpd-legacyProperty"),editMap.get("Legacy Property ID"));			
		}
		
		if (editMap.containsKey("FIT Reservations Via")) {

			clearAndType(By.id("providerUpd-reserveViaFITsupplier-name"),editMap.get("FIT Reservations Via"));
		}

		if (editMap.containsKey("Group Communications")) {
			String groupCommunicationsTypeValue = editMap.get("Group Communications");
			waitForElement(By.id("providerUpd-commsGroup"));
			ComboBox groupCommunicationsType = new ComboBox(By.id("providerUpd-commsGroup"));
			groupCommunicationsType.select(groupCommunicationsTypeValue);
			executeIEFireEventJS("providerUpd-commsGroup", "onchange");

		}

	}

	public void updateProviderDetails() {
		WebElement parentEL = waitForElement(By.id("provider_div"));
		Button updateButton = new Button(parentEL, "Update");
		updateButton.click();
		sleep(2);
		waitForInVisibilityOfElement(parentEL,
				By.cssSelector("input[class='gsButton'][value='Update']"), 10);
	}

	public void createSupplierProviderDetails(Map<String, String> map) {
		String ProviderName = null;
		String groupReservation = null;
		String invoice = null;
		String fITReservation = null;
		assertPageContainsText("Gc Autoscript9*Donotchange*");

		if (map.containsKey("Provider Type")) {
			String providerdetailsTypeValue = map.get("Provider Type");
			waitForElement(By.id("providerCrt-supplierType"));
			ComboBox providerTypeCB = new ComboBox(By.id("providerCrt-supplierType"));
			providerTypeCB.select(providerdetailsTypeValue);
			executeIEFireEventJS("providerCrt-supplierType", "onchange");

		}
		if (map.containsKey("Business Type")) {
			String providerdetailsTypeValue = map.get("Business Type");
			waitForElement(By.id("providerCrt-businessType"));
			ComboBox providerTypeCB = new ComboBox(By.id("providerCrt-businessType"));
			providerTypeCB.select(providerdetailsTypeValue);
			executeIEFireEventJS("providerCrt-businessType", "onchange");

		}

		if (map.containsKey("Provider Name")) {
			ProviderName = (map.get("Provider Name"));
			selectValueFromAjaxList("providerCrt-supplier-name",ProviderName.substring(0, 3), "providerCrt-businessType","providerCrt-supplier-choices", ProviderName, ProviderName,0);
		}

		if (map.containsKey("On Sale")) {
			String onSaleValue = map.get("On Sale");
			if (onSaleValue.equalsIgnoreCase("Yes")) {
				RadioButton onSaleRB = new RadioButton(By.name("onSale"),"true");
				onSaleRB.select();
			} else {
				RadioButton onSaleRB = new RadioButton(By.name("onSale"),"false");
				onSaleRB.select();
			}
		}

		if (map.containsKey("Allow On Request")) {
			String onRequestValue = map.get("Allow On Request");
			if (onRequestValue.equalsIgnoreCase("Yes")) {
				RadioButton onRequestRB = new RadioButton(By.name("onRequest"),"true");
				onRequestRB.select();
			} else {
				RadioButton onRequestRB = new RadioButton(By.name("onRequest"),"false");
				onRequestRB.select();
			}
		}

		if (map.containsKey("Allow Overbooking")) {
			String overBookingValue = map.get("Allow Overbooking");
			if (overBookingValue.equalsIgnoreCase("Yes")) {
				RadioButton overBookingRB = new RadioButton(By.name("overbooking"), "true");
				overBookingRB.select();
			} else {
				RadioButton overBookingRB = new RadioButton(By.name("overbooking"), "false");
				overBookingRB.select();
			}
		}

		if (map.containsKey("Group Reservations Via")) {
			groupReservation = (map.get("Group Reservations Via"));
			selectValueFromAjaxList("providerCrt-reserveViaGroupsupplier-name",groupReservation.substring(0, 3),"providerCrt-businessType","providerCrt-reserveViaGroupsupplier-choices",groupReservation, groupReservation, 0);
		}

		if (map.containsKey("FIT Reservations Via")) {
			fITReservation = (map.get("FIT Reservations Via"));
			selectValueFromAjaxList("providerCrt-reserveViaFITsupplier-name",fITReservation.substring(0, 3), "providerCrt-businessType","providerCrt-reserveViaFITsupplier-choices",fITReservation, fITReservation, 0);
		}

		if (map.containsKey("Invoice Via")) {
			invoice = (map.get("Invoice Via"));
			selectValueFromAjaxList("providerCrt-invoiceViasupplier-name",invoice.substring(0, 3), "providerCrt-businessType","providerCrt-invoiceViasupplier-choices", invoice, invoice,0);
		}

		if (map.containsKey("Send FIT Communication to Property")) {
			String fITCommunicationValue = map.get("Send FIT Communication to Property");
			if (fITCommunicationValue.equalsIgnoreCase("Yes")) {
				RadioButton fitCommunicationRB = new RadioButton(By.name("commsToProperty"), "true");
				fitCommunicationRB.select();
			} else {
				RadioButton fitCommunicationRB = new RadioButton(By.name("commsToProperty"), "false");
				fitCommunicationRB.select();
			}
		}

		if (map.containsKey("Groups Communications")) {
			String fitCommunicationsTypeValue = map.get("Groups Communications");
			WebElement parentEl = waitForElement(By.id("provider_create"));
			waitForElement(parentEl, By.id("providerCrt-commsG"));
			String AppProviderName = getElement(parentEl,By.id("providerCrt-commsG")).getText();
//			assertText(fitCommunicationsTypeValue, AppProviderName);

		}

		if (map.containsKey("validity start day")) {

			ComboBox startDayCB = new ComboBox(By.id("providerCrt-effective_day"));
			startDayCB.select(map.get("validity start day"));
		}

		if (map.containsKey("validity start month")) {
			ComboBox startMonthCB = new ComboBox(By.id("providerCrt-effective_months"));
			startMonthCB.select(map.get("validity start month"));
		}

		if (map.containsKey("validity start year")) {
			ComboBox startYearCB = new ComboBox(By.id("providerCrt-effective_years"));
			startYearCB.select(map.get("validity start year"));
		}

		if (map.containsKey("validity end day")) {
			ComboBox endDayCB = new ComboBox(By.id("providerCrt-expiry_day"));
			endDayCB.select(map.get("validity end day"));
		}

		if (map.containsKey("validity end month")) {
			ComboBox endMonthCB = new ComboBox(By.id("providerCrt-expiry_months"));
			endMonthCB.select(map.get("validity end month"));
		}

		if (map.containsKey("validity end year")) {
			ComboBox endYearCB = new ComboBox(By.id("providerCrt-expiry_years"));
			endYearCB.select(map.get("validity end year"));
		}

	}

	public void createCentralOfficeProviderDetails(Map<String, String> map) {

		String ProviderName = null;
		String fITReservation = null;
		String invoice = null;

		assertPageContainsText("Gc Autoscript9*Donotchange*");

		if (map.containsKey("Provider Type")) {
			String providerdetailsTypeValue = map.get("Provider Type");
			waitForElement(By.id("providerCrt-supplierType"));
			ComboBox providerTypeCB = new ComboBox(By.id("providerCrt-supplierType"));
			providerTypeCB.select(providerdetailsTypeValue);
			executeIEFireEventJS("providerCrt-supplierType", "onchange");

		}
		if (map.containsKey("Business Type")) {
			String providerdetailsTypeValue = map.get("Business Type");
			waitForElement(By.id("providerCrt-businessType"));
			ComboBox providerTypeCB = new ComboBox(By.id("providerCrt-businessType"));
			providerTypeCB.select(providerdetailsTypeValue);
			executeIEFireEventJS("providerCrt-businessType", "onchange");

		}

		if (map.containsKey("Provider Name")) {
			ProviderName = (map.get("Provider Name"));
			selectValueFromAjaxList("providerCrt-supplier-name",ProviderName.substring(0, 3), "providerCrt-legacyCity","providerCrt-supplier-choices", ProviderName, ProviderName,0);
		}

		if (map.containsKey("On Sale")) {
			String onSaleValue = map.get("On Sale");
			if (onSaleValue.equalsIgnoreCase("Yes")) {
				RadioButton onSaleRB = new RadioButton(By.name("onSale"),"true");
				onSaleRB.select();
			} else {
				RadioButton onSaleRB = new RadioButton(By.name("onSale"),"false");
				onSaleRB.select();
			}
		}

		if (map.containsKey("Allow On Request")) {
			String onRequestValue = map.get("Allow On Request");
			if (onRequestValue.equalsIgnoreCase("Yes")) {
				RadioButton onRequestRB = new RadioButton(By.name("onRequest"),"true");
				onRequestRB.select();
			} else {
				RadioButton onRequestRB = new RadioButton(By.name("onRequest"),"false");
				onRequestRB.select();
			}
		}

		if (map.containsKey("Allow Overbooking")) {
			String overBookingValue = map.get("Allow Overbooking");
			if (overBookingValue.equalsIgnoreCase("Yes")) {
				RadioButton overBookingRB = new RadioButton(By.name("overbooking"), "true");
				overBookingRB.select();
			} else {
				RadioButton overBookingRB = new RadioButton(By.name("overbooking"), "false");
				overBookingRB.select();
			}
		}

		if (map.containsKey("FIT Reservations Via")) {
			fITReservation = (map.get("FIT Reservations Via"));
			selectValueFromAjaxList("providerCrt-reserveViaFITsupplier-name",fITReservation.substring(0, 3), "providerCrt-legacyCity","providerCrt-reserveViaFITsupplier-choices",fITReservation, fITReservation, 0);
		}

		if (map.containsKey("Invoice Via")) {
			invoice = (map.get("Invoice Via"));
			selectValueFromAjaxList("providerCrt-invoiceViasupplier-name",invoice.substring(0, 3), "providerCrt-businessType","providerCrt-invoiceViasupplier-choices", invoice, invoice,0);
		}

		if (map.containsKey("Send FIT Communication to Property")) {
			String fITCommunicationValue = map.get("Send FIT Communication to Property");
			if (fITCommunicationValue.equalsIgnoreCase("Yes")) {
				RadioButton fitCommunicationRB = new RadioButton(By.name("commsToProperty"), "true");
				fitCommunicationRB.select();
			} else {
				RadioButton fitCommunicationRB = new RadioButton(By.name("commsToProperty"), "false");
				fitCommunicationRB.select();
			}
		}

		if (map.containsKey("FIT Communications")) {
			String fitCommunicationsTypeValue = map.get("FIT Communications");

			WebElement parentEl = waitForElement(By.id("provider_create"));
			waitForElement(parentEl, By.id("providerCrt-commsFIT-td"));
			String AppProviderName = getElement(parentEl,By.id("providerCrt-commsFIT-td")).getText();
//			assertText(fitCommunicationsTypeValue, AppProviderName);

		}

		if (map.containsKey("validity start day")) {

			ComboBox startDayCB = new ComboBox(By.id("providerCrt-effective_day"));
			startDayCB.select(map.get("validity start day"));
		}

		if (map.containsKey("validity start month")) {
			ComboBox startMonthCB = new ComboBox(By.id("providerCrt-effective_months"));
			startMonthCB.select(map.get("validity start month"));
		}

		if (map.containsKey("validity start year")) {
			ComboBox startYearCB = new ComboBox(By.id("providerCrt-effective_years"));
			startYearCB.select(map.get("validity start year"));
		}

		if (map.containsKey("validity end day")) {
			ComboBox endDayCB = new ComboBox(By.id("providerCrt-expiry_day"));
			endDayCB.select(map.get("validity end day"));
		}

		if (map.containsKey("validity end month")) {
			ComboBox endMonthCB = new ComboBox(By.id("providerCrt-expiry_months"));
			endMonthCB.select(map.get("validity end month"));
		}

		if (map.containsKey("validity end year")) {
			ComboBox endYearCB = new ComboBox(By.id("providerCrt-expiry_years"));
			endYearCB.select(map.get("validity end year"));
		}

	}

	public boolean addAnotherProvider() {
		WebElement parentElement = waitForElement(By.id("provider_create"));
		Button addAnotherButton = new Button(parentElement, "Add Another");
		addAnotherButton.click();

		if (waitForElement(By.id("providerContent")) != null) {
			return true;
		}
		return false;

	}

	public boolean saveProvider() {
		WebElement parentElement = waitForElement(By.id("provider_create"));
		Button saveButton = new Button(parentElement, "Save");
		saveButton.click();
		if (waitForElement(By.id("providerContent")) != null) {
			return true;
		}
		return false;

	}

	public boolean verifyRecordCreatedMessage(String message) {
		WebElement parentEl = waitForElement(By.id("providerContent"), 5);
		sleep(1);
		waitForElement(parentEl, By.className("message"));
		if (getElement(parentEl, By.className("message")).getText().contains(
				message)) {
			return true;
		}
		return false;
	}

	private void selectValueFromAjaxList(String textBoxId, String text,
			String dummyTextBoxId, String choiceListId, String valueToSelect,
			String title, int noOfTimes) {

		TextBox textBox = new TextBox(By.id(textBoxId));
		textBox.setText(text);
		textBox.clickTab();

		TextBox dummyTextBox = new TextBox(By.id(dummyTextBoxId));
		dummyTextBox.clickTab();

		WebElement choicesEl = null;
		while (true) {
			choicesEl = getElementIfItIsPresent(By.id(choiceListId));
			if (choicesEl != null) {
				break;
			}
		}
		if (textBox.getText().length() == 3) {
			if (choicesEl != null) {
				if (waitAndGetElementIfItIsPresent(By.linkText(title), 5) != null) {
					Link link = new Link(choicesEl, valueToSelect, title);
					sleep(2);
					link.clickLink();
				} else if (noOfTimes == 0) {
					noOfTimes++;
					selectValueFromAjaxList(textBoxId, valueToSelect,
							dummyTextBoxId, choiceListId, valueToSelect, title,
							noOfTimes);
				}
			}
		}
	}

	public void updateCentralOfficeProviderDetails(Map<String, String> editMap) {

		String fITReservation = null;

		if (editMap.containsKey("FIT Reservations Via")) {

			fITReservation = (editMap.get("FIT Reservations Via"));

			selectValueFromAjaxList("providerUpd-reserveViaFITsupplier-name",fITReservation.substring(0, 3), "providerUpd-businessType","providerUpd-reserveViaFITsupplier-choices",fITReservation, fITReservation, 0);
		}

		if (editMap.containsKey("Migrate Bookings?")) {
			String bookingMigrationValue = editMap.get("Migrate Bookings?");
			if (bookingMigrationValue.equalsIgnoreCase("No")) {
				RadioButton bookingMigrationRB = new RadioButton(By.name("bookingMigration"), "false");
				bookingMigrationRB.select();
			} else {
				RadioButton bookingMigrationRB = new RadioButton(By.name("bookingMigration"), "true");
				bookingMigrationRB.select();
			}
		}

		if (editMap.containsKey("Send FIT Communication to Property")) {
			String fITCommunicationValue = editMap
					.get("Send FIT Communication to Property");
			if (fITCommunicationValue.equalsIgnoreCase("Yes")) {
				RadioButton fitCommunicationRB = new RadioButton(By.name("commsToProperty"), "true");
				fitCommunicationRB.select();
			} else {
				RadioButton fitCommunicationRB = new RadioButton(By.name("commsToProperty"), "false");
				fitCommunicationRB.select();
			}
		}

		if (editMap.containsKey("FIT Communications")) {
			String fitCommunicationsTypeValue = editMap
					.get("FIT Communications");

			WebElement parentEl = waitForElement(By.id("provider_edit"));
			waitForElement(parentEl, By.id("providerUpd-commsF"));
			String AppProviderName = getElement(parentEl,By.id("providerUpd-commsF")).getText();
//			assertText(fitCommunicationsTypeValue, AppProviderName);

		}

	}

	public void updateSupplierProviderDetails(Map<String, String> editMap) {

		String fITReservation = null;
		String groupReservation = null;

		if (editMap.containsKey("Business Type")) {
			String providerdetailsTypeValue = editMap.get("Business Type");
			waitForElement(By.id("providerUpd-businessType"));
			ComboBox providerTypeCB = new ComboBox(	By.id("providerUpd-businessType"));
			providerTypeCB.select(providerdetailsTypeValue);
			executeIEFireEventJS("providerUpd-businessType", "onchange");

		}

		if (editMap.containsKey("Group Reservations Via")) {
			groupReservation = (editMap.get("Group Reservations Via"));
			selectValueFromAjaxList("providerUpd-reserveViaGroupsupplier-name",groupReservation.substring(0, 3),"providerUpd-businessType","providerUpd-reserveViaGroupsupplier-choices",groupReservation, groupReservation, 0);
		}

		if (editMap.containsKey("FIT Reservations Via")) {
			fITReservation = (editMap.get("FIT Reservations Via"));
			selectValueFromAjaxList("providerUpd-reserveViaFITsupplier-name",fITReservation.substring(0, 3), "providerUpd-businessType","providerUpd-reserveViaFITsupplier-choices",fITReservation, fITReservation, 0);
		}

		if (editMap.containsKey("Migrate Bookings?")) {
			String bookingMigrationValue = editMap.get("Migrate Bookings?");
			if (bookingMigrationValue.equalsIgnoreCase("No")) {
				RadioButton bookingMigrationRB = new RadioButton(By.name("bookingMigration"), "false");
				bookingMigrationRB.select();
			} else {
				RadioButton bookingMigrationRB = new RadioButton(By.name("bookingMigration"), "true");
				bookingMigrationRB.select();
			}
		}

		if (editMap.containsKey("Send FIT Communication to Property")) {
			String fITCommunicationValue = editMap
					.get("Send FIT Communication to Property");
			if (fITCommunicationValue.equalsIgnoreCase("Yes")) {
				RadioButton fitCommunicationRB = new RadioButton(By.name("commsToProperty"), "true");
				fitCommunicationRB.select();
			} else {
				RadioButton fitCommunicationRB = new RadioButton(By.name("commsToProperty"), "false");
				fitCommunicationRB.select();
			}
		}

		if (editMap.containsKey("FIT Communications")) {
			String fitCommunicationsTypeValue = editMap.get("FIT Communications");

			WebElement parentEl = waitForElement(By.id("provider_edit"));
			waitForElement(parentEl, By.id("providerUpd-commsF"));
			String AppProviderName = getElement(parentEl,By.id("providerUpd-commsF")).getText();
//			assertText(fitCommunicationsTypeValue, AppProviderName);

		}
	}

	public boolean SortOnProviderType() {
		return sort(0, "String");
	}

	public boolean SortOnProviderName() {
		return sort(1, "String");
	}

	private boolean sort(int colNum, String objectType) {

		boolean result = true;

		WebElement tableDivEl = waitForElement(By.id("provider_list"));
		WebElement chainEl = getElements(tableDivEl, By.tagName("th")).get(
				colNum);
		getElement(chainEl, By.tagName("a")).click();

		sleep(2);

		// Need to load the below objects again as the above click() funtion
		// reload the div element.
		tableDivEl = waitForElement(By.id("provider_list"));
		chainEl = getElements(tableDivEl, By.tagName("th")).get(colNum);
		String href = getElement(chainEl, By.tagName("a")).getAttribute("href");
		String sortOrder = "asc";

		if (href.contains("=desc")) {
			sortOrder = "desc";
		}

		result = verifySortOrder(sortOrder, tableDivEl, colNum, objectType);
		if (result) {

			getElement(chainEl, By.tagName("a")).click();

			sleep(2);

			// Need to load the below objects again as the above click() funtion
			// reload the div element.
			tableDivEl = waitForElement(By.id("provider_list"));
			chainEl = getElements(tableDivEl, By.tagName("th")).get(colNum);
			href = getElement(chainEl, By.tagName("a")).getAttribute("href");
			sortOrder = "asc";

			if (href.contains("order=desc")) {
				sortOrder = "desc";
			}
			result = verifySortOrder(sortOrder, tableDivEl, colNum, objectType);
		}
		return result;
	}

	private boolean verifySortOrder(String sortOrder, WebElement tableDivEl,
			int colNum, String objectType) {
		boolean result = true;
		List<WebElement> trList = getTableRowsListFromDiv(tableDivEl);
		String prevValue = null;
		String currentValue = null;
		for (int i = 1; i < trList.size(); i++) {
			WebElement tr = trList.get(i);
			List<WebElement> tdList = getElements(tr, By.tagName("td"));
			if (i == 1) {
				currentValue = tdList.get(colNum).getText();
			} else {
				prevValue = currentValue;
				currentValue = tdList.get(colNum).getText();
				if (sortOrder.equals("asc")) {
					if (objectType.equals("String")
							&& prevValue.compareToIgnoreCase(currentValue) < 0) {
						result = false;
						break;
					} else if (objectType.equals("Date")) {
						if (!compareSortOrderOnDateObjects(prevValue,
								currentValue, sortOrder)) {
							result = false;
							break;
						}
					}
				} else {
					if (objectType.equals("String")
							&& currentValue.compareToIgnoreCase(prevValue) < 0) {
						result = false;
						break;
					} else if (objectType.equals("Date")) {
						if (!compareSortOrderOnDateObjects(prevValue,
								currentValue, sortOrder)) {
							result = false;
							break;
						}
					}
				}
			}
		}
		return result;
	}

	private boolean compareSortOrderOnDateObjects(String prevValue,
			String currentValue, String sortOrder) {
		// TODO Auto-generated method stub
		return false;
	}

}