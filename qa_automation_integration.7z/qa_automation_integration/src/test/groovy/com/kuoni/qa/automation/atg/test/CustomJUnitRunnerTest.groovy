package com.kuoni.qa.automation.atg.test
import org.junit.runner.RunWith
import org.junit.runners.Suite


@RunWith(Suite.class)
@Suite.SuiteClasses([VerifyActivityRefData_CB7864.class, VerifyAreaRefData_CB8502, VerifyErrataAreaRefData_CB6595,VerifyErrataDisturbanceRefData_CB6593,
	VerifyErrataTypeDescRefData_CB6592,VerifyLandMarktypeRefdata_CB9714,VerifyOfferDescriptionRefData_CB6590,VerifyPropInformationsRefData_CB7865,
	VerifyRoomCategoryRefData_CB6599,VerifyRoomDescRefdata_CB6601,VerifyRoomFacilityRefData_CB_6589,VerifyRoomTypeDescRefData_CB6597,
	VerifyRoomViewDescriptionsRefData_CB6600,VerifyStyleRefData_CB7862,CountryDataTest,RegionDataTest,CityDataTest,
	PropertyDataTest,ProductDataTest,ContractDataTest,RateplanDataTest])
class CustomJUnitRunnerTest {
}
