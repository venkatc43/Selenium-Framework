package com.kuoni.qa.automation.gc.test;

import java.util.HashMap;
import java.util.Map;

import com.gta.travel.page.base.GSTestBase;
import com.kuoni.qa.automation.page.object.cities.CityListPage;
import com.kuoni.qa.automation.page.object.cities.CityPage;
import com.kuoni.qa.automation.page.object.cities.CityResultListPage;
import com.kuoni.qa.automation.page.object.cities.ViewCityPage;
import com.kuoni.qa.automation.page.object.common.HomePageSub;
import com.kuoni.qa.automation.page.object.common.LoginPageSub;
import com.kuoni.qa.constants.CommonConstants;
import com.mediaocean.qa.framework.utils.ExcelUtil;

public class CityCreateEditDeleteTest extends GSTestBase{

	
	private String userName;
	private String password;
	private String webId;
	
	private String sheetName = null;
	
	private CityListPage cityListPage;
	private CityResultListPage cityResultListPage;
	private ViewCityPage viewCityPage;
	private CityPage cityPage;
	private ExcelUtil excelData;

	public CityCreateEditDeleteTest(String driverSheetPath, String dataSheetPath, String sheetName){
		this.sheetName = sheetName;
		init(driverSheetPath, dataSheetPath);
	}
	
	public void init(String driverSheetPath, String dataSheetPath){

		excelData = new ExcelUtil(dataSheetPath);
		if (driverSheetPath != null){
			setDriverSheetAbsolutePath(driverSheetPath);
		}else{
			setDriverSheetFileName("Driver_Sheet.xls");
		}
		initialiseEnvironmentAndTest();
		openBrowser();
		setLoginInfo();
		if(CommonConstants.webDriver != null){
			CommonConstants.webDriver = getDriver();
		}
	}

	private void setLoginInfo(){
		webId = excelUtil.getKeyValue(ENVIRONMENT, "webId");
		userName = excelUtil.getKeyValue(ENVIRONMENT, "userName");
		password = excelUtil.getKeyValue(ENVIRONMENT, "password");
	}
	
	public void executeDataScriptForCreate(){
		executeLoginPageFlow();
		executeSearcCitiesFlow();
		executeCreateCityFlow();
//		getDriver().quit();
	}
	
	public void executeDataScriptForEdit(boolean isCityCodeUpdate){
		executeLoginPageFlow();
		executeSearcCitiesFlow();
		if(isCityCodeUpdate){
			executeSearchResultsScreenFlowForEditCityCode();
		}else{
			executeSearchResultsScreenFlowForEditCityDescription();
		}
		executeEditCityFlow();
//		getDriver().quit();
	}
	
	public void executeDataScriptForDelete(){
		executeLoginPageFlow();
		executeSearcCitiesFlow();
		executeSearchResultsScreenFlow();
		executeDeleteFlow();
//		getDriver().quit();		
	}
	
	private void executeLoginPageFlow(){
		LoginPageSub loginPage = new LoginPageSub();
		HomePageSub homePage = loginPage.login(webId, userName, password);
		cityListPage = homePage.selectCities();
	}
	
	private void executeCreateCityFlow(){
		cityPage = cityListPage.selectCreateCity();
		Map<String, String> data = new HashMap<String,String>();
		data.put("Code", excelData.getKeyValue(sheetName, "Code"));
		data.put("Description", excelData.getKeyValue(sheetName, "Description"));
		data.put("IataCode", excelData.getKeyValue(sheetName, "IataCode"));
		data.put("LegacyCode", excelData.getKeyValue(sheetName, "LegacyCode"));
		data.put("Country", excelData.getKeyValue(sheetName, "Country"));
		data.put("Timezone", excelData.getKeyValue(sheetName, "Timezone"));
		cityPage.createCity(data);
		cityPage.sleep(3);
	}
	
	private void executeSearcCitiesFlow(){
		Map<String, String> searchDataMap = new HashMap<String, String>();
		searchDataMap.put("Country", excelData.getKeyValue(sheetName, "Country"));
		cityResultListPage = cityListPage.searchCities(searchDataMap);
	}

	private void executeSearchResultsScreenFlow() {
		Map<String, String> searchResultsDataMap = new HashMap<String, String>();
		searchResultsDataMap.put("City", excelData.getKeyValue(sheetName, "Description"));
		viewCityPage = cityResultListPage.selectRecordFromSearchResults(searchResultsDataMap);
	}
	
	private void executeSearchResultsScreenFlowForEditCityDescription() {
		Map<String, String> searchResultsDataMap = new HashMap<String, String>();
		searchResultsDataMap.put("Code",  excelData.getKeyValue(sheetName, "Code"));
		viewCityPage = cityResultListPage.selectRecordFromSearchResults(searchResultsDataMap);
	}
	
	private void executeSearchResultsScreenFlowForEditCityCode() {
		Map<String, String> searchResultsDataMap = new HashMap<String, String>();
		searchResultsDataMap.put("City",  excelData.getKeyValue(sheetName, "City"));
		viewCityPage = cityResultListPage.selectRecordFromSearchResults(searchResultsDataMap);
	}	
	
	private void executeEditCityFlow(){
		cityPage = viewCityPage.clickEdit();
		Map<String, String> data = new HashMap<String,String>();
		data.put("Code", excelData.getKeyValue(sheetName, "Code"));
		data.put("Description", excelData.getKeyValue(sheetName, "Description"));
		data.put("IataCode", excelData.getKeyValue(sheetName, "IataCode"));
		data.put("LegacyCode", excelData.getKeyValue(sheetName, "LegacyCode"));
		data.put("Country", excelData.getKeyValue(sheetName, "Country"));
		data.put("Timezone", excelData.getKeyValue(sheetName, "Timezone"));
		cityPage.editCity(data);
		cityPage.sleep(3);	
	}
	
	private void executeDeleteFlow(){
		viewCityPage.clickDelete();
		viewCityPage.sleep(3);
	}
	
	
	public ExcelUtil getExcelData() {
		return excelData;
	}	

}
