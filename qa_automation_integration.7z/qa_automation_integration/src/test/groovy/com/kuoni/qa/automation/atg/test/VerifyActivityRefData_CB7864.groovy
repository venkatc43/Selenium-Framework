package com.kuoni.qa.automation.atg.test

import org.testng.asserts.SoftAssert;

import spock.lang.Shared;
import spock.lang.Specification
import spock.lang.Unroll;
import static com.kuoni.qa.automation.util.ReadFilesUtil.getFiles

import com.kuoni.atg.jaxbclasses.ChangerecordsType
import com.kuoni.atg.jaxbclasses.DescriptionType
import com.kuoni.atg.jaxbclasses.PropertyActivityDescriptionsRecord
import com.kuoni.qa.automation.common.properties.EnvironmentProperties;
import com.kuoni.qa.automation.dao.GetReferenceDataDescription;
import com.kuoni.qa.automation.dto.ReferenceDataDTO
import com.kuoni.qa.automation.helper.JaxbHelper
import com.kuoni.qa.automation.spock.annotation.Regression;
import com.kuoni.qa.automation.util.PerformDataLoadUtil

class VerifyActivityRefData_CB7864 extends Specification{


	SoftAssert softAssert = new SoftAssert()
	GetReferenceDataDescription offerDesc = new GetReferenceDataDescription()

	@Shared
	EnvironmentProperties envProp = new EnvironmentProperties()

	def setupSpec() {

		def folderLocation = envProp.getValueForProperty("istDataLoc")+"/PropertyActivityDescriptionsRecord"
		PerformDataLoadUtil dataLoad = new PerformDataLoadUtil()
		dataLoad.changeTestDataReaderLocation(folderLocation)
		dataLoad.importFilesandPerformLoadfromQueue()
	}

	@Regression
	@Unroll
	public "verifyReferenceData for : #xmlFile.getName()"() {

		given: "The XmLs are available at the desired Location"
		ReferenceDataDTO data
		JaxbHelper jaxbObj = new JaxbHelper()

		ChangerecordsType xml = jaxbObj.buildRequestJaxbClass(xmlFile)

		xml.recordset.get(0).record.get(0)

		PropertyActivityDescriptionsRecord recordNode = xml.recordset.get(0).record.get(0)

		String activityCode = recordNode.getPropertyActivityDescriptionsRecord().getCode().value()

		List<DescriptionType> activityDescList =  recordNode.getPropertyActivityDescriptionsRecord().getActivityDescriptions().getActivityDescription()



		println "\n xml File : " + xmlFile.getName()
		println "Code : " + activityCode
		int languageCount = recordNode.getPropertyActivityDescriptionsRecord().getActivityDescriptions().getActivityDescription().size()
		println "Xml Language Count :  " + languageCount
		when:"The data can be read from XML and Database"
		for(DescriptionType activityDescriptions: activityDescList) {
			String language = activityDescriptions.getLanguage().value()
			String activityDescription = activityDescriptions.getText()
			data = offerDesc.getOfferDesc(activityCode,language,309)

			//println "DB Language Count : " + data.getLanguageCount()
			if(languageCount == data.getLanguageCount())

			{

				println "\n Language::" + language + "::"
				println "xml StyleDescription :  " + activityDescription
				println "\n Database Style Desc : " +  data.getDataDescription()

				softAssert.assertEquals(activityDescription, data.getDataDescription(),"Activity Description: "+activityDescription+" Doesnot Match with Database : "+ data.getDataDescription() )

			}

			else
				softAssert.assertEquals(languageCount,data.getLanguageCount(),"The Language count doesn't match with Database")

		}

		softAssert.assertAll()
		then:"The XML Descriptions should match with Database"

		where:

		xmlFile << getFiles("/PropertyActivityDescriptionsRecord")


	}


}
