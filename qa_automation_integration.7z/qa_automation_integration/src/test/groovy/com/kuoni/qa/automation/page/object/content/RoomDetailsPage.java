package com.kuoni.qa.automation.page.object.content;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.gta.travel.page.base.GSPageBase;
import com.mediaocean.qa.framework.selenium.ui.controls.Button;
import com.mediaocean.qa.framework.selenium.ui.controls.CheckBox;
import com.mediaocean.qa.framework.selenium.ui.controls.ComboBox;
import com.mediaocean.qa.framework.selenium.ui.controls.Link;
import com.mediaocean.qa.framework.selenium.ui.controls.RadioButton;
import com.mediaocean.qa.framework.selenium.ui.controls.Table;
import com.mediaocean.qa.framework.selenium.ui.controls.TextBox;

public class RoomDetailsPage extends GSPageBase {

	GSPageBase gsPageBase = new GSPageBase(getDriver());
	String[] roomTypesArr = { "Twin", "Double", "Single", "Triple", "Quad", "Twin for Sole Use",
			"Double for Sole Use" };

	/**
	 * Default Constructor
	 */
	public RoomDetailsPage ( ) {
		super(getDriver());
	}

	/**
	 * This method returns the page factory object for the Room Details Page
	 * 
	 * @return static
	 */
	public static RoomDetailsPage getInstance ( ) {
		return PageFactory.initElements(getDriver(), RoomDetailsPage.class);
	}

	/**
	 * This method clicks on create Link of RoomDetails and waits till the table
	 * is displayed
	 */
	public void clickCreateRoomDetails ( ) {
		final WebElement parentElement = waitForElement(By.id("roomContentMenuOptions"));
		final Link createLink = new Link(parentElement, "Create");
		createLink.clickLink();
		waitForPageElementById("roomCreateCancel");
	}

	/**
	 * This method clicks on refresh Link of Room Details and waits till the
	 * table is displayed
	 */
	public void clickRefreshRoomDetails ( ) {
		final WebElement parentElement = waitForElement(By.id("roomContentMenuOptions"));
		final Link refreshLink = new Link(parentElement, "Refresh");
		refreshLink.clickLink();
		sleep(2);
	}

	/**
	 * This method selects the option from the select option dropdown
	 * 
	 * @param optionName
	 */
	public void selectRoomDetailsOptions ( final String optionName ) {
		// sleep(1);
		final WebElement menuElement = waitForElement(By.id("roomContentMenuOptions"));
		waitForElement(menuElement, By.linkText("Select Option"));
		if (Link.isLinkVisible(menuElement, "Select Option")) {
			final Link slectOptionLink = new Link(menuElement, "Select Option");
			slectOptionLink.clickLink();
		}

		waitForElement(By.linkText(optionName));
		final Link optionLink = new Link(menuElement, optionName);
		optionLink.clickLink();
		if (optionName.equalsIgnoreCase("Create")) {
			// int count = getRoomDetailsRowCount();
			waitForElement(By.id("roomCategory"));
			// WebElement parentElement = waitForElement(By.id("roomCategory"));
			// if (count == 0){
			// waitForElement(parentElement,
			// By.id("ratePlanCancellation-create-overrideBaseCancellation-Y"));
			// }else{
			// waitForElement(parentElement, By.id("cancellationCreateCancel"));
			// }
		}
		if (optionName.equalsIgnoreCase("Edit")) {
			waitForElement(By.id("roomEdit"));
		}
		if (optionName.equalsIgnoreCase("Refresh")) {
			sleep(1);
			for (int i = 0; i < 10; i++) {
				try {
					getRoomDetailsRowCount();
					break;
				} catch (final Exception e) {
					continue;
				}
			}
			// sleep(2);
			// waitForInVisibilityOfElement(By.id("cancellation_tr"));
			// waitForInVisibilityOfElement(By.id("cancellation_historySearch"));
		}
		if (optionName.equalsIgnoreCase("Copy")) {
			waitForElement(By.id("roomCreateCancel"));
		}
		// sleep(1);
	}

	private int getRoomDetailsRowCount ( ) {
		final WebElement parentElement = waitForElement(By.id("roomContent"));
		final Table tbl = new Table(parentElement, 1);
		return tbl.getRowCount();
	}

	/**
	 * This method enter the values in the Room Details Section
	 * 
	 * @param inputMap
	 */
	public void enterRoomDetails ( final Map<String, String> inputMap ) {

		if (inputMap.containsKey("RoomCategory")) {
			final ComboBox roomCategoryCombo = new ComboBox(By.id("roomCategory"));
			roomCategoryCombo.select(inputMap.get("RoomCategory"));
		}
		if (inputMap.containsKey("RoomType")) {
			final ComboBox roomTypeCombo = new ComboBox(By.id("roomType"));
			roomTypeCombo.select(inputMap.get("RoomType"));
		}
		if (inputMap.containsKey("RoomView")) {
			final ComboBox roomViewCombo = new ComboBox(By.id("roomView"));
			roomViewCombo.select(inputMap.get("RoomView"));
		}
		if (inputMap.containsKey("RoomCode")) {
			final TextBox roomCodeTB = new TextBox(By.id("code"));
			roomCodeTB.setText("");
			roomCodeTB.setText(inputMap.get("RoomCode"));
		}
		if (inputMap.containsKey("NumberOfBeds")) {
			final TextBox numberOfBedsTB = new TextBox(By.id("beds"));
			numberOfBedsTB.setText("");
			numberOfBedsTB.setText(inputMap.get("NumberOfBeds"));
		}
		if (inputMap.containsKey("MaximumOccupancy")) {
			final TextBox maximumOccupancyTB = new TextBox(By.id("maxOccupancy"));
			maximumOccupancyTB.setText("");
			maximumOccupancyTB.setText(inputMap.get("MaximumOccupancy"));

		}
		if (inputMap.containsKey("RateBasis")) {
			final TextBox rateBasisTB = new TextBox(By.id("rateBasis"));
			rateBasisTB.setText("");
			rateBasisTB.setText(inputMap.get("RateBasis"));

		}
		if (inputMap.containsKey("NumberOfExtraBedsPossible")) {
			final TextBox extraBedTB = new TextBox(By.id("extraBed"));
			extraBedTB.setText("");
			extraBedTB.setText(inputMap.get("NumberOfExtraBedsPossible"));

		}
		if (inputMap.containsKey("ExistingBed")) {
			waitForVisibilityOfElement(By.name("existingBed"), 20);
			final String value = inputMap.get("ExistingBed");
			if (value.equalsIgnoreCase("true")) {
				final RadioButton existingBedRB = new RadioButton(By.name("existingBed"), "true");
				if (!existingBedRB.isSelected())
					existingBedRB.select();
			} else {
				final RadioButton existingBedRB = new RadioButton(By.name("existingBed"), "false");
				if (!existingBedRB.isSelected())
					existingBedRB.select();
			}
		}
		if (inputMap.containsKey("NumberOfBabyCots")) {
			final TextBox numberOfBabyCotsTB = new TextBox(By.id("cots"));
			numberOfBabyCotsTB.setText("");
			numberOfBabyCotsTB.setText(inputMap.get("NumberOfBabyCots"));
		}

		final Map<String, String> map = new HashMap<String, String>();
		map.put("Air Conditioned", "crt-hasAirCon");
//		map.put("Air Conditioned", "chg-hasAirCon");
		map.put("CD Player", "FEATURES-60");
		map.put("DVD", "FEATURES-59");
		map.put("Hairdryer", "FEATURES-51");
		map.put("In-house Film", "FEATURES-64");
		map.put("Internet", "FEATURES-61");
		map.put("Ironing", "FEATURES-56");
		map.put("Kitchenette", "FEATURES-53");
		map.put("Laundry", "FEATURES-57");
		map.put("Microwave", "FEATURES-54");
		map.put("Mini Bar", "FEATURES-50");
		map.put("Non-Smoking", "FEATURES-58");
		map.put("Safe", "FEATURES-49");
		map.put("Satellite TV", "FEATURES-63");
		map.put("Smoking", "FEATURES-52");
		map.put("Tea & Coffee Making Facilities", "FEATURES-82");
		map.put("Television", "FEATURES-62");
		map.put("Washing Machine", "FEATURES-55");

		waitForVisibilityOfElement(By.name("FEATURES"), 20);
		CheckBox.uncheckAll(By.name("FEATURES"));
		sleep(2);
		waitForVisibilityOfElement(By.id("crt-hasAirCon"), 20);
//		waitForVisibilityOfElement(By.id("chg-hasAirCon"), 20);

		CheckBox facilitiesCB = null;

		if ((inputMap.get("Air Conditioned") != null)) {
			facilitiesCB = new CheckBox(By.id(map.get("Air Conditioned")));
			if (inputMap.get("Air Conditioned").equalsIgnoreCase("true")) {
				facilitiesCB.check();
			} else {
				facilitiesCB.uncheck();
			}
		}

		if ((inputMap.get("CD Player") != null)) {
			facilitiesCB = new CheckBox(By.id(map.get("CD Player")));
			if (inputMap.get("CD Player").equalsIgnoreCase("true")) {
				facilitiesCB.check();
			} else {
				facilitiesCB.uncheck();
			}
		}

		if ((inputMap.get("DVD") != null)) {
			facilitiesCB = new CheckBox(By.id(map.get("DVD")));
			if (inputMap.get("DVD").equalsIgnoreCase("true")) {
				facilitiesCB.check();
			} else {
				facilitiesCB.uncheck();
			}
		}

		if ((inputMap.get("Hairdryer") != null)) {
			facilitiesCB = new CheckBox(By.id(map.get("Hairdryer")));
			if (inputMap.get("Hairdryer").equalsIgnoreCase("true")) {
				facilitiesCB.check();
			} else {
				facilitiesCB.uncheck();
			}
		}

		if ((inputMap.get("In-house Film") != null)) {
			facilitiesCB = new CheckBox(By.id(map.get("In-house Film")));
			if (inputMap.get("In-house Film").equalsIgnoreCase("true")) {
				facilitiesCB.check();
			} else {
				facilitiesCB.uncheck();
			}
		}

		if ((inputMap.get("Internet") != null)) {
			facilitiesCB = new CheckBox(By.id(map.get("Internet")));
			if (inputMap.get("Internet").equalsIgnoreCase("true")) {
				facilitiesCB.check();
			} else {
				facilitiesCB.uncheck();
			}
		}

		if ((inputMap.get("Ironing") != null)) {
			facilitiesCB = new CheckBox(By.id(map.get("Ironing")));
			if (inputMap.get("Ironing").equalsIgnoreCase("true")) {
				facilitiesCB.check();
			} else {
				facilitiesCB.uncheck();
			}
		}

		if ((inputMap.get("Kitchenette") != null)) {
			facilitiesCB = new CheckBox(By.id(map.get("Kitchenette")));
			if (inputMap.get("Kitchenette").equalsIgnoreCase("true")) {
				facilitiesCB.check();
			} else {
				facilitiesCB.uncheck();
			}
		}

		if ((inputMap.get("Laundry") != null)) {
			facilitiesCB = new CheckBox(By.id(map.get("Laundry")));
			if (inputMap.get("Laundry").equalsIgnoreCase("true")) {
				facilitiesCB.check();
			} else {
				facilitiesCB.uncheck();
			}
		}

		if ((inputMap.get("Microwave") != null)) {
			facilitiesCB = new CheckBox(By.id(map.get("Microwave")));
			if (inputMap.get("Microwave").equalsIgnoreCase("true")) {
				facilitiesCB.check();
			} else {
				facilitiesCB.uncheck();
			}
		}

		if ((inputMap.get("Mini Bar") != null)) {
			facilitiesCB = new CheckBox(By.id(map.get("Mini Bar")));
			if (inputMap.get("Mini Bar").equalsIgnoreCase("true")) {
				facilitiesCB.check();
			} else {
				facilitiesCB.uncheck();
			}
		}

		if ((inputMap.get("Non-Smoking") != null)) {
			facilitiesCB = new CheckBox(By.id(map.get("Non-Smoking")));
			if (inputMap.get("Non-Smoking").equalsIgnoreCase("true")) {
				facilitiesCB.check();
			} else {
				facilitiesCB.uncheck();
			}
		}

		if ((inputMap.get("Safe") != null)) {
			facilitiesCB = new CheckBox(By.id(map.get("Safe")));
			if (inputMap.get("Safe").equalsIgnoreCase("true")) {
				facilitiesCB.check();
			} else {
				facilitiesCB.uncheck();
			}
		}

		if ((inputMap.get("Satellite TV") != null)) {
			facilitiesCB = new CheckBox(By.id(map.get("Satellite TV")));
			if (inputMap.get("Satellite TV").equalsIgnoreCase("true")) {
				facilitiesCB.check();
			} else {
				facilitiesCB.uncheck();
			}
		}

		if ((inputMap.get("Smoking") != null)) {
			facilitiesCB = new CheckBox(By.id(map.get("Smoking")));
			if (inputMap.get("Smoking").equalsIgnoreCase("true")) {
				facilitiesCB.check();
			} else {
				facilitiesCB.uncheck();
			}
		}

		if ((inputMap.get("Tea & Coffee Making Facilities") != null)) {
			facilitiesCB = new CheckBox(By.id(map.get("Tea & Coffee Making Facilities")));
			if (inputMap.get("Tea & Coffee Making Facilities").equalsIgnoreCase("true")) {
				facilitiesCB.check();
			} else {
				facilitiesCB.uncheck();
			}
		}

		if ((inputMap.get("Television") != null)) {
			facilitiesCB = new CheckBox(By.id(map.get("Television")));
			if (inputMap.get("Television").equalsIgnoreCase("true")) {
				facilitiesCB.check();
			} else {
				facilitiesCB.uncheck();
			}
		}

		if ((inputMap.get("Washing Machine") != null)) {
			facilitiesCB = new CheckBox(By.id(map.get("Washing Machine")));
			if (inputMap.get("Washing Machine").equalsIgnoreCase("true")) {
				facilitiesCB.check();
			} else {
				facilitiesCB.uncheck();
			}
		}

		if (inputMap.containsKey("RoomTypes")) {
			String[] roomTypesArr = null;
			sleep(2);
			waitForVisibilityOfElement(By.id("twinBed"), 20);
			CheckBox.uncheckAll(By.id("twinBed"));
			CheckBox.uncheckAll(By.id("doubleBed"));
			CheckBox.uncheckAll(By.id("singleBed"));
			CheckBox.uncheckAll(By.id("tripleBed"));
			CheckBox.uncheckAll(By.id("quadBed"));
			CheckBox.uncheckAll(By.id("twinSoleUse"));
			CheckBox.uncheckAll(By.id("doubleSoleUse"));
			sleep(2);
			waitForVisibilityOfElement(By.id("twinBed"), 20);
			final String roomTypes = inputMap.get("RoomTypes");
			if (roomTypes.contains(",")) {
				roomTypesArr = roomTypes.split(",");
			}
			for (int i = 0; i < roomTypesArr.length; i++) {
				waitForElement(By.id("twinBed"));
				if (roomTypesArr[i].trim().equals("Twin")) {
					final CheckBox twinBedCB = new CheckBox(By.id("twinBed"));
					twinBedCB.check();
				}
				if (roomTypesArr[i].trim().equals("Double")) {
					final CheckBox doubleBedCB = new CheckBox(By.id("doubleBed"));
					doubleBedCB.check();
				}
				if (roomTypesArr[i].trim().equals("Single")) {
					final CheckBox singleBedCB = new CheckBox(By.id("singleBed"));
					singleBedCB.check();
				}
				if (roomTypesArr[i].trim().equals("Triple")) {
					final CheckBox tripleBedCB = new CheckBox(By.id("tripleBed"));
					tripleBedCB.check();
				}
				if (roomTypesArr[i].trim().equals("Quad")) {
					final CheckBox quadBedCB = new CheckBox(By.id("quadBed"));
					quadBedCB.check();
				}
				if (roomTypesArr[i].trim().equals("Twin for Sole Use")) {
					final CheckBox twinSoleUseCB = new CheckBox(By.id("twinSoleUse"));
					twinSoleUseCB.check();
				}
				if (roomTypesArr[i].trim().equals("Double for Sole Use")) {
					final CheckBox doubleSoleUseCB = new CheckBox(By.id("doubleSoleUse"));
					doubleSoleUseCB.check();
				}

			}
		}
		if (inputMap.containsKey("BathShower")) {
			final String bathShower = inputMap.get("BathShower");
			sleep(2);
			for (int i = 1; i <= 3; i++) {
				waitForVisibilityOfElement(By.name("bath" + i), 20);
				CheckBox.uncheckAll(By.name("bath" + i));
			}
			if (bathShower.contains(",")) {
				final String[] bathShowerArr = bathShower.split(",");
				waitForElement(By.name("bath1"));
				for (int k = 0; k < bathShowerArr.length - 1; k++) {
					if (bathShowerArr[k].trim().equals("Bathtub with overhead shower")) {
						final CheckBox bath1CB = new CheckBox(By.name("bath1"));
						bath1CB.check();
					}
					if (bathShowerArr[k].trim().equals("Shower cubicle")) {
						final CheckBox bath2CB = new CheckBox(By.name("bath2"));
						bath2CB.check();
					}
					if (bathShowerArr[k].trim().equals("Shared Facilities")) {
						final CheckBox bath3CB = new CheckBox(By.name("bath3"));
						bath3CB.check();
					}
				}
			} else {

				if (bathShower.trim().equals("Bathtub with overhead shower")) {
					final CheckBox bath1CB = new CheckBox(By.name("bath1"));
					bath1CB.check();
				} else if (bathShower.trim().equals("Shower cubicle")) {
					final CheckBox bath2CB = new CheckBox(By.name("bath2"));
					bath2CB.check();
				} else if (bathShower.trim().equals("Shared Facilities")) {
					final CheckBox bath3CB = new CheckBox(By.name("bath3"));
					bath3CB.check();
				}

			}
		}

		if (inputMap.containsKey("AllRooms")) {
			waitForVisibilityOfElement(By.name("allBathrooms"), 20);
			final String value = inputMap.get("AllRooms");
			if (value.equalsIgnoreCase("true")) {
				final RadioButton bathRoomsRB = new RadioButton(By.name("allBathrooms"), "true");
				if (!bathRoomsRB.isSelected())
					bathRoomsRB.select();
			} else {
				final RadioButton bathRoomsRB = new RadioButton(By.name("allBathrooms"), "false");
				if (!bathRoomsRB.isSelected())
					bathRoomsRB.select();
			}
		}

	}

	/**
	 * This method clicks on add another button in the room details section
	 */
	public void addAnotherRoomDetails ( ) {
		final WebElement parentElement = waitForElement(By.id("room_create"));
		final Button addAnotherButton = new Button(parentElement, "Add Another");
		final int countBefore = getRoomDetailsRowCount();
		addAnotherButton.click();
		for (int i = 0; i < 3; i++) {
			try {
				final int countAfter = getRoomDetailsRowCount();
				if (countBefore + 1 == countAfter) {
					break;
				} else {
					sleepms(200l);
				}
			} catch (final Exception e) {
				sleepms(200l);
				continue;
			}
		}
		final WebElement parentEl = waitForElement(By.id("roomContent"));
		waitForElement(parentEl, By.className("message"), 60);
	}

	/**
	 * This method clicks on save button in the room details
	 */
	public void saveRoomDetails ( ) {
		WebElement parentElement = null;
		parentElement = waitForElement(By.id("room_create"));
		final Button saveButton = new Button(parentElement, "Save");
		saveButton.click();

	}

	/**
	 * This method clicks on save button to verify the error messages
	 */
	public void saveErrorRoomDetails ( ) {
		WebElement parentElement = null;
		parentElement = waitForElement(By.id("roomCreate"));
		final Button saveButton = new Button(parentElement, "Save");
		saveButton.click();
		waitForVisibilityOfElement(By.id("roomCategory-errors"), 20);
		sleep(2);
	}

	/**
	 * This method gets the validation message as a string
	 */
	public String getValidationMessage ( ) {
		final WebElement errorElement = waitForElement(By.id("roomCategory-errors"));
		return errorElement.getText();
	}

	/**
	 * This method clicks on copy button in the room details section
	 */
	public void copyRoomDetails ( ) {
		final WebElement parentElement = waitForElement(By.id("room_create"));
		final Button copyButton = new Button(parentElement, "Copy");
		final int countBefore = getRoomDetailsRowCount();
		copyButton.click();
		for (int i = 0; i < 3; i++) {
			try {
				final int countAfter = getRoomDetailsRowCount();
				if (countBefore + 1 == countAfter) {
					break;
				} else {
					sleepms(200l);
				}
			} catch (final Exception e) {
				sleepms(200l);
				continue;
			}
		}
		final WebElement parentEl = waitForElement(By.id("roomContent"));
		waitForElement(parentEl, By.className("message"), 60);
	}

	/**
	 * This method clicks on the edit link of the room details
	 */
	public void clickEditRoomDetails ( ) {
		final WebElement parentElement = waitForElement(By.id("roomContentMenuOptions"));
		final Link editLink = new Link(parentElement, "Edit");
		editLink.clickLink();
		waitForVisibilityOfElement((By.name("bath3")), 40);
	}

	/**
	 * This method clicks on the update button of the room details section
	 */
	public void updateRoomDetails ( ) {
		final Button updateButton = new Button("roomEdit");
		updateButton.click();
		final WebElement parentEl = waitForElement(By.id("roomContent"));
		waitForElement(parentEl, By.className("message"), 60);
	}

	/**
	 * This method sorts on the Room Type section
	 * 
	 * @return boolean
	 */
	public boolean sortOnRoomType ( ) {
		return sort(0, "String");
	}

	/**
	 * This method sorts on the Room Code section
	 * 
	 * @return boolean
	 */
	public boolean sortOnRoomCode ( ) {
		return sort(1, "String");
	}

	private boolean sort ( final int colNum, final String objectType ) {

		boolean result = true;
		WebElement tableDivEl = waitForElement(By.id("roomContent"));
		WebElement chainEl = getElements(tableDivEl, By.tagName("th")).get(colNum);
		getElement(chainEl, By.tagName("a")).click();

		sleep(2);

		// Need to load the below objects again as the above click() funtion
		// reload the div element.
		tableDivEl = waitForElement(By.id("roomContent"));
		chainEl = getElements(tableDivEl, By.tagName("th")).get(colNum);
		String href = getElement(chainEl, By.tagName("a")).getAttribute("href");
		String sortOrder = "asc";

		if (href.contains("=desc")) {
			sortOrder = "desc";
		}

		result = verifySortOrder(sortOrder, tableDivEl, colNum, objectType);
		if (result) {

			getElement(chainEl, By.tagName("a")).click();

			sleep(2);

			// Need to load the below objects again as the above click() funtion
			// reload the div element.
			tableDivEl = waitForElement(By.id("roomContent"));
			chainEl = getElements(tableDivEl, By.tagName("th")).get(colNum);
			href = getElement(chainEl, By.tagName("a")).getAttribute("href");
			sortOrder = "asc";

			if (href.contains("order=desc")) {
				sortOrder = "desc";
			}
			result = verifySortOrder(sortOrder, tableDivEl, colNum, objectType);
		}
		return result;
	}

	private boolean verifySortOrder ( final String sortOrder, final WebElement tableDivEl, final int colNum,
			final String objectType ) {
		boolean result = true;
		final List<WebElement> trList = getTableRowsListFromDiv(tableDivEl);
		String prevValue = null;
		String currentValue = null;
		for (int i = 1; i < trList.size(); i++) {
			final WebElement tr = trList.get(i);
			final List<WebElement> tdList = tr.findElements(By.tagName("td"));
			if (i == 1) {
				currentValue = tdList.get(colNum).getText();
			} else {
				prevValue = currentValue;
				currentValue = tdList.get(colNum).getText();
				if (sortOrder.equals("asc")) {
					if (objectType.equals("String")
							&& prevValue.compareToIgnoreCase(currentValue) < 0) {
						result = false;
						break;
					}
				} else {
					if (objectType.equals("String")
							&& currentValue.compareToIgnoreCase(prevValue) < 0) {
						result = false;
						break;
					}
				}
			}
		}
		return result;
	}

	/**
	 * This method clicks on cancel button on the create Room Details page
	 */
	public void clickCancel ( ) {
		final Button cancelButton = new Button(By.id("roomCreateCancel"));
		cancelButton.click();
		waitForInVisibilityOfElement(By.id("roomContentMenuOptions"));
	}

	/**
	 * This method clicks on cancel button on the Edit Room Details page
	 */
	public void clickCancelInEdit ( ) {
		final WebElement parentElement = waitForElement(By.id("room_div"));
		final Button cancelButton = new Button(parentElement, "Cancel");
		cancelButton.click();
		waitForInVisibilityOfElement(By.id("roomContentMenuOptions"));
	}

	/**
	 * This method deletes all the Room details
	 */
	public void resetData ( ) {
		deleteAllRooms();
	}

	private void deleteAllRooms ( ) {
		int count = getRoomDetailsRowCount();
		while (count > 1) {
			final WebElement parentEl = waitForElement(By.id("roomContent"));
			final Table table = new Table(parentEl, 1);
			table.getCell(1, "Room Type").click();
			waitForElement(By.id("room_div"), 20);
			selectRoomDetailsOptions("Delete");
			deleteRoomDetailsWithOK();
			verifyRowcount(count - 1);
			clickRefreshRoomDetails();
			waitForInVisibilityOfElement(By.className("message"));
			count = getRoomDetailsRowCount();
		}
	}

	/**
	 * This method clicks on the ok button for the pop up display
	 */
	public void deleteRoomDetailsWithOK ( ) {
		acceptAlert();
		// sleep(2);
	}

	/**
	 * This method clicks on the cancel button of the pop up display
	 */
	public void deleteRoomDetailsWithCancel ( ) {
		dismissAlert();
	}

	/**
	 * This method verifies the row count with the expected value
	 * 
	 * @param expectedCount
	 * @return boolean
	 */
	public boolean verifyRowcount ( final int expectedCount ) {
		for (int i = 0; i < 10; i++) {
			try {
				final int rowCount = getRoomDetailsRowCount();
				if (expectedCount == rowCount) {
					return true;
				} else {
					sleep(1);
					continue;
				}
			} catch (final Exception e) {
				continue;
			}
		}
		return false;

	}

	/**
	 * @param parentLocator
	 * @param message
	 * @return
	 */
	public boolean verifyRecordUpdatedMessage ( final By parentLocator, final String message ) {
		final WebElement parentEl = waitForElement(parentLocator);
		waitForElement(parentEl, By.className("message"));
		if (getElement(parentEl, By.className("message")).getText().contains(message)) {
			return true;
		}
		return false;
	}

	/**
	 * This method verifies for the record updated message and will return true
	 * or false based on the message
	 * 
	 * @return boolean
	 */
	public boolean isMessageDisplayed ( ) {
		return isElementPresent(By.className("message"));
	}

	/**
	 * @param inputMap
	 */
	public void selectRoom ( final Map<String, String> inputMap ) {
		sleep(2);
		WebElement parentEl = waitForElement(By.id("roomContent"));
		Table table = new Table(parentEl, 1);
		for (int i = 1; i < table.getRowCount(); i++) {
			boolean flag = true;
			for (final String key : inputMap.keySet()) {
				final String value = inputMap.get(key);
				if (!value.equalsIgnoreCase(table.getCellData(i, key))) {
					flag = false;
					break;
				}
			}
			if (flag) {
				for (int j = 0; j < 10; j++) {
					try {
						parentEl = waitForElement(By.id("roomContent"));
						table = new Table(parentEl, 1);
						table.getCell(i, "Room Type").click();
						waitForElement(By.id("room_div"), 5);
						break;
					} catch (final Exception e) {
						sleep(1);
						continue;
					}
				}
				break;
			}
		}
	}

	public String getRoomId ( final Map<String, String> inputMap ) {
		sleep(2);
		String roomId = null;
		int count = getRoomDetailsRowCount();
		if (count < 10) {
			int i = 1;
			for (final String key : inputMap.keySet()) {
				final String value = inputMap.get(key);
				final WebElement parentEl = waitForElement(By.id("roomContent"));
				final Table table = new Table(parentEl, 1);
				while (i < count) {
					// System.out.println(j + " page : " + i + " = " +
					// table.getCellData(i, key));

					if (value.trim().equalsIgnoreCase(table.getCellData(i, key))) {
						final String id = table.getRowElements().get(i).getAttribute("id");
						if (StringUtils.isNotBlank(id)) {
							roomId = id.substring(5, id.length());
							return roomId;
						}
					}
					i++;
				}
			}
		} else {
			for (final String key : inputMap.keySet()) {
				final String value = inputMap.get(key);
				List<WebElement> pagination = getDriver().findElements(
						By.xpath("//div[@class='paginateButtons']//a"));
				for (int j = 0; j < pagination.size(); j++) {
					int i = 1;
					final WebElement parentEl = waitForElement(By.id("roomContent"));
					final Table table = new Table(parentEl, 1);
					while (i < count) {
						// System.out.println(j + " page : " + i + " = " +
						// table.getCellData(i, key));
						if (value.trim().equalsIgnoreCase(table.getCellData(i, key))) {
							final String id = table.getRowElements().get(i).getAttribute("id");
							if (StringUtils.isNotBlank(id)) {
								roomId = id.substring(5, id.length());
								return roomId;
							}
						}
						i++;
					}
					pagination = getDriver().findElements(
							By.xpath("//div[@class='paginateButtons']//a"));
					pagination.get(j).click();
					sleep(2);
					count = getRoomDetailsRowCount();
				}
			}
		}
		return roomId;
	}

	public void deleteRoomCategoty ( final Map<String, String> inputMap ) {
		sleep(2);
		int count = getRoomDetailsRowCount();
		for (final String key : inputMap.keySet()) {
			final String value = inputMap.get(key);
			int i = 1;
			while (count > 1) {
				final WebElement parentEl = waitForElement(By.id("roomContent"));
				final Table table = new Table(parentEl, 1);
				final String roomType = table.getCellData(i, key).split(" ")[0];
				if (value.trim().equalsIgnoreCase(roomType.trim())) {
					table.getCell(i, "Room Type").click();
					waitForElement(By.id("room_div"), 20);
					selectRoomDetailsOptions("Delete");
					deleteRoomDetailsWithOK();
					verifyRowcount(count - 1);
					clickRefreshRoomDetails();
					waitForInVisibilityOfElement(By.className("message"));
					count = getRoomDetailsRowCount();
					i--;
				} else if (value.charAt(0) < table.getCellData(i, key).charAt(0)) {
					return;
				} else
					i++;
			}
		}
	}

	public void deleteRoomCategotyOTHER ( final Map<String, String> inputMap ) {
		sleep(2);
		final String roomId = null;
		int count = getRoomDetailsRowCount();

		if (count < 10) {
			int i = 1;
			for (final String key : inputMap.keySet()) {
				final String value = inputMap.get(key);
				final WebElement parentEl = waitForElement(By.id("roomContent"));
				final Table table = new Table(parentEl, 1);
				while (i < count) {
					if (value.trim().equalsIgnoreCase(table.getCellData(i, key))) {
						table.getCell(i, "Room Type").click();
						waitForElement(By.id("room_div"), 20);
						selectRoomDetailsOptions("Delete");
						deleteRoomDetailsWithOK();
						count = getRoomDetailsRowCount();
						i--;
						return;
					} else if (value.charAt(0) < table.getCellData(i, key).charAt(0)) {
						return;
					} else
						i++;
				}

			}
		}

		else {

			for (final String key : inputMap.keySet()) {
				final String value = inputMap.get(key);
				List<WebElement> pagination = getDriver().findElements(
						By.xpath("//div[@class='paginateButtons']//a"));
				for (int j = 0; j < pagination.size(); j++) {
					int i = 1;
					final WebElement parentEl = waitForElement(By.id("roomContent"));
					final Table table = new Table(parentEl, 1);
					while (i < count) {
						if (value.trim().equalsIgnoreCase(table.getCellData(i, key))) {
							table.getCell(i, "Room Type").click();
							waitForElement(By.id("room_div"), 20);
							selectRoomDetailsOptions("Delete");
							deleteRoomDetailsWithOK();
							count = getRoomDetailsRowCount();
							i--;
							return;

						} else if (value.charAt(0) < table.getCellData(i, key)
								.charAt(0)) {
							return;
						} else
							i++;
					}
					pagination = getDriver().findElements(
							By.xpath("//div[@class='paginateButtons']//a"));
					pagination.get(j).click();
					sleep(2);
					count = getRoomDetailsRowCount();
				}

			}
		}
	}
}
