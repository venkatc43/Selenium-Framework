package com.kuoni.qa.automation.util

import com.kuoni.qa.automation.dto.PropertyDTO

class PropertyXmlUtil {

	def PropertyDTO readXML(propertyXml) {

		PropertyDTO xmlData = new PropertyDTO()

		
		def p = propertyXml.recordset.record.property
		//Reading values from each XML File
		xmlData.setPropertyId(p.@propertyId[0].toInteger())
		xmlData.setAddressId(p.addresses.address.@addressId[0].toInteger())
		xmlData.setAddressActive(p.addresses.address.@active[0])
		xmlData.setAddressType(p.addresses.address.@type[0])
		xmlData.setAddressL1(p.addresses.address.addressLine1.text())
		xmlData.setAddressL2(p.addresses.address.addressLine2.text())
		xmlData.setAddressL3(p.addresses.address.addressLine3.text())
		xmlData.setPostCode(p.addresses.address.postCode.text())
		xmlData.setCityId(p.addresses.address.city.@cityId[0].toInteger())
		xmlData.setCountryId(p.addresses.address.country.@countryId[0].toInteger())
		xmlData.setLocationCode(p.locationCode.text())
		xmlData.setGeoLatitude(p.geoCodes.latitude.text().toFloat())
		xmlData.setGeoLongitude(p.geoCodes.longitude.text().toFloat())
		//xmlData.setLegCityCode(p.legacyProperty.cityCode.text())  Removed in 0.7 schema
		//xmlData.setLegPropertyCode(p.legacyProperty.propertyCode[0].text())
		xmlData.setPropertyName(p.names.name.text.text())
		xmlData.setStarRating(p.rating.text())
		xmlData.setCheckinTime(p.checkInTime.text())
		xmlData.setCheckoutTime(p.checkOutTime.text())
		xmlData.setMinAge(p.minimumAge.text().toInteger())
		xmlData.setTelephone(p.telephone.text())
		xmlData.setCoachDrop(p.coachDropOff.text())
		xmlData.setTotalRooms(p.totalRooms.text().toInteger())


		return xmlData

	}
}
