package com.kuoni.qa.automation.datacreate.test.helper

import com.kuoni.qa.automation.gc.test.PropertyProvisionsTest
import com.kuoni.qa.util.CommonUtil
import com.kuoni.qa.util.ConfigProperties
import com.mediaocean.qa.framework.utils.ExcelUtil

class PropertyProvisionsTestHelper {
	
	private ExcelUtil excelData
	
	public def updatePropertyProvisions(String sheetName){
		boolean executionFlag = false
		PropertyProvisionsTest test = new PropertyProvisionsTest(ConfigProperties.getVlaue("driverSheetPath"),ConfigProperties.getVlaue("dataSheetPathSprint4"),sheetName)
		test.executeDataScriptsForPropertyProvisionsUpdate()
		executionFlag = true
		excelData = test.getData()
		return executionFlag
	}
	
	public def readXMLFromQ(String filePath, String inputQName, String sheetName){
		boolean executionFlag = false
		def value = null
		String propertyId = excelData.getKeyValue(sheetName, "PropertyId")
		executionFlag = CommonUtil.readXMLFromQ(filePath,inputQName, propertyId)
		return executionFlag
	}

	public def validatePropertyProvisionsOutputXML(String sheetName, String xmlPath){
		
		boolean executionFlag = false
		def xmlFile = new File(xmlPath)
		def changerecords = new XmlParser().parse(xmlFile)
		
		try{
			
			def value =  changerecords.recordset.record.property.provisions.parking.find{(it.@type == "Valet") && (it.@chargeApplies == "true")}
			assert value != null,"parking type valet with charges applicable true is not exist with canonical xml"
			assert value.text() == "true", "Invalid parking type Valet with canonical xml"
			
			value =  changerecords.recordset.record.property.provisions.parking.find{(it.@type == "Coach") && (it.@chargeApplies == "true")}
			assert value != null,"parking type Coach with charges applicable true is not exist with canonical xml"
			assert value.text() == "true", "Invalid parking type Coach with canonical xml"
			
			value =  changerecords.recordset.record.property.provisions.parking.find{(it.@type == "Car") && (it.@chargeApplies == "true")}
			assert value != null,"parking type Car with charges applicable true is not exist with canonical xml"
			assert value.text() == "true", "Invalid parking type Car with Canonical xml"
			
			value =  changerecords.recordset.record.property.provisions.shuttle.find{(it.@type == "Centre") && (it.@chargeApplies == "true")}
			assert value != null,"shuttle type Centre with charges applicable true is not exist with canonical xml"
			assert value.text() == "true", "Invalid shuttle type Centre with Canonical xml"
			
			value =  changerecords.recordset.record.property.provisions.shuttle.find{(it.@type == "Airport") && (it.@chargeApplies == "true")}
			assert value != null,"shuttle type Airport with charges applicable true is not exist with canonical xml"
			assert value.text() == "true", "Invalid shuttle type Airport with Canonical xml"
			
			executionFlag = true
			
		}catch(java.lang.AssertionError e){
			println e
			executionFlag = false
		}catch(Exception e){
			println e
			executionFlag = false
		}
		changerecords = null
		return executionFlag
	}
}
