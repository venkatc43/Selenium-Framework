package com.kuoni.qa.automation.page.object.cities;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.gta.travel.page.base.GSPageBase;
import com.mediaocean.qa.framework.selenium.ui.controls.Button;
import com.mediaocean.qa.framework.selenium.ui.controls.ComboBox;

public class CityListPage extends GSPageBase{


	public CityListPage() {
		super(getDriver());
	}
	
	public static CityListPage getInstance(){
		return PageFactory.initElements(getDriver(), CityListPage.class);
	}
	

	public CityResultListPage searchCities(Map<String, String> map){
		
		if (map.containsKey("Country")){
			ComboBox propTypeComboBox = new ComboBox(By.id("countryId"));
			propTypeComboBox.select(map.get("Country"));
		}
		if (map.containsKey("City")){
			ComboBox propTypeComboBox = new ComboBox(By.id("cityName"));
			propTypeComboBox.select(map.get("City"));
		}
		
		Button searchButton = new Button("search");
		searchButton.click();
		
		return PageFactory.initElements(getDriver(), CityResultListPage.class);
	}
	
	public CityPage selectCreateCity(){

		WebElement create = waitForElement(By.linkText("Create"));
		create.click();
		return PageFactory.initElements(getDriver(), CityPage.class);
	}
	

}
