package com.kuoni.qa.automation.dto

class RegionDTO {
	
	def regionCode
	def regionDesc
	def countryId
	

}
