package com.kuoni.qa.automation.atg.test

import org.testng.asserts.SoftAssert;

import spock.lang.Shared;
import spock.lang.Specification
import spock.lang.Unroll;
import static com.kuoni.qa.automation.util.ReadFilesUtil.getFiles

import com.kuoni.atg.jaxbclasses.ChangerecordsType
import com.kuoni.atg.jaxbclasses.DescriptionType
import com.kuoni.atg.jaxbclasses.ErrataDisturbanceDescriptionsRecord
import com.kuoni.qa.automation.common.properties.EnvironmentProperties;
import com.kuoni.qa.automation.dao.GetReferenceDataDescription;
import com.kuoni.qa.automation.dto.ReferenceDataDTO
import com.kuoni.qa.automation.helper.JaxbHelper
import com.kuoni.qa.automation.spock.annotation.Regression;
import com.kuoni.qa.automation.util.PerformDataLoadUtil

class VerifyErrataDisturbanceRefData_CB6593 extends Specification{

	SoftAssert softAssert = new SoftAssert()
	GetReferenceDataDescription offerDesc = new GetReferenceDataDescription()

	@Shared
	EnvironmentProperties envProp = new EnvironmentProperties()

	def setupSpec() {

		def folderLocation = envProp.getValueForProperty("istDataLoc")+"/ErrataDisturbanceDescriptionsRecord"
		PerformDataLoadUtil dataLoad = new PerformDataLoadUtil()
		dataLoad.changeTestDataReaderLocation(folderLocation)
		dataLoad.importFilesandPerformLoadfromQueue()
	}

	@Regression
	@Unroll
	public "verifyReferenceData for : #xmlFile.getName()"() {

		given: "The XmLs are available at the desired Location"
		ReferenceDataDTO data
		JaxbHelper jaxbObj = new JaxbHelper()

		ChangerecordsType xml = jaxbObj.buildRequestJaxbClass(xmlFile)

		ErrataDisturbanceDescriptionsRecord recordNode = xml.recordset.get(0).record.get(0)

		String errataAreaCode = recordNode.getErrataDisturbanceDescriptions().getAt("disturbance")

		List<DescriptionType> erratDisturbDescList =  recordNode.getErrataDisturbanceDescriptions().getErrataDisturbanceDescription()


		println "\n xml File : " + xmlFile.getName()
		println "Code : " + errataAreaCode
		int languageCount = recordNode.getErrataDisturbanceDescriptions().getErrataDisturbanceDescription().size()
		println "Xml Language Count :  " + languageCount
		when:"The data can be read from XML and Database"
		for(DescriptionType errataDisturbDescriptions: erratDisturbDescList) {
			String language = errataDisturbDescriptions.getLanguage().value()
			String ErrataDisturbDescription = errataDisturbDescriptions.getText()
			data = offerDesc.getOfferDesc(errataAreaCode,language,315)

			//println "DB Language Count : " + data.getLanguageCount()
			if(languageCount == data.getLanguageCount())

			{

				println "\n Language::" + language + "::"
				println "xmlErrataDisturbDescription :  " + ErrataDisturbDescription
				println "\n Database ErratDisturb Desc : " +  data.getDataDescription()

				softAssert.assertEquals(ErrataDisturbDescription, data.getDataDescription(),"ErrataDisturbDescription :"+ ErrataDisturbDescription + " Doesnot Match with Database : "+ data.getDataDescription())

			}

			else
				softAssert.assertEquals(languageCount,data.getLanguageCount(),"The Language count doesn't match with Database")

		}

		softAssert.assertAll()
		then:"The XML Descriptions should match with Database"

		where:

		xmlFile << getFiles("/ErrataDisturbanceDescriptionsRecord")


	}

}
