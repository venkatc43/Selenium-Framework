package com.kuoni.qa.automation.coh.tests

import org.springframework.context.support.ClassPathXmlApplicationContext
import spock.lang.Specification
import com.gta.nova.api.client.ClientService
import com.gta.nova.api.search.PriceAvailabilityService
import com.gta.nova.api.search.PropertyPriceAvailabilityRequest
import com.gta.nova.api.search.PropertyPriceAvailabilityResponse
import com.kuoni.qa.automation.spock.annotation.Sanity
import com.tangosol.coherence.component.util.Collections
import org.springframework.context.support.ClassPathXmlApplicationContext
import java.util.Collections
import spock.lang.Specification

import com.gta.nova.api.client.ClientService
import com.gta.nova.api.search.PriceAvailabilityService
import com.gta.nova.api.search.PropertyPriceAvailabilityRequest
import com.gta.nova.api.search.PropertyPriceAvailabilityResponse
import com.kuoni.qa.automation.spock.annotation.Sanity
 



class RequestReturnPropertyDetailsTest extends Specification{
	//Property
	private static final String PRICE_AVAILABILITY_BEANS_FILE_LOCATION = "classpath:/spring/price-availability-client-beans.xml";
	private static final String PRICE_AVAILABILITY_SERVICE_BEAN_NAME = "priceAvailabilityServiceClient";
	 
	ClassPathXmlApplicationContext ctx = new ClassPathXmlApplicationContext(PRICE_AVAILABILITY_BEANS_FILE_LOCATION);
	PriceAvailabilityService priceAvailabilityService = (PriceAvailabilityService) ctx.getBean(PRICE_AVAILABILITY_SERVICE_BEAN_NAME);
	
	//Client
	private static final String CLIENT_ATTRIBUTES_API_BEANS_FILE_LOCATION = "classpath:/spring/client-service-client-beans.xml";
	private static final String CLIENT_ATTRIBUTES_SERVICE_BEAN_NAME = "clientServiceClient";
	ClassPathXmlApplicationContext clientContext = new ClassPathXmlApplicationContext(CLIENT_ATTRIBUTES_API_BEANS_FILE_LOCATION);
	ClientService clientService = (ClientService) clientContext.getBean(CLIENT_ATTRIBUTES_SERVICE_BEAN_NAME);

	Calendar calendar = new GregorianCalendar()
	Date effectiveDate = calendar.getTime()


	// Functional Tests

		@Sanity
		def "returnProeprty_Hotel_Id_And_Name" () {
			given: "The property exists in the cahe - 17037"
					def searchPropertyId = 17022L
			and: "The property name is known - Banks_Data, London"
					def expectedPropertyName = "Banks_Data, London"
			and: "The property name is in english"
							  
			when: "I search for a property ID 17037"
				  PropertyPriceAvailabilityRequest request = new PropertyPriceAvailabilityRequestBuilder()
					.checkOutDate(effectiveDate+2)
					.ids(Collections.singleton(searchPropertyId))
					.build()
					PropertyPriceAvailabilityResponse response = priceAvailabilityService.search(request)
				  
				  def actualResult = response.getPricedPropertyMap().get(searchPropertyId).getId()
							  
			then: "I receive a response from the cache that contains the property ID - 17037"
				  println "Property Id - " + actualResult
				  assert actualResult == searchPropertyId
			and: "property name is Banks_Data, London"
				  def actualPropertyName = response.getPricedPropertyMap().get(searchPropertyId).getName()
				  println "Property Name - " + actualPropertyName
				  assert actualPropertyName == expectedPropertyName
		}
				
		@Sanity
		def "returnNullForInvalidPropertySearch" () {
					def searchPropertyId = "GTA123"
			when: " I search for an invalid property ID GTA123"
					PropertyPriceAvailabilityRequest request = new PropertyPriceAvailabilityRequestBuilder()
					.checkOutDate(effectiveDate+2)
					.ids(Collections.singleton(searchPropertyId))
					.build()
					PropertyPriceAvailabilityResponse response = priceAvailabilityService.search(request)
			
			then: "I receive a null response"
					assert response.getPricedPropertyMap().isEmpty() == true
		}
		
	
}
