package com.kuoni.qa.automation.page.object.contracts;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.gta.travel.page.base.GSPageBase;
import com.mediaocean.qa.framework.selenium.ui.controls.Button;
import com.mediaocean.qa.framework.selenium.ui.controls.CheckBox;
import com.mediaocean.qa.framework.selenium.ui.controls.ComboBox;
import com.mediaocean.qa.framework.selenium.ui.controls.Link;
import com.mediaocean.qa.framework.selenium.ui.controls.RadioButton;
import com.mediaocean.qa.framework.selenium.ui.controls.Table;
import com.mediaocean.qa.framework.selenium.ui.controls.TextBox;

public class GeneralDetailsProviderSectionPageCustom extends GSPageBase {

	public GeneralDetailsProviderSectionPageCustom() {
		super(getDriver());
	}

	public static GeneralDetailsProviderSectionPageCustom getInstance() {
		return PageFactory.initElements(getDriver(), GeneralDetailsProviderSectionPageCustom.class);
	}

	public boolean isProviderRowCollapsed() {
		try {
			getDriver().findElement(By.id("propertyContract_div"));
		} catch (Exception e) {
			return true;
		}
		return false;
	}

	public boolean verifyRecordUpdatedMessage(String message) {
		WebElement parentEl = waitForElement(By.id("propertyContractContent"));
		sleep();
		if (getElement(parentEl, By.className("message")).getText().contains(message)) {
			return true;
		}
		return false;
	}

	public boolean verifyFieldError(By locator, String message) {
		sleep();
		WebElement element = waitForElement(locator);
		if (element.getText().contains(message)) {
			return true;
		}
		return false;
	}

	public boolean verifyReleasetimeData(String releaseTime) {
		sleep();
		WebElement divEl = waitForElement(By.id("propertyContract_div"));
		WebElement tr = getTRElementFromTable(divEl, 2);
		String text = getElements(tr, By.tagName("td")).get(1).getText();
		if (!text.equalsIgnoreCase(releaseTime)) {
			return true;
		}
		return false;
	}

	public int getProviderListcount() {
		WebElement parentElement = waitForElement(By.id("propertyContractContent"));
		Table providerTable = new Table(parentElement, 1);
		return providerTable.getRowCount();
	}

	public void selectProviderFromTheList(Map<String, String> map) {
		sleep(1);
		WebElement parentElement = waitForElement(By.id("propertyContractContent"));
		Table providerTable = new Table(parentElement, 1);
		for (int i = 1; i < providerTable.getRowCount(); i++) {
			boolean flag = true;
			for (String key : map.keySet()) {
				String value = map.get(key);
				if (providerTable.getCellData(i, key).equalsIgnoreCase(value)) {
					continue;
				} else {
					flag = false;
					break;
				}
			}
			if (flag) {
				providerTable.getCell(i, "Provider").click();
				sleep();
				return;
			}
		}
	}

	public void selectProviderOptions(String optionName) {
		sleep();
		WebElement menuElement = waitForElement(By.id("propertyContractContentMenuOptions"));
		if (Link.isLinkVisible(menuElement, "Select Option")) {
			Link slectOptionLink = new Link(menuElement, "Select Option");
			slectOptionLink.clickLink();
		}

		waitForElement(By.linkText(optionName));
		Link optionLink = new Link(menuElement, optionName);
		optionLink.clickLink();
		sleep();
	}

	public void createProvider(Map<String, String> inputMap) {

		if (inputMap.containsKey("provider")) {
			String providerValue = inputMap.get("provider");
			sleep(3);
			waitForElement(By.id("providerId"));
			ComboBox providerSelect = new ComboBox(By.id("providerId"));
			providerSelect.select(providerValue);
		}
		if (inputMap.containsKey("model")) {

			String value = inputMap.get("model");
			RadioButton modelRB = null;
			if (value.equals("STATIC"))
				modelRB = new RadioButton(By.id("selectModel-S"), value);
			else
				modelRB = new RadioButton(By.id("selectModel-M"), value);
			modelRB.select();
		}

		if (inputMap.containsKey("business type")) {
			String businessType = inputMap.get("business type");
			sleep(3);
			waitForElement(By.id("contractType"));
			ComboBox providerSelect = new ComboBox(By.id("contractType"));
			providerSelect.select(businessType);
		}

		if (inputMap.containsKey("margin amount")) {
			TextBox marginTB = new TextBox(By.id("margin"));
			marginTB.setText(inputMap.get("margin amount"));
		}

		if (inputMap.containsKey("channel")) {
			CheckBox.uncheckAll(By.id("channel"));
			String channel = inputMap.get("channel");
			String[] channelOptions = channel.split(",");
			for (int i = 0; i < channelOptions.length; i++) {
				CheckBox channelCB = new CheckBox(By.id("channel"), channelOptions[i]);
				channelCB.check();
			}
		}
		if (inputMap.containsKey("inventory style")) {
			String inventoryStyle = inputMap.get("inventory style");
			RadioButton inventoryStyleRB = null;
			if (inventoryStyle.equalsIgnoreCase("room")) {
				inventoryStyleRB = new RadioButton(By.id("inventoryByRoom1"), "true");
			} else {
				inventoryStyleRB = new RadioButton(By.id("inventoryByRoom2"), "false");
			}
			inventoryStyleRB.select();
		}
		if (inputMap.containsKey("release time")) {
			TextBox releaseTimeTB = new TextBox(By.id("releaseTime"));
			releaseTimeTB.setText(inputMap.get("release time"));
		}
		if (inputMap.containsKey("currency")) {
			ComboBox releaseTimeCB = new ComboBox(By.id("currency"));
			releaseTimeCB.select(inputMap.get("currency"));
		}

		/*
		 * if (inputMap.containsKey("allow raise cap")){ String inventoryStyle =
		 * inputMap.get("allow raise cap"); RadioButton allowRaiseCapRB = null;
		 * if (inventoryStyle.equalsIgnoreCase("no")){ allowRaiseCapRB = new
		 * RadioButton(By.id("allowRaiseCap"), "false"); }else{ allowRaiseCapRB
		 * = new RadioButton(By.id("allowRaiseCap"), "true"); } String value =
		 * inventoryStyle.equalsIgnoreCase("yes") ? "true" : "false";
		 * RadioButton allowRaiseCapRB = new RadioButton(By.id("allowRaiseCap"),
		 * value); allowRaiseCapRB.select(); } if
		 * (inputMap.containsKey("allow RSP")){ String inventoryStyle =
		 * inputMap.get("allow RSP"); String value =
		 * inventoryStyle.equalsIgnoreCase("yes") ? "true" : "false";
		 * RadioButton allowRSPRB = new RadioButton(By.id("allowRSP"), value);
		 * allowRSPRB.select(); }
		 */
	}

	public void cancelNewProvider() {
		Button cancelButton = new Button(By.id("propertyContractCreateCancel"));
		cancelButton.click();
	}

	public void saveNewProvider() {
		WebElement parentEL = waitForElement(By.id("propertyContract_create"));
		Button saveButton = new Button(parentEL, "Save");
		saveButton.click();
	}

	public void editProvider(Map<String, String> inputMap) {
		if (inputMap.containsKey("channel")) {
			CheckBox.uncheckAll(By.id("channel"));
			String channel = inputMap.get("channel");
			String[] channelOptions = channel.split(",");
			for (int i = 0; i < channelOptions.length; i++) {
				waitForElement(By.id("channel"));
				CheckBox channelCB = new CheckBox(By.id("channel"), channelOptions[i]);
				channelCB.check();
			}
		}

		if (inputMap.containsKey("inventory style")) {

			String value = inputMap.get("inventory style");
			RadioButton room = null;
			if (inputMap.containsKey("Model")) {
				if (inputMap.get("Model").equalsIgnoreCase("MARGIN")) {
					// do nothing
				} else {
					if (value.equalsIgnoreCase("room"))
						room = new RadioButton(By.id("inventoryByRoom"), "true");
					else
						room = new RadioButton(By.id("inventoryByRoom"), "false");
					room.select();
				}
			}

		}
		if (inputMap.containsKey("margin amount")) {
			TextBox marginTB = new TextBox(By.id("margin"));
			marginTB.setText(inputMap.get("margin amount"));
		}

		if (inputMap.containsKey("release time")) {
			TextBox releaseTimeTB = new TextBox(By.id("releaseTime"));
			releaseTimeTB.setText(inputMap.get("release time"));
		}
		if (inputMap.containsKey("currency")) {
			ComboBox releaseTimeCB = new ComboBox(By.id("releaseTime"));
			releaseTimeCB.select(inputMap.get("currency"));
		}

	}

	public void selectFromCOntract(Map<String, String> inputMap) {
		WebElement parentElement = waitForElement(By.id("propertyContractContent"));
		Table resultsTable = new Table(parentElement, 1);
		for (int i = 1; i < resultsTable.getRowCount(); i++) {
			boolean isRecordFound = true;
			for (String key : inputMap.keySet()) {
				String value = inputMap.get(key);
				WebElement cellElement = resultsTable.getCell(i, key);
				if (!cellElement.getText().equalsIgnoreCase(value)) {
					isRecordFound = false;
					break;
				}
			}
			if (isRecordFound) {
				resultsTable.clickOnRow(i);
				break;
			}
		}
	}

	public void updateEditProvider() {
		WebElement parentEL = waitForElement(By.id("propertyContract_div"));
		Button updateButton = new Button(parentEL, "Update");
		updateButton.click();
	}

	public void cancelEditProvider() {
		WebElement parentEL = waitForElement(By.id("propertyContract_div"));
		Button cancelButton = new Button(parentEL, "Cancel");
		cancelButton.click();
		sleep(2);
	}

	public void deleteAndOKProvider() {
		acceptAlert();
		sleep(4);
	}

	public boolean verifyAllowRaiseCap() {

		WebElement parentEl = waitForElement(By.id("propertyContract_tr"), 3);
		sleep();
		if (!parentEl.getText().contains("Allow Raise Cap")) {
			return true;
		}
		return false;

	}

	public boolean verifyAllowRSP() {

		WebElement parentEl = waitForElement(By.id("propertyContract_tr"), 3);
		sleep();
		if (!parentEl.getText().contains("Allow RSP")) {
			return true;
		}
		return false;

	}

	public boolean expandSelfServicePermissions() {

		WebElement parentEl = waitForElement(By.id("selfServiceShowSection"));
		getElement(parentEl, By.className("clickable")).click();
		sleep(1);
		WebElement element = waitForElement(By.id("selfServiceArrow"));
		if (element.getAttribute("src").contains("ArrowDown")) {
			return true;
		}
		return false;
	}

	public boolean verifyAllowRaiseCapDisplay() {
		WebElement parentEl = waitForElement(By.id("propertyContract_tr"));
		sleep();
		if (parentEl.getText().contains("Allow Raise Cap")) {
			return true;
		}
		return false;

	}

	public void clickEditOnSelfServicePermission() {
		sleep();
		WebElement menuElement = waitForElement(By.id("selfServiceContentMenuOptions"));
		waitForElement(By.linkText("Edit"));
		Link optionLink = new Link(menuElement, "Edit");
		optionLink.clickLink();
		sleep();

	}

	public void selectSelfServicePermission(String value) {
		waitForElement(By.id("isPermitted0"));
		RadioButton selfservicepermissionOptionRB = new RadioButton(By.id("isPermitted0"), value);
		selfservicepermissionOptionRB.select();
		if (value.equals("false")) {
			waitForElement(By.id("selfServiceEdit"));
		} else {
			if (value.equals("true")) {
				waitForElement(By.id("selfServiceEdit"));
			}
		}

	}

	public void cancelSelfServicePermission() {
		WebElement parentElement = waitForElement(By.id("selfServiceContent"));
		Button cancelButton = new Button(parentElement, "Cancel");
		cancelButton.click();
		sleep();

	}

	public void updateselfpermission(String buttonLabel) {
		WebElement parentElement = waitForElement(By.id("selfServiceContent"));
		Button updateButton = new Button(parentElement, buttonLabel);
		updateButton.click();
		sleep();
	}

	public boolean verifyAllowRaiseCapOption() {

		WebElement parentEl = waitForElement(By.id("propertyContractCreate"));
		sleep();
		if (!parentEl.getText().contains("Allow Raise Cap")) {
			return true;
		}
		return false;

	}

	public boolean verifyAllowRSPOption() {

		WebElement parentEl = waitForElement(By.id("propertyContractCreate"), 3);
		sleep();
		if (!parentEl.getText().contains("Allow RSP")) {
			return true;
		}
		return false;
	}

	public boolean verifyMessage(String message) {
		WebElement parentElement = waitForElement(By.id("selfServiceContent"));
		String text = parentElement.findElement(By.className("message")).getText();
		if (text.contains(message)) {
			return true;
		}
		return false;
	}

	public boolean verifyAllowRSPDisplay() {
		WebElement parentEl = waitForElement(By.id("propertyContract_tr"));
		sleep();
		if (parentEl.getText().contains("Allow RSP")) {
			return true;
		}
		return false;
	}

	public boolean verifyAllowMinimumNightsMaintenanceDisplay() {
		WebElement parentEl = waitForElement(By.id("propertyContract_tr"));
		sleep();
		if (parentEl.getText().contains("Allow Minimum Nights Maintenance")) {
			return true;
		}
		return false;
	}

	public void selectSelfServicePermissionMinNights(String value) {

		waitForElement(By.id("isPermitted2"));
		RadioButton selfservicepermissionOptionRB = new RadioButton(By.id("isPermitted2"), value);
		selfservicepermissionOptionRB.select();
		if (value.equals("false")) {
			waitForElement(By.id("selfServiceEdit"));
		} else {
			if (value.equals("true")) {
				waitForElement(By.id("selfServiceEdit"));
			}
		}

	}

	public boolean verifyChannelPermission() {
		WebElement theCheckBox = waitForElement(By.xpath("//input[@id='channel' and @type='checkbox']"));

		if (theCheckBox.isEnabled())

			return true;
		else
			return false;
	}

	public boolean verifydisabledChannelPermission() {
		WebElement theCheckBox = waitForElement(By.xpath("//input[@id='channel' and @type='checkbox' and @disabled='disabled']"));

		if (!theCheckBox.isEnabled())

			return true;
		else
			return false;
	}

	public void selectFirstProviderFromTheList() {
		selectProviderOptions("Refresh");
		sleep(5);
		WebElement parentElement = waitForElement(By.id("propertyContractContent"));
		Table providerTable = new Table(parentElement, 1);
		if(!providerTable.getRowElements().get(2).getAttribute("id").contains("propertyContract_tr")) {
			providerTable.getCell(1, "Provider").click();
		}
		sleep();
		return;
	}
}
