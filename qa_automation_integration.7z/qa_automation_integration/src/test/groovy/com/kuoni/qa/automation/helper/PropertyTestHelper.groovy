package com.kuoni.qa.automation.helper

import com.kuoni.qa.automation.common.properties.EnvironmentProperties
import com.kuoni.qa.automation.dto.PropertyDTO
import com.kuoni.qa.automation.util.PropertyUtil
import org.testng.asserts.SoftAssert
import spock.lang.Specification


class PropertyTestHelper {


	PropertyDTO facilityData
	def envprop = new EnvironmentProperties()


	//Facilities

	def verifyFacility(propertyXml,dbData,data,propertyId,softAssert)
	{
		def facility = propertyXml.recordset.record.property.facilities.facility

		List facilityList = envprop.getValueForProperty("facilityList").split(',').toList()

		facilityList.each {fcode->

			if((facility.findAll{it.'@code'== fcode}.'@text'[0])!=null) {

				softAssert.assertEquals(data.getFacilities(propertyId, fcode),true,"\n Faciltity  : " + fcode + " Doesn't Exist in Database or Duplicates Exist in Database")

				println "Facility  : " + fcode + " Exists in Database"
			}
		}

	}


	//Informations

	def verifyInformations(propertyXml,dbData,data,propertyId,softAssert)
	{

		def information = propertyXml.recordset.record.property.informations.information
		List informationList = envprop.getValueForProperty("informationList").split(',').toList()

		informationList.each {fcode->
			if((information.findAll{it.'@code'== fcode}.'@text'[0])!=null) {

				softAssert.assertEquals(data.getInformations(propertyId, fcode),true,"\n Information  : " + fcode + " Doesn't Exist in Database or Duplicates Exist in Database")

				println "Information  : " + fcode + " Exists in Database"

			}
		}

	}


	//Activities
	def verifyActivity(propertyXml,dbData,data,propertyId,softAssert)
	{

		def activity = propertyXml.recordset.record.property.activities.activity
		List activityList = envprop.getValueForProperty("activityList").split(',').toList()

		activityList.each {fcode->
			if((activity.findAll{it.'@code'== fcode}.'@text'[0])!=null) {

				softAssert.assertEquals(data.getActivities(propertyId, fcode),true,"\n Activity  : " + fcode + " Doesn't Exist in Database or Duplicates Exist in Database")

				println "Activity : " + fcode + " Exists in Database"
			}

		}


	}


	//Styles

	def verifyStyles(propertyXml,dbData,data,propertyId,softAssert)
	{
		def style = propertyXml.recordset.record.property.styles.style
		List styleList = envprop.getValueForProperty("styleList").split(',').toList()

		styleList.each {fcode->
			if((style.findAll{it.'@code'== fcode}.'@text'[0])!=null) {

				softAssert.assertEquals(data.getStyles(propertyId, fcode),true,"\n Style  : " + fcode + " Doesn't Exist in Database or Duplicates Exist in Database")
				println "Style : " + fcode + " Exists in Database"

			}
		}

	}


	//Swimming Pools
	def verifySwimmingPools(propertyXml,dbData,data,propertyId,softAssert)
	{
		def swimming = propertyXml.recordset.record.property.swimmingPools.swimmingPool
		List swimmingList = envprop.getValueForProperty("swimmingpools").split(',').toList()


		swimmingList.each {fcode->
			if((swimming.findAll{it.'@type'== fcode}.'@numberOfPools'[0])!=null)
			{

				facilityData = data.getSwimmingPools(propertyId, fcode)

				softAssert.assertEquals(swimming.findAll{it.'@type'== fcode}.'@numberOfPools'[0].toInteger(), facilityData.getPoolTypeCount()," \n"+ swimming.findAll{it.'@type' == fcode}.'@numberOfPools'[0] + " SwimmingPool doesnt match with Database :" + facilityData.getPoolTypeCount() + "For Property : " + propertyId)
				println "Xml "+ fcode + " Swimming Pools :" + swimming.findAll{it.'@type'== fcode}.'@numberOfPools'[0] + " 	Database "+fcode+" SwimmingPools : " + facilityData.getPoolTypeCount()
			}
		}



	}


	//Restrictions

	def verifyRestrictions(propertyXml,dbData,data,propertyId,softAssert)
	{
		def restrictions = propertyXml.recordset.record.property.restrictions.restriction

		for(int i=0;i<restrictions.size();i++)
		{

			facilityData=data.getRestrictions(propertyId,restrictions[i].'@restrictionId')

			def startDate = PropertyUtil.getDate(restrictions[i].'@startDate')
			def endDate =  PropertyUtil.getDate(restrictions[i].'@endDate')


			softAssert.assertEquals(startDate,facilityData.getResStartDate(),"\n Restriction Start Date doesnt match for Restriction ID : " + restrictions[i].'@restrictionId' + " in property : " + propertyId)
			println "Xml Restriction Start Date : " + startDate + "	Database Restriction StartDate : " + facilityData.getResStartDate()

			softAssert.assertEquals(endDate,facilityData.getResEndDate()," \n Restriction End Date doesnt match for Restriction ID : " + restrictions[i].'@restrictionId' + " in property : " + propertyId)
			println "Xml Restriction End Date : " + endDate + "	Database Restriction EndDate : " + facilityData.getResEndDate()

			softAssert.assertEquals(restrictions[i].'@type',facilityData.getRestrictionType(),"\n Restriction Type : "+restrictions[i].'@type'  +" doesnt match with Database : "+facilityData.getRestrictionType() +" for Restriction ID : " + restrictions[i].'@restrictionId' + " in property : " + propertyId)
			println "Xml Restriction Type : " + restrictions[i].'@type' + "	Database Restriction Type : " + facilityData.getRestrictionType()

		}

	}


	//Provisions
	def verifyProvisions(propertyXml,dbData,data,propertyId,softAssert)
	{
		int parkingSize=0
		int shuttleSize=0
		int provisionSize =0
		def provisions = propertyXml.recordset.record.property.provisions
		if(provisions.parking.size()!=null)
			parkingSize =  provisions.parking.size()

		if(provisions.shuttle.size()!=null)
			shuttleSize = provisions.shuttle.size()

		provisionSize = parkingSize + shuttleSize

		if(provisionSize >0)
		{

			softAssert.assertEquals(provisionSize,dbData.getProvisionsCount(),"\n Provisions count doesnot match with database for Property : "+propertyId)

		}
		println "XML Provisions Count : " + (parkingSize + shuttleSize) + ":: Database Provisions Count :" + dbData.getProvisionsCount()



	}

}