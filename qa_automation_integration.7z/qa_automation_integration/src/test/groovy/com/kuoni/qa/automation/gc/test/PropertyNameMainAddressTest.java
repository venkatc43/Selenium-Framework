package com.kuoni.qa.automation.gc.test;

import java.util.HashMap;
import java.util.Map;

import com.gta.travel.page.base.GSTestBase;
import com.gta.travel.page.object.common.HomePage;
import com.gta.travel.page.object.common.LoginPage;
import com.gta.travel.page.object.common.TopLinksPage;
import com.gta.travel.page.object.content.search.ContentSearchPage;
import com.gta.travel.page.object.content.search.ContentSearchResultsPage;
import com.kuoni.qa.automation.page.object.content.PropertyMainAddressPage;
import com.kuoni.qa.constants.CommonConstants;
import com.mediaocean.qa.framework.utils.ExcelUtil;

public class PropertyNameMainAddressTest extends GSTestBase{

	private LoginPage loginPage;
	private HomePage homePage;
	private ContentSearchPage contentSearchPage;
	private ContentSearchResultsPage contentSearchResultsPage;
	
	private String userName;
	private String password;
	private String webId;
	
	private ExcelUtil data = null;
	
	private static String sheetName = null;
	
	public PropertyNameMainAddressTest(String driverSheetPath, String dataSheetPath, String sheetName){
		this.sheetName = sheetName;
		init(driverSheetPath, dataSheetPath);		
	}
	
	public void init(String driverSheetPath, String dataSheetPath){
		data = new ExcelUtil(dataSheetPath);
		if (driverSheetPath != null){
			setDriverSheetAbsolutePath(driverSheetPath);
		}
		initialiseEnvironmentAndTest();
		openBrowser();
		setLoginInfo();
		CommonConstants.webDriver = getDriver();
	}
	
	private void setLoginInfo() {
		webId = excelUtil.getKeyValue(ENVIRONMENT, "webId");
		userName = excelUtil.getKeyValue(ENVIRONMENT, "userName");
		password = excelUtil.getKeyValue(ENVIRONMENT, "password");
	}
	
	public void execueteDataScriptForNameEdit(){
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSearchResultsScreenFlow();
		editPropertyName();
//		getDriver().quit();
	}
	
	public void execueteDataScriptForMainAddressEdit(){
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSearchResultsScreenFlow();
		editPropertyMainAddress();
//		getDriver().quit();
	}
	
	private void executeLoginPageFlow(){
		loginPage = new LoginPage(getDriver());
		homePage = loginPage.login(webId, userName, password);
		contentSearchPage = homePage.selectContent();
		contentSearchPage.sleep(2);
	}
	
	private void executeSearchScreenFlow(){
		Map<String, String> searchDataMap = new HashMap<String, String>();
		//Set the search data to the map here.
		searchDataMap.put("Country", data.getKeyValue(sheetName, "Country"));
		searchDataMap.put("City", data.getKeyValue(sheetName, "City"));
		searchDataMap.put("Property Name", data.getKeyValue(sheetName, "Property Name"));
		contentSearchResultsPage = contentSearchPage.search(searchDataMap);
		contentSearchResultsPage.sleep(2);
	}
	
	private void executeSearchResultsScreenFlow(){
		Map<String, String> searchResultsDataMap = new HashMap<String, String>();
		//Set the search data to the map here.
		searchResultsDataMap.put("Country", data.getKeyValue(sheetName, "Country"));
		searchResultsDataMap.put("City", data.getKeyValue(sheetName, "City"));
		searchResultsDataMap.put("Property Name", data.getKeyValue(sheetName, "Property Name"));		
		TopLinksPage topLinksPage = contentSearchResultsPage.selectRecordFromSearchResults(searchResultsDataMap);
		topLinksPage.sleep(3);
	}

	private void editPropertyName() {
		PropertyMainAddressPage propertyMainAddressPage = PropertyMainAddressPage.getInstance();
		propertyMainAddressPage.clickEditLink();
		propertyMainAddressPage.sleep(1);
		Map<String, String> mapData = new HashMap<String, String>();
		mapData.put("Property Name", data.getKeyValue(sheetName, "Property Name Edit"));
		propertyMainAddressPage.editPropertyName(mapData);
		propertyMainAddressPage.sleep(2);
	}
	
	private void editPropertyMainAddress(){
		PropertyMainAddressPage propertyMainAddressPage = PropertyMainAddressPage.getInstance();
		propertyMainAddressPage.clickEditLink();
		propertyMainAddressPage.sleep(1);
		Map<String, String> mapData = new HashMap<String, String>();
		mapData.put("Street1", data.getKeyValue(sheetName, "Street1"));
		mapData.put("Street2", data.getKeyValue(sheetName, "Street2"));
		mapData.put("City", data.getKeyValue(sheetName, "City"));
		mapData.put("State/Country", data.getKeyValue(sheetName, "State/Country"));
		mapData.put("Zip/PostalCode", data.getKeyValue(sheetName, "Zip/PostalCode"));
		propertyMainAddressPage.editMainAddress(mapData);
		propertyMainAddressPage.sleep(2);
	}

	public ExcelUtil getData() {
		return data;
	}
	
}
