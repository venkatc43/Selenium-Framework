package com.kuoni.qa.automation.dao


import com.kuoni.qa.automation.common.properties.EnvironmentProperties
import geb.Page
import java.sql.*


class GetDatabaseConn {
	
	def dbprops = new EnvironmentProperties() 
	def url = dbprops.getValueForProperty("oracle_url")
	def uname = dbprops.getValueForProperty("oracle_uname")
	def pwd = dbprops.getValueForProperty("oracle_pwd")
	
	def  Connection getDBconnection()
	{
		Connection conn = null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection(url,uname,pwd);
			
		
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		
		}
		
		return conn
		
	}
}
