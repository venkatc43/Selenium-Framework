package com.kuoni.qa.automation.atg.test

import org.testng.asserts.SoftAssert
import static com.kuoni.qa.automation.util.GetCoherenceObject.*
import spock.lang.Shared;
import spock.lang.Specification
import spock.lang.Unroll
import static com.kuoni.qa.automation.util.ReadFilesUtil.getFiles

import com.gta.nova.contractprovider.model.ContractProvider
import com.gta.nova.propertycontract.model.PropertyContract
import com.kuoni.qa.automation.common.properties.EnvironmentProperties
import com.kuoni.qa.automation.dao.GetContractDBdata
import com.kuoni.qa.automation.dto.ContractDTO
import com.kuoni.qa.automation.helper.ContractTestHelper
import com.kuoni.qa.automation.spock.annotation.Regression
import com.kuoni.qa.automation.util.ContractXmlUtil
import com.kuoni.qa.automation.util.PerformDataLoadUtil

class ContractDataTest extends Specification{


	@Shared
	EnvironmentProperties envProp = new EnvironmentProperties()

	def setupSpec() {

		def folderLocation = envProp.getValueForProperty("istDataLoc")+"/Contract"
		PerformDataLoadUtil dataLoad = new PerformDataLoadUtil()
		dataLoad.changeTestDataReaderLocation(folderLocation)
		dataLoad.importFilesandPerformLoadfromQueue()
		dataLoad.incrementalPushtoCoherence()
	}


	@Regression
	@Unroll
	def "VerifyContractXmlData for : #fileEntry.getName()" () {

		given: "XML Test Data for Property is available at the appropriate Location"
		def envprop = new EnvironmentProperties()
		SoftAssert softAssert = new SoftAssert()
		ContractDTO dbData,xmlData
		ContractXmlUtil getxmlDetails = new ContractXmlUtil()
		GetContractDBdata data = null
		ContractTestHelper validator = new ContractTestHelper()

		when: "Property xml files are according to the XSD agreed and accesible by the tests"

		//URL url = ContractDataTest.class.getClass().getResource("/Contracts")

		//Read the XML File and set the values

		def contractXml = new XmlParser().parse(fileEntry)
		xmlData = getxmlDetails.readXml(contractXml)
		def contractId = xmlData.getContractId()

		data = new GetContractDBdata()
		dbData = data.getContractData(contractId)


		//Verifying the xml Contract properties with the database

		def properties = xmlData.properties
		println "\n" + "Verifying Data for Contract : " + fileEntry.getName() + "\n"
		properties.each {node,val->

			if ((xmlData."$node")!=null && ("$node") != "class" && ("$node")!="contractId")
			{

				softAssert.assertEquals(xmlData."$node", dbData."$node", "\n" + "Xml " + "$node" + ": " + xmlData."$node"+ "	Doesn't Match with "+" DataBase " + "$node" + ": " + dbData."$node" + " For Contract : " + contractId +"	in File : "+ fileEntry)
				println "Xml " + "$node" + ": " + xmlData."$node"+ "	::		" + " DataBase " + "$node" + ": " + dbData."$node"
			}

		}

		//Verify Channels,Excluded Countries,Cancellations,Restrictions and RatePlans

		validator.verifyChannels(contractXml,dbData,data,contractId,softAssert)
		validator.verifyRestrictions(contractXml,dbData,data,contractId,softAssert)
		validator.verifyCountries(contractXml, dbData, data, contractId,softAssert)
		validator.verifyCancellations(contractXml,dbData,data,contractId,softAssert)

		//validator.verifyRateplans(contractXml,softAssert)
		
		
		// Verify with Coherence
		
		PropertyContract coherenceContract = verifyCoherenceContractsandRateplans(contractId.toString())
		
		println "\n ***Coherence Validation*** \n"
		if(xmlData.getContractStatus()!=null)
		{
		softAssert.assertEquals(xmlData.getContractStatus().toUpperCase(),coherenceContract.getContractStatus().toString(), "Xml Data ContractStatus Code doesn't match with Coherence Data")
		println "Xml ContractStatus :" + xmlData.getContractStatus() + ": " + "Coherence ContractStatus : " + coherenceContract.getContractStatus()
		}
		
		softAssert.assertEquals(xmlData.getContractModel().toUpperCase(),coherenceContract.getContractModel().toString(), "Xml Data Contract Model Code doesn't match with Coherence Data")
		println "Xml Contract Model :" + xmlData.getContractModel() + ": " + "Coherence Contract Model : " + coherenceContract.getContractModel()
		
		ContractProvider providerDetails = 	coherenceContract.getContractProvider()
		
		softAssert.assertEquals(xmlData.getProviderId().toString(),providerDetails.getIdentifier().toString(), "Xml Data Contract Provider ID Code doesn't match with Coherence Data")
		println "Xml Contract Provider Id :" + xmlData.getProviderId() + ": " + "Coherence Contract Provider Id : " + providerDetails.getIdentifier()
		
		softAssert.assertEquals(xmlData.getOnSale(),providerDetails.isOnSale().toString(), "Xml Data Contract Provider ON SALE  Code doesn't match with Coherence Data")
		println "Xml Contract Provider ON SALE :" + xmlData.getOnSale() + ": " + "Coherence Contract Provider ON SALE : " + providerDetails.isOnSale()
		
		softAssert.assertEquals(xmlData.getAllowOnRequest(),providerDetails.isOnRequest().toString(), "Xml Data Contract Provider ON REQUEST  Code doesn't match with Coherence Data")
		println "Xml Contract Provider ON REQUEST :" + xmlData.getAllowOnRequest() + ": " + "Coherence Contract Provider ON REQUEST : " + providerDetails.isOnRequest()
		
		
		softAssert.assertAll()
		then: "The XML Data for Contracts should Match with the Database"
		where:
		fileEntry << getFiles("/Contract")

	}

}



