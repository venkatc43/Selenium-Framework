package com.kuoni.qa.automation.gc.testcases

import com.kuoni.qa.constants.CommonConstants;

import spock.lang.Specification

class WebDriverCloseTest extends Specification{

	def "close webdriver"(){
		when:""
		if(CommonConstants.webDriver != null){
			CommonConstants.webDriver.quit()
		}
		then:""
	}
}