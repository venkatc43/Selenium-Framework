package com.kuoni.qa.automation.gc.test;

import java.util.HashMap;
import java.util.Map;

import com.gta.travel.page.base.GSTestBase;
import com.gta.travel.page.object.common.TopLinksPage;
import com.gta.travel.page.object.contract.generaldetails.GeneralDetailsProviderSectionPage;
import com.gta.travel.page.object.contract.inventory.InventoryGeneratorSectionPage;
import com.gta.travel.page.object.contract.manageavailability.ManageAvailabilitySearchAndResultsSectionPage;
import com.gta.travel.page.object.contract.rateplans.RatePlanDetailsSectionPage;
import com.gta.travel.page.object.contract.rateplans.RatePlanStandardRateSectionPage;
import com.gta.travel.page.object.contract.search.ContractSearchPage;
import com.gta.travel.page.object.contract.search.ContractSearchResultsPage;
import com.kuoni.qa.automation.page.object.common.HomePageSub;
import com.kuoni.qa.automation.page.object.common.LoginPageSub;
import com.mediaocean.qa.framework.utils.ExcelUtil;

public class PushAvailabilityTest extends GSTestBase {

	private String userName;
	private String password;
	private String webId;

	private static String sheetName = null;
	private InventoryGeneratorSectionPage Inventory;
	private ContractSearchPage contractSearchPage;
	private ContractSearchResultsPage contractSearchResultsPage;
	private RatePlanStandardRateSectionPage rpDetailsSectionPage;
	private RatePlanDetailsSectionPage DetailsSectionPage;
	private ManageAvailabilitySearchAndResultsSectionPage ManageAvailability;
	private ExcelUtil excelData;

	// ExcelUtil excelData = null;

	public PushAvailabilityTest(String driverSheetPath, String dataSheetPath, String sheetName) {
		this.sheetName = sheetName;
		init(driverSheetPath, dataSheetPath);
	}

	public void init(String driverSheetPath, String dataSheetPath) {
		excelData = new ExcelUtil(dataSheetPath);

		if (driverSheetPath != null) {

			setDriverSheetAbsolutePath(driverSheetPath);
		} else {
			setDriverSheetFileName("Driver_Sheet.xls");
		}
		initialiseEnvironmentAndTest();
		openBrowser();
		setLoginInfo();
	}

	private void setLoginInfo() {
		webId = excelUtil.getKeyValue(ENVIRONMENT, "webId");
		userName = excelUtil.getKeyValue(ENVIRONMENT, "userName");
		password = excelUtil.getKeyValue(ENVIRONMENT, "password");
	}

	public void executeDataScriptForCreate() throws InterruptedException {
		executeLoginPageFlow();
		Thread.sleep(3000);

		// sleep(Integer.parseInt((String)
		// ConfigProperties.getVlaue("pollingInterval")));
		executeSearchScreenFlow();
		GeneralDetails();
		CreateInventoryDetails();
		// executeSelectRatePlan();
		// executeManageAvailabilityFlow();
		// getDriver().quit();
	}
	public void executeDataScriptForDelete() throws InterruptedException {
		executeLoginPageFlow();
		Thread.sleep(3000);

		// sleep(Integer.parseInt((String)
		// ConfigProperties.getVlaue("pollingInterval")));
		executeSearchScreenFlow();
		GeneralDetails();
		DeleteInventoryDetails();
		// executeSelectRatePlan();
		// executeManageAvailabilityFlow();
		// getDriver().quit();
	}
	
	private void executeLoginPageFlow() {
		LoginPageSub loginPage = new LoginPageSub();
		HomePageSub homePage = loginPage.login(webId, userName, password);
		contractSearchPage = homePage.selectContract();
		contractSearchPage.sleep(2);
	}

	private void executeSearchScreenFlow() {

		Map<String, String> searchDataMap = new HashMap<String, String>();
		// Set the search data to the map here.
		searchDataMap.put("Country", excelData.getKeyValue(sheetName, "Country"));
		searchDataMap.put("City", excelData.getKeyValue(sheetName, "City"));
		searchDataMap.put("Property Name", excelData.getKeyValue(sheetName, "Property Name"));
		contractSearchResultsPage = contractSearchPage.search(searchDataMap);
		contractSearchResultsPage.sleep(3);
		contractSearchResultsPage.selectFirstRowFromTheResults();
	}

	private void CreateInventoryDetails() {
		Inventory = InventoryGeneratorSectionPage.getInstance();
		TopLinksPage selectTab = new TopLinksPage();
		selectTab.selectInventoryTab();
		InventoryGeneratorSectionPage tab = new InventoryGeneratorSectionPage();
		tab.selectInventoryOptions("Create");
		Map<String, String> map = new HashMap<String, String>();
		map.put("inventory type", excelData.getKeyValue(sheetName, "inventory type"));
		map.put("days", excelData.getKeyValue(sheetName, "days"));
		// map.put("channel", excelData.getKeyValue(sheetName, "channel"));
		//map.put("inventory style", excelData.getKeyValue(sheetName, "inventory style"));
		map.put("room types", excelData.getKeyValue(sheetName, "room types"));
		map.put("Business", excelData.getKeyValue(sheetName, "Business"));
		tab.createInventory(map);
		tab.saveInventory();
		tab.saveInventory();
	}
	private void DeleteInventoryDetails() {
		Inventory = InventoryGeneratorSectionPage.getInstance();
		TopLinksPage selectTab = new TopLinksPage();
		selectTab.selectInventoryTab();
		InventoryGeneratorSectionPage tab = new InventoryGeneratorSectionPage();
		tab.selectInventoryOptions("Delete");
		Map<String, String> map = new HashMap<String, String>();
		map.put("start day", excelData.getKeyValue(sheetName, "start day"));
		map.put("start month", excelData.getKeyValue(sheetName, "start month"));
		map.put("start year", excelData.getKeyValue(sheetName, "start year"));
		map.put("end day", excelData.getKeyValue(sheetName, "end day"));
		map.put("end month", excelData.getKeyValue(sheetName, "end month"));
		map.put("end year", excelData.getKeyValue(sheetName, "end year"));
		tab.enterDeleteInventoryDates(map);
		tab.deleteInventory();
		tab.deleteInventory();
	}
	private void executeSelectRatePlan() {
		DetailsSectionPage = RatePlanDetailsSectionPage.getInstance();
		Map<String, String> map = new HashMap<String, String>();
		map.put("Rate Plan Code", excelData.getKeyValue(sheetName, "Rate Plan Code"));
		// DetailsSectionPage.selectRatePlan(map);
		DetailsSectionPage.selectRatePlanFromTheList(map);
	}

	private void GeneralDetails() {

		TopLinksPage toplink = new TopLinksPage();
		toplink.clickGeneralDetailsTab();
		GeneralDetailsProviderSectionPage selectOption = new GeneralDetailsProviderSectionPage();
		selectOption.selectProviderOptions("Create");
		Map<String, String> map = new HashMap<String, String>();
		map.put("provider", excelData.getKeyValue(sheetName, "provider"));
		map.put("model", excelData.getKeyValue(sheetName, "model"));
		map.put("channel", excelData.getKeyValue(sheetName, "channel"));
		// map.put("margin amount", excelData.getKeyValue(sheetName,
		// "margin amount"));
		// map.put("margin amount", "50");
		map.put("currency", excelData.getKeyValue(sheetName, "currency"));

		selectOption.createProvider(map);
		selectOption.saveNewProvider();

	}

	private void executeManageAvailabilityFlow() {

		ManageAvailability = ManageAvailabilitySearchAndResultsSectionPage.getInstance();

		Map<String, String> map = new HashMap<String, String>();
		map.put("minimum nights", excelData.getKeyValue(sheetName, "Minimum Nights"));
		map.put("provider", excelData.getKeyValue(sheetName, "Minimum Nights"));

		map.put("executive king bay view type", excelData.getKeyValue(sheetName, "executive king bay view type"));
		map.put("executive quad bay view type", excelData.getKeyValue(sheetName, "executive quad bay view type"));
		map.put("standard double type", excelData.getKeyValue(sheetName, "standard double type"));
		map.put("standard room type", excelData.getKeyValue(sheetName, "standard room type"));
		map.put("executive king bay view type net", excelData.getKeyValue(sheetName, "executive king bay view type net"));
		map.put("executive quad bay view type net", excelData.getKeyValue(sheetName, "executive quad bay view type net"));
		map.put("standard double type net", excelData.getKeyValue(sheetName, "standard double type net "));
		map.put("standard room type net", excelData.getKeyValue(sheetName, "standard room type net"));
		// map.put("On Sale", data.getKeyValue(sheetName, "On Sale"));
		// map.put("Legacy City ID", data.getKeyValue(sheetName,
		// "Legacy City ID"));
		// map.put("Legacy Property ID",
		// data.getKeyValue(sheetName, "Legacy Property ID"));
		// map.put("FIT Reservations Via",
		// data.getKeyValue(sheetName, "FIT Reservations Via"));

		rpDetailsSectionPage.createOptionClick();
		rpDetailsSectionPage.createStandardRates(map);
		rpDetailsSectionPage.sleep(2);
		rpDetailsSectionPage.saveSaveCreateRateRules();
		rpDetailsSectionPage.sleep(2);
	}

}
