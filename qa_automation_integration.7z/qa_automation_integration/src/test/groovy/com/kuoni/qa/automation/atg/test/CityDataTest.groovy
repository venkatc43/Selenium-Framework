package com.kuoni.qa.automation.atg.test
import static com.kuoni.qa.automation.util.ReadFilesUtil.getFiles
import static com.kuoni.qa.automation.util.GetCoherenceObject.*
import org.testng.asserts.SoftAssert
import spock.lang.Specification
import spock.lang.Unroll
import spock.lang.Shared;
import com.gta.nova.city.model.City
import com.kuoni.qa.automation.common.properties.EnvironmentProperties
import com.kuoni.qa.automation.dao.GetCityDBdata
import com.kuoni.qa.automation.dto.CityDTO
import com.kuoni.qa.automation.spock.annotation.Regression
import com.kuoni.qa.automation.util.CityXmlUtil
import com.kuoni.qa.automation.util.PerformDataLoadUtil

class CityDataTest extends Specification {

	@Shared
	EnvironmentProperties envProp = new EnvironmentProperties()

	def setupSpec() {

		def folderLocation = envProp.getValueForProperty("istDataLoc")+"/City"
		PerformDataLoadUtil dataLoad = new PerformDataLoadUtil()
		dataLoad.changeTestDataReaderLocation(folderLocation)
		dataLoad.importFilesandPerformLoadfromQueue()
		dataLoad.incrementalPushtoCoherence()
	}

	@Regression
	@Unroll
	def "VerifyCityXmldata for :  #fileEntry.getName() "() {

		given: "XML Test Data for CITY is available at the appropriate Location"

		CityXmlUtil xml = new CityXmlUtil()
		GetCityDBdata data = new GetCityDBdata()
		SoftAssert softAssert = new SoftAssert()
		CityDTO dbData, xmlData
		Set cityCount = new HashSet()

		when: "city xml files are according to the XSD agreed and accesible by the tests"

		//parseXML file
		def cityXml = new XmlParser().parse(fileEntry)
		//println "XML Validation with XSD is: "+ XmlUtil.validateXMLSchema(xsdFile,xmlFile)
		def c= cityXml.recordset.record.city
		def cityId = c.@cityId[0]
		cityCount.add(cityId)

		//Read the Xml values
		xmlData = xml.readCityXml(c)
		dbData = data.getCitydata(cityId)

		def properties = xmlData.properties
		println "\n" + "Verifying Data for City : " + fileEntry.getName() + "\n"

		//validate xml with database values
		println "\n ***Xml Validation with ATG*** \n"
		properties.each{node,val->

			if( "$node" != "cityCount" && "$node" !="class")
			{
				softAssert.assertEquals(xmlData."$node", dbData."$node", "\n" + "Xml " + "$node" + ": " + xmlData."$node"+ "	Doesn't Match with "+" DataBase " + "$node" + ": " + dbData."$node" + " For City : " + cityId+"	in File : " + fileEntry)
				println "Xml " + "$node" + ": " + xmlData."$node"+ "	::		" + " DataBase " + "$node" + ": " + dbData."$node"
			}

		}

		//validate xml with Coherence Cache

		City city = getCoherenceCityDetails (cityId)
		println "\n ***Coherence Validation*** \n"
		softAssert.assertEquals(xmlData.getCityCode(),city.getCityCode(), "Xml Data City Code doesn't match with Coherence Data")
		println "Xml CityCode :" + xmlData.getCityCode() + ": " + "Coherence CityCode : " + city.getCityCode()

		softAssert.assertEquals(xmlData.getTimeZone(),city.getCityTimeZone(), "Xml Data CityTimeZone Code doesn't match with Coherence Data")
		println "Xml CityTimeZone :" + xmlData.getTimeZone() + ": " + "Coherence TimeZone : " + city.getCityTimeZone()

		softAssert.assertAll()
		then: "The XML Data for Cities should Match with the Database"
		println "\n" + "***Test complete***"

		where:
		fileEntry << getFiles("/City")

	}
}
