package com.kuoni.qa.automation.util

import com.kuoni.qa.automation.dto.RateplanDTO

class RateplanXmlUtil {
	
	RateplanDTO xmlData = new RateplanDTO()
	
	def readXml(rateplanXml)
	
	{
		def r = rateplanXml.recordset.record.ratePlan
		xmlData.setRateplanId((r.@id[0]).toInteger())
		xmlData.setContractId(r.@contractId[0])
		xmlData.setRateplanStatus(r.@status[0])
		xmlData.setRateplanName(r.@name[0])
		xmlData.setRateplanCode(r.@code[0])
		
		xmlData.setMarginType(r.margin.@type[0])
		if((r.margin.@percentage[0])!=null)
		xmlData.setMarginPercentage((r.margin.@percentage[0]).toFloat())
		else
		xmlData.setMarginPercentage(r.margin.@percentage[0])
		
		/*xmlData.setMealBasisCode(r)
		xmlData.setMealBasisDesc(r)
		xmlData.setMealBasisType(r)*/
		
		
		return xmlData
	}

}
