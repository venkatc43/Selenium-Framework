package com.kuoni.qa.automation.gc.test;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import com.gta.travel.page.base.GSTestBase;
import com.gta.travel.page.object.common.HomePage;
import com.gta.travel.page.object.common.LoginPage;
import com.gta.travel.page.object.common.TopLinksPage;
import com.gta.travel.page.object.content.facilitiesandservices.LocationDetailsPage;
import com.gta.travel.page.object.content.search.ContentSearchPage;
import com.gta.travel.page.object.content.search.ContentSearchResultsPage;
import com.kuoni.qa.constants.CommonConstants;
import com.mediaocean.qa.framework.utils.ExcelUtil;

public class PropertyLocationDetailsTest extends GSTestBase{

	private LoginPage loginPage;
	private HomePage homePage;
	private ContentSearchPage contentSearchPage;
	private ContentSearchResultsPage contentSearchResultsPage;
	private LocationDetailsPage locationDetailsPage;
	
	private String userName;
	private String password;
	private String webId;
	
	ExcelUtil data = null;
	private static String sheetName = null;
	
	public PropertyLocationDetailsTest(String driverSheetPath, String dataSheetPath, String sheetName){
		this.sheetName = sheetName;
		init(driverSheetPath, dataSheetPath);		
	}
	
	public void init(String driverSheetPath, String dataSheetPath){
		data = new ExcelUtil(dataSheetPath);
		if (driverSheetPath != null){
			setDriverSheetAbsolutePath(driverSheetPath);
		}else{
			setDriverSheetFileName("Driver_Sheet.xls");
		}
		initialiseEnvironmentAndTest();
		openBrowser();
		setLoginInfo();
		if(CommonConstants.webDriver != null){
			CommonConstants.webDriver = getDriver();
		}
	}
	
	private void setLoginInfo() {
		webId = excelUtil.getKeyValue(ENVIRONMENT, "webId");
		userName = excelUtil.getKeyValue(ENVIRONMENT, "userName");
		password = excelUtil.getKeyValue(ENVIRONMENT, "password");
	}
	
	public void executeDataScriptsForUpdate(){
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSearchResultsScreenFlow();
		executeEditLocationDetails();
//		getDriver().quit();
	}
	
	private void executeLoginPageFlow(){
		loginPage = new LoginPage(getDriver());
		homePage = loginPage.login(webId, userName, password);
		contentSearchPage = homePage.selectContent();
		contentSearchPage.sleep(2);
	}
	
	private void executeSearchScreenFlow(){
		Map<String, String> searchDataMap = new HashMap<String, String>();
		searchDataMap.put("Country", data.getKeyValue(sheetName, "Country"));
		searchDataMap.put("City", data.getKeyValue(sheetName, "City"));		
		contentSearchResultsPage = contentSearchPage.search(searchDataMap);
		contentSearchResultsPage.sleep(2);
	}
	
	private void executeSearchResultsScreenFlow(){
		Map<String, String> searchResultsDataMap = new HashMap<String, String>();
		searchResultsDataMap.put("Country", data.getKeyValue(sheetName, "Country"));
		searchResultsDataMap.put("City", data.getKeyValue(sheetName, "City"));
		searchResultsDataMap.put("Property Name", data.getKeyValue(sheetName, "Property Name"));
		TopLinksPage topLinksPage = contentSearchResultsPage.selectRecordFromSearchResults(searchResultsDataMap);
		topLinksPage.sleep(3);
		topLinksPage.clickFacilitiesAndServices();
		topLinksPage.sleep(2);
	}	
	
	private void executeEditLocationDetails() {
		locationDetailsPage = LocationDetailsPage.getInstance();
		Map<String, String> map = new HashMap<String, String>();
		
		map.put("Latitude", data.getKeyValue(sheetName, "Latitude"));
		
		map.put("Longitude", data.getKeyValue(sheetName, "Longitude"));
		
		map.put("Location", data.getKeyValue(sheetName, "Location"));
		
		locationDetailsPage.editLocationDetails(map);
		
		locationDetailsPage.updateLocationDetails();
	}
}
