package com.kuoni.qa.automation.page.object.cities;

import org.openqa.selenium.support.PageFactory;

import com.gta.travel.page.base.GSPageBase;
import com.mediaocean.qa.framework.selenium.ui.controls.Button;

public class ViewCityPage extends GSPageBase{


	public ViewCityPage() {
		super(getDriver());
	}
	
	public CityPage clickEdit(){
		
		Button edit = new Button("Edit");
		sleep(1);
		edit.click();
		return PageFactory.initElements(getDriver(), CityPage.class);
	}
	
	public void clickDelete(){
		
		Button edit = new Button("Delete");
		sleep(1);
		edit.click();
		sleep(1);
		getDriver().switchTo().alert().accept();
	}

}
