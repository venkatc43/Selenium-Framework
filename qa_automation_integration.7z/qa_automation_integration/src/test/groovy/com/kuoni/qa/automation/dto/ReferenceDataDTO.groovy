package com.kuoni.qa.automation.dto

class ReferenceDataDTO {
	
	def languageCount
	def dataDescription
	def landmarkCode
	def landmarkLatitude
	def landmarkLongitude

}
