

package com.kuoni.qa.automation.helper
import com.gta.nova.condition.model.CancellationCondition;
import com.kuoni.qa.automation.dao.GetContractDBdata
import com.kuoni.qa.automation.dto.ContractDTO
import static com.kuoni.qa.automation.util.GetCoherenceObject.*

class ContractTestHelper {

	GetContractDBdata dbattributes = new GetContractDBdata()
	ContractDTO dbData,addlData

	//Channels
	def verifyChannels(contractXml,dbData,data,contractId,softAssert)
	{
		def dbChannelCode =null
		def channel =   contractXml.recordset.record.contract.channels.channel

		List dbChannels = data.getContractChannels(contractId)

		if(channel.size() >0 && channel.size() == dbData.getChannelCount())
		{
			for (int j=0;j<channel.size() ;j++)
			{

				def xmlChannel = channel[j].@code
				def match
				for(ContractDTO dto : dbChannels)
				{ 
					
					dbChannelCode = dto.channelCode
					if(xmlChannel == dbChannelCode)
					{
						println "xml ChannelCode : " +  xmlChannel + "	::	" + "DatabaseChannelCode : " + dbChannelCode 
						break
					}
					
				}

			}

		}
		else 
		{
			println "xml Channels : "+ channel.size() + ":: Database Channels : " + dbData.getChannelCount()
			softAssert.assertEquals(channel.size(),dbData.getChannelCount(),"\n Channels doesn't match with database for Contract : " + contractId)
			
		} 
		


	}


	//Margins
	def verifyMargins()
	{
		if(recordset.record.contract.@model=="Margin")
		{
			def marginPer = recordset.record.contract.margin.@percentage
		}
		else
			println "Contract Type is Static, Margins not available to Test"
	}


	//Excluded Countries
	def verifyCountries(contractXml,dbData,data,contractId,softAssert)
	{
		def dbCountryCode =null
		def country =   contractXml.recordset.record.contract.excludedCountries.country

		List dbCountries = data.getContractCountries(contractId)

		if(country.size() >0 && country.size() == dbData.getCountryCount())
		{
			for (int j=0;j<country.size() ;j++)
			{

				def xmlCountry = country[j].@code

				for(ContractDTO dto : dbCountries)
				{
					dbCountryCode = dto.countryCode
					if(xmlCountry == dbCountryCode)
					{
						println "xml ExcludedCountries : " + xmlCountry + "	::	" + "Database Excluded Countries : " + dbCountryCode 
						break
					}

				}


			}

		}
		
		else softAssert.assertEquals(country.size(),dbData.getCountryCount(),"\n Excluded Countries doenst match with Database")
		
	}






	//Cancellations
	def verifyCancellations(contractXml,dbData,data,contractId,softAssert)

	{
		def c = contractXml.recordset.record.contract.cancellations.cancellation
		
		if(c.size()!=0) 
		{
		for(int i=0;i<c.size();i++)
			{

				addlData=data.getContractCancellationsData(contractId,c[i].'@id')
				
				CancellationCondition coherenceCancellation = verifyCoherenceCancelConditions(contractId.toString(),(c[i].'@id').toString())
				//def startdate = addlData.getCancelStart()
				//def enddate = addlData.getCancelEnd()

				softAssert.assertEquals(c[i].'@type',addlData.getCancellationType(),"\n Cancellation Type doesnt match for Cancellation ID : " + c[i].'@id' + " in Contract : " + contractId)
				println "Xml Cancellation Type : " + c[i].'@type' + "	Database Cancellation Type : " + addlData.getCancellationType()

				softAssert.assertEquals(c[i].'@travelStart',addlData.getCancelStart()," \n Cancellation Start Date doesnt match for Cancellation ID : " + c[i].'@id' + " in Contract : " + contractId)
				println "Xml Cancellation Start Date : " + c[i].'@travelStart' + "	Database Cancellation Start Date : " + addlData.getCancelStart()

				softAssert.assertEquals(c[i].'@travelEnd',addlData.getCancelEnd(),"\n Cancellation EndDate doesnot match for Cancellation Id: "+ c[i].'@id' + "in Contract : " + contractId)
				println "Xml Cancellation EndDate : " + c[i].'@travelEnd' + "	Database Cancellation EndDate : " + addlData.getCancelEnd()
				
				softAssert.assertEquals(c[i].'@daysPrior',addlData.getCancelDaysPrior(),"\n Cancellation Days Prior doesnt match for Cancellation ID : " + c[i].'@id' + " in Contract : " + contractId)
				println "Xml Cancellation DaysPrior : " + c[i].'@daysPrior' + "	Database Cancellation DaysPrior : " + addlData.getCancelDaysPrior()
				
				softAssert.assertEquals((c[i].'@daysPrior').toString(),coherenceCancellation.getDaysPrior().toString(), "Xml Data Contract Cancellation DaysPrior doesn't match with Coherence Data")
				println "Xml Contract Cancellation DaysPrior :" + (c[i].'@daysPrior').toString() + ": " + "Coherence Contract Cancellation DaysPrior : " + coherenceCancellation.getDaysPrior().toString()
				
				if(c[i].'@cancelTime' != null)
				{
				softAssert.assertEquals(c[i].'@cancelTime',addlData.getCancelTime()," \n Cancellation Time doesnt match for Cancellation ID : " + c[i].'@id' + " in Contract : " + contractId)
				println "Xml Cancellation Time : " + c[i].'@cancelTime' + "	Database Cancellation Time : " + addlData.getCancelTime()
				}

				softAssert.assertEquals(Double.parseDouble(c[i].'@chargePercentage'),addlData.getCancelchargePercentage(),"\n Cancellation Percentage doesnt match with Database for Cancellation ID : " + c[i].'@id' + " in Contract : " + contractId)
				println "Xml Cancellation Percentage : " + Double.parseDouble(c[i].'@chargePercentage') + "	Database Cancellation Percentage : " + addlData.getCancelchargePercentage()
				
				softAssert.assertEquals(c[i].'@duration',addlData.getCancelDuration(),"\n Cancellation Duration doesnt match with Database  for Cancellation ID : " + c[i].'@id' + " in Contract : " + contractId)
				println "Xml Cancellation Duration : " + c[i].'@duration' + "	Database Cancellation Duration : " + addlData.getCancelDuration()
				
				softAssert.assertEquals((c[i].'@duration').toString(),coherenceCancellation.getChargeDuration().toString(), "Xml Data Contract Cancellation Duration doesn't match with Coherence Data")
				println "Xml Contract Cancellation Duration :" + (c[i].'@duration').toString() + ": " + "Coherence Contract Cancellation Duration : " + coherenceCancellation.getChargeDuration().toString()
				
			

			}
		}
		
		//else if(c.size()!=0 && c.size()!= dbData.getCancelCount())
		//	println "Cancellations Count doesnt match with Database"
	}


	//Restrictions
	def verifyRestrictions(contractXml,dbData,data,contractId,softAssert)
	{
		def restrictions = contractXml.recordset.record.contract.restrictions.restriction
		
		if(restrictions.size()!=0 && restrictions.size()==dbData.getRestrictionCount())
		{

			for(int i=0;i<restrictions.size();i++)
			{

				ContractDTO	dbRestriction = data.getContractRestrictionsData(contractId,restrictions[i].'@id')
				
				//softAssert.assertEquals(restrictions[i].@type,dbRestriction.getRestrictionType(),"\n Restriction Type doesnt match for Restriction ID : " + restrictions[i].'@id' + " in Contract : " + contractId)
				println "Xml Restriction Type : " + restrictions[i].'@type' + "	Database Restriction Type : " + dbRestriction.getRestrictionType()

				softAssert.assertEquals(restrictions[i].@travelStart,dbRestriction.getRestrictionStart(),"\n Restriction StartDate doesnt match for Restriction ID : " + restrictions[i].'@id' + " in Contract : " + contractId)
				println "Xml Restriction StartDate : " + restrictions[i].'@travelStart' + "	Database Restriction Type : " + dbRestriction.getRestrictionStart()

				softAssert.assertEquals(restrictions[i].@travelEnd,dbRestriction.getRestrictionEnd(),"\n Restriction EndDate doesnt match for Restriction ID : " + restrictions[i].'@id' + " in Contract : " + contractId)
				println "Xml Restriction EndDate : " + restrictions[i].'@travelEnd' + "	Database Restriction Type : " + dbRestriction.getRestrictionEnd()


			}
		}
		else if(restrictions.size()!=0 && restrictions.size()!= dbData.getRestrictionCount())
		{
			println "Restrictions Count doesnt match with Database"
		}
	}

	//RatePlans
	def verifyRateplans()
	{

	}


	

}
