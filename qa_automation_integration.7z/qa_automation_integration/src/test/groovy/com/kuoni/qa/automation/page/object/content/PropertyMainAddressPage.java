package com.kuoni.qa.automation.page.object.content;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.gta.travel.page.base.GSPageBase;
import com.mediaocean.qa.framework.selenium.ui.controls.Button;
import com.mediaocean.qa.framework.selenium.ui.controls.Link;
import com.mediaocean.qa.framework.selenium.ui.controls.TextBox;

public class PropertyMainAddressPage extends GSPageBase{

	public PropertyMainAddressPage() {
		super(getDriver());
	}
	
	public static PropertyMainAddressPage getInstance(){
		return PageFactory.initElements(getDriver(),PropertyMainAddressPage.class);
	}

	public void clickEditLink(){
		WebElement parentElement = waitForElement(By.id("propertyHeaderContentMenuOptions"));
		Link editLink = new Link(parentElement, "Edit");
		editLink.clickLink();
	}
	
	public void editPropertyName(Map<String, String> data){
		waitForElement(By.id("propertyHeader-name"));
		this.sleep(1);
		if(data.get("Property Name") != null){
			clearAndType(By.id("propertyHeader-name"),data.get("Property Name"));
		}
		sleep(1);
		Button update = new Button("Update");
		update.click();	
	}
	
	public void editPropertyPhoneWebsite(Map<String, String> data){
		waitForElement(By.id("propertyHeader-name"));
		this.sleep(1);
		if(data.get("Telephone Number") != null){
			clearAndType(By.id("propertyHeader-mainPhone"),data.get("Telephone Number"));
		}
		if(data.get("Website") != null){
			clearAndType(By.id("propertyHeader-website"),data.get("Website"));
		}		
		sleep(1);
		Button update = new Button("Update");
		update.click();		
	}
	
	public void editMainAddress(Map<String, String> data){
		waitForElement(By.id("propertyHeader-name"));
		this.sleep(1);
		if(data.get("Street1") != null){
			clearAndType(By.id("main-line1"),data.get("Street1"));
		}
		if(data.get("Street2") != null){
			clearAndType(By.id("main-line2"),data.get("Street2"));
		}
		if(data.get("City") != null){
			String city = data.get("City");
			selectValueFromAjaxList("main-city-name", city.substring(0,3), "main-state", "main-city-choices",  city, city,0);			
		}
		sleep(1);
		if(data.get("State/Country") != null){
			clearAndType(By.id("main-state"),data.get("State/Country"));
		}
		if(data.get("Zip/PostalCode") != null){
			clearAndType(By.id("main-postcode"),data.get("Zip/PostalCode"));
		}			
		sleep(1);
		Button update = new Button("Update");
		update.click();			
	}
	
	private void selectValueFromAjaxList(String textBoxId, String text, 
			String dummyTextBoxId, String choiceListId, String valueToSelect, String title, int noOfTimes){
		
		TextBox textBox = new TextBox(By.id(textBoxId));
		textBox.setText(text);
		TextBox dummyTextBox = new TextBox(By.id(dummyTextBoxId));
		dummyTextBox.clickTab();
		WebElement choicesEl = null;
		while(true){
			choicesEl = getElementIfItIsPresent(By.id(choiceListId));
			if (choicesEl != null){
				break;
			}
		}
		if (textBox.getText().length() == 3){
			if (choicesEl != null){
				if (waitAndGetElementIfItIsPresent(By.linkText(title),5) != null){
					Link link = new Link(choicesEl, valueToSelect, title);
					link.clickLink();
				}else if (noOfTimes == 0){
					noOfTimes++;
					selectValueFromAjaxList(textBoxId,valueToSelect,dummyTextBoxId,choiceListId,valueToSelect,title, noOfTimes);
				}
			}
		}
	}	
	
}
