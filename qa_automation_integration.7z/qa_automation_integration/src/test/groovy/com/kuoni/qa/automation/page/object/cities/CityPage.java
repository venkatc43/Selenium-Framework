package com.kuoni.qa.automation.page.object.cities;

import java.util.Map;

import org.openqa.selenium.By;

import com.gta.travel.page.base.GSPageBase;
import com.mediaocean.qa.framework.selenium.ui.controls.Button;
import com.mediaocean.qa.framework.selenium.ui.controls.ComboBox;

public class CityPage extends GSPageBase{

	public CityPage() {
		super(getDriver());
	}
	
	public void createCity(Map<String, String> data){
		waitForElement(By.name("code"));
		applyDataForCityPage(data);		
		Button saveCity = new Button("Save");
		saveCity.click();
	}
	
	public void editCity(Map<String, String> data){
		waitForElement(By.name("name"));
		applyDataForCityPage(data);		
		Button editCity = new Button("Save");
		editCity.click();		
	}

	private void applyDataForCityPage(Map<String, String> data) {
		if(data.get("Code") != null){
			clearAndType(By.id("code"),data.get("Code"));
		}
		
		if(data.get("Description") != null){
			clearAndType(By.id("name"),data.get("Description"));
		}
		
		if(data.get("IataCode") != null){
			clearAndType(By.id("iataCode"),data.get("IataCode"));
		}
		
		if(data.get("LegacyCode") != null){
			clearAndType(By.id("legacyCode"),data.get("LegacyCode"));
		}
		
		if(data.get("Country") != null){
			ComboBox propTypeComboBox = new ComboBox(By.id("country.id"));
			propTypeComboBox.select(data.get("Country"));
		}
		
		if(data.get("Timezone") != null){
			ComboBox propTypeComboBox = new ComboBox(By.id("timezone"));
			propTypeComboBox.select(data.get("Timezone"));
		}
	}



}
