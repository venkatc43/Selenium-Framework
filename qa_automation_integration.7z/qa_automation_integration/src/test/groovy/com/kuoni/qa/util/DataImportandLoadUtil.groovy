package com.kuoni.qa.util


import org.apache.http.auth.Credentials
import org.openqa.selenium.WebDriver
import org.openqa.selenium.WebElement
import org.openqa.selenium.firefox.FirefoxDriver
import org.openqa.selenium.firefox.FirefoxProfile
import org.openqa.selenium.firefox.internal.ProfilesIni

import org.openqa.selenium.By


class DataImportandLoadUtil {

	WebDriver driver = null;


	public DataImportandLoadUtil() {

		ProfilesIni profile = new ProfilesIni();
		FirefoxProfile myprofile = profile.getProfile("AtgProfile");
		driver = new FirefoxDriver(myprofile);

	}

	public gotoUrl(String url1) {
		driver.get(url1);
		driver.manage().window().maximize()
		Thread.sleep(1000)
		//driver.get("http://admin:admin@longwlg05a.emea.kuoni.int:8180/dyn/admin/nucleus/fit/commerce/catalog/loader/DataLoaderQueueRepository/")

		//driver.switchTo().window("http://longwlg05a.emea.kuoni.int:8180")
		//WebElement cancelButton = driver.findElement(By.name("Cancel"))

		//println cancelButton
	}


	public provideDataLocation(String datapath) {

		WebElement datalocation = driver.findElement(By.name("newValue"));
		datalocation.sendKeys(datapath);
		Thread.sleep(2000)
		WebElement submitButton = driver.findElement(By.name("change"));
		submitButton.click();
	}


	public importData(String url2) {
		gotoUrl(url2)
		Thread.sleep(1000)
		WebElement importButton = driver.findElement(By.name("submit"));
		Thread.sleep(2000)
		importButton.click();
	}


	public closeBrowser() {
		driver.quit()
	}

	public clearQueue() {
		String query= " <remove-all-items item-descriptor=\"item\"/> "
		driver.findElement(By.name("xmltext")).sendKeys(query)
		Thread.sleep(2000)
		driver.findElement(By.cssSelector("input[value=Enter]")).click()
	}
}
