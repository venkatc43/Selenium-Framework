package com.kuoni.qa.automation.page.object.content;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.gta.travel.page.base.GSPageBase;
import com.mediaocean.qa.framework.selenium.ui.controls.Button;
import com.mediaocean.qa.framework.selenium.ui.controls.CheckBox;
import com.mediaocean.qa.framework.selenium.ui.controls.ComboBox;
import com.mediaocean.qa.framework.selenium.ui.controls.Link;

public class CategoryDetailsPage extends GSPageBase{
	
	/**
	 * Default Constructor
	 */
	public CategoryDetailsPage(){
		super(getDriver());
	}
	
	/**
	 * This method returns the page factory object for the Category Details Page
	 * @return static
	 */
	public static CategoryDetailsPage getInstance(){
		return PageFactory.initElements(getDriver(),  CategoryDetailsPage.class);
	}
	
	/**
	 * This method clicks on the edit link of the Category details section
	 */
	public void clickEditCategoryDetails() {
		WebElement parentElement = waitForElement(By.id("categoryDetailsContentMenuOptions"));
		Link editLink = new Link(parentElement, "Edit");
		editLink.clickLink();	
		waitForVisibilityOfElement((By.id("categoryDetailsEdit")), 40);
	}
	
	/**
	 * This method enters the values in the edit section of the category details section
	 * @param inputMap
	 */
	public void editCategoryDetails(Map<String, String> inputMap) {
		
		ComboBox stationCombo = null;
		if (inputMap.containsKey("StarRating")){
			stationCombo = new ComboBox(By.id("categoryDetails-rating"));
			stationCombo.select(inputMap.get("StarRating"));
		}
		if (inputMap.containsKey("Category")){
			stationCombo = new ComboBox(By.id("categoryDetails-category"));
			stationCombo.select(inputMap.get("Category"));
		}		
		if (inputMap.containsKey("PropertyType")) {
			stationCombo = new ComboBox(By.id("categoryDetails-type"));
			stationCombo.select(inputMap.get("PropertyType"));
		}
		if (inputMap.containsKey("MinimumAge")) {
			stationCombo = new ComboBox(By.id("categoryDetails-minimumAge"));
			stationCombo.select(inputMap.get("MinimumAge"));
		}
		
		Map<String, String> map = new HashMap<String, String>();
		map.put("Bed and Breakfast", "STYLES-1");
		map.put("Boutique", "STYLES-2");
		map.put("Castle/Chateau", "STYLES-3");
		map.put("Historical", "STYLES-4");
		map.put("Inn", "STYLES-5");
		map.put("Manor House", "STYLES-6");
		map.put("Parador", "STYLES-7");
		map.put("Pousada", "STYLES-8");
		map.put("Resort", "STYLES-9");
		map.put("Ryokan", "STYLES-10");
		map.put("Spa", "STYLES-11");
		map.put("Villa", "STYLES-12");
		
		CheckBox stylesCB  = null;

		if(inputMap.containsKey("Bed and Breakfast")){
			if(inputMap.get("Bed and Breakfast").equalsIgnoreCase("true")){
				stylesCB = new CheckBox(By.id(map.get("Bed and Breakfast")));
				stylesCB.check();	
			}else{
				stylesCB = new CheckBox(By.id(map.get("Bed and Breakfast")));
				stylesCB.uncheck();					
			}
		}
		
		if(inputMap.containsKey("Boutique")){
			if(inputMap.get("Boutique").equalsIgnoreCase("true")){
				stylesCB = new CheckBox(By.id(map.get("Boutique")));
				stylesCB.check();				
			}else{
				stylesCB = new CheckBox(By.id(map.get("Boutique")));
				stylesCB.uncheck();				
			}

		}

		if (inputMap.containsKey("Castle/Chateau")){
			if(inputMap.get("Castle/Chateau").equalsIgnoreCase("true")){
				stylesCB = new CheckBox(By.id(map.get("Castle/Chateau")));
				stylesCB.check();
			}else{
				stylesCB = new CheckBox(By.id(map.get("Castle/Chateau")));
				stylesCB.uncheck();				
			}

		}
		
		if (inputMap.containsKey("Historical")){
			if(inputMap.get("Historical").equalsIgnoreCase("true")){
				stylesCB = new CheckBox(By.id(map.get("Historical")));
				stylesCB.check();
			}else{
				stylesCB = new CheckBox(By.id(map.get("Historical")));
				stylesCB.uncheck();
			}

		}
		
		if (inputMap.containsKey("Inn")){
			if(inputMap.get("Inn").equalsIgnoreCase("true")){
				stylesCB = new CheckBox(By.id(map.get("Inn")));
				stylesCB.check();
			}else{
				stylesCB = new CheckBox(By.id(map.get("Inn")));
				stylesCB.uncheck();
			}

		}
		
		if (inputMap.containsKey("Manor House")){
			if(inputMap.get("Manor House").equalsIgnoreCase("true")){
				stylesCB = new CheckBox(By.id(map.get("Manor House")));
				stylesCB.check();				
			}else{
				stylesCB = new CheckBox(By.id(map.get("Manor House")));
				stylesCB.uncheck();
			}

		}
		
		if (inputMap.containsKey("Parador")){
			if(inputMap.get("Parador").equalsIgnoreCase("true")){
				stylesCB = new CheckBox(By.id(map.get("Parador")));
				stylesCB.check();
			}else{
				stylesCB = new CheckBox(By.id(map.get("Parador")));
				stylesCB.uncheck();
			}

		}
		
		if (inputMap.containsKey("Pousada")){
			if(inputMap.get("Pousada").equalsIgnoreCase("true")){
				stylesCB = new CheckBox(By.id(map.get("Pousada")));
				stylesCB.check();
			}else{
				stylesCB = new CheckBox(By.id(map.get("Pousada")));
				stylesCB.uncheck();
			}

		}
		
		if (inputMap.containsKey("Resort")){
			if(inputMap.get("Resort").equalsIgnoreCase("true")){
				stylesCB = new CheckBox(By.id(map.get("Resort")));
				stylesCB.check();
			}else{
				stylesCB = new CheckBox(By.id(map.get("Resort")));
				stylesCB.uncheck();
			}

		}
		
		if (inputMap.containsKey("Ryokan")){
			if(inputMap.get("Ryokan").equalsIgnoreCase("true")){
				stylesCB = new CheckBox(By.id(map.get("Ryokan")));
				stylesCB.check();
			}else{
				stylesCB = new CheckBox(By.id(map.get("Ryokan")));
				stylesCB.uncheck();
			}

		}
		
		if (inputMap.containsKey("Spa")){
			if(inputMap.get("Spa").equalsIgnoreCase("true")){
				stylesCB = new CheckBox(By.id(map.get("Spa")));
				stylesCB.check();
			}else{
				stylesCB = new CheckBox(By.id(map.get("Spa")));
				stylesCB.uncheck();
			}
		}
		
		if(inputMap.containsKey("Villa")){
			if(inputMap.get("Villa").equalsIgnoreCase("true")){
				stylesCB = new CheckBox(By.id(map.get("Villa")));
				stylesCB.check();
			}else{
				stylesCB = new CheckBox(By.id(map.get("Villa")));
				stylesCB.uncheck();
			}
		}
	}
	
	/**
	 * This method clicks on the cancel button in the category details section
	 */
	public void cancelCategoryDetails() {
		WebElement parentElement = waitForElement(By.id("categoryDetailsContent"));
		Button cancelButton = new Button(parentElement, "Cancel");
		cancelButton.click();
		waitForInVisibilityOfElement((By.id("categoryDetails-rating")), 40);
	}
	
	/**
	 * This method clicks on the update button of the category details section
	 */
	public void updateCategoryDetails() {
		Button updateButton = new Button("categoryDetailsEdit");
		updateButton.click();
		waitForInVisibilityOfElement(By.id("categoryDetails-rating"),40);
	}
	
	/**
	 * @param parentLocator
	 * @param message
	 * @return
	 */
	public boolean verifyRecordUpdatedMessage(By parentLocator, String message){
		WebElement parentEl = waitForElement(parentLocator);
		waitForElement(parentEl, By.className("message"));
		if (getElement(parentEl, By.className("message")).getText().contains(message)){
			return true;
		}
		return false;
	}
	
	/**
	 * This method verifies for the record updated message and will return true 
	 * or false based on the message
	 * @return boolean
	 */
	public boolean isMessageDisplayed(){
		return isElementPresent(By.className("message"));
	}

}
