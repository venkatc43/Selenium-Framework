package com.kuoni.qa.automation.helper

import com.kuoni.qa.automation.dao.GetRateplanDBdata
import com.kuoni.qa.automation.dto.RateplanDTO

class RateplanTestHelper {

	RateplanDTO addlData,dbData
	GetRateplanDBdata data = new GetRateplanDBdata()

	//Cancellations
	def verifyCancellations(ratePlanXml,dbData,data,ratePlanId,softAssert)

	{
		def c = ratePlanXml.recordset.record.ratePlan.cancellations.cancellation
		
		if(c.size()!=0 && c.size() == dbData.getCancelCount())
		{
		for(int i=0;i<c.size();i++)
			{

				addlData=data.getCancellations(ratePlanId,c[i].'@id')
				def startdate = addlData.getCancelStart()
				def enddate = addlData.getCancelEnd()

				softAssert.assertEquals(c[i].'@type',addlData.getCancellationType(),"\n Cancellation Type doesnt match for Cancellation ID : " + c[i].'@id' + " in RatePlan : " + ratePlanId)
				println "Xml Cancellation Type : " + c[i].'@type' + "	Database Cancellation Type : " + addlData.getCancellationType()

				softAssert.assertEquals(c[i].'@travelStart',addlData.getCancelStart()," \n Cancellation Start Date doesnt match for Cancellation ID : " + c[i].'@id' + " in RatePlan : " + ratePlanId)
				println "Xml Cancellation Start Date : " + c[i].'@travelStart' + "	Database Cancellation Start Date : " + addlData.getCancelStart()

				softAssert.assertEquals(c[i].'@travelEnd',addlData.getCancelEnd(),"\n Cancellation EndDate doesnot match for Cancellation Id: "+ c[i].'@id' + "in Rateplan : " + ratePlanId)
				println "Xml Cancellation EndDate : " + c[i].'@travelEnd' + "	Database Cancellation EndDate : " + addlData.getCancelEnd()
				
				softAssert.assertEquals(c[i].'@daysPrior',addlData.getCanceldaysPrior(),"\n Cancellation Days Prior doesnt match for Cancellation ID : " + c[i].'@id' + " in RatePlan : " + ratePlanId)
				println "Xml Cancellation DaysPrior : " + c[i].'@daysPrior' + "	Database Restriction StartDate : " + addlData.getCanceldaysPrior()

				softAssert.assertEquals(c[i].'@cancelTime',addlData.getCancel_time()," \n Cancellation Time doesnt match for Cancellation ID : " + c[i].'@id' + " in property : " + ratePlanId)
				println "Xml Cancellation Time : " + c[i].'@cancelTime' + "	Database Cancellation Time : " + addlData.getCancel_time()

				softAssert.assertEquals(Double.parseDouble(c[i].'@chargePercentage'),addlData.getCancelPercentage(),"\n Cancellation Percentage doesnt match with Database for Cancellation ID : " + c[i].'@id' + " in RatePlan : " + ratePlanId)
				println "Xml Cancellation Percentage : " + Double.parseDouble(c[i].'@chargePercentage') + "	Database Cancellation Percentage : " + addlData.getCancelPercentage()
				
				softAssert.assertEquals(c[i].'@duration',addlData.getCancelduration(),"\n Cancellation Duration doesnt match with Database  for Cancellation ID : " + c[i].'@id' + " in RatePlan : " + ratePlanId)
				println "Xml Cancellation Duration : " + c[i].'@duration' + "	Database Cancellation Duration : " + addlData.getCancelduration()
				

			}
		}
		
		else if(c.size()!=0 && c.size()!= dbData.getCancelCount())
			println "Restrictions Count doesnt match with Database"
	}



	//Restrictions
	def verifyRestrictions(rateplanXml,dbData,data,ratePlanId,softAssert)
	{
		def restrictions = rateplanXml.recordset.record.ratePlan.restrictions.restriction

		if(restrictions.size()!=0 && restrictions.size()==dbData.getRestrictionCount())
		{

			for(int i=0;i<restrictions.size();i++)
			{

				addlData=data.getRestrictions(ratePlanId,restrictions[i].'@id')


				softAssert.assertEquals(restrictions[i].'@travelStart',addlData.getResStartDate(),"\n Restriction Start Date doesnt match for Restriction ID : " + restrictions[i].'@restrictionId' + " in RatePlan : " + ratePlanId)
				println "Xml Restriction Start Date : " + restrictions[i].'@travelStart' + "	Database Restriction StartDate : " + addlData.getResStartDate()

				softAssert.assertEquals(restrictions[i].'@travelEnd',addlData.getResEndDate()," \n Restriction End Date doesnt match for Restriction ID : " + restrictions[i].'@restrictionId' + " in property : " + ratePlanId)
				println "Xml Restriction End Date : " + restrictions[i].'@travelEnd' + "	Database Restriction EndDate : " + addlData.getResEndDate()

				softAssert.assertEquals(restrictions[i].'@type',addlData.getRestrictionType(),"\n Restriction Type : "+restrictions[i].'@type'  +" doesnt match with Database : "+addlData.getRestrictionType() +" for Restriction ID : " + restrictions[i].'@restrictionId' + " in property : " + ratePlanId)
				println "Xml Restriction Type : " + restrictions[i].'@type' + "	Database Restriction Type : " + addlData.getRestrictionType()

			}
		}
		else if(restrictions.size()!=0 && restrictions.size()!= dbData.getRestrictionCount())
			println "Restrictions Count doesnt match with Database"
	}
}


