package com.kuoni.qa.automation.coh.tests
import com.gta.nova.api.search.PropertyPriceAvailabilityRequest

class PropertyPriceAvailabilityRequestBuilder {
	
	
	
	
	 PropertyPriceAvailabilityRequest propertyPriceAvailabilityRequest;
	 
	 Calendar calendar = new GregorianCalendar()
	 
	 private Set<Long> ids = new HashSet<Long>(Collections.singleton(17037L));
	 private Date effectiveDate = calendar.getTime();
	 private long siteId = 1L;
	 private long clientId = 1L;
	 private int occupancy = 1;
	 private Date checkInDate = effectiveDate;
	 private Date checkOutDate = effectiveDate+1;
	 private Integer numberOfBeds = 1;
	 private String country = null;
	 private boolean includeCancellationCondition = false;
	 private String language = null;
	 private String currency = null;
	 private boolean includeImmediateConfirmation = false;
	 
	 public PropertyPriceAvailabilityRequest build() {
	  return new PropertyPriceAvailabilityRequest(siteId, clientId, ids, effectiveDate, occupancy, checkInDate, checkOutDate, numberOfBeds, country, includeCancellationCondition, language, currency, includeImmediateConfirmation);
	 }
	  
	 public PropertyPriceAvailabilityRequestBuilder ids(Set<Long> ids) {
	  this.ids = ids;
	  return this;
	 }
	 
	 public PropertyPriceAvailabilityRequestBuilder effectiveDate(Date effectiveDate) {
	  this.effectiveDate = effectiveDate;
	  return this;
	 }
	 
	 public PropertyPriceAvailabilityRequestBuilder siteId(long siteId) {
	  this.siteId = siteId;
	  return this;
	 }
	 
	 public PropertyPriceAvailabilityRequestBuilder clientId(long clientId) {
	  this.clientId = clientId;
	  return this;
	 }
	 
	 public PropertyPriceAvailabilityRequestBuilder occupancy(int occupancy) {
	  this.occupancy = occupancy;
	  return this;
	 }
	 
	 public PropertyPriceAvailabilityRequestBuilder checkInDate(Date checkInDate) {
	  this.checkInDate = checkInDate;
	  return this;
	 }
	 
	 public PropertyPriceAvailabilityRequestBuilder checkOutDate(Date checkOutDate) {
	  this.checkOutDate = checkOutDate;
	  return this;
	 }
	 
	 public PropertyPriceAvailabilityRequestBuilder numberOfBeds(Integer numberOfBeds) {
	  this.numberOfBeds = numberOfBeds;
	  return this;
	 }
	 
	 public PropertyPriceAvailabilityRequestBuilder country(String country) {
	  this.country = country;
	  return this;
	 }
	 
	 public PropertyPriceAvailabilityRequestBuilder includeCancellationCondition(boolean includeCancellationCondition) {
	  this.includeCancellationCondition = includeCancellationCondition;
	  return this;
	 }
	 
	 public PropertyPriceAvailabilityRequestBuilder language(String language) {
	  this.language = language;
	  return this;
	 }
	 
	 public PropertyPriceAvailabilityRequestBuilder currency(String currency) {
	  this.currency = currency;
	  return this;
	 }
	 
	 public PropertyPriceAvailabilityRequestBuilder includeImmediateConfirmation(boolean includeImmediateConfirmation) {
	  this.includeImmediateConfirmation = includeImmediateConfirmation;
	  return this;
	 }
	
	

}
