package com.kuoni.qa.automation.gc.testcases

import org.testng.asserts.SoftAssert
import spock.lang.IgnoreIf
import spock.lang.Specification
import spock.lang.Stepwise

import com.kuoni.qa.automation.datacreate.test.helper.PropertyFacilitiesAndServicesTestHelper
import com.kuoni.qa.constants.CommonConstants
import com.kuoni.qa.util.CommonUtil
import com.kuoni.qa.util.ConfigProperties
import com.kuoni.qa.util.TestSuiteProperties

@Stepwise
class PropertyPhoneandWebsiteTest_CB_7521 extends Specification{
	
	PropertyFacilitiesAndServicesTestHelper helper = new PropertyFacilitiesAndServicesTestHelper()
	
	
	@IgnoreIf({TestSuiteProperties.getVlaue("Ignore_PropertyPhoneandWebsiteTest_CB_7521").equals("true")? true : false})
	def"update property phone website details"(){
		
		when:"Update property PHONE WEBSITE details from gc application"
		assert helper.updatePhoneWebSite("CB-7521-Update-PhoneNwebsite"),"error occurred while upadting property phone website details from gc application"
		
		then:"Wait Until the Message appears on Queue"
		sleep(Integer.parseInt(ConfigProperties.getVlaue("pollingInterval")))
		
		then: "Load the Data to ATG Database"
		assert helper.loadDataintoAtg(),"Error while loading data into ATG"
		
		then:"Verify Data with the ATG Database"
		sleep(6000)
		helper.verifyPhoneNwebsite("CB-7521-Update-PhoneNwebsite")
		
	}
	
	@IgnoreIf({TestSuiteProperties.getVlaue("Ignore_PropertyGeneralAttributesTest_CB_4222").equals("true")? true : false})
	def"delete property phone website details"(){
		
		when:"Revert property PHONE WEBSITE details from gc application"
		assert helper.updatePhoneWebSite("CB-7521-Revert-PhoneNwebsite"),"error occurred while upadting property phone website details from gc application"
		
		then:"Wait Until the Message appears on Queue"
		sleep(Integer.parseInt(ConfigProperties.getVlaue("pollingInterval")))
		
		then: "Load the Data to ATG Database"
		assert helper.loadDataintoAtg(),"Error while loading data into ATG"
		
		then:"Verify Data with the ATG Database"
		sleep(6000)
		helper.verifyPhoneNwebsite("CB-7521-Revert-PhoneNwebsite")
	}
	
	@IgnoreIf({TestSuiteProperties.getVlaue("Ignore_CloseWebdrver").equals("true")? true : false})
	def "close webdriver"(){
		
		when:""
		if(CommonConstants.webDriver != null){
			CommonConstants.webDriver.quit()
		}
		then:""
	}
	
	def cleanupSpec()
	{
		CommonConstants.webDriver.quit()
	}

}