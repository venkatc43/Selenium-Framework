package com.kuoni.qa.automation.datacreate.test.helper

import java.text.SimpleDateFormat

import com.kuoni.qa.automation.gc.test.PropertyRestrictionsTest
import com.kuoni.qa.util.CommonUtil
import com.kuoni.qa.util.ConfigProperties
import com.mediaocean.qa.framework.utils.DateUtil
import com.mediaocean.qa.framework.utils.ExcelUtil

class PropertyRestrictionsTestHelper {
	
	private ExcelUtil excelData
	
	public def executePropertyRestrictions(String sheetName){
		boolean executionFlag = false
		PropertyRestrictionsTest test = new PropertyRestrictionsTest(ConfigProperties.getVlaue("driverSheetPath"),ConfigProperties.getVlaue("dataSheetPathSprint4"),sheetName)
		if(sheetName.equalsIgnoreCase("CB-4235-Create")){
			test.executePropertyRestrictionCreate()
		}else{
			test.executePropertyRestrictionDelete()
		}
		excelData = test.getData()
		executionFlag = true
		return executionFlag
	}

	public def readXMLFromQ(String filePath, String inputQName, String sheetName){
		boolean executionFlag = false
		def value = null
		String propertyId = excelData.getKeyValue(sheetName, "PropertyId")
		executionFlag = CommonUtil.readXMLFromQ(filePath,inputQName, propertyId)
		return executionFlag
	}
	
	public def validatePropertyRetrictions(String sheetName, String xmlPath){
		
		boolean executionFlag = false
		def xmlFile = new File(xmlPath)
		def changerecords = new XmlParser().parse(xmlFile)
		
		try{
			
			if(sheetName.equals("CB-4235-Create")){
				
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat("YYYY-MM-dd")
				Date date = DateUtil.addDays(new Date(), 30);
				Date date1 = DateUtil.addDays(new Date(), 31);
				String startDate = simpleDateFormat.format(date).concat("T00:00:00")
				String endDate =  simpleDateFormat.format(date1).concat("T23:59:59")
				def value  = changerecords.recordset.record.find{it.recordtype.text() == "INSERT"}.property.restrictions.restriction.find{(it.@type == "Closed for Business") && (it.@startDate == startDate) && (it.@endDate == endDate)}
				assert value != null, "Closed for Business restriction not found with canonical xml"
				
			}else{
				
				def value  = changerecords.recordset.record.find{it.recordtype.text() == "DELETE"}.property.restrictions.restriction
				assert value != null, "deleted property restriction not found with canonical xml"
				
			}

			executionFlag = true
			
		}catch(java.lang.AssertionError e){
			println e
			executionFlag = false
		}catch(Exception e){
			println e
			executionFlag = false
		}
		changerecords = null
		return executionFlag
	}

}
