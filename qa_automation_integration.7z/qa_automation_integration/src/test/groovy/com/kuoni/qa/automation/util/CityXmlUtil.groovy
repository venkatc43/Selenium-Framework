package com.kuoni.qa.automation.util

import com.kuoni.qa.automation.dto.CityDTO

class CityXmlUtil {
	
	def CityDTO readCityXml(def c)
	{
		
		CityDTO xmlData = new CityDTO()
				
		xmlData.setCityCode(c.@code[0])
		xmlData.setTimeZone(c.timezone.text())
		xmlData.setRegionId(c.regionId.text().toInteger())
		xmlData.setCountryId(c.countryId.text().toInteger())

		return xmlData
	}

}
