//package com.kuoni.qa.automation.gc.test;
//
//public class PushPropertyContractRatePlanCancellationsTest {
//
//}
package com.kuoni.qa.automation.gc.test;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import com.gta.travel.page.base.GSTestBase;
import com.gta.travel.page.object.contract.generaldetails.GeneralDetailsCancellationSectionPage;
import com.gta.travel.page.object.contract.rateplans.RatePlanCancellationSectionPage;
import com.gta.travel.page.object.contract.rateplans.RatePlanDetailsSectionPage;
import com.gta.travel.page.object.contract.search.ContractSearchPage;
import com.gta.travel.page.object.contract.search.ContractSearchResultsPage;
import com.kuoni.qa.automation.page.object.common.HomePageSub;
import com.kuoni.qa.automation.page.object.common.LoginPageSub;
import com.mediaocean.qa.framework.selenium.PageBase;
import com.mediaocean.qa.framework.selenium.ui.controls.Table;
import com.mediaocean.qa.framework.utils.DateUtil;
import com.mediaocean.qa.framework.utils.ExcelUtil;

public class PushPropertyContractRatePlanCancellationsTest extends GSTestBase {

	private String userName;
	private String password;
	private String webId;
	private String sheetName = null;
	private ContractSearchPage contractSearchPage;
	private ContractSearchResultsPage contractSearchResultsPage;
	private RatePlanDetailsSectionPage DetailsSectionPage;
	private GeneralDetailsCancellationSectionPage generalDetailsCancellations;
	private RatePlanCancellationSectionPage rpCancellationSectionPage;
	private ExcelUtil excelData;

	public PushPropertyContractRatePlanCancellationsTest ( String driverSheetPath, String dataSheetPath, String sheetName ) {
		this.sheetName = sheetName;
		init(driverSheetPath, dataSheetPath);
	}

	public void init ( String driverSheetPath, String dataSheetPath ) {
		excelData = new ExcelUtil(dataSheetPath);

		if (driverSheetPath != null) {

			setDriverSheetAbsolutePath(driverSheetPath);
		} else {
			setDriverSheetFileName("Driver_Sheet.xls");
		}
		initialiseEnvironmentAndTest();
		openBrowser();
		setLoginInfo();
	}

	private void setLoginInfo ( ) {
		webId = excelUtil.getKeyValue(ENVIRONMENT, "webId");
		userName = excelUtil.getKeyValue(ENVIRONMENT, "userName");
		password = excelUtil.getKeyValue(ENVIRONMENT, "password");
	}

	public void executeDataScriptForCreate ( ) {
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSelectRatePlan();
		executeCreateRatePlanCancellationSecPage();
	}

	public void executeDataScriptForEdit ( ) {
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSelectRatePlan();
		executeEditRatePlanCancellationSecPage();
	}	

	public void executeDataScriptForDelete ( ) {
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSelectRatePlan();
		executeDeleteCancellationSecPage();
	}	

	private void executeSelectRatePlan ( ) {
		DetailsSectionPage = RatePlanDetailsSectionPage.getInstance();
		Map<String, String> map = new HashMap<String, String>();
		map.put("Rate Plan Code", excelData.getKeyValue(sheetName, "Rate Plan Code"));
		DetailsSectionPage.selectRatePlanFromTheList(map);
	}
	public void executeDataScriptForAllDataDelete() {
		generalDetailsCancellations = GeneralDetailsCancellationSectionPage.getInstance();
		generalDetailsCancellations.resetData();
	}

	private void executeLoginPageFlow ( ) {
		LoginPageSub loginPage = new LoginPageSub();
		HomePageSub homePage = loginPage.login(webId, userName, password);
		contractSearchPage = homePage.selectContract();
		contractSearchPage.sleep(2);
	}

	private void executeSearchScreenFlow ( ) {
		Map<String, String> searchDataMap = new HashMap<String, String>();
		searchDataMap.put("Country", excelData.getKeyValue(sheetName, "Country"));
		searchDataMap.put("City", excelData.getKeyValue(sheetName, "City"));
		searchDataMap.put("Property Name", excelData.getKeyValue(sheetName, "Property Name"));
		contractSearchResultsPage = contractSearchPage.search(searchDataMap);
		contractSearchResultsPage.sleep(3);
		contractSearchResultsPage.selectFirstRowFromTheResults();
	}

	public void executeDeleteCancellationSecPage() {
		generalDetailsCancellations = GeneralDetailsCancellationSectionPage.getInstance();
		Map<String, String> cancellationRecordMap = new HashMap<String, String>();
		cancellationRecordMap.put("Rate Type", excelData.getKeyValue(sheetName, "Rate Type"));
		cancellationRecordMap.put("Day/Time Prior", excelData.getKeyValue(sheetName, "Day/Time Prior"));
		cancellationRecordMap.put("Charge Condition",excelData.getKeyValue(sheetName, "Charge Condition"));
		generalDetailsCancellations.selectCancellation(cancellationRecordMap);
		generalDetailsCancellations.selectCancellationOptions("Delete");
		generalDetailsCancellations.deleteCancellationWithOK();
	}	

	private void executeCreateRatePlanCancellationSecPage() {
		rpCancellationSectionPage = RatePlanCancellationSectionPage.getInstance();
		Map<String, String> map = new HashMap<String, String>();
		map.put("override base cancellation",excelData.getKeyValue(sheetName, "override base cancellation"));
		map.put("days prior",excelData.getKeyValue(sheetName, "days prior"));
		map.put("arrival time", excelData.getKeyValue(sheetName, "arrival time"));
		map.put("percentage",excelData.getKeyValue(sheetName, "percentage"));
		map.put("charge duration",excelData.getKeyValue(sheetName, "charge duration"));
		String todayDay = Integer.toString(DateUtil.getDay(new Date()));
		String todayMonth = DateUtil.getMonthName(new Date());
		String todayYear = Integer.toString(DateUtil.getYear(new Date()));
		map.put("travel start day", todayDay);
		map.put("travel start month", todayMonth);
		map.put("travel start year", todayYear);
		map.put("travel end day", "31");
		map.put("travel end month", "Dec");
		map.put("travel end year", todayYear);
		rpCancellationSectionPage.createCancellation(map);
		rpCancellationSectionPage.saveCancellation();
	}
	private void executeEditRatePlanCancellationSecPage() {
		rpCancellationSectionPage = RatePlanCancellationSectionPage.getInstance();
		Map<String, String> map = new HashMap<String, String>();
		map.put("override base cancellation",excelData.getKeyValue(sheetName, "override base cancellation"));
		map.put("days prior",excelData.getKeyValue(sheetName, "days prior"));
		map.put("arrival time", excelData.getKeyValue(sheetName, "arrival time"));
		map.put("percentage",excelData.getKeyValue(sheetName, "percentage"));
		map.put("charge duration",excelData.getKeyValue(sheetName, "charge duration"));
		String todayDay = Integer.toString(DateUtil.getDay(new Date()));
		String todayMonth = DateUtil.getMonthName(new Date());
		String todayYear = Integer.toString(DateUtil.getYear(new Date()));
		map.put("travel start day", todayDay);
		map.put("travel start month", todayMonth);
		map.put("travel start year", todayYear);
		map.put("travel end day", "31");
		map.put("travel end month", "Dec");
		map.put("travel end year", todayYear);
		selectCancellation(map);
		rpCancellationSectionPage.selectCancellationOptions("Edit");
		Map<String, String> ChangedValuesMap = new HashMap<String, String>();
		ChangedValuesMap.put("override base cancellation",excelData.getKeyValue(sheetName, "override base cancellation"));
		ChangedValuesMap.put("days prior",excelData.getKeyValue(sheetName, "days prior"));
		rpCancellationSectionPage.editCancellation(ChangedValuesMap);
		rpCancellationSectionPage.updateCancellation();
		rpCancellationSectionPage.selectCancellationOptions("Refresh");
	}


	public void selectCancellation(Map<String, String> inputMap){
		WebElement parentEl = PageBase.waitForElement(By.id("cancellation_list"));
		Table table = new Table(parentEl, 1);
		for (int i=1;i<table.getRowCount();){
			table.getCell(i, "Rate Type").click();
			PageBase.waitForElement(By.id("cancellation_div"),5);
			break;
		}
	}

}
