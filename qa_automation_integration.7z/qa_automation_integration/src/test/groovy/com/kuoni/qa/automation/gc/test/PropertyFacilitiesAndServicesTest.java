package com.kuoni.qa.automation.gc.test;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.gta.travel.page.base.GSTestBase;
import com.gta.travel.page.object.common.HomePage;
import com.gta.travel.page.object.common.LoginPage;
import com.gta.travel.page.object.common.TopLinksPage;
import com.gta.travel.page.object.content.facilitiesandservices.CheckInDetailsPage;
import com.gta.travel.page.object.content.search.ContentSearchPage;
import com.gta.travel.page.object.content.search.ContentSearchResultsPage;
import com.kuoni.qa.automation.dao.GetPropertyDBdata;
import com.kuoni.qa.automation.dto.PropertyDTO;
import com.kuoni.qa.automation.page.object.content.CategoryDetailsPage;
import com.kuoni.qa.automation.page.object.content.FacilitiesAndServicesDetailsPage;
import com.kuoni.qa.automation.page.object.content.PropertyMainAddressPage;
import com.kuoni.qa.constants.CommonConstants;
import com.mediaocean.qa.framework.utils.ExcelUtil;

public class PropertyFacilitiesAndServicesTest extends GSTestBase{

	private LoginPage loginPage;
	private HomePage homePage;
	private ContentSearchPage contentSearchPage;
	private ContentSearchResultsPage contentSearchResultsPage;
	private FacilitiesAndServicesDetailsPage facilitiesAndServicesDetailsPage;
	private CategoryDetailsPage categoryDetailsPage;
	private PropertyMainAddressPage propertyMainAddressPage;
	private TopLinksPage topLinksPage;
	private CheckInDetailsPage checkInDetailsPage;
	
	
	private String userName;
	private String password;
	private String webId;
	
	ExcelUtil data = null;
	private static String sheetName = null;
	
	public PropertyFacilitiesAndServicesTest()
	{
		
	}
	
	public PropertyFacilitiesAndServicesTest(String driverSheetPath, String dataSheetPath, String sheetName){
		this.sheetName = sheetName;
		init(driverSheetPath, dataSheetPath);			
	}
	
	public void init(String driverSheetPath, String dataSheetPath){
		data = new ExcelUtil(dataSheetPath);
		if (driverSheetPath != null){
			defaultEnvironment="TEST";
			setDriverSheetAbsolutePath(driverSheetPath);
		}
		initialiseEnvironmentAndTest();
		openBrowser();
		setLoginInfo();
		CommonConstants.webDriver = getDriver();		
	}
	
	private void setLoginInfo() {
		webId = excelUtil.getKeyValue(ENVIRONMENT, "webId");
		userName = excelUtil.getKeyValue(ENVIRONMENT, "userName");
		password = excelUtil.getKeyValue(ENVIRONMENT, "password");
	}
	
	public void executeDataScriptsForUpdateGenralAttributesFromFecilitiesSection(){
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSearchResultsScreenFlow();
		executeEditGeneralAttributesFromFacilitiesSection();
	
		
//		getDriver().quit();
	}
	
	public void executeDataScriptsForUpdateRoomServiceFromFecilitiesSection(){
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSearchResultsScreenFlow();
		executeEditRoomServiceTest();
//		getDriver().quit();
	}
	
	public void executeDataScriptsForUpdateMaidServiceFromFecilitiesSection(){
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSearchResultsScreenFlow();
		executeEditMaidServiceTest();
//		getDriver().quit();
	}	
	
	public void executeDataScriptsForUpdateCheckInCheckOutDeatils(){
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSearchResultsScreenFlow();
		editCheckinCheckOutDetails();
//		getDriver().quit();
	}	
	
	public void executeDataScriptsForDeleteRoomServiceFromFecilitiesSection(){
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSearchResultsScreenFlow();
		executeDeleteRoomServiceTest();
//		getDriver().quit();
	}
	
	public void executeDataScriptsForDeleteMaidServiceFromFecilitiesSection(){
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSearchResultsScreenFlow();
		executeDeleteMaidServiceTest();
//		getDriver().quit();
	}	
	
	public void executeDataScriptsForStyleAssignmentsUpdate(){
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSearchResultsScreenFlow();
		executeEditStyleAssignments();
//		getDriver().quit();
	}
	
	public void executeDataScriptsForUpdateCategoryDetails(){
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSearchResultsScreenFlow();
		executeEditCategoryDetails();
//		getDriver().quit();
	}
	
	public void executeDataScriptsForUpdatePhoneWebsite(){
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSearchResultsScreenFlow();
		executeEditPhoneWebsite();
//		getDriver().quit();
	}		
	
	private void executeLoginPageFlow(){
		loginPage = new LoginPage(getDriver());
		homePage = loginPage.login(webId, userName, password);
		contentSearchPage = homePage.selectContent();
		contentSearchPage.sleep(2);
	}
	
	private void executeSearchScreenFlow(){
		Map<String, String> searchDataMap = new HashMap<String, String>();
		searchDataMap.put("Country", data.getKeyValue(sheetName, "Country"));
		searchDataMap.put("City", data.getKeyValue(sheetName, "City"));
		searchDataMap.put("Property Name",data.getKeyValue(sheetName,"Property Name") );
		contentSearchResultsPage = contentSearchPage.search(searchDataMap);
		contentSearchResultsPage.sleep(2);
	}
	
	private void executeSearchResultsScreenFlow(){
		Map<String, String> searchResultsDataMap = new HashMap<String, String>();
		searchResultsDataMap.put("Country", data.getKeyValue(sheetName, "Country"));
		searchResultsDataMap.put("City", data.getKeyValue(sheetName, "City"));
		searchResultsDataMap.put("Property Name", data.getKeyValue(sheetName, "Property Name"));
		topLinksPage = contentSearchResultsPage.selectRecordFromSearchResults(searchResultsDataMap);
		topLinksPage.sleep(3);

	}
	
	private void executeEditGeneralAttributesFromFacilitiesSection(){
		topLinksPage.clickFacilitiesAndServices();
		topLinksPage.sleep(2);		
		facilitiesAndServicesDetailsPage = FacilitiesAndServicesDetailsPage.getInstance();
		Map<String, String> map = new HashMap<String, String>();
		map.put("TotalRooms", data.getKeyValue(sheetName, "TotalRooms"));
		map.put("Lifts", data.getKeyValue(sheetName, "Lifts"));
		map.put("CoachDropOff", data.getKeyValue(sheetName, "CoachDropOff"));
		map.put("IndoorPools", data.getKeyValue(sheetName, "IndoorPools"));
		map.put("OutdoorPools", data.getKeyValue(sheetName, "OutdoorPools"));
		map.put("ChildrensPools", data.getKeyValue(sheetName, "ChildrensPools"));
		map.put("EarlierBreakfast", data.getKeyValue(sheetName, "EarlierBreakfast"));
		facilitiesAndServicesDetailsPage.clickEditFacilitiesAndServicesDetails();
		facilitiesAndServicesDetailsPage.editFacilitiesAndServicesDetails(map);
		facilitiesAndServicesDetailsPage.sleep(1);
		facilitiesAndServicesDetailsPage.updateFacilitiesAndServicesDetails();
		facilitiesAndServicesDetailsPage.sleep(1);
	}

	private void executeEditCategoryDetails(){
		topLinksPage.clickFacilitiesAndServices();
		topLinksPage.sleep(2);		
		categoryDetailsPage = CategoryDetailsPage.getInstance();
		Map<String, String> map = new HashMap<String, String>();
		map.put("StarRating", data.getKeyValue(sheetName, "StarRating"));
		map.put("Category", data.getKeyValue(sheetName, "Category"));
		map.put("PropertyType", data.getKeyValue(sheetName, "PropertyType"));
		map.put("MinimumAge", data.getKeyValue(sheetName, "MinimumAge"));
		categoryDetailsPage.clickEditCategoryDetails();
		categoryDetailsPage.editCategoryDetails(map);
		categoryDetailsPage.sleep(1);
		categoryDetailsPage.updateCategoryDetails();
		categoryDetailsPage.sleep(1);
	}
	
	private void executeEditStyleAssignments(){
		topLinksPage.clickFacilitiesAndServices();
		topLinksPage.sleep(2);		
		categoryDetailsPage = CategoryDetailsPage.getInstance();
		Map<String, String> map = new HashMap<String, String>();
		map.put("Bed and Breakfast", data.getKeyValue(sheetName, "Bed and Breakfast"));
		map.put("Boutique", data.getKeyValue(sheetName, "Boutique"));
		map.put("Castle/Chateau", data.getKeyValue(sheetName, "Castle/Chateau"));
		map.put("Historical", data.getKeyValue(sheetName, "Historical"));
		map.put("Inn", data.getKeyValue(sheetName, "Inn"));
		map.put("Manor House", data.getKeyValue(sheetName, "Manor House"));
		map.put("Parador", data.getKeyValue(sheetName, "Parador"));
		map.put("Pousada", data.getKeyValue(sheetName, "Pousada"));
		map.put("Resort", data.getKeyValue(sheetName, "Resort"));
		map.put("Ryokan", data.getKeyValue(sheetName, "Ryokan"));
		map.put("Spa", data.getKeyValue(sheetName, "Spa"));
		map.put("Villa", data.getKeyValue(sheetName, "Villa"));		
		categoryDetailsPage.clickEditCategoryDetails();
		categoryDetailsPage.editCategoryDetails(map);
		categoryDetailsPage.sleep(1);
		categoryDetailsPage.updateCategoryDetails();
		categoryDetailsPage.sleep(1);
	}	
	
	private void executeEditPhoneWebsite(){
		propertyMainAddressPage = PropertyMainAddressPage.getInstance();
		propertyMainAddressPage.clickEditLink();
		propertyMainAddressPage.sleep(1);
		Map<String, String> map = new HashMap<String, String>();
		map.put("Telephone Number", data.getKeyValue(sheetName, "Telephone Number"));
		map.put("Website", data.getKeyValue(sheetName, "Website"));
		propertyMainAddressPage.editPropertyPhoneWebsite(map);
		propertyMainAddressPage.sleep(1);
	}
	
	private void executeEditRoomServiceTest(){
		topLinksPage.clickFacilitiesAndServices();
		topLinksPage.sleep(2);		
		facilitiesAndServicesDetailsPage = FacilitiesAndServicesDetailsPage.getInstance();
		Map<String, String> map = new HashMap<String, String>();
		map.put("RoomService", data.getKeyValue(sheetName, "RoomService"));
		map.put("RoomServiceTwentyFourHour", data.getKeyValue(sheetName, "RoomServiceTwentyFourHour"));
		map.put("TimesFrom", data.getKeyValue(sheetName, "TimesFrom"));
		map.put("TimesTo", data.getKeyValue(sheetName, "TimesTo"));
		facilitiesAndServicesDetailsPage.clickEditFacilitiesAndServicesDetails();
		facilitiesAndServicesDetailsPage.editFacilitiesAndServicesDetails(map);
		facilitiesAndServicesDetailsPage.sleep(1);
		facilitiesAndServicesDetailsPage.updateFacilitiesAndServicesDetails();
		facilitiesAndServicesDetailsPage.sleep(1);		
	}
	
	private void executeDeleteRoomServiceTest(){
		topLinksPage.clickFacilitiesAndServices();
		topLinksPage.sleep(2);		
		facilitiesAndServicesDetailsPage = FacilitiesAndServicesDetailsPage.getInstance();
		Map<String, String> map = new HashMap<String, String>();
		map.put("RoomService", data.getKeyValue(sheetName, "RoomService"));
		facilitiesAndServicesDetailsPage.clickEditFacilitiesAndServicesDetails();
		facilitiesAndServicesDetailsPage.editFacilitiesAndServicesDetails(map);
		facilitiesAndServicesDetailsPage.sleep(1);
		facilitiesAndServicesDetailsPage.updateFacilitiesAndServicesDetails();
		facilitiesAndServicesDetailsPage.sleep(1);		
	}
	
	private void executeEditMaidServiceTest(){
		topLinksPage.clickFacilitiesAndServices();
		topLinksPage.sleep(2);		
		facilitiesAndServicesDetailsPage = FacilitiesAndServicesDetailsPage.getInstance();
		Map<String, String> map = new HashMap<String, String>();
		map.put("MaidService", data.getKeyValue(sheetName, "MaidService"));
		map.put("MaidServiceFrequency", data.getKeyValue(sheetName, "MaidServiceFrequency"));
		map.put("ServiceCharge", data.getKeyValue(sheetName, "ServiceCharge"));
		facilitiesAndServicesDetailsPage.clickEditFacilitiesAndServicesDetails();
		facilitiesAndServicesDetailsPage.editFacilitiesAndServicesDetails(map);
		facilitiesAndServicesDetailsPage.sleep(1);
		facilitiesAndServicesDetailsPage.updateFacilitiesAndServicesDetails();
		facilitiesAndServicesDetailsPage.sleep(1);		
	}
	
	private void executeDeleteMaidServiceTest(){
		topLinksPage.clickFacilitiesAndServices();
		topLinksPage.sleep(2);		
		facilitiesAndServicesDetailsPage = FacilitiesAndServicesDetailsPage.getInstance();
		Map<String, String> map = new HashMap<String, String>();
		map.put("MaidService", data.getKeyValue(sheetName, "MaidService"));
		facilitiesAndServicesDetailsPage.clickEditFacilitiesAndServicesDetails();
		facilitiesAndServicesDetailsPage.editFacilitiesAndServicesDetails(map);
		facilitiesAndServicesDetailsPage.sleep(1);
		facilitiesAndServicesDetailsPage.updateFacilitiesAndServicesDetails();
		facilitiesAndServicesDetailsPage.sleep(1);		
	}
	
	private void editCheckinCheckOutDetails(){
		topLinksPage.clickFacilitiesAndServices();
		topLinksPage.sleep(2);
		checkInDetailsPage = CheckInDetailsPage.getInstance();

		Map<String, String> inputMap = new HashMap<String, String>();
		String[] arrCheckInRowValBefore = new String[4];
		String[] arrCheckInRowValAfter = new String[4];

		inputMap.put("CheckInTime", data.getKeyValue(sheetName, "CheckInTime"));
		inputMap.put("CheckOutTime", data.getKeyValue(sheetName, "CheckOutTime"));
		inputMap.put("CheckInDays", data.getKeyValue(sheetName, "CheckInDays"));
		inputMap.put("CheckOutDays", data.getKeyValue(sheetName, "CheckOutDays"));

		checkInDetailsPage.clickEditCheckInDetails();
		checkInDetailsPage.editCheckInDetails(inputMap);
		checkInDetailsPage.sleep(1);
		checkInDetailsPage.updateCheckInDetails();
			
	}
	
	public void executeDataScriptForUpdatePropertyContent(){
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSearchResultsScreenFlow();
		executeEditCategoryDetails();
	}

	public ExcelUtil getData() {
		return data;
	}
	
	
	
	
	
	
}
