package com.kuoni.qa.automation.datacreate.test.helper

import groovy.util.slurpersupport.Node

import javax.xml.XMLConstants
import javax.xml.transform.stream.StreamSource
import javax.xml.validation.Schema
import javax.xml.validation.SchemaFactory
import javax.xml.validation.Validator

import org.xml.sax.SAXException

import com.kuoni.qa.automation.gc.test.PropertyLocationDetailsTest
import com.kuoni.qa.util.ConfigProperties
import com.kuoni.qa.util.HornetQUtil
import com.mediaocean.qa.framework.utils.ExcelUtil

class PropertyLocationDetailsTestHelper {
	ExcelUtil excelData
	public def editPropertyLocationDetailsFromGCApplication(String sheetName){
		boolean executionFlag = false
		try{
			PropertyLocationDetailsTest test = new PropertyLocationDetailsTest(ConfigProperties.getVlaue("driverSheetPath"),ConfigProperties.getVlaue("dataSheetPath"),sheetName)
			test.executeDataScriptsForUpdate()
			executionFlag = true
		}catch(Exception e){
			println e
		}
		return executionFlag;
	}
	
	public def validateEditPropertyLocationDetailsInputXML(){
		boolean executionFlag = false
		try{
			def xmlFile = new File(ConfigProperties.getVlaue("propertyLocationDetaislInputXMLPathForEdit"))
			def contentrecords = new XmlParser().parse(xmlFile)
			def record = contentrecords.recordset.record[0]
			executionFlag = true
		}catch(Exception e){
			println e
		}
		return executionFlag
	}
	
	public def readcdmOutputXMLFromOutputQ(String filePath, String outputQName){
		boolean executionFlag = false
		File file = null
		String message = null
		HornetQUtil hornetQUtil = HornetQUtil.getInstance()
		message  = hornetQUtil.subscribeMessage(outputQName)
		file  = new File(filePath).write(message)
		executionFlag = true
		return executionFlag
 }
	
	public def  boolean validateCanonicalXML(String xsdFilePath, String  xmlPath){
		
				try {
					def xsdFile = new File(xsdFilePath)
					def xmlFile = new File(xmlPath)
					SchemaFactory factory =
							SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI)
					Schema schema = factory.newSchema(xsdFile)
					Validator validator = schema.newValidator()
					validator.validate(new StreamSource(xmlFile))
				}
				catch (IOException | SAXException e) {
					System.out.println("Exception: "+ e.getMessage())
					return false
				}
				return true
			}
		
	public def parseXmlAttribute(groovy.util.slurpersupport.Node contentrecords, String k, String v){
		
				contentrecords.childNodes().each { child ->
					child.attributes()
					child.attributes().each{ it ->
						it.key +"==" + it.value
						if(it.key.equalsIgnoreCase(k)){
		
							def value = it.value
							assert value.equalsIgnoreCase(v), "data is not maching"
							if(value.equalsIgnoreCase(v)){
								println value + ' & ' + v + " both match "
							}
						}
					}
					parseXmlAttribute(child, k, v)
		
		
				}
			}
	
	public def parseXmlforENUMs(groovy.util.slurpersupport.Node contentrecords, String k, String v){
		boolean match
		contentrecords.childNodes().each { child ->

			if(child.name.equalsIgnoreCase(k)){

				def value = child.text()
				if(v.equalsIgnoreCase("french") && value.equalsIgnoreCase("fr")){
					match = true
				}
				if(v.equalsIgnoreCase("english") && value.equalsIgnoreCase("en")){
					match = true
				}
				assert match, "data is not maching"
				if(match){
					println "inputData: " +value  + ' & '  + " outputData: " + v  + "   " + " both match "
				}
			}
			parseXmlforENUMs(child, k, v)

		}
	}
	public def parseXml(groovy.util.slurpersupport.Node contentrecords, String k, String v){
		
				contentrecords.childNodes().each { child ->
		
					if(child.name.equalsIgnoreCase(k)){
		
						def value = child.text()
					/*	String v=new String(str);
						println(v.trim());*/
						assert value.equalsIgnoreCase(v), "data is not maching"
						if(value.equalsIgnoreCase(v)){
							println "inputData: " +value  + ' & '  + " outputData: " + v  + "   " + " both match "
						}
					}
					parseXml(child, k, v)
		
				}
			}
	public def validateXmlFileWithXlsValues(Map<String, String> data, String xmlPath){
		def xmlFile = new File(xmlPath)
		def contentrecords = new XmlSlurper().parse(xmlFile)
		data.each{ k, v ->
			println "${k}:${v}"
			def key = k.value.toString()
			def value = v.value.toString()
			contentrecords.childNodes().each { child ->
				child.name
				parseXml(child, key, value)
			}
		}
	}

	public def validateXmlFileWithXlsValuesEnums(Map<String, String> data, String xmlPath){
		def xmlFile = new File(xmlPath)
		def contentrecords = new XmlSlurper().parse(xmlFile)
		data.each{ k, v ->
			println "${k}:${v}"
			def key = k.value.toString()
			def value = v.value.toString()
			contentrecords.childNodes().each { child ->
				child.name
				parseXmlforENUMs(child, key, value)
			}
		}
	}

	public def validateXmlFileWithXlsValuesAttrs(Map<String, String> data, String xmlPath){
		def xmlFile = new File(xmlPath)
		def contentrecords = new XmlSlurper().parse(xmlFile)
		data.each{ k, v ->
			println "${k}:${v}"
			def key = k.value.toString()
			def value = v.value.toString()
			contentrecords.childNodes().each { child ->
				parseXmlAttribute(child, key, value)
			}
		}
	}
	public def validateLocationDetailsOutputXML(String sheetName,String xmlPath ){
		boolean executionFlag = false
		Map<String, String> data = new HashMap<String,String>()
//		Map<String, String> data1 = new HashMap<String,String>()
//		Map<String, String> data2 = new HashMap<String,String>()
		excelData = new ExcelUtil(ConfigProperties.getVlaue("dataSheetPath"))
		try{
			data.put("latitude", excelData.getKeyValue(sheetName, "Latitude"))
//			if(sheetName.equalsIgnoreCase("CB-3597-Create")){
//				data.put("text", excelData.getKeyValue(sheetName, "Text"))
//			}else if(sheetName.equalsIgnoreCase("CB-3597-Edit")){
//				data.put("text", excelData.getKeyValue(sheetName, "TextEdit"))
//			}else{
//				data.put("text", excelData.getKeyValue(sheetName, "Text"))
//			}
			data.put("longitude", excelData.getKeyValue(sheetName, "Longitude"))
			//data2.put("code", excelData.getKeyValue(sheetName, "Code"))
			validateXmlFileWithXlsValues(data, xmlPath)
//			validateXmlFileWithXlsValuesEnums(data1, xmlPath)
//			validateXmlFileWithXlsValuesAttrs(data2, xmlPath)
			executionFlag = true
		}catch(Exception e){
			println e
		}
		return executionFlag

	}
}
