package com.kuoni.qa.automation.page.object.text;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import com.gta.travel.page.base.GSPageBase;
import com.mediaocean.qa.framework.selenium.ui.controls.Button;
import com.mediaocean.qa.framework.selenium.ui.controls.ComboBox;

public class TextPage extends GSPageBase {

	public TextPage ( WebDriver driver ) {
		super(getDriver());
	}

	public void createText ( Map<String, String> data ) {
		waitForElement(By.id("code"));
		applyDataForCityPage(data);
		Button editCity = new Button("Save");
		editCity.click();
	}

	public void editText ( Map<String, String> data ) {
		waitForElement(By.name("category"));
		applyDataForCityPage(data);
		Button editCity = new Button("Save");
		editCity.click();
	}

	private void applyDataForCityPage ( Map<String, String> data ) {
		if (data.get("Category") != null) {
			ComboBox propTypeComboBox = new ComboBox(By.id("category"));
			propTypeComboBox.select(data.get("Category"));
		}
		if (data.get("Code") != null) {
			clearAndType(By.id("code"), data.get("Code"));
		}
		if (data.get("Language") != null) {
			ComboBox propTypeComboBox = new ComboBox(By.id("language"));
			propTypeComboBox.select(data.get("Language"));
		}
		if (data.get("Text") != null) {
			clearAndType(By.id("text"), data.get("Text"));
		}
	}
}
