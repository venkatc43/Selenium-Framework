package com.kuoni.qa.automation.atg.test

import static com.kuoni.qa.automation.util.ReadFilesUtil.getFiles

import org.junit.Ignore
import org.testng.asserts.SoftAssert

import spock.lang.Shared;
import spock.lang.Specification
import spock.lang.Unroll;

import com.kuoni.qa.automation.common.properties.EnvironmentProperties
import com.kuoni.qa.automation.dao.GetPropertyDBdata
import com.kuoni.qa.automation.dto.PropertyDTO
import com.kuoni.qa.automation.helper.PropertyTestHelper
import com.kuoni.qa.automation.spock.annotation.Regression
import com.kuoni.qa.automation.util.PerformDataLoadUtil
import com.kuoni.qa.automation.util.PropertyUtil
import com.kuoni.qa.automation.util.PropertyXmlUtil

class PropertyDataTest extends Specification{

	GetPropertyDBdata data
	PropertyTestHelper propertyValidator = new PropertyTestHelper()


	@Shared
	EnvironmentProperties envProp = new EnvironmentProperties()

	def setupSpec() {

		def folderLocation = envProp.getValueForProperty("istDataLoc")+"/Property"
		PerformDataLoadUtil dataLoad = new PerformDataLoadUtil()
		dataLoad.changeTestDataReaderLocation(folderLocation)
		dataLoad.importFilesandPerformLoadfromQueue()
	}


	@Regression
	@Unroll
	def "VerifyPropertyXmlData for : #fileEntry.getName()"() {

		given: "XML Test Data for Property is available at the appropriate Location"

		def envprop = new EnvironmentProperties()
		SoftAssert softAssert = new SoftAssert()
		PropertyXmlUtil getxmlDetails = new PropertyXmlUtil()
		PropertyDTO dbData,xmlData
		PropertyDTO facilityData
		Set propertyCount = new HashSet()
		when: "Property xml files are according to the XSD agreed and accesible by the tests"


		def propertyXml = new XmlParser().parse(fileEntry)
		//Read the XML File and set the values
		xmlData= getxmlDetails.readXML(propertyXml)

		//Counting the Number of Properties by using ProperyId
		def propertyId = xmlData.getPropertyId()
		propertyCount.add(propertyId)


		data = new GetPropertyDBdata()
		dbData = data.getPropertyData(propertyId)


		//Verifying the xml properties with the database

		def properties = xmlData.properties
		println "\n" + "Verifying Data for Property : " + fileEntry.getName() + "\n"
		properties.each {node,val->

			if(PropertyUtil.requireAssert("$node".toString()) )
			{
				if("$node" == "addressL1" || "$node" == "addressL2" || "$node" == "addressL3" )
				{
					if ((xmlData."$node").length()>0)
					{

						softAssert.assertEquals(xmlData."$node", dbData."$node", "\n" + "Xml " + "$node" + ": " + xmlData."$node"+ "	Doesn't Match with "+" DataBase " + "$node" + ": " + dbData."$node" + " For property : " + propertyId+"	in File : "+ fileEntry)
						println "Xml " + "$node" + ": " + xmlData."$node"+ "	::		" + " DataBase " + "$node" + ": " + dbData."$node"
					}
				}else if ((xmlData."$node")!= null && ((xmlData."$node")!=""))
				{

					softAssert.assertEquals(xmlData."$node", dbData."$node", "\n" + "Xml " + "$node" + ": " + xmlData."$node"+ "	Doesn't Match with "+" DataBase " + "$node" + ": " + dbData."$node" + " For property : " + propertyId+"	in File : "+ fileEntry)
					println "Xml " + "$node" + ": " + xmlData."$node"+ "	::		" + " DataBase " + "$node" + ": " + dbData."$node"
				}
			}

		}

		//Verify facilities,informations,activities,styles and swimmingPools

		propertyValidator.verifyFacility(propertyXml, dbData,data,propertyId,softAssert)
		propertyValidator.verifyInformations(propertyXml, dbData,data,propertyId,softAssert)
		propertyValidator.verifyActivity(propertyXml, dbData,data,propertyId,softAssert)
		propertyValidator.verifyStyles(propertyXml, dbData,data,propertyId,softAssert)
		propertyValidator.verifyRestrictions(propertyXml, dbData,data,propertyId,softAssert)
		propertyValidator.verifySwimmingPools(propertyXml, dbData,data,propertyId,softAssert)


		//		}
		//Verify the property count with the database
		//	softAssert.assertEquals(propertyCount.size(), dbData.getPropertyCount(),"\n"+"PropertyCount " + propertyCount.size() + " : Doesnt Match with dataBase :" + dbData.getPropertyCount())

		//println "\n" + "XML PropertyCount: " + propertyCount.size() + " DB rows: " + dbData.getPropertyCount()
		softAssert.assertAll()
		then: "The XML Data for Property should Match with the Database"
		println "\n" + "***Test complete***"

		where:
		fileEntry << getFiles("/Property")
	}
}


