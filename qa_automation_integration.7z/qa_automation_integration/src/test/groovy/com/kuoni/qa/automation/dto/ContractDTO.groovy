package com.kuoni.qa.automation.dto

class ContractDTO {

	def contractId
	def contractType
	def contractModel
	def contractStatus
	def providerId
	def onSale
	def propertyId
	def allowOnRequest
	def validFrom
	
	def legacyCityCode
	def legacyPropertyCode
	def channelCode
	def channelCount
	
	
	def cancellationId
	def cancellationType
	def cancelStart
	def cancelEnd
	def cancelDaysPrior
	def cancelTime
	def cancelchargePercentage
	def cancelDuration
	def cancelCount
	
	def restrictionId
	def restrictionType
	def restrictionStart
	def restrictionEnd
	def restrictionDaysPrior
	def restrictionCount
	def countryCount
	def countryCode
	
	
	public String getCancellationType()
	{
		if(cancellationType =="1")
		{
			return "Standard"
		}
		else if (cancellationType =="2")
		return "Peak"
	}
	
	
	
	public String getOnSale()
	{
		
		if(onSale=="true" || onSale == "1")
		return "true"
		else
		return "false"
		
	}
	
	public String getAllowOnRequest()
	{
		if(allowOnRequest=="true" || allowOnRequest=="1")
		return "true"
		else
		return "false"
	}
	
	public String getContractModel()
	{
		if(contractModel == "Static" || contractModel == "611")
		return "Static"
		else if (contractModel == "Margin" || contractModel == "612")
		return "Margin"
	}
	
	public String getContractStatus()
	{
		if(contractStatus == "Live" || contractStatus== "607" )
		return "Live"
		else if (contractStatus == "Pending" || contractStatus== "608" )
		return "Pending"
		else if (contractStatus == "Suspended" || contractStatus== "609" )
		return "Suspended"
		else if (contractStatus == "Cancelled" || contractStatus== "610" )
		return "Cancelled"
	}
	
	
	public String getContractType()
	{
		if(contractType == "Property" || contractType== "601" )
		return "Property"
		else if (contractType == "Transfers" || contractType== "602" )
		return "Transfers"
		else if (contractType == "Sightseeing" || contractType== "603" )
		return "Sightseeing"
	}
	
	
	
	
	
	
	
	
}
