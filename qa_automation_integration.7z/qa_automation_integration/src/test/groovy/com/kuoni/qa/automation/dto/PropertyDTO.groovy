package com.kuoni.qa.automation.dto

class PropertyDTO {


	def propertyId
	def addressId
	def addressActive
	def addressType
	def addressL1
	def addressL2
	def addressL3
	def postCode
	def countryId
	def cityId

	def locationCode
	def geoLatitude
	def geoLongitude
	def legCityCode
	def legPropertyCode
	def starRating

	def propertyName
	def propertyCount

	def facilityName
	def facilityCount

	def informationName
	def informationCount

	def activityName
	def activityCount

	def styleName
	def styleCount

	def totalRooms

	def checkinTime
	def checkoutTime

	def minAge
	def coachDrop

	def telephone
	def website

	def poolTypeCount
	def swimmingCount
	
	def roomService
	def maidService
	def multimediaLinks
	def propertyDesc
	def roomCategoryDesc
	
	
	def restrictionId
	def restrictionType
	def resStartDate
	def resEndDate
	def restrictionsCount

	def provisionsCount
	
	def roomServiceRequired
	def availableAllDay
	def timeRange
	
	def maidServiceRequired
	def chargeApplies
	def frequency
	
	def earliestBreakFast
	
	
	/*public def getStarRating() {
		
				if(starRating == "NONE" || starRating== "SANDALS")
					return -1
				else
					return starRating
			}*/
	
	
	
	public String getAvailableAllDay() {
		
				if(addressActive == 1 || addressActive == "true")
					return "true"
				else
					return "false"
			}
	
	public String getFrequency() {
		
				if(frequency == null )
					return "null"
				else
					return frequency
			}
	
	
	
	public String getMaidServiceRequired() {
		
				if(maidServiceRequired == 1 || maidServiceRequired == "true")
					return "true"
				else
					return "false"
			}
	
	public String getChargeApplies() {
		
				if(chargeApplies == 1 || chargeApplies == "true")
					return "true"
				else
					return "false"
			}
	
	
		
	
	public String getRoomServiceRequired() {
		
				if(roomServiceRequired == 1 || roomServiceRequired == "true")
					return "true"
				else
					return "false"
			}
		

	public String getAddressActive() {

		if(addressActive == 1 || addressActive == "true")
			return "true"
		else
			return "false"
	}


	public String getCoachDrop() {

		if(coachDrop == 1 || coachDrop == "true")
			return "true"
		else
			return "false"
	}
}
