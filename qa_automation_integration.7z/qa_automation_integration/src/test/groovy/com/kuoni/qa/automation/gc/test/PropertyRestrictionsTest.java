package com.kuoni.qa.automation.gc.test;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.gta.travel.page.base.GSTestBase;
import com.gta.travel.page.object.common.HomePage;
import com.gta.travel.page.object.common.LoginPage;
import com.gta.travel.page.object.common.TopLinksPage;
import com.gta.travel.page.object.content.renovationsandupdates.PropertyRestrictionsPage;
import com.gta.travel.page.object.content.search.ContentSearchPage;
import com.gta.travel.page.object.content.search.ContentSearchResultsPage;
import com.kuoni.qa.constants.CommonConstants;
import com.gta.travel.page.object.contract.generaldetails.GeneralDetailsRestrictionSectionPage;
import com.mediaocean.qa.framework.utils.DateUtil;
import com.mediaocean.qa.framework.utils.ExcelUtil;

public class PropertyRestrictionsTest extends GSTestBase{

	private LoginPage loginPage;
	private HomePage homePage;
	private ContentSearchPage contentSearchPage;
	private ContentSearchResultsPage contentSearchResultsPage;
	private TopLinksPage topLinksPage;
	private PropertyRestrictionsPage propertyRestrictionsPage;
	private GeneralDetailsRestrictionSectionPage generalDetailsRestrictionSectionPage;
	
	private String userName;
	private String password;
	private String webId;
	
	private ExcelUtil data = null;
	private static String sheetName = null;
	
	public PropertyRestrictionsTest(String driverSheetPath, String dataSheetPath, String sheetName){
		this.sheetName = sheetName;
		init(driverSheetPath, dataSheetPath);		
	}
	
	public void init(String driverSheetPath, String dataSheetPath){
		data = new ExcelUtil(dataSheetPath);
		if (driverSheetPath != null){
			setDriverSheetAbsolutePath(driverSheetPath);
		}
		initialiseEnvironmentAndTest();
		openBrowser();
		setLoginInfo();
		CommonConstants.webDriver = getDriver();
	}
	
	private void setLoginInfo() {
		webId = excelUtil.getKeyValue(ENVIRONMENT, "webId");
		userName = excelUtil.getKeyValue(ENVIRONMENT, "userName");
		password = excelUtil.getKeyValue(ENVIRONMENT, "password");
	}
	
	public void executePropertyRestrictionCreate(){
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSearchResultsScreenFlow();
		createPropertyRestriction();
//		getDriver().quit();
	}
	
	public void executePropertyRestrictionDelete(){
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSearchResultsScreenFlow();
		deletePropertyRestriction();
//		getDriver().quit();		
	}
	
	private void executeLoginPageFlow(){
		loginPage = new LoginPage(getDriver());
		homePage = loginPage.login(webId, userName, password);
		contentSearchPage = homePage.selectContent();
		contentSearchPage.sleep(2);
	}
	
	private void executeSearchScreenFlow(){
		Map<String, String> searchDataMap = new HashMap<String, String>();
		searchDataMap.put("Country", data.getKeyValue(sheetName, "Country"));
		searchDataMap.put("City", data.getKeyValue(sheetName, "City"));
		searchDataMap.put("Property Name",data.getKeyValue(sheetName,"Property Name"));
		contentSearchResultsPage = contentSearchPage.search(searchDataMap);
		contentSearchResultsPage.sleep(2);
	}
	
	private void executeSearchResultsScreenFlow(){
		Map<String, String> searchResultsDataMap = new HashMap<String, String>();
		searchResultsDataMap.put("Country", data.getKeyValue(sheetName, "Country"));
		searchResultsDataMap.put("City", data.getKeyValue(sheetName, "City"));
		searchResultsDataMap.put("Property Name", data.getKeyValue(sheetName, "Property Name"));
		topLinksPage = contentSearchResultsPage.selectRecordFromSearchResults(searchResultsDataMap);
		topLinksPage.sleep(3);

	}	
	
	private void createPropertyRestriction(){
		
		topLinksPage.clickRenovationsAndUpdatesTab();
		topLinksPage.sleep(2);
		propertyRestrictionsPage = PropertyRestrictionsPage.getInstance();
		propertyRestrictionsPage.resetData();
		propertyRestrictionsPage.sleep(2);
		Map<String, String> inputMap = new HashMap<String, String>();
		inputMap.put("RestrictionType", "Closed for business");	
		
		Date date = DateUtil.addDays(new Date(), 30);
		String todayDay = Integer.toString(DateUtil.getDay(date));
		String todayMonth = DateUtil.getMonthName(date);
		String todayYear = Integer.toString(DateUtil.getYear(date));
		
		inputMap.put("StartDay", todayDay);
		inputMap.put("StartMonth", todayMonth);
		inputMap.put("StartYear", todayYear);
		
		Date date1 = DateUtil.addDays(new Date(), 31);
		String endDay = Integer.toString(DateUtil.getDay(date1));
		String endMonth = DateUtil.getMonthName(date1);
		String endYear = Integer.toString(DateUtil.getYear(date1));
		
		inputMap.put("EndDay", endDay);
		inputMap.put("EndMonth", endMonth);
		inputMap.put("EndYear", endYear);

		propertyRestrictionsPage.clickCreatePropertyRestrictions();
		propertyRestrictionsPage.enterRestrictionDetails(inputMap);
		//propertyRestrictionsPage.addAnotherPropertyRestrictionsDetails();		
	}
	
	private void deletePropertyRestriction(){
		topLinksPage.clickRenovationsAndUpdatesTab();
		topLinksPage.sleep(2);
		propertyRestrictionsPage = PropertyRestrictionsPage.getInstance();
		Map<String, String> inputMap = new HashMap<String, String>();
		inputMap.put("Restriction Type", "Closed for business");
		propertyRestrictionsPage.selectPropertyRestriction(inputMap);
		propertyRestrictionsPage.sleep(1);
		propertyRestrictionsPage.selectPropertyRestrictionsOptions("Delete");
		getDriver().switchTo().alert().accept();
		propertyRestrictionsPage.sleep(2);		
	}

	public ExcelUtil getData() {
		return data;
	}
	
}
