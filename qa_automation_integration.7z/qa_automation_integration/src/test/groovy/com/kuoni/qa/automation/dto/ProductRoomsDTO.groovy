package com.kuoni.qa.automation.dto

class ProductRoomsDTO {

	def roomActive
	def roomCategory
	def roomType
	def twinBed
	def doubleBed
	def singleBed
	def tripleBed
	def quadBed
	def twinSoleUse
	def doubleSoleUse
	def maximumOccupcy
	def cots
	def beds
	def extraBed
	def rateBasis
	def existingBed
	def bathAndShower

	public def getRoomActive() {

		if (roomActive == 1 || roomActive =="true")
			return "true"
		else
			return "false"
	}

	public String getTwinBed() {
		if (twinBed == 1 || twinBed ==  "true")
			return "true"
		else
			return "false"
	}
	public void setTwinBed(def twinBed) {
		this.twinBed = twinBed
	}
	public String getDoubleBed() {
		if (doubleBed == 1 || doubleBed == "true")
			return "true"
		else
			return "false"
	}
	public void setDoubleBed(def doubleBed) {
		this.doubleBed = doubleBed
	}
	public String getSingleBed() {
		if (singleBed == 1 || singleBed == "true")
			return "true"
		else
			return "false"
	}
	public void setSingleBed(def singleBed) {
		this.singleBed = singleBed
	}
	public String getTripleBed() {
		if (tripleBed == 1 || tripleBed == "true")
			return "true"
		else
			return "false"
	}
	public void setTripleBed(def tripleBed) {
		this.tripleBed = tripleBed
	}
	public String getQuadBed() {
		if (quadBed == 1 || quadBed == "true")
			return "true"
		else
			return "false"
	}
	public String getTwinSoleUse() {
		if (twinSoleUse == 1 || twinSoleUse == "true")
			return "true"
		else
			return "false"
	}
	public void setTwinSoleUse(def twinSoleUse) {
		this.twinSoleUse = twinSoleUse
	}
	public String getDoubleSoleUse() {
		if (doubleSoleUse == 1 || doubleSoleUse == "true")
			return "true"
		else
			return "false"
	}

	public String getExistingBed() {
		if (existingBed == 1 || existingBed == "true")
			return "true"
		else
			return "false"
	}
	public void setExistingBed(def existingBed) {
		this.existingBed = existingBed
	}
	public String getBathAndShower() {
		if (bathAndShower == 1 || bathAndShower == "true")
			return "true"
		else
			return "false"
	}
}
