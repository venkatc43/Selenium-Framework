package com.kuoni.qa.automation.datacreate.test.helper

import com.kuoni.qa.automation.gc.test.PropertyFeatureAssignmentsTest
import com.kuoni.qa.util.CommonUtil
import com.kuoni.qa.util.ConfigProperties
import com.mediaocean.qa.framework.utils.ExcelUtil

class PropertyFeatureAssignmentsTestHelper {
	
	private ExcelUtil excelData
	
	public def updatePropertyFeaturesFromGC(String sheetName){
		boolean executionFlag = false
		PropertyFeatureAssignmentsTest test = new PropertyFeatureAssignmentsTest(ConfigProperties.getVlaue("driverSheetPath"),ConfigProperties.getVlaue("dataSheetPathSprint4"),sheetName)
		excelData = test.getExcelUtil()
		if(sheetName.equalsIgnoreCase("CB-3992-Update")){
			test.executeDataScriptsForUpdate()
		}else{
			test.executeDataScriptsForDelete()
		}
		executionFlag = true
		return executionFlag
	}
	
	public def readXMLFromQ(String filePath, String inputQName, String sheetName){
		boolean executionFlag = false
		def value = null
		String propertyId = excelData.getKeyValue(sheetName, "PropertyId")
		executionFlag = CommonUtil.readXMLFromQ(filePath,inputQName, propertyId)
		return executionFlag
	}
		
	public def validatePropertyFeaturesAssignmentsOutputXML(String sheetName,String xmlPath ){

		boolean executionFlag = false
//		excelData = new ExcelUtil(ConfigProperties.getVlaue("dataSheetPathSprint4"))
		def xmlFile = new File(xmlPath)
		def changerecords = new XmlParser().parse(xmlFile)
		String code = null
		def value = null
		try{
			
			code = excelData.getKeyValue(sheetName, "BabySittingCode")
			value =  changerecords.recordset.record.property.facilities.facility.find{it.@code == code}
			assert value != null,"Canonical xml not contains Baby Sitting Code"
			
			code = excelData.getKeyValue(sheetName, "BeautyParlourCode")
			value =  changerecords.recordset.record.property.facilities.facility.find{it.@code == code}
			assert value != null,"Canonical xml not contains Beauty Parlour Code"
			
			code = excelData.getKeyValue(sheetName, "BicycleHireCode")
			value = changerecords.recordset.record.property.activities.activity.find{it.@code == code}
			assert value != null,"Canonical xml not contains Bicycle Hire Code"
			
			code = excelData.getKeyValue(sheetName, "CasinoCode")
			value = changerecords.recordset.record.property.activities.activity.find{it.@code == code}
			assert value != null,"Canonical xml not contains Casino Code"
			
			code = excelData.getKeyValue(sheetName, "BeachFrontCode")
			value = changerecords.recordset.record.property.informations.information.find{it.@code == code}
			assert value != null,"Canonical xml not contains Beach Front Code"
			
			code = excelData.getKeyValue(sheetName, "CarEssentialCode")
			value = changerecords.recordset.record.property.informations.information.find{it.@code == code}
			assert value != null,"Canonical xml not contains Car Essential Code"
			
			executionFlag = true
		}catch(java.lang.AssertionError e){
			println e
			executionFlag = false
		}catch(Exception e){
			println e
			executionFlag = false
		}
		excelData = null
		changerecords = null
		return executionFlag
	}

}
