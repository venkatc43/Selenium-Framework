package com.kuoni.qa.automation.gc.testcases

import org.testng.asserts.SoftAssert
import spock.lang.IgnoreIf
import spock.lang.Specification
import spock.lang.Stepwise

import com.kuoni.qa.automation.datacreate.test.helper.PropertyFacilitiesAndServicesTestHelper
import com.kuoni.qa.constants.CommonConstants
import com.kuoni.qa.util.CommonUtil
import com.kuoni.qa.util.ConfigProperties
import com.kuoni.qa.util.TestSuiteProperties

@Stepwise
class PropertyGeneralAttributesTest_CB_5910 extends Specification{
	
	PropertyFacilitiesAndServicesTestHelper helper = new PropertyFacilitiesAndServicesTestHelper()
	
	
	@IgnoreIf({TestSuiteProperties.getVlaue("Ignore_PropertyGeneralAttributesTest_CB_5910").equals("true")? true : false})
	def "update property general attributes"(){
		
		when:"Update property GENERIC attributes from gc application"

		assert helper.updateGeneralAttributes("CB-5910-Update-G-Attributes"),"error occurred while updating general updates from gc application"
		assert helper.updateCategoryDetails("CB-5910-Update-G-Attributes"),"error occurred while upadting property category details from gc application"
		
		then:"Wait Until the Message appears on Queue"
		sleep(Integer.parseInt(ConfigProperties.getVlaue("pollingInterval")))
		
		then: "Load the Data to ATG Database"
		assert helper.loadDataintoAtg(),"Error while loading data into ATG"
		
		then:"Verify Data with the ATG Database"
		sleep(6000)
		helper.verifyATGProperyGenericdata("CB-5910-Update-G-Attributes")
		
		then:"load the Data to Endecca and Coherence"
		assert helper.loadDatatoCEC(),"Error Loading data to CMS, Endecca and Coherence"
		sleep(6000)
		
		then:"Verify data in Coherence"
		assert helper.verifyCOHProperyGenericdata("CB-5910-Update-G-Attributes")
		
		
	}
	
	@IgnoreIf({TestSuiteProperties.getVlaue("Ignore_PropertyGeneralAttributesTest_CB_4222").equals("true")? true : false})
	def"Revert property general attributes"(){
		
		when:"Revert property GENERIC attributes from gc application"
		assert helper.updateGeneralAttributes("CB-5910-Delete-G-Attributes"),"error occurred while updating general updates from gc application"
		assert helper.updateCategoryDetails("CB-5910-Delete-G-Attributes"),"error occurred while upadting property category details from gc application"
		
		then:"Wait Until the Message appears on Queue"
		sleep(Integer.parseInt(ConfigProperties.getVlaue("pollingInterval")))
		
		then: "Load the Data to ATG Database"
		assert helper.loadDataintoAtg(),"Error while loading data into ATG"
		
		then:"Verify Data with the ATG Database"
		sleep(6000)
		helper.verifyATGProperyGenericdata("CB-5910-Delete-G-Attributes")
		
		then:"load the Data to Endecca and Coherence"
		assert helper.loadDatatoCEC(),"Error Loading data to CMS, Endecca and Coherence"
		sleep(6000)
		
		then:"Verify data in Coherence"
		assert helper.verifyCOHProperyGenericdata("CB-5910-Delete-G-Attributes")
	}
	
	
	
	@IgnoreIf({TestSuiteProperties.getVlaue("Ignore_CloseWebdrver").equals("true")? true : false})
	def "close webdriver"(){
		
		when:""
		if(CommonConstants.webDriver != null){
			CommonConstants.webDriver.quit()
		}
		then:""
	}
	
	def cleanupSpec()
	{
		CommonConstants.webDriver.quit()
	}

}
