package com.kuoni.qa.automation.page.object.contracts;

import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.gta.travel.page.base.GSPageBase;
import com.mediaocean.qa.framework.selenium.ui.controls.Button;
import com.mediaocean.qa.framework.selenium.ui.controls.CheckBox;
import com.mediaocean.qa.framework.selenium.ui.controls.ComboBox;
import com.mediaocean.qa.framework.selenium.ui.controls.Link;
import com.mediaocean.qa.framework.selenium.ui.controls.RadioButton;
import com.mediaocean.qa.framework.selenium.ui.controls.TextBox;

public class RatePlanStandardRateSectionPageCustom extends GSPageBase {

	public String[] dayArr = { "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun", "All" };

	/**
	 * Default Constructor
	 */
	public RatePlanStandardRateSectionPageCustom ( ) {
		super(getDriver());
	}

	/**
	 * This method returns the instance of the current object.
	 * 
	 * @return RatePlanStandardRateSectionPage
	 */
	public static RatePlanStandardRateSectionPageCustom getInstance ( ) {
		return PageFactory.initElements(getDriver(), RatePlanStandardRateSectionPageCustom.class);
	}

	/**
	 * This method sets the values to create the new Rate Rule.
	 * 
	 * @param inputMap
	 */
	public void createStandardRates ( Map<String, String> inputMap ) {

		if (inputMap.containsKey("start day")) {
			waitForElement(By.id("rateRule-travelStartDatePicker_day"));
			ComboBox startDay = new ComboBox(By.id("rateRule-travelStartDatePicker_day"));
			startDay.select(inputMap.get("start day"));
		}
		if (inputMap.containsKey("start month")) {
			waitForElement(By.id("rateRule-travelStartDatePicker_months"));
			ComboBox startMonth = new ComboBox(By.id("rateRule-travelStartDatePicker_months"));
			startMonth.select(inputMap.get("start month"));
		}
		if (inputMap.containsKey("start year")) {
			waitForElement(By.id("rateRule-travelStartDatePicker_years"));
			ComboBox startYear = new ComboBox(By.id("rateRule-travelStartDatePicker_years"));
			startYear.select(inputMap.get("start year"));
		}

		if (inputMap.containsKey("end day")) {
			String endDayValue = inputMap.get("end day");
			waitForElement(By.id("rateRule-travelEndDatePicker_day"));
			ComboBox endDay = new ComboBox(By.id("rateRule-travelEndDatePicker_day"));
			endDay.select(endDayValue);
			if (!endDay.getSelectedItem().equals(endDayValue)) {
				endDay.select(endDayValue);
			}
		}
		if (inputMap.containsKey("end month")) {
			String endMonthValue = inputMap.get("end month");
			waitForElement(By.id("rateRule-travelEndDatePicker_months"));
			ComboBox endMonth = new ComboBox(By.id("rateRule-travelEndDatePicker_months"));
			endMonth.select(endMonthValue);
			if (!endMonth.getSelectedItem().equals(endMonthValue)) {
				endMonth.select(endMonthValue);
			}
		}
		if (inputMap.containsKey("end year")) {
			String endYearValue = inputMap.get("end year");
			waitForElement(By.id("rateRule-travelEndDatePicker_years"));
			ComboBox endYear = new ComboBox(By.id("rateRule-travelEndDatePicker_years"));
			endYear.select(endYearValue);
			if (!endYear.getSelectedItem().equals(endYearValue)) {
				endYear.select(endYearValue);
			}
		}

		if (inputMap.containsKey("days")) {
			String value = inputMap.get("days");
			if (value.equalsIgnoreCase("All")) {
				CheckBox allCB = new CheckBox(By.id("daysOfWeekTickAll"));
				if (!allCB.isChecked()) {
					allCB.check();
				}
				for (int i = 0; i < dayArr.length - 1; i++) {
					CheckBox dayCB = new CheckBox(By.id("daysOfWeek" + i));
					if (!dayCB.isChecked()) {
						dayCB.check();
					}
				}
			} else {
				CheckBox allCB = new CheckBox(By.id("daysOfWeekTickAll"));
				if (allCB.isChecked()) {
					allCB.uncheck();
				}
				for (int i = 0; i < dayArr.length - 1; i++) {
					CheckBox dayCB = new CheckBox(By.id("daysOfWeek" + i));
					if (dayCB.isChecked()) {
						dayCB.uncheck();
					}
				}

				for (int i = 0; i < dayArr.length - 1; i++) {
					String dayValue = dayArr[i];
					waitForElement(By.id("daysOfWeek" + i));
					CheckBox dayCB = new CheckBox(By.id("daysOfWeek" + i));
					if (value.contains(dayValue)) {
						dayCB.check();
					}
				}
			}
			// new CheckBox(By.id("daysOfWeekTickAll")).check();;
			// new CheckBox(By.id("daysOfWeekTickAll")).uncheck();
			//
			// for (int i=0;i<dayArr.length;i++){
			// String dayValue = dayArr[i];
			// CheckBox dayCB = null;
			//
			// if (i<6){
			// waitForElement(By.id("daysOfWeek"+i));
			// dayCB = new CheckBox(By.id("daysOfWeek"+i));
			// }else{
			// waitForElement(By.id("daysOfWeekTickAll"));
			// dayCB = new CheckBox(By.id("daysOfWeekTickAll"));
			// }
			// if (value.contains(dayValue)){
			// dayCB.check();
			// }
			// }
		}

		if (inputMap.containsKey("minimum nights")) {
			waitForElement(By.id("minNightsSelect"));
			ComboBox startDay = new ComboBox(By.id("minNightsSelect"));
			startDay.select(inputMap.get("minimum nights"));
		}
		if (inputMap.containsKey("minimum passengers")) {
			waitForElement(By.id("minPax"));
			ComboBox startDay = new ComboBox(By.id("minPax"));
			startDay.select(inputMap.get("minimum passengers"));
		}

		if (inputMap.containsKey("rate type")) {
			String value = inputMap.get("rate type");
			if (value.equalsIgnoreCase("Nett")) {
				RadioButton rateTypeRB = new RadioButton(By.name("rateType"), "N");
				rateTypeRB.select();
			} else {
				RadioButton rateTypeRB = new RadioButton(By.name("rateType"), "Q");
				rateTypeRB.select();
			}
		}
		if (inputMap.containsKey("more rules")) {
			RadioButton moreRulesRB = new RadioButton(By.name("moreRules"),
					inputMap.get("more rules"));
			moreRulesRB.select();
		}

		if (inputMap.containsKey("stay full period")) {
			RadioButton moreRulesRB = new RadioButton(By.name("fullPeriod"),
					inputMap.get("stay full period"));
			moreRulesRB.select();
		}

		CheckBox roomType0 = new CheckBox(By.id("rateRuleCreate.roomCheck.0"));
		CheckBox roomType1 = new CheckBox(By.id("rateRuleCreate.roomCheck.1"));
		CheckBox roomType2 = new CheckBox(By.id("rateRuleCreate.roomCheck.2"));
		CheckBox roomType3 = new CheckBox(By.id("rateRuleCreate.roomCheck.3"));
		CheckBox roomType4 = new CheckBox(By.id("rateRuleCreate.roomCheck.4"));
		CheckBox roomType5 = new CheckBox(By.id("rateRuleCreate.roomCheck.5"));
		CheckBox roomType6 = new CheckBox(By.id("rateRuleCreate.roomCheck.6"));
		CheckBox roomType7 = new CheckBox(By.id("rateRuleCreate.roomCheck.7"));
		CheckBox roomType8 = new CheckBox(By.id("rateRuleCreate.roomCheck.8"));
		CheckBox roomType9 = new CheckBox(By.id("rateRuleCreate.roomCheck.9"));

		int count = -1;
		for (int i = 0; i < 25; i++) {
			if (isElementPresent(By.id("rateRuleCreate.roomCheck." + i))) {
				CheckBox roomType = new CheckBox(By.id("rateRuleCreate.roomCheck." + i));
				roomType.uncheck();
				executeIEFireEventJS("rateRuleCreate.roomCheck." + i, "onclick");
				count++;
			}
		}

		if (inputMap.containsKey("Beachfront 1 Bedroom Suite")) {
			roomType0.check();
		} else {
			roomType0.uncheck();
		}
		if (inputMap.containsKey("Beachfront 1 Bedroom Suite net")) {
			TextBox stdRmNetTB = new TextBox(By.id("rateRuleCreate.nett.0"));
			stdRmNetTB.setText(inputMap.get("Beachfront 1 Bedroom Suite net"));
		}
		if (inputMap.containsKey("Beachfront 1 Bedroom Suite rsp")) {
			TextBox stdRmRSPTB = new TextBox(By.id("rateRuleCreate.rsp.0"));
			stdRmRSPTB.setText(inputMap.get("Beachfront 1 Bedroom Suite rsp"));
		}

		if (inputMap.containsKey("Business Twin")) {
			roomType1.check();
		} else {
			roomType1.uncheck();
		}
		if (inputMap.containsKey("Business Twin net")) {
			TextBox stdRmNetTB = new TextBox(By.id("rateRuleCreate.nett.1"));
			stdRmNetTB.setText(inputMap.get("Business Twin net"));
		}
		if (inputMap.containsKey("Business Twin rsp")) {
			TextBox stdRmRSPTB = new TextBox(By.id("rateRuleCreate.rsp.1"));
			stdRmRSPTB.setText(inputMap.get("Business Twin rsp"));
		}

		if (inputMap.containsKey("Business Twin - TSU")) {
			roomType2.check();
		} else {
			roomType2.uncheck();
		}

		if (inputMap.containsKey("Business Twin - TSU net")) {
			TextBox stdRmNetTB = new TextBox(By.id("rateRuleCreate.nett.2"));
			stdRmNetTB.setText(inputMap.get("Business Twin - TSU net"));
		}
		if (inputMap.containsKey("Business Twin - TSU rsp")) {
			TextBox stdRmRSPTB = new TextBox(By.id("rateRuleCreate.rsp.2"));
			stdRmRSPTB.setText(inputMap.get("Business Twin - TSU rsp"));
		}

		if (inputMap.containsKey("Classic Single")) {
			roomType3.check();
		} else {
			roomType3.uncheck();
		}
		if (inputMap.containsKey("Classic Single net")) {
			TextBox stdRmNetTB = new TextBox(By.id("rateRuleCreate.nett.3"));
			stdRmNetTB.setText(inputMap.get("Classic Single net"));
		}
		if (inputMap.containsKey("Classic Single rsp")) {
			TextBox stdRmRSPTB = new TextBox(By.id("rateRuleCreate.rsp.3"));
			stdRmRSPTB.setText(inputMap.get("Classic Single rsp"));
		}
		if (inputMap.containsKey("Economy Single")) {
			roomType4.check();
		} else {
			roomType4.uncheck();
		}
		if (inputMap.containsKey("Economy Single net")) {
			TextBox stdRmNetTB = new TextBox(By.id("rateRuleCreate.nett.4"));
			stdRmNetTB.setText(inputMap.get("Economy Single net"));
		}
		if (inputMap.containsKey("Economy Single rsp")) {
			TextBox stdRmRSPTB = new TextBox(By.id("rateRuleCreate.rsp.4"));
			stdRmRSPTB.setText(inputMap.get("Economy Single rsp"));
		}

		if (inputMap.containsKey(" Economy Triple")) {
			roomType5.check();
		} else {
			roomType5.uncheck();
		}
		if (inputMap.containsKey(" Economy Triple net")) {
			TextBox stdRmNetTB = new TextBox(By.id("rateRuleCreate.nett.5"));
			stdRmNetTB.setText(inputMap.get(" Economy Triple net"));
		}
		if (inputMap.containsKey(" Economy Triple rsp")) {
			TextBox stdRmRSPTB = new TextBox(By.id("rateRuleCreate.rsp.5"));
			stdRmRSPTB.setText(inputMap.get(" Economy Triple rsp"));
		}

		if (inputMap.containsKey("Economy Twin")) {
			roomType6.check();
		} else {
			roomType6.uncheck();
		}

		if (inputMap.containsKey("Economy Twin net")) {
			TextBox stdRmNetTB = new TextBox(By.id("rateRuleCreate.nett.6"));
			stdRmNetTB.setText(inputMap.get("Economy Twin net"));
		}
		if (inputMap.containsKey("Economy Twin rsp")) {
			TextBox stdRmRSPTB = new TextBox(By.id("rateRuleCreate.rsp.6"));
			stdRmRSPTB.setText(inputMap.get("Economy Twin rsp"));
		}

		if (inputMap.containsKey("Standard Quad")) {
			roomType7.check();
		} else {
			roomType7.uncheck();
		}
		if (inputMap.containsKey("Standard Quad net")) {
			TextBox stdRmNetTB = new TextBox(By.id("rateRuleCreate.nett.7"));
			stdRmNetTB.setText(inputMap.get("Standard Quad net"));
		}
		if (inputMap.containsKey("Standard Quad rsp")) {
			TextBox stdRmRSPTB = new TextBox(By.id("rateRuleCreate.rsp.7"));
			stdRmRSPTB.setText(inputMap.get("Standard Quad rsp"));
		}
		if (inputMap.containsKey("Standard Room")) {
			roomType8.check();
		} else {
			roomType8.uncheck();
		}

		if (inputMap.containsKey("Standard Room net")) {
			TextBox stdRmNetTB = new TextBox(By.id("rateRuleCreate.nett.8"));
			stdRmNetTB.setText(inputMap.get("Standard Room net"));
		}
		if (inputMap.containsKey("Standard Room rsp")) {
			TextBox stdRmRSPTB = new TextBox(By.id("rateRuleCreate.rsp.8"));
			stdRmRSPTB.setText(inputMap.get("Standard Room rsp"));
		}

		if (inputMap.containsKey("Standard Single")) {
			roomType9.check();
		} else {
			roomType9.uncheck();
		}
		if (inputMap.containsKey("Standard Single net")) {
			TextBox stdRmNetTB = new TextBox(By.id("rateRuleCreate.nett.9"));
			stdRmNetTB.setText(inputMap.get("Standard Single net"));
		}
		if (inputMap.containsKey("Standard Single rsp")) {
			TextBox stdRmRSPTB = new TextBox(By.id("rateRuleCreate.rsp.9"));
			stdRmRSPTB.setText(inputMap.get("Standard Single rsp"));
		}

	}

	/**
	 * This method edit the values of the rate rules.
	 * 
	 * @param inputMap
	 */
	public void editRateRules ( Map<String, String> inputMap ) {

		if (inputMap.containsKey("more rules")) {
			waitForElements(By.name("moreRules"));
			try {
				RadioButton moreRulesRB = new RadioButton(By.name("moreRules"),
						inputMap.get("more rules"));
				moreRulesRB.select();
			} catch (Exception e) {
				sleep(2);
				RadioButton moreRulesRB = new RadioButton(By.name("moreRules"),
						inputMap.get("more rules"));
				moreRulesRB.select();
			}
		}

		if (inputMap.containsKey("stay full period")) {
			waitForElements(By.id("fullPeriod"));
			try {
				RadioButton stayFullPeriodRB = new RadioButton(By.id("fullPeriod"),
						inputMap.get("stay full period"));
				stayFullPeriodRB.select();
			} catch (Exception e) {
				sleep(2);
				RadioButton stayFullPeriodRB = new RadioButton(By.id("fullPeriod"),
						inputMap.get("stay full period"));
				stayFullPeriodRB.select();
			}
		}

		CheckBox roomType0 = new CheckBox(By.id("rateRuleEdit.roomCheck.0"));
		CheckBox roomType1 = new CheckBox(By.id("rateRuleEdit.roomCheck.1"));
		CheckBox roomType2 = new CheckBox(By.id("rateRuleEdit.roomCheck.2"));
		CheckBox roomType3 = new CheckBox(By.id("rateRuleEdit.roomCheck.3"));
		CheckBox roomType4 = new CheckBox(By.id("rateRuleEdit.roomCheck.4"));
		CheckBox roomType5 = new CheckBox(By.id("rateRuleEdit.roomCheck.5"));
		CheckBox roomType6 = new CheckBox(By.id("rateRuleEdit.roomCheck.6"));
		CheckBox roomType7 = new CheckBox(By.id("rateRuleEdit.roomCheck.7"));
		CheckBox roomType8 = new CheckBox(By.id("rateRuleEdit.roomCheck.8"));
		CheckBox roomType9 = new CheckBox(By.id("rateRuleEdit.roomCheck.9"));

		int count = -1;
		for (int i = 0; i < 25; i++) {
			if (isElementPresent(By.id("rateRuleEdit.roomCheck." + i))) {
				CheckBox roomType = new CheckBox(By.id("rateRuleEdit.roomCheck." + i));
				roomType.uncheck();
				executeIEFireEventJS("rateRuleEdit.roomCheck." + i, "onclick");
				count++;
			}
		}

		if (inputMap.containsKey("room type edit")
				&& inputMap.get("room type edit").equalsIgnoreCase("Yes")) {
			roomType0.uncheck();
			roomType1.uncheck();
			roomType2.uncheck();
			roomType3.uncheck();
			roomType4.uncheck();
			roomType5.uncheck();
			roomType6.uncheck();
			roomType7.uncheck();
			roomType8.uncheck();
			roomType9.uncheck();

		}

		if (inputMap.containsKey("Beachfront 1 Bedroom Suite")) {
			roomType0.check();
		} else {
			roomType0.uncheck();
		}
		if (inputMap.containsKey("Beachfront 1 Bedroom Suite net")) {
			TextBox stdRmNetTB = new TextBox(By.id("rateRuleEdit.nett.0"));
			stdRmNetTB.setText(inputMap.get("Beachfront 1 Bedroom Suite net"));
		}
		if (inputMap.containsKey("Beachfront 1 Bedroom Suite rsp")) {
			TextBox stdRmRSPTB = new TextBox(By.id("rateRuleEdit.rsp.0"));
			stdRmRSPTB.setText(inputMap.get("Beachfront 1 Bedroom Suite rsp"));
		}

		if (inputMap.containsKey("Business Twin")) {
			roomType1.check();
		} else {
			roomType1.uncheck();
		}
		if (inputMap.containsKey("Business Twin net")) {
			TextBox stdRmNetTB = new TextBox(By.id("rateRuleEdit.nett.1"));
			stdRmNetTB.setText(inputMap.get("Business Twin net"));
		}
		if (inputMap.containsKey("Business Twin rsp")) {
			TextBox stdRmRSPTB = new TextBox(By.id("rateRuleEdit.rsp.1"));
			stdRmRSPTB.setText(inputMap.get("Business Twin rsp"));
		}

		if (inputMap.containsKey("Business Twin - TSU")) {
			roomType2.check();
		} else {
			roomType2.uncheck();
		}

		if (inputMap.containsKey("Business Twin - TSU net")) {
			TextBox stdRmNetTB = new TextBox(By.id("rateRuleEdit.nett.2"));
			stdRmNetTB.setText(inputMap.get("Business Twin - TSU net"));
		}
		if (inputMap.containsKey("Business Twin - TSU rsp")) {
			TextBox stdRmRSPTB = new TextBox(By.id("rateRuleEdit.rsp.2"));
			stdRmRSPTB.setText(inputMap.get("Business Twin - TSU rsp"));
		}

		if (inputMap.containsKey("Classic Single")) {
			roomType3.check();
		} else {
			roomType3.uncheck();
		}
		if (inputMap.containsKey("Classic Single net")) {
			TextBox stdRmNetTB = new TextBox(By.id("rateRuleEdit.nett.3"));
			stdRmNetTB.setText(inputMap.get("Classic Single net"));
		}
		if (inputMap.containsKey("Classic Single rsp")) {
			TextBox stdRmRSPTB = new TextBox(By.id("rateRuleEdit.rsp.3"));
			stdRmRSPTB.setText(inputMap.get("Classic Single rsp"));
		}
		if (inputMap.containsKey("Economy Single")) {
			roomType4.check();
		} else {
			roomType4.uncheck();
		}
		if (inputMap.containsKey("Economy Single net")) {
			TextBox stdRmNetTB = new TextBox(By.id("rateRuleEdit.nett.4"));
			stdRmNetTB.setText(inputMap.get("Economy Single net"));
		}
		if (inputMap.containsKey("Economy Single rsp")) {
			TextBox stdRmRSPTB = new TextBox(By.id("rateRuleEdit.rsp.4"));
			stdRmRSPTB.setText(inputMap.get("Economy Single rsp"));
		}

		if (inputMap.containsKey(" Economy Triple")) {
			roomType5.check();
		} else {
			roomType5.uncheck();
		}
		if (inputMap.containsKey(" Economy Triple net")) {
			TextBox stdRmNetTB = new TextBox(By.id("rateRuleEdit.nett.5"));
			stdRmNetTB.setText(inputMap.get(" Economy Triple net"));
		}
		if (inputMap.containsKey(" Economy Triple rsp")) {
			TextBox stdRmRSPTB = new TextBox(By.id("rateRuleEdit.rsp.5"));
			stdRmRSPTB.setText(inputMap.get(" Economy Triple rsp"));
		}

		if (inputMap.containsKey("Economy Twin")) {
			roomType6.check();
		} else {
			roomType6.uncheck();
		}

		if (inputMap.containsKey("Economy Twin net")) {
			TextBox stdRmNetTB = new TextBox(By.id("rateRuleEdit.nett.6"));
			stdRmNetTB.setText(inputMap.get("Economy Twin net"));
		}
		if (inputMap.containsKey("Economy Twin rsp")) {
			TextBox stdRmRSPTB = new TextBox(By.id("rateRuleEdit.rsp.6"));
			stdRmRSPTB.setText(inputMap.get("Economy Twin rsp"));
		}

		if (inputMap.containsKey("Standard Quad")) {
			roomType7.check();
		} else {
			roomType7.uncheck();
		}
		if (inputMap.containsKey("Standard Quad net")) {
			TextBox stdRmNetTB = new TextBox(By.id("rateRuleEdit.nett.7"));
			stdRmNetTB.setText(inputMap.get("Standard Quad net"));
		}
		if (inputMap.containsKey("Standard Quad rsp")) {
			TextBox stdRmRSPTB = new TextBox(By.id("rateRuleEdit.rsp.7"));
			stdRmRSPTB.setText(inputMap.get("Standard Quad rsp"));
		}
		if (inputMap.containsKey("Standard Room")) {
			roomType8.check();
		} else {
			roomType8.uncheck();
		}

		if (inputMap.containsKey("Standard Room net")) {
			TextBox stdRmNetTB = new TextBox(By.id("rateRuleEdit.nett.8"));
			stdRmNetTB.setText(inputMap.get("Standard Room net"));
		}
		if (inputMap.containsKey("Standard Room rsp")) {
			TextBox stdRmRSPTB = new TextBox(By.id("rateRuleEdit.rsp.8"));
			stdRmRSPTB.setText(inputMap.get("Standard Room rsp"));
		}

		if (inputMap.containsKey("Standard Single")) {
			roomType9.check();
		} else {
			roomType9.uncheck();
		}
		if (inputMap.containsKey("Standard Single net")) {
			TextBox stdRmNetTB = new TextBox(By.id("rateRuleEdit.nett.9"));
			stdRmNetTB.setText(inputMap.get("Standard Single net"));
		}
		if (inputMap.containsKey("Standard Single rsp")) {
			TextBox stdRmRSPTB = new TextBox(By.id("rateRuleEdit.rsp.9"));
			stdRmRSPTB.setText(inputMap.get("Standard Single rsp"));
		}

	}

	/**
	 * This method clicks on the given option from the select optons menu.
	 * 
	 * @param optionName
	 */
	public void clickDeleteLink ( ) {
		WebElement parentEl = waitForElement(By.id("marginRateRuleContentMenuOptions"));
		Link link = new Link(parentEl, "Delete");
		link.clickLink();
		// /waitForElement(By.id("marginRateRuleCreateCancel"));
		sleepms(500l);
	}

	public void deleteSmartFillRateplan ( ) {

		WebElement parentElement = waitForElement(By.id("marginRateRule_create"));
		waitForElement(parentElement, By.cssSelector("input[class='gsButton'][value='Delete']"));
		Button DeleteButton = new Button(parentElement, "Delete");
		DeleteButton.click();
		acceptAlert();
	}

	public void saveSmartFillRateplan ( ) {

		WebElement parentElement = waitForElement(By.id("marginRateRule_create"));
		waitForElement(parentElement, By.cssSelector("input[class='gsButton'][value='Save']"));
		Button SaveButton = new Button(parentElement, "Save");
		SaveButton.click();

	}

	public void updateEditRateRules ( ) {
		WebElement parentElement = waitForElement(By.id("rateRuleEdit"));
		Button updateButton = new Button(parentElement, "Update");
		updateButton.click();

	}

	public String editRates ( Map<String, String> inputMap ) {
		String grossValue = "";
		if (inputMap.containsKey("start day")) {
			waitForElement(By.id("marginRateRule-travelStartDatePicker_day"));
			ComboBox startDay = new ComboBox(By.id("marginRateRule-travelStartDatePicker_day"));
			startDay.select(inputMap.get("start day"));
		}
		if (inputMap.containsKey("start month")) {
			waitForElement(By.id("marginRateRule-travelStartDatePicker_months"));
			ComboBox startMonth = new ComboBox(By.id("marginRateRule-travelStartDatePicker_months"));
			startMonth.select(inputMap.get("start month"));
		}
		if (inputMap.containsKey("start year")) {
			waitForElement(By.id("marginRateRule-travelStartDatePicker_years"));
			ComboBox startYear = new ComboBox(By.id("marginRateRule-travelStartDatePicker_years"));
			startYear.select(inputMap.get("start year"));
		}

		if (inputMap.containsKey("end day")) {
			String endDayValue = inputMap.get("end day");
			waitForElement(By.id("marginRateRule-travelEndDatePicker_day"));
			ComboBox endDay = new ComboBox(By.id("marginRateRule-travelEndDatePicker_day"));
			endDay.select(endDayValue);
			if (!endDay.getSelectedItem().equals(endDayValue)) {
				endDay.select(endDayValue);
			}
		}
		if (inputMap.containsKey("end month")) {
			String endMonthValue = inputMap.get("end month");
			waitForElement(By.id("marginRateRule-travelEndDatePicker_months"));
			ComboBox endMonth = new ComboBox(By.id("marginRateRule-travelEndDatePicker_months"));
			endMonth.select(endMonthValue);
			if (!endMonth.getSelectedItem().equals(endMonthValue)) {
				endMonth.select(endMonthValue);
			}
		}
		if (inputMap.containsKey("end year")) {
			String endYearValue = inputMap.get("end year");
			waitForElement(By.id("marginRateRule-travelEndDatePicker_years"));
			ComboBox endYear = new ComboBox(By.id("marginRateRule-travelEndDatePicker_years"));
			endYear.select(endYearValue);
			if (!endYear.getSelectedItem().equals(endYearValue)) {
				endYear.select(endYearValue);
			}
		}
		if (inputMap.containsKey("Keep Existing Rates")) {
			CheckBox ExistRateChk = new CheckBox(By.id("keepExistingRates"));
			ExistRateChk.check();
		}

		if (inputMap.containsKey("days")) {
			String value = inputMap.get("days");
			if (value.equalsIgnoreCase("All")) {
				CheckBox allCB = new CheckBox(By.id("daysOfWeekTickAll"));
				if (!allCB.isChecked()) {
					allCB.check();
				}
				for (int i = 0; i < dayArr.length - 1; i++) {
					CheckBox dayCB = new CheckBox(By.id("daysOfWeek" + i));
					if (!dayCB.isChecked()) {
						dayCB.check();
					}
				}
			} else {
				CheckBox allCB = new CheckBox(By.id("daysOfWeekTickAll"));
				if (allCB.isChecked()) {
					allCB.uncheck();
				}
				for (int i = 0; i < dayArr.length - 1; i++) {
					CheckBox dayCB = new CheckBox(By.id("daysOfWeek" + i));
					if (dayCB.isChecked()) {
						dayCB.uncheck();
					}
				}

				for (int i = 0; i < dayArr.length - 1; i++) {
					String dayValue = dayArr[i];
					waitForElement(By.id("daysOfWeek" + i));
					CheckBox dayCB = new CheckBox(By.id("daysOfWeek" + i));
					if (value.contains(dayValue)) {
						dayCB.check();
					}
				}
			}
		}

		if (inputMap.containsKey("minimum nights")) {
			waitForElement(By.id("minNightsSelect"));
			ComboBox startDay = new ComboBox(By.id("minNightsSelect"));
			startDay.select(inputMap.get("minimum nights"));
		}

		if (inputMap.containsKey("more rules")) {
			RadioButton moreRulesRB = new RadioButton(By.name("moreRules"),
					inputMap.get("more rules"));
			moreRulesRB.select();
		}

		if (inputMap.containsKey("stay full period")) {
			RadioButton moreRulesRB = new RadioButton(By.name("fullPeriod"),
					inputMap.get("stay full period"));
			moreRulesRB.select();
		}

		CheckBox roomType0 = new CheckBox(By.id("marginRateRuleCreate.roomCheck.0"));
		CheckBox roomType1 = new CheckBox(By.id("marginRateRuleCreate.roomCheck.1"));
		CheckBox roomType2 = new CheckBox(By.id("marginRateRuleCreate.roomCheck.2"));
		CheckBox roomType3 = new CheckBox(By.id("marginRateRuleCreate.roomCheck.3"));
		CheckBox roomType4 = new CheckBox(By.id("marginRateRuleCreate.roomCheck.4"));
		CheckBox roomType5 = new CheckBox(By.id("marginRateRuleCreate.roomCheck.5"));
		CheckBox roomType6 = new CheckBox(By.id("marginRateRuleCreate.roomCheck.6"));
		CheckBox roomType7 = new CheckBox(By.id("marginRateRuleCreate.roomCheck.7"));
		CheckBox roomType8 = new CheckBox(By.id("marginRateRuleCreate.roomCheck.8"));
		CheckBox roomType9 = new CheckBox(By.id("marginRateRuleCreate.roomCheck.9"));
		CheckBox roomType10 = new CheckBox(By.id("marginRateRuleCreate.roomCheck.10"));

		int count = -1;
		for (int i = 0; i < 25; i++) {
			if (isElementPresent(By.id("marginRateRuleCreate.roomCheck." + i))) {
				CheckBox roomType = new CheckBox(By.id("marginRateRuleCreate.roomCheck." + i));
				roomType.uncheck();
				executeIEFireEventJS("marginRateRuleCreate.roomCheck." + i, "onclick");
				count++;
			}
		}
		if (inputMap.containsKey("Beachfront 1 Bedroom Suite")) {
			roomType0.check();
		} else {
			roomType0.uncheck();
		}
		if (inputMap.containsKey("Beachfront 1 Bedroom Suite margin")) {
			TextBox stdRmNetTB = new TextBox(By.id("marginRateRuleCreate.margin.0"));
			stdRmNetTB.setText(inputMap.get("Beachfront 1 Bedroom Suite margin"));
		}
		if (inputMap.containsKey("Beachfront 1 Bedroom Suite net")) {
			TextBox stdRmRSPTB = new TextBox(By.id("marginRateRuleCreate.nett.0"));
			stdRmRSPTB.setText(inputMap.get("Beachfront 1 Bedroom Suite net"));
		}

		if (inputMap.containsKey("Business Twin")) {
			roomType1.check();
		} else {
			roomType1.uncheck();
		}
		if (inputMap.containsKey("Business Twin margin")) {
			TextBox stdRmNetTB = new TextBox(By.id("marginRateRuleCreate.margin.1"));
			stdRmNetTB.setText(inputMap.get("Business Twin margin"));
		}
		if (inputMap.containsKey("Business Twin net")) {
			TextBox stdRmRSPTB = new TextBox(By.id("marginRateRuleCreate.nett.1"));
			stdRmRSPTB.setText(inputMap.get("Business Twin net"));
		}

		if (inputMap.containsKey("Business Twin - TSU")) {
			roomType2.check();
		} else {
			roomType2.uncheck();
		}

		if (inputMap.containsKey("Business Twin - TSU margin")) {
			TextBox stdRmNetTB = new TextBox(By.id("marginRateRuleCreate.margin.2"));
			stdRmNetTB.setText(inputMap.get("Business Twin - TSU margin"));
		}
		if (inputMap.containsKey("Business Twin - TSU net")) {
			TextBox stdRmRSPTB = new TextBox(By.id("marginRateRuleCreate.nett.2"));
			stdRmRSPTB.setText(inputMap.get("Business Twin - TSU net"));
		}

		if (inputMap.containsKey("Classic Single")) {
			roomType3.check();
		} else {
			roomType3.uncheck();
		}
		if (inputMap.containsKey("Classic Single margin")) {
			TextBox stdRmNetTB = new TextBox(By.id("marginRateRuleCreate.margin.3"));
			stdRmNetTB.setText(inputMap.get("Classic Single margin"));
		}
		if (inputMap.containsKey("Classic Single net")) {
			TextBox stdRmRSPTB = new TextBox(By.id("marginRateRuleCreate.nett.3"));
			stdRmRSPTB.setText(inputMap.get("Classic Single net"));
		}
		if (inputMap.containsKey("Economy Single")) {
			roomType4.check();
		} else {
			roomType4.uncheck();
		}
		if (inputMap.containsKey("Economy Single margin")) {
			TextBox stdRmNetTB = new TextBox(By.id("marginRateRuleCreate.margin.4"));
			stdRmNetTB.setText(inputMap.get("Economy Single margin"));
		}
		if (inputMap.containsKey("Economy Single net")) {
			TextBox stdRmRSPTB = new TextBox(By.id("marginRateRuleCreate.nett.4"));
			stdRmRSPTB.setText(inputMap.get("Economy Single net"));
		}

		if (inputMap.containsKey(" Economy Triple")) {
			roomType5.check();
		} else {
			roomType5.uncheck();
		}
		if (inputMap.containsKey(" Economy Triple margin")) {
			TextBox stdRmNetTB = new TextBox(By.id("marginRateRuleCreate.margin.5"));
			stdRmNetTB.setText(inputMap.get(" Economy Triple margin"));
		}
		if (inputMap.containsKey(" Economy Triple net")) {
			TextBox stdRmRSPTB = new TextBox(By.id("marginRateRuleCreate.nett.5"));
			stdRmRSPTB.setText(inputMap.get(" Economy Triple net"));
		}

		if (inputMap.containsKey("Economy Twin")) {
			roomType6.check();
		} else {
			roomType6.uncheck();
		}

		if (inputMap.containsKey("Economy Twin margin")) {
			TextBox stdRmNetTB = new TextBox(By.id("marginRateRuleCreate.margin.6"));
			stdRmNetTB.setText(inputMap.get("Economy Twin margin"));
		}
		if (inputMap.containsKey("Economy Twin net")) {
			TextBox stdRmRSPTB = new TextBox(By.id("marginRateRuleCreate.nett.6"));
			stdRmRSPTB.setText(inputMap.get("Economy Twin net"));
		}

		if (inputMap.containsKey("Hotel Cottage")) {
			roomType7.check();
		} else {
			roomType7.uncheck();
		}

		if (inputMap.containsKey("Hotel Cottage margin")) {
			TextBox stdRmNetTB = new TextBox(By.id("marginRateRuleCreate.margin.7"));
			stdRmNetTB.setText(inputMap.get("Hotel Cottage margin"));
		}
		if (inputMap.containsKey("Hotel Cottage net")) {
			TextBox stdRmRSPTB = new TextBox(By.id("marginRateRuleCreate.nett.7"));
			stdRmRSPTB.setText(inputMap.get("Hotel Cottage net"));
		}

		if (inputMap.containsKey("Standard Quad")) {
			roomType8.check();
		} else {
			roomType8.uncheck();
		}
		if (inputMap.containsKey("Standard Quad margin")) {
			TextBox stdRmNetTB = new TextBox(By.id("marginRateRuleCreate.margin.8"));
			stdRmNetTB.setText(inputMap.get("Standard Quad margin"));
		}
		if (inputMap.containsKey("Standard Quad net")) {
			TextBox stdRmRSPTB = new TextBox(By.id("marginRateRuleCreate.nett.8"));
			stdRmRSPTB.setText(inputMap.get("Standard Quad net"));
		}
		if (inputMap.containsKey("Standard Room")) {
			roomType9.check();
		} else {
			roomType9.uncheck();
		}

		if (inputMap.containsKey("Standard Room margin")) {
			TextBox stdRmNetTB = new TextBox(By.id("marginRateRuleCreate.margin.9"));
			stdRmNetTB.setText(inputMap.get("Standard Room margin"));
		}
		if (inputMap.containsKey("Standard Room net")) {
			TextBox stdRmRSPTB = new TextBox(By.id("marginRateRuleCreate.nett.9"));
			stdRmRSPTB.setText(inputMap.get("Standard Room net"));
		}

		if (inputMap.containsKey("Standard Single")) {
			roomType10.check();
		} else {
			roomType10.uncheck();
		}
		if (inputMap.containsKey("Standard Single margin")) {
			TextBox stdRmNetTB = new TextBox(By.id("marginRateRuleCreate.margin.10"));
			stdRmNetTB.setText(inputMap.get("Standard Single margin"));
		}
		if (inputMap.containsKey("Standard Single net")) {
			TextBox stdRmRSPTB = new TextBox(By.id("marginRateRuleCreate.nett.10"));
			stdRmRSPTB.setText(inputMap.get("Standard Single net"));
		}

		return grossValue;
	}

	public String DeleteRates ( Map<String, String> inputMap ) {
		String grossValue = "";
		if (inputMap.containsKey("start day")) {
			waitForElement(By.id("marginRateRule-travelStartDatePicker_day"));
			ComboBox startDay = new ComboBox(By.id("marginRateRule-travelStartDatePicker_day"));
			startDay.select(inputMap.get("start day"));
		}
		if (inputMap.containsKey("start month")) {
			waitForElement(By.id("marginRateRule-travelStartDatePicker_months"));
			ComboBox startMonth = new ComboBox(By.id("marginRateRule-travelStartDatePicker_months"));
			startMonth.select(inputMap.get("start month"));
		}
		if (inputMap.containsKey("start year")) {
			waitForElement(By.id("marginRateRule-travelStartDatePicker_years"));
			ComboBox startYear = new ComboBox(By.id("marginRateRule-travelStartDatePicker_years"));
			startYear.select(inputMap.get("start year"));
		}

		if (inputMap.containsKey("end day")) {
			String endDayValue = inputMap.get("end day");
			waitForElement(By.id("marginRateRule-travelEndDatePicker_day"));
			ComboBox endDay = new ComboBox(By.id("marginRateRule-travelEndDatePicker_day"));
			endDay.select(endDayValue);
			if (!endDay.getSelectedItem().equals(endDayValue)) {
				endDay.select(endDayValue);
			}
		}
		if (inputMap.containsKey("end month")) {
			String endMonthValue = inputMap.get("end month");
			waitForElement(By.id("marginRateRule-travelEndDatePicker_months"));
			ComboBox endMonth = new ComboBox(By.id("marginRateRule-travelEndDatePicker_months"));
			endMonth.select(endMonthValue);
			if (!endMonth.getSelectedItem().equals(endMonthValue)) {
				endMonth.select(endMonthValue);
			}
		}
		if (inputMap.containsKey("end year")) {
			String endYearValue = inputMap.get("end year");
			waitForElement(By.id("marginRateRule-travelEndDatePicker_years"));
			ComboBox endYear = new ComboBox(By.id("marginRateRule-travelEndDatePicker_years"));
			endYear.select(endYearValue);
			if (!endYear.getSelectedItem().equals(endYearValue)) {
				endYear.select(endYearValue);
			}
		}
		if (inputMap.containsKey("Keep Existing Rates")) {
			CheckBox ExistRateChk = new CheckBox(By.id("keepExistingRates"));
			ExistRateChk.check();
		}

		if (inputMap.containsKey("days")) {
			String value = inputMap.get("days");
			if (value.equalsIgnoreCase("All")) {
				CheckBox allCB = new CheckBox(By.id("daysOfWeekTickAll"));
				if (!allCB.isChecked()) {
					allCB.check();
				}
				for (int i = 0; i < dayArr.length - 1; i++) {
					CheckBox dayCB = new CheckBox(By.id("daysOfWeek" + i));
					if (!dayCB.isChecked()) {
						dayCB.check();
					}
				}
			} else {
				CheckBox allCB = new CheckBox(By.id("daysOfWeekTickAll"));
				if (allCB.isChecked()) {
					allCB.uncheck();
				}
				for (int i = 0; i < dayArr.length - 1; i++) {
					CheckBox dayCB = new CheckBox(By.id("daysOfWeek" + i));
					if (dayCB.isChecked()) {
						dayCB.uncheck();
					}
				}

				for (int i = 0; i < dayArr.length - 1; i++) {
					String dayValue = dayArr[i];
					waitForElement(By.id("daysOfWeek" + i));
					CheckBox dayCB = new CheckBox(By.id("daysOfWeek" + i));
					if (value.contains(dayValue)) {
						dayCB.check();
					}
				}
			}
		}

		if (inputMap.containsKey("minimum nights")) {
			waitForElement(By.id("minNightsSelect"));
			ComboBox startDay = new ComboBox(By.id("minNightsSelect"));
			startDay.select(inputMap.get("minimum nights"));
		}

		if (inputMap.containsKey("more rules")) {
			RadioButton moreRulesRB = new RadioButton(By.name("moreRules"),
					inputMap.get("more rules"));
			moreRulesRB.select();
		}

		if (inputMap.containsKey("stay full period")) {
			RadioButton moreRulesRB = new RadioButton(By.name("fullPeriod"),
					inputMap.get("stay full period"));
			moreRulesRB.select();
		}

		CheckBox roomType0 = new CheckBox(By.id("marginRateRuleDelete.roomCheck.0"));
		CheckBox roomType1 = new CheckBox(By.id("marginRateRuleDelete.roomCheck.1"));
		CheckBox roomType2 = new CheckBox(By.id("marginRateRuleDelete.roomCheck.2"));
		CheckBox roomType3 = new CheckBox(By.id("marginRateRuleDelete.roomCheck.3"));
		CheckBox roomType4 = new CheckBox(By.id("marginRateRuleDelete.roomCheck.4"));
		CheckBox roomType5 = new CheckBox(By.id("marginRateRuleDelete.roomCheck.5"));
		CheckBox roomType6 = new CheckBox(By.id("marginRateRuleDelete.roomCheck.6"));
		CheckBox roomType7 = new CheckBox(By.id("marginRateRuleDelete.roomCheck.7"));
		CheckBox roomType8 = new CheckBox(By.id("marginRateRuleDelete.roomCheck.8"));
		CheckBox roomType9 = new CheckBox(By.id("marginRateRuleDelete.roomCheck.9"));
		CheckBox roomType10 = new CheckBox(By.id("marginRateRuleDelete.roomCheck.10"));

		int count = -1;
		for (int i = 0; i < 25; i++) {
			if (isElementPresent(By.id("marginRateRuleCreate.roomCheck." + i))) {
				CheckBox roomType = new CheckBox(By.id("marginRateRuleCreate.roomCheck." + i));
				roomType.uncheck();
				executeIEFireEventJS("marginRateRuleCreate.roomCheck." + i, "onclick");
				count++;
			}
		}
		if (inputMap.containsKey("Beachfront 1 Bedroom Suite")) {
			roomType0.check();
		} else {
			roomType0.uncheck();
		}

		if (inputMap.containsKey("Business Twin")) {
			roomType1.check();
		} else {
			roomType1.uncheck();
		}

		if (inputMap.containsKey("Business Twin - TSU")) {
			roomType2.check();
		} else {
			roomType2.uncheck();
		}

		if (inputMap.containsKey("Classic Single")) {
			roomType3.check();
		} else {
			roomType3.uncheck();
		}

		if (inputMap.containsKey("Economy Single")) {
			roomType4.check();
		} else {
			roomType4.uncheck();
		}

		if (inputMap.containsKey(" Economy Triple")) {
			roomType5.check();
		} else {
			roomType5.uncheck();
		}

		if (inputMap.containsKey("Economy Twin")) {
			roomType6.check();
		} else {
			roomType6.uncheck();
		}

		if (inputMap.containsKey("Hotel Cottage")) {
			roomType7.check();
		} else {
			roomType7.uncheck();
		}

		if (inputMap.containsKey("Standard Quad")) {
			roomType8.check();
		} else {
			roomType8.uncheck();
		}

		if (inputMap.containsKey("Standard Room")) {
			roomType9.check();
		} else {
			roomType9.uncheck();
		}

		if (inputMap.containsKey("Standard Single")) {
			roomType10.check();
		} else {
			roomType10.uncheck();
		}

		return grossValue;
	}
}
