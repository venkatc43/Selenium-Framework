package com.kuoni.qa.automation.dto

class CountryDTO {

	def countryId
	def countryCode
	def countryDesc
	def countryDefaultCrncy
	def countryCount
	def zoneCode
	def zoneDesc



	public String getZoneCode() {


		switch(zoneCode)
		{
			case '441': 
			return"AF"
			break;
			case '442': return"US"
			break;
			case '443': return"GC"
			break;
			case '444': return"SC"
			break;
			case '445': return"EU"
			break;
			case '446': return"ME"
			break;
			case '447': return"SA"
			break;
			case '448': return"AU"
			break;
			case '449': return"CB"
			break;
			case '450': return"FE"
			break;
				
		}
}
	
}