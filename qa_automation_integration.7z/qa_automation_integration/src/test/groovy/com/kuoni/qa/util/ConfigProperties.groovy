package com.kuoni.qa.util

/**
 * This class loads the config properties.
 * @author 104378
 *
 */
class ConfigProperties {
	
	static Properties props = null
	
	/**
	 * This method will return the property value for the given key
	 * @param key
	 * @return
	 */
	def public static getVlaue(String key){
		if(props == null){
			loadProperties()
			props.get(key)
		}else{
			props.get(key)
		}
	}
	
	def private static loadProperties(){
		props = new Properties();
		File propsFile = new File("src/test/resources/config.properties")
		props.load(propsFile.newDataInputStream())
	}
	
	static main(def args){
		String value  = getVlaue("inputQ")
		println value
	}	
}
