package com.kuoni.qa.automation.dao

import com.sun.jna.platform.unix.X11.XClientMessageEvent.Data;
import com.kuoni.qa.automation.dto.RateplanDTO
import java.sql.Connection
import java.sql.ResultSet
import java.sql.Statement



class GetRateplanDBdata {

	GetDatabaseConn db = new GetDatabaseConn()

	def getRateplanData(ratePlanId) {
		Connection conn
		RateplanDTO data = new RateplanDTO()
		conn=db.getDBconnection()
		Statement statement = null
		ResultSet rs = null
		def count
		try{

			statement = conn.createStatement()
			String sql = "select COUNT(*) COUNT from FIT_RATE_PLAN where RATE_PLAN_ID= " + ratePlanId + " "
			rs = statement.executeQuery(sql)
			if(rs.next())
			count=	rs.getInt("COUNT")

			if(count>0) {

				sql = """ SELECT  
					(select count(*) from FIT_RATE_PLAN a ,FIT_RP_RESTRICTIONS c where a.SKU_ID=c.RATE_PLAN_ID and a.RATE_PLAN_ID= """+"'" +ratePlanId + "'" + """) RSCOUNT,
					(select count(0) from FIT_RATE_PLAN a, FIT_RP_CANCELLATIONS b, FIT_CANCELLATION c where a.SKU_ID = b.RATE_PLAN_ID and b.CANCELLATION_ID=c.ID and a.RATE_PLAN_ID =  """+"'" +ratePlanId + "'" + """) CLCOUNT, 
					mg.MARGIN_TYPE,
					mg.PERCENTAGE,
					rp.RATE_PLAN_ID,
					rp.STATUS,
					rp.CODE RPCODE,
					rp.NAME,
					rp.CONTRACT_ID
					
    				FROM FIT_RATE_PLAN rp,FIT_MARGIN mg where rp.margin = mg.ID (+)
  
					AND   rp.rate_plan_id=""" + ratePlanId

				rs = statement.executeQuery(sql)

				while (rs.next()) {
					data.setRateplanId(rs.getInt("RATE_PLAN_ID"))
					data.setRateplanStatus(rs.getString("STATUS"))
					data.setRateplanCode(rs.getString("RPCODE"))
					data.setContractId(rs.getString("CONTRACT_ID"))
					data.setMarginType(rs.getString("MARGIN_TYPE"))
					data.setRateplanName(rs.getString("NAME"))
					data.setMarginPercentage(rs.getFloat("PERCENTAGE"))
					data.setRestrictionCount(rs.getInt("RSCOUNT"))
					data.setCancelCount(rs.getInt("CLCOUNT"))
					//data.setMealBasisCode(rs.getString("MEALCODE"))
					//data.setMealBasisType(rs.getString("MEAL_TYPE"))
					//data.setMealBasisDesc(rs.getString("MEAL_DESCRIPTION"))


				}
				return data
			}
			else
			println "No records in Database for RatePlan : " + ratePlanId
		}
		catch (Exception e1) {
			e1.printStackTrace()
		}

		finally {
			rs.close()
			statement.close()
			conn.close()
		}
	}


	//Restrictions
	def getRestrictions(ratePlanId,restrictionId) {
		Connection conn =null
		Statement statement =null
		ResultSet rs = null
		RateplanDTO data = new RateplanDTO()

		try{
			conn = db.getDBconnection()
			statement = conn.createStatement()
			String sql = """
				SELECT b.RESTRICTION_ID,
			b.RESTRICTION_TYPE,
			b.TRAVEL_START,
			b.TRAVEL_END,
			b.DAYS_PRIOR
			FROM FIT_RATE_PLAN a ,
			FIT_RESTRICTION b,
			FIT_RP_RESTRICTIONS c
			WHERE a.SKU_ID       = c.RATE_PLAN_ID
			AND c.RESTRICTION_ID = b.ID and b.RESTRICTION_ID="""+"'"+restrictionId+"'"+"""
			AND a.RATE_PLAN_ID   ="""+"'"+ratePlanId+"'"

			rs = statement.executeQuery(sql)

			while(rs.next()) {

				data.setRestrictionType(rs.getString("RESTRICTION_TYPE"))
				data.setResStartDate(rs.getString("travel_start").substring(0, 10))
				data.setResEndDate(rs.getString("travel_end").substring(0, 10))
				data.setResDaysPrior(rs.getString("days_prior"))


			}

			return data
		}
		catch(Exception e1) {
			e1.printStackTrace()
		}

		finally{
			statement.close()
			rs.close()
			conn.close()
			
			
		}
	}


	//Cancellations
	def getCancellations(ratePlanId,cancellationId) {
		Connection conn =null
		Statement statement =null
		ResultSet rs = null
		RateplanDTO data = new RateplanDTO()

		try{
			conn = db.getDBconnection()
			statement = conn.createStatement()

			String sql = """ SELECT c.CANCELLATION_TYPE,
				   c.TRAVEL_START,
				   c.TRAVEL_END,
				   c.CANCEL_TIME,
				   c.DAYS_PRIOR,
				   c.CHARGES,
				   c.DURATION
				FROM FIT_RATE_PLAN a,
				  FIT_RP_CANCELLATIONS b,
				  FIT_CANCELLATION c
				WHERE a.SKU_ID       = b.RATE_PLAN_ID
				AND b.CANCELLATION_ID=c.ID
				AND a.RATE_PLAN_ID = """ + "'" +ratePlanId+"'"+"""
				AND c.ID             =""" + "'" +cancellationId+"'"
				
			rs = statement.executeQuery(sql)

			while (rs.next()) {
				//data.setCancellationId(cancellations)
				data.setCancellationType(rs.getString("CANCELLATION_TYPE"))
				data.setCancelStart(rs.getString("travel_start").substring(0, 10))
				data.setCancelEnd(rs.getString("travel_end").substring(0, 10))
				data.setCancel_time(rs.getString("CANCEL_TIME"))
				data.setCanceldaysPrior(rs.getString("days_prior"))
				data.setCancelPercentage(rs.getDouble("charges"))
				data.setCancelduration(rs.getString("duration"))
								
			}
			
			return data
		}
		catch(Exception e1) {
			e1.printStackTrace()
		                   }

				finally{
					statement.close()
					rs.close()
					conn.close()
					
					
				}
	
	}		
}