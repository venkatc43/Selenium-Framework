package com.kuoni.qa.automation.dao

import geb.Page

class ReadXmlFilePage {
	
	
	 def File readXml(String filename)
	
	{
		
		URL xml = this.class.getClass().getResource(filename);
		File xmlFile = new File(xml.getFile())
		
		//URL xsd = this.class.getClass().getResource("/books.xsd");
		//File xsdFile = new File (xsd.getFile())

		return xmlFile
		
	}

}
