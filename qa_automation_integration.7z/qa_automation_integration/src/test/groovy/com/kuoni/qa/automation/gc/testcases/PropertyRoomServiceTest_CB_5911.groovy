package com.kuoni.qa.automation.gc.testcases

import spock.lang.IgnoreIf
import spock.lang.Specification
import spock.lang.Stepwise;

import com.kuoni.qa.automation.datacreate.test.helper.PropertyFacilitiesAndServicesTestHelper
import com.kuoni.qa.constants.CommonConstants
import com.kuoni.qa.util.CommonUtil
import com.kuoni.qa.util.ConfigProperties
import com.kuoni.qa.util.TestSuiteProperties

@Stepwise
class PropertyRoomServiceTest_CB_5911 extends Specification{
	
	PropertyFacilitiesAndServicesTestHelper helper = new PropertyFacilitiesAndServicesTestHelper()
	
	@IgnoreIf({TestSuiteProperties.getVlaue("Ignore_PropertyRoomServiceTest_CB_5911").equals("true")? true : false})
	def "update property room service"(){
		
		given: "The GC Connect, HornetQueue and IST Database are working"
		when:"Property room service is updated"
		assert helper.executeRoomServiceFromFacilitiesAndServices("CB-5911-Update"), "error occurred while updating room service from gc application"
		
		then:"Wait for the Message to appear on the Q"
		sleep(Integer.parseInt(ConfigProperties.getVlaue("pollingInterval")))
				
		then:"Push the Message to the ATG"
		assert helper.loadDataintoAtg(), "error occurred while Pushing data to ATG"
		sleep(5000)
		
		then:"Validate the GC CHanges against the ATG Database"
		assert helper.verifyPropertyRoomService("CB-5911-Update"),"Room Service Validation Failed"
		
	}
	
	@IgnoreIf({TestSuiteProperties.getVlaue("Ignore_PropertyRoomServiceTest_CB_5911").equals("true")? true : false})
	def "delete property room service"(){
		
		given: "The GC Connect, HornetQueue and IST Database are working"
		when:"Property room service values are Reverted "
		assert helper.executeRoomServiceFromFacilitiesAndServices("CB-5911-Delete"), "error occurred while deleting room service from gc application"
		
		then:"Wait for the Message to appear on the Q"
		sleep(Integer.parseInt(ConfigProperties.getVlaue("pollingInterval")))
		
		then:"Load the Message to the ATG Database"
		assert helper.loadDataintoAtg(), "error Pushing data to ATG"
			
		sleep(5000)
		then:"Verify the GC Changes in the ATG Database"
		assert helper.verifyPropertyRoomService("CB-5911-Delete"),"Room Service Validation Failed"
		
	}
	
	@IgnoreIf({TestSuiteProperties.getVlaue("Ignore_CloseWebdrver").equals("true")? true : false})
	def "close webdriver"(){
		
		when:""
		if(CommonConstants.webDriver != null){
			CommonConstants.webDriver.quit()
		}
		then:""
	}
	
	def cleanupSpec()
	{
		CommonConstants.webDriver.quit()
	}
}