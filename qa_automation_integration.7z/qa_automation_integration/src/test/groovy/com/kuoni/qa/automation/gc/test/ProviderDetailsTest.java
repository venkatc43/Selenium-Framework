package com.kuoni.qa.automation.gc.test;

import java.util.HashMap;
import java.util.Map;

import com.gta.travel.page.base.GSTestBase;
import com.gta.travel.page.object.common.HomePage;
import com.gta.travel.page.object.common.LoginPage;
import com.gta.travel.page.object.common.TopLinksPage;
import com.gta.travel.page.object.content.search.ContentSearchPage;
import com.gta.travel.page.object.content.search.ContentSearchResultsPage;
import com.kuoni.qa.automation.page.object.content.ProviderDetailsSectionPage;
import com.kuoni.qa.constants.CommonConstants;
import com.mediaocean.qa.framework.utils.ExcelUtil;

public class ProviderDetailsTest extends GSTestBase{

	private LoginPage loginPage;
	private HomePage homePage;
	private ContentSearchPage contentSearchPage;
	private ContentSearchResultsPage contentSearchResultsPage;
	private ProviderDetailsSectionPage providerDetailsSectionPage;
	
	private String userName;
	private String password;
	private String webId;
	
	ExcelUtil data = null;
	private static String sheetName = null;
	
	public ProviderDetailsTest(String driverSheetPath, String dataSheetPath, String sheetName){
		this.sheetName = sheetName;
		init(driverSheetPath, dataSheetPath);
	}	
	
	public void init(String driverSheetPath, String dataSheetPath){

		data = new ExcelUtil(dataSheetPath);
		if (driverSheetPath != null){
			setDriverSheetAbsolutePath(driverSheetPath);
		}else{
			setDriverSheetFileName("Driver_Sheet.xls");
		}
		initialiseEnvironmentAndTest();
		openBrowser();
		setLoginInfo();
		if(CommonConstants.webDriver != null){
			CommonConstants.webDriver = getDriver();
		}
	}
	
	private void setLoginInfo() {
		webId = excelUtil.getKeyValue(ENVIRONMENT, "webId");
		userName = excelUtil.getKeyValue(ENVIRONMENT, "userName");
		password = excelUtil.getKeyValue(ENVIRONMENT, "password");
		
	}
	
	public void execueteDataScriptForCraete(){
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSearchResultsScreenFlow();
		executeCreateProvider();
		getDriver().quit();
	}	
	
	public void execueteDataScriptForEdit(){
		
		executeLoginPageFlow();
		executeSearchScreenFlow();
		executeSearchResultsScreenFlow();
		executeEditProvider();
		getDriver().quit();
	}	
	
	private void executeLoginPageFlow(){
		loginPage = new LoginPage(getDriver());
		homePage = loginPage.login(webId, userName, password);
		contentSearchPage = homePage.selectContent();
		contentSearchPage.sleep(2);
	}	
	
	private void executeSearchScreenFlow(){
		
		Map<String, String> searchDataMap = new HashMap<String, String>();
		//Set the search data to the map here.
		searchDataMap.put("Country", data.getKeyValue(sheetName, "Country"));
		searchDataMap.put("City", data.getKeyValue(sheetName, "City"));		
		contentSearchResultsPage = contentSearchPage.search(searchDataMap);
		contentSearchResultsPage.sleep(2);
	}
	
	private void executeSearchResultsScreenFlow(){
		
		Map<String, String> searchResultsDataMap = new HashMap<String, String>();
		//Set the search data to the map here.
		TopLinksPage topLinksPage = contentSearchResultsPage.selectRecordFromSearchResults(searchResultsDataMap);
		topLinksPage.sleep(3);
	}
	
	private void executeCreateProvider(){
		
		providerDetailsSectionPage = ProviderDetailsSectionPage.getInstance();
		
		Map<String, String> map = new HashMap<String, String>();
		map.put("Provider Type", data.getKeyValue(sheetName, "Provider Type"));
		map.put("Business Type", data.getKeyValue(sheetName, "Business Type"));
		map.put("On Sale", data.getKeyValue(sheetName, "On Sale"));
		map.put("Legacy City ID", data.getKeyValue(sheetName, "Legacy City ID"));
		map.put("Legacy Property ID", data.getKeyValue(sheetName, "Legacy Property ID"));
		map.put("FIT Reservations Via", data.getKeyValue(sheetName, "FIT Reservations Via"));		

		providerDetailsSectionPage.selectProviderDetailsOptions("Create");
		providerDetailsSectionPage.createProviderDetails(map);
		providerDetailsSectionPage.sleep(2);
		providerDetailsSectionPage.savePropertyProvider();
		providerDetailsSectionPage.sleep(2);
	}
	
	private void executeEditProvider(){
		providerDetailsSectionPage = ProviderDetailsSectionPage.getInstance();
		Map<String, String> map = new HashMap<String, String>();
	
		Map<String, String> selectMap = new HashMap<String, String>();
		selectMap.put("Provider Type", data.getKeyValue(sheetName, "Provider Type"));
		selectMap.put("FIT Reservations Via", data.getKeyValue(sheetName, "FIT Reservations Via"));
		
 		providerDetailsSectionPage.selectProviderFromTheList(selectMap);
		providerDetailsSectionPage.selectProviderDetailsOptions("Edit");
		
		map.put("Legacy City ID", data.getKeyValue(sheetName, "Legacy City ID"));
		map.put("Legacy Property ID", data.getKeyValue(sheetName, "Legacy Property ID"));
		map.put("FIT Reservations Via", data.getKeyValue(sheetName, "FIT Reservations Via"));	
		providerDetailsSectionPage.editProviderDetails(map);
		providerDetailsSectionPage.sleep(2);
		providerDetailsSectionPage.updateProviderDetails();
		providerDetailsSectionPage.sleep(2);
	
	}
	
}
