package com.kuoni.qa.automation.dao

import com.kuoni.qa.automation.dto.ReferenceDataDTO
import java.sql.Connection
import java.sql.ResultSet
import java.sql.Statement

class GetReferenceDataDescription {

	public static ReferenceDataDTO getOfferDesc(String code,String language,def type) {

		ReferenceDataDTO data = new ReferenceDataDTO()
		ResultSet resultset =null
		Connection connection = null
		String text = null

		try{


			GetDatabaseConn db = new GetDatabaseConn();

			connection = db.getDBconnection()

			Statement statement = connection.createStatement()

			String sql = """SELECT (select count(0) from FIT_DESCRIPTION_TYPE a, FIT_DESC_TEXTS b where a.TYPE='"""+type+"""' AND a.code ='"""+code+"""' and a.DESC_TYPE_ID= b.DESC_TYPE_ID) as LangCount, 
						
				c.TEXT
				FROM FIT_DESCRIPTION_TYPE a,
				FIT_DESC_TEXTS b,
				FIT_DESC_LANG_TEXT c
				WHERE a.TYPE      ='"""+type+"""'
				AND a.code        ='"""+code+"""'
				AND a.DESC_TYPE_ID= b.DESC_TYPE_ID
				AND c.LANGUAGE    ='"""+language+"""'
				AND b.TEXT_ID     =c.TEXT_ID """


		 resultset =	statement.executeQuery(sql)

		while(resultset.next()) {
			
			data.setLanguageCount(resultset.getInt("LangCount"))
			data.setDataDescription(resultset.getString("TEXT"))
					
		}
		
		}catch (Exception e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
		
		finally{
			
				resultset.close();
				connection.close();
					}

		return data
	}
	
	
	
	public static ReferenceDataDTO getLandmarkData(String landmarkId)
	{
		ReferenceDataDTO data = new ReferenceDataDTO()
		String text = null
		GetDatabaseConn db = new GetDatabaseConn();
		Connection connection=null
		ResultSet resultset = null
		
		try {
		connection = db.getDBconnection()
		
		Statement statement = connection.createStatement()

		String sql = """SELECT
			lmark.CODE,
			lmark.LATITUDE,
			lmark.LONGITUDE
			FROM FIT_LANDMARK lmark
			where lmark.LANDMARK_ID= '"""+landmarkId+ """'"""

		resultset =	statement.executeQuery(sql)

		if(resultset.next()) {
			
			data.setLandmarkCode(resultset.getString("CODE"))
			data.setLandmarkLatitude(resultset.getString("LATITUDE"))
			data.setLandmarkLongitude(resultset.getString("LONGITUDE"))
			
					
		}
		
		}catch (Exception e){
		e.printStackTrace();
		
		}
		
		finally {
			resultset.close();
			connection.close();
		}

		return data
	}
	}




