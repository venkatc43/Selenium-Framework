package com.kuoni.qa.util

import java.sql.Connection
import java.sql.DriverManager
import java.sql.ResultSet;
import java.sql.Statement

/**
 * This is the utility class for AS400 DB2 database. It having methods to get connection and to close connection.
 * 
 * @author 104378
 *
 */
class DB2Util {
	
	private static Properties props
	private static String HOST = "host"
	private static String USER_ID = "userId"
	private static String PASSWORD = "password"
	private static String DRIVER = "com.ibm.as400.access.AS400JDBCDriver"
	private static String DB2_PROPERTIES_FILE_PATH = "db2propetiesFilePath"
	private static String JDBC_AS400 = "jdbc:as400://"
	private static String NAMING_SYATEM = ";naming=system;errors=full"
	
	/**
	 * This method returns the connection for AS400 DB2 database.
	 * 
	 * @return
	 */
	public static def getConnection(){
		try{
			props = new Properties();
			props.load(new FileInputStream(ConfigProperties.getVlaue(DB2_PROPERTIES_FILE_PATH)))
			String URL = JDBC_AS400 + props.getProperty(HOST).trim() + NAMING_SYATEM
			Class.forName(DRIVER);
			Connection conn = DriverManager.getConnection(URL, props.getProperty(USER_ID).trim(), props.getProperty(PASSWORD).trim())
		}catch(Exception e){
			println e
		}
	}
	
	/**
	 * This method close the connection for AS400 DB2 database.
	 * 
	 * @param conn
	 * @return
	 */
	public static def closeConnection(Connection conn){
		if(conn != null){
			conn.close()
		}
	}
}
