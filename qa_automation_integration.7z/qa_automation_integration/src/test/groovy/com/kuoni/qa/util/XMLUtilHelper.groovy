package com.kuoni.qa.util

import groovy.util.slurpersupport.Node

import java.util.regex.Pattern

import javax.xml.XMLConstants
import javax.xml.transform.stream.StreamSource
import javax.xml.validation.Schema
import javax.xml.validation.SchemaFactory
import javax.xml.validation.Validator

import org.xml.sax.SAXException

class XMLUtilHelper {


	public def static inkeyValue, outkeyvalue, config
	private static XMLUtilHelper  xmlutilhelper = null
	public def inpValues = []
	public def inpValues2 = []
	public def inpValues3 = []
	public def inpValues4 = []
	public def inpValues5 = []

	def public static getInstance() {

		/*if (xmlutilhelper == null)
		 {*/
		xmlutilhelper = new XMLUtilHelper()
		//}
	}
	/**
	 * Reading from the Config properties file
	 * @return
	 */

	def static getConfig(){

		java.util.Properties props = new Properties()

		File propsFile = new File("src//test//resources//XML_Element_Names.properties")
		props.load(propsFile.newDataInputStream())


		config = new ConfigSlurper().parse(props)
	}
	/**
	 * validation of XML against the schem
	 * @param xsdFile
	 * @param xmlFile
	 * @return
	 */

	def  boolean validateXMLSchema(File xsdFile, File xmlFile){

		try {

			SchemaFactory factory =
					SchemaFactory.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI)
			Schema schema = factory.newSchema(xsdFile)
			Validator validator = schema.newValidator()
			validator.validate(new StreamSource(xmlFile))
		}
		catch (IOException | SAXException e) {
			System.out.println("Exception: "+ e.getMessage())
			return false
		}
		return true
	}

	//validation of the InputXML to Output XML
	/**
	 * Method for iterating through the child nodes matching with the input tag
	 * @param inputcust
	 * @param keyContent
	 * @return
	 */

	def static String readXml1(groovy.util.slurpersupport.Node inputcust, String keyContent){

		inputcust.childNodes().each { child ->
			child.name
			if(child.name.equals(keyContent)){
				inkeyValue = child.text()
				println(child.name +"  : "+ inkeyValue)

			}
			readXml1(child, keyContent)
		}

		return inkeyValue
	}

	/**
	 * Method for iterating through the child attribute node matching with the input tag
	 * @param inputcust
	 * @param outputTag
	 * @param outputAttr
	 * @return
	 */
	def static String readXmlAttrs(groovy.util.slurpersupport.Node inputcust, String outputTag, String outputAttr){

		inputcust.childNodes().each { child ->
			child.attributes()

			child.attributes().each{ it ->
				it.key +"==" + it.value

				if(it.key.equals(outputAttr) && child.name.equalsIgnoreCase(outputTag) ){
					inkeyValue = it.value
					println(it.key + ": " +inkeyValue)

				}
			}
			readXmlAttrs(child, outputTag, outputAttr)
		}

		return inkeyValue
	}




	//For Mulitple Record validations
	/**
	 * With LIST for multiple values -->Method for iterating through the child nodes matching with the input tag
	 * @param inputcust
	 * @param keyContent
	 * @return
	 */
	def List readXml2(groovy.util.slurpersupport.Node inputcust, String keyContent){

		inputcust.childNodes().each { child ->
			child.name
			if(child.name.equals(keyContent)){
				inkeyValue = child.text()
				println(child.name +"  : "+ inkeyValue)
				inpValues.add(inkeyValue)

			}
			readXml2(child, keyContent)
		}

		return inpValues
	}

	/**
	 * Mulitple values Method for iterating through the child nodes matching with the input tag
	 * @param inputcust
	 * @param keyContent
	 * @return
	 */

	def List readXml3(groovy.util.slurpersupport.Node inputcust, String keyContent){

		inputcust.childNodes().each { child ->
			child.name
			if(child.name.equals(keyContent)){
				inkeyValue = child.text()
				println(child.name +"  : "+ inkeyValue)
				inpValues2.add(inkeyValue)

			}
			readXml3(child, keyContent)
		}

		return inpValues2
	}

	/**
	 * Multi Values Method for iterating through the child nodes matching with the input tag
	 * @param inputcust
	 * @param keyContent
	 * @param attr
	 * @return
	 */
	def List readXml4(groovy.util.slurpersupport.Node inputcust, String keyContent, String attr){

		inputcust.childNodes().each { child ->
			child.name
			if(child.name.equals(keyContent)){
				//child ->   child.attributes()
				def attrkey = attr.tokenize(":")
				inputcust.attributes().each{ it ->
					it.key +"==" + it.value
					if(it.key.equals(attrkey[0]) && it.value.equalsIgnoreCase(attrkey[1])){
						inkeyValue = child.text()
						println(child.name +"  : "+ inkeyValue)
						inpValues3.add(inkeyValue)
					}
				}

			}
			readXml4(child, keyContent, attr)
		}

		return inpValues3
	}

	/**
	 * Multi values Method for iterating through the child nodes matching with the input tag
	 * @param inputcust
	 * @param keyContent
	 * @param attr
	 * @return
	 */
	def static String readXml5(groovy.util.slurpersupport.Node inputcust, String keyContent, String attr){

		inputcust.childNodes().each { child ->
			child.name
			if(child.name.equals(keyContent)){
				//child ->   child.attributes()
				def attrkey = attr.tokenize(":")
				inputcust.attributes().each{ it ->
					it.key +"==" + it.value
					if(it.key.equals(attrkey[0]) && it.value.equalsIgnoreCase(attrkey[1])){
						inkeyValue = child.text()
						println(child.name +"  : "+ inkeyValue)
						//inpValues3.add(inkeyValue)
					}
				}

			}
			readXml5(child, keyContent, attr)
		}

		return inkeyValue
	}
	/**
	 * Multi Method for iterating through the child Attribute nodes matching with the input tag
	 * @param inputcust
	 * @param outputTag
	 * @param outputAttr
	 * @return
	 */
	def List readXmlAttrs1(groovy.util.slurpersupport.Node inputcust, String outputTag, String outputAttr){

		inputcust.childNodes().each { child ->
			child.attributes()

			child.attributes().each{ it ->
				it.key +"==" + it.value


				if(it.key.equals(outputAttr) && child.name.equalsIgnoreCase(outputTag) ){
					//if(it.key.equals(attrkey[0]) && it.value.equals(attrkey[1]) && child.name.equalsIgnoreCase(outputTag) ){
					inkeyValue = it.value
					println(it.key + ": " +inkeyValue)
					inpValues4.add(inkeyValue)

				}
			}
			readXmlAttrs1(child, outputTag, outputAttr)
		}

		return inpValues4
	}

	/**
	 * Compare XMlS for different tags from i/p to o/p
	 */


	def static boolean compareXMLsDifftags(inputxmlFile, outputxmlFile,propertyName){
		def match = true
		def inputkeyValue, outputkeyValue

		def inputcust = new XmlSlurper().parse(inputxmlFile)
		def outputcust = new XmlSlurper().parse(outputxmlFile)
		getConfig()

		def elementList = config.get(new String(propertyName)).tokenize(';')


		for(e in 0 .. elementList.size()-1) {
			try{
				def tags  = elementList[e].tokenize('=')
				println("Input Data :")
				inputcust.childNodes().each { child ->
					child.name
					inputkeyValue = readXml1(child, tags[0])	}
				println "OutPut Data :"
				outputcust.childNodes().each { child ->
					child.name
					outputkeyValue = readXml1(child, tags[1]) }

				if(!inputkeyValue.equals(outputkeyValue))
				{

					match = false
					break
				}



			}
			catch(Exception e2)
			{
				println(e2)
			}

		}
		//			}

		return match

	}

	/**
	 * Compare XMls for boolean values
	 */



	def static boolean compareXMLsBooleanValues(inputxmlFile, outputxmlFile,propertyName){
		def match = true
		def inputkeyValue, outputkeyValue

		def inputcust = new XmlSlurper().parse(inputxmlFile)
		def outputcust = new XmlSlurper().parse(outputxmlFile)
		getConfig()

		def elementList = config.get(new String(propertyName)).tokenize(';')

		for(e in 0 .. elementList.size()-1) {

			try{
				def tags  = elementList[e].tokenize('=')
				println("Input Data :")
				inputcust.childNodes().each { child ->
					child.name
					inputkeyValue = readXml1(child, tags[0])	}
				println "OutPut Data :"
				outputcust.childNodes().each { child ->
					child.name
					outputkeyValue = readXml1(child, tags[1]) }

				if(inputkeyValue.toInteger() == 1){
					if(!outputkeyValue.equals("true")){
						match = false
						break
					}

				}else{
					if(!outputkeyValue.equals("false")){
						match = false
						break
					}
				}


			}
			catch(Exception e2)
			{
				println(e2)
			}

		}
		//			}

		return match

	}
	/**
	 * Compare XMls for boolean values with Attributes
	 */


	def static boolean compareXMLsAttrBooleanValues(inputxmlFile, outputxmlFile,propertyName){
		def match = true
		def inputkeyValue, outputkeyValue

		def inputcust = new XmlSlurper().parse(inputxmlFile)
		def outputcust = new XmlSlurper().parse(outputxmlFile)
		getConfig()

		def elementList = config.get(new String(propertyName)).tokenize(';')

		for(e in 0 .. elementList.size()-1) {

			try{
				def tags  = elementList[e].tokenize('=')
				def inputTag = tags[0]
				def outputValues = tags[1].tokenize(',')
				def outputAttr = outputValues[1]
				def outputTag = outputValues[0]
				println("Input Data :")
				inputcust.childNodes().each { child ->
					child.name
					inputkeyValue = readXml1(child, inputTag)  }
				println "OutPut Data :"
				outputcust.childNodes().each { child ->
					child.name
					outputkeyValue = readXmlAttrs(child, outputTag, outputAttr) }

				if(inputkeyValue.toInteger() == 1){
					if(!outputkeyValue.equals("true")){
						match = false
						break
					}

				}else{
					if(!outputkeyValue.equals("false")){
						match = false
						break
					}
				}


			}
			catch(Exception e2)
			{
				println(e2)
			}

		}
		//          }

		return match

	}
	/**
	 * Compare two XMls with Different attributes
	 * @param inputxmlFile
	 * @param outputxmlFile
	 * @param propertyName
	 * @return
	 */

	def static boolean compareXMLsWithAttributes(inputxmlFile, outputxmlFile, propertyName){

		def match = true
		def inputkeyValue, outputAttrValue

		def inputcust = new XmlSlurper().parse(inputxmlFile)
		def outputcust = new XmlSlurper().parse(outputxmlFile)

		getConfig()

		def attribList  = config.get(new String(propertyName)).tokenize(';')
		for (a in 0 .. attribList.size()-1)
		{
			def input = attribList[a].tokenize('=')
			def inputTag = input[0]
			def outputValues = input[1].tokenize(',')
			def outputAttr = outputValues[1]
			def outputTag = outputValues[0]


			try{
				println("Input Data :")
				inputcust.childNodes().each { child ->
					child.name
					inputkeyValue = readXml1(child, inputTag)
				}
				println "OutPut Data :"
				outputcust.childNodes().each { child ->
					child.name
					outputAttrValue = readXmlAttrs(child, outputTag, outputAttr)
				}
				if(!inputkeyValue.equals(outputAttrValue)){
					match = false
					break
				}



			}
			catch(Exception e2)
			{
				println(e2)
			}
		}
		return match
	}
	/**
	 * Compare two XMls with case sensitve with Different attributes
	 * @param inputxmlFile
	 * @param outputxmlFile
	 * @param propertyName
	 * @return
	 */

	def static boolean compareXMLsWithAttributesIgnoreCase(inputxmlFile, outputxmlFile, propertyName){

		def match = true
		def inputkeyValue, outputAttrValue

		def inputcust = new XmlSlurper().parse(inputxmlFile)
		def outputcust = new XmlSlurper().parse(outputxmlFile)

		getConfig()

		def attribList  = config.get(new String(propertyName)).tokenize(';')
		for (a in 0 .. attribList.size()-1)
		{
			def input = attribList[a].tokenize('=')
			def inputTag = input[0]
			def outputValues = input[1].tokenize(',')
			def outputAttr = outputValues[1]
			def outputTag = outputValues[0]


			try{
				println("Input Data :")
				inputcust.childNodes().each { child ->
					child.name
					inputkeyValue = readXml1(child, inputTag)
				}
				println "OutPut Data :"
				outputcust.childNodes().each { child ->
					child.name
					outputAttrValue = readXmlAttrs(child, outputTag, outputAttr)
				}


				if(!inputkeyValue.equalsIgnoreCase(outputAttrValue))
				{
					match = false
					break
				}


			}
			catch(Exception e2)
			{
				println(e2)
			}
		}
		return match
	}


	/**
	 * Comparing the Multiple Records in the Output XML
	 *Compare XMlS for different tags 
	 */


	def boolean MULcompareXMLsDifftags(inputxmlFile, outputxmlFile,propertyName){
		def match = true
		def inputkeyValue = [], outputkeyValue = []

		def inputcust = new XmlSlurper().parse(inputxmlFile)
		def outputcust = new XmlSlurper().parse(outputxmlFile)
		getConfig()

		def elementList = config.get(new String(propertyName)).tokenize(';')


		for(e in 0 .. elementList.size()-1) {
			try{
				def tags  = elementList[e].tokenize('=')
				println("Input Data :")
				inputcust.childNodes().each { child ->
					child.name
					inputkeyValue = readXml2(child, tags[0])

				}

				println "OutPut Data :"
				outputcust.childNodes().each { child ->
					child.name
					outputkeyValue = readXml3(child, tags[1]) }

				/*if(!inputkeyValue.equals(outputkeyValue))
				 {
				 match = false;
				 break;
				 }*/
				match = inputkeyValue.containsAll(outputkeyValue)
				//match = inputkeyValue.equals(outputkeyValue)
				//println match
				//if(match)
				//break;

			}
			catch(Exception e2)
			{
				println(e2)
			}

		}
		//          }

		return match

	}

	/**
	 * Compare XMls for boolean values in mulitple records
	 */


	def boolean MULcompareXMLsBooleanValues(inputxmlFile, outputxmlFile,propertyName){
		def match = true
		def inputkeyValue = [], outputkeyValue = []

		def inputcust = new XmlSlurper().parse(inputxmlFile)
		def outputcust = new XmlSlurper().parse(outputxmlFile)
		getConfig()

		def elementList = config.get(new String(propertyName)).tokenize(';')

		for(e in 0 .. elementList.size()-1) {

			try{
				def tags  = elementList[e].tokenize('=')
				println("Input Data :")
				inputcust.childNodes().each { child ->
					child.name
					inputkeyValue = readXml2(child, tags[0])    }
				def  invalue =inputkeyValue
				//inpValues.clear()

				println "OutPut Data :"
				outputcust.childNodes().each { child ->
					child.name
					outputkeyValue = readXml3(child, tags[1]) }
				def outvalue=outputkeyValue
				//inpValues.clear()
				for(b in 0 .. invalue.size()-1){
					def c= invalue.get(b)
					def d =outvalue.get(b)
					if(c == "1")
					{
						if(!d.equals("true")){
							match = false
							break
						}

					}else{
						if(!d.equals("false")){
							match = false
							break
						}
					}
				}


			}
			catch(Exception e2)
			{
				println(e2)
			}

		}
		//          }

		return match

	}

	/**
	 * Compare two XMls with Different attributes for multiple records
	 * @param inputxmlFile
	 * @param outputxmlFile
	 * @param propertyName
	 * @return
	 */

	def  boolean MULcompareXMLsWithAttributes(inputxmlFile, outputxmlFile, propertyName){

		def match = true
		def inputkeyValue = [],inputAttrValue = [],outputAttrValue =[]

		def inputcust = new XmlSlurper().parse(inputxmlFile)
		def outputcust = new XmlSlurper().parse(outputxmlFile)

		getConfig()

		def attribList  = config.get(new String(propertyName)).tokenize(';')
		for (a in 0 .. attribList.size()-1)
		{
			def input = attribList[a].tokenize('=')
			def inputValues = input[0].tokenize(',')
			def inputTag = inputValues[0]
			def inputAttr = inputValues[1]
			def ChildinputTag = inputValues[2]
			def outputValues = input[1].tokenize(',')
			def outputTag = outputValues[0]
			def outputAttr = outputValues[1]



			try{

				println("Input Data :")
				inputcust.childNodes().each { child ->
					child.name
					inputkeyValue = readXml4(child, ChildinputTag, inputAttr)
				}

				println "OutPut Data :"
				outputcust.childNodes().each { child ->
					child.name
					outputAttrValue = readXmlAttrs1(child, outputTag, outputAttr)
				}
				/*if(!inputkeyValue.equals(outputAttrValue)){
				 match = false;
				 break;
				 }
				 */
				match = inputkeyValue.equals(outputAttrValue)

			}
			catch(Exception e2)
			{
				println(e2)
			}
		}
		return match
	}
	/**
	 * Compare two XMls with Different attributes + additional tag  on multilpe records
	 */

	def  boolean MULTagcompareXMLsWithAttributes(inputxmlFile, outputxmlFile, propertyName){

		def match = true
		def inputkeyValue = [],inputAttrValue = [],outputAttrValue =[],outputMtagvalue

		def inputcust = new XmlSlurper().parse(inputxmlFile)
		def outputcust = new XmlSlurper().parse(outputxmlFile)

		getConfig()

		def attribList  = config.get(new String(propertyName)).tokenize(';')
		for (a in 0 .. attribList.size()-1)
		{
			def input = attribList[a].tokenize('=')
			def inputValues = input[0].tokenize(',')
			def inputTag = inputValues[0]
			def inputAttr = inputValues[1]
			def ChildinputTag = inputValues[2]
			def outputValues = input[1].tokenize(',')
			def outputTag = outputValues[0]
			def outputAttr = outputValues[1]
			def outputMTag = outputValues[2]



			try{
				println("Input Data :")
				inputcust.childNodes().each { child ->
					child.name
					inputkeyValue = readXml4(child, ChildinputTag, inputAttr)
				}

				println "OutPut Data :"
				outputcust.childNodes().each { child ->
					child.name
					outputAttrValue = readXmlAttrs1(child, outputTag, outputAttr)
					outputMtagvalue = readXml1(child,outputMTag)
				}
				outputAttrValue.add(outputMtagvalue)
				//match =  inputkeyValue.contains(outputAttrValue)
				match = inputkeyValue.equals(outputAttrValue)
				//println match
			}
			catch(Exception e2)
			{
				println(e2)
			}
		}
		return match
	}


	/**
	 * Compare two XMls with Mulitple attributes + additional tag  on multiple records
	 * @param inputxmlFile
	 * @param outputxmlFile
	 * @param propertyName
	 * @return
	 */

	def  boolean MULTag_AttrcompareXMLsWithAttributes(inputxmlFile, outputxmlFile, propertyName){

		def match = true
		def inputkeyValue = [],inputAttrValue = [],outputAttrValue =[],outputMtagvalue,outputAttrValue2

		def inputcust = new XmlSlurper().parse(inputxmlFile)
		def outputcust = new XmlSlurper().parse(outputxmlFile)

		getConfig()

		def attribList  = config.get(new String(propertyName)).tokenize(';')
		for (a in 0 .. attribList.size()-1)
		{
			def input = attribList[a].tokenize('=')
			def inputValues = input[0].tokenize(',')
			def inputTag = inputValues[0]
			def inputAttr = inputValues[1]
			def ChildinputTag = inputValues[2]
			def outputValues2 = input[1].tokenize('&')
			def outputValues = outputValues2[0].tokenize(',')
			def outputTag = outputValues[0]
			def outputAttr = outputValues[1]


			def outputValues3 = outputValues2[1].tokenize(',')
			def outputTag2 = outputValues3[0]
			def outputAttr2 = outputValues3[1]
			def outputMTag = outputValues3[2]


			try{


				println("Input Data :")
				inputcust.childNodes().each { child ->
					child.name
					inputkeyValue = readXml4(child, ChildinputTag, inputAttr)
				}

				println "OutPut Data :"
				outputcust.childNodes().each { child ->
					child.name
					outputAttrValue = readXmlAttrs1(child, outputTag, outputAttr)
					outputAttrValue2 = readXmlAttrs(child, outputTag2, outputAttr2)
					outputMtagvalue = readXml1(child,outputMTag)
				}
				/*if(!inputkeyValue.equals(outputAttrValue)){
				 match = false;
				 break;
				 }
				 */
				outputAttrValue.add(outputAttrValue2)
				outputAttrValue.add(outputMtagvalue)


				match =  inputkeyValue.containsAll(outputAttrValue)
				//match = inputkeyValue.equals(outputAttrValue)
				//println match
			}
			catch(Exception e2)
			{
				println(e2)
			}
		}
		return match
	}
	/**
	 * Compare XMlS  for different Atrributes with Entity Type
	 * @param inputxmlFile
	 * @param outputxmlFile
	 * @param propertyName
	 * @return
	 */

	def static boolean EntitycompareXMLsWithAttributes(inputxmlFile, outputxmlFile, propertyName){

		def match = true
		def inputkeyValue, outputAttrValue

		def inputcust = new XmlSlurper().parse(inputxmlFile)
		def outputcust = new XmlSlurper().parse(outputxmlFile)

		getConfig()

		def attribList  = config.get(new String(propertyName)).tokenize(';')
		for (a in 0 .. attribList.size()-1)
		{
			def input = attribList[a].tokenize('=')

			def inputValues = input[0].tokenize(',')
			def inputTag = inputValues[0]
			def inputAttr = inputValues[1]
			def ChildinputTag = inputValues[2]
			def outputValues = input[1].tokenize(',')
			def outputTag = outputValues[0]
			def outputAttr = outputValues[1]




			try{
				println("Input Data :")
				inputcust.childNodes().each { child ->
					child.name
					inputkeyValue = readXml5(child, ChildinputTag, inputAttr)
				}
				println "OutPut Data :"
				outputcust.childNodes().each { child ->
					child.name
					outputAttrValue = readXmlAttrs(child, outputTag, outputAttr)
				}
				if(outputAttrValue.contains(inputkeyValue)){
					match = true
					//break;
				}

			}
			catch(Exception e2)
			{
				println(e2)
			}
		}
		return match
	}

	/**
	 * Work for the story specific to 4223,4225
	 * @param inputxmlFile
	 * @param outputxmlFile
	 * @param propertyName
	 * @return
	 */
	def static boolean compareXMLsAttrGenService(inputxmlFile, outputxmlFile,propertyName){
		def match = true
		def inputkeyValue, outputkeyValue
		def String TIME24HOURS_PATTERN =
				"[0-2][0-9]\\:[0-5][0-9]\\-[0-2][0-9]\\:[0-5][0-9]"

		def pattern = Pattern.compile(TIME24HOURS_PATTERN)

		//return matcher.matches();

		def inputcust = new XmlSlurper().parse(inputxmlFile)
		def outputcust = new XmlSlurper().parse(outputxmlFile)
		getConfig()

		def elementList = config.get(new String(propertyName)).tokenize(';')

		for(e in 0 .. elementList.size()-1) {

			try{
				def tags  = elementList[e].tokenize('=')
				def inputTag = tags[0]
				def outputValues = tags[1].tokenize(',')
				def outputAttr = outputValues[1]
				def outputTag = outputValues[0]
				println("Input Data :")
				inputcust.childNodes().each { child ->
					child.name
					inputkeyValue = readXml1(child, inputTag)  }
				println "OutPut Data :"
				outputcust.childNodes().each { child ->
					child.name
					outputkeyValue = readXmlAttrs(child, outputTag, outputAttr) }

				if(inputkeyValue.equals("24HR")){
					if(outputkeyValue.equals("true"))
						match = true

				}
				if(inputkeyValue.equals("0")){

					if(outputkeyValue.equals("Weekly"))
						match=true
				}
				if(inputkeyValue.equals("1")){

					if(outputkeyValue.equals("Daily"))
						match=true
				}

				if(inputkeyValue.equals("")){
					if(outputkeyValue.equals("false"))
						match = true

				}

				if(inputkeyValue.equals("0")){
					if(outputkeyValue.equals("false"))
						match = true

				}


				def  matcher = pattern.matcher(inputkeyValue)
				if(matcher){

					match = true

				}

			}

			catch(Exception e2)
			{
				println(e2)
			}


		}
		return match

	}

	/**
	 * Compare XMls for boolean values with Attributes for CB4224-CheckInOut Details
	 * @param inputxmlFile
	 * @param outputxmlFile
	 * @param propertyName
	 * @return
	 */


	def static boolean compareXMLsAttrBooleanValuesCheckInOut(inputxmlFile, outputxmlFile,propertyName){
		def match = true
		def inputkeyValue, outputkeyValue
		def week = [
			"mon",
			"tue",
			"wed",
			"thu",
			"fri",
			"sat",
			"sun"
		]

		def inputcust = new XmlSlurper().parse(inputxmlFile)
		def outputcust = new XmlSlurper().parse(outputxmlFile)
		getConfig()

		println outputcust

		def elementList = config.get(new String(propertyName)).tokenize(';')

		for(e in 0 .. elementList.size()-1) {
			String[] day  = elementList.get(e).split(",")
			int index = week.indexOf(day[1])
			try{
				def tags  = elementList[e].tokenize('=')
				def inputTag = tags[0]
				def outputValues = tags[1].tokenize(',')
				def outputAttr = outputValues[1]
				def outputTag = outputValues[0]
				println("Input Data :")
				inputcust.childNodes().each { child ->
					child.name
					inputkeyValue = readXml1(child, inputTag)  }
				println "OutPut Data :"
				outputcust.childNodes().each { child ->
					child.name
					outputkeyValue = readXmlAttrs(child, outputTag, outputAttr)
				}
				match =  inputkeyValue.charAt(index) == '1' ? true : false  == Boolean.parseBoolean(outputkeyValue)
			}
			catch(Exception e2)
			{
				println(e2)
			}

		}
		//          }

		return match

	}

	/**
	 * Compare Multiple XMls for boolean values with Attributes for CB4224-CheckInOut Details
	 * @param inputxmlFile
	 * @param outputxmlFile
	 * @param propertyName
	 * @return
	 */

	def static boolean MULcompareXMLsAttrBooleanValuesCheckInOut(inputxmlFile, outputxmlFile,propertyName)
	{
		def match = true
		def inputkeyValue = [],inputAttrValue = [],outputAttrValue =[],outputMtagvalue,outputAttrValue2

		def week = [
			"mon",
			"tue",
			"wed",
			"thu",
			"fri",
			"sat",
			"sun"
		]

		def inputcust = new XmlSlurper().parse(inputxmlFile)
		def outputcust = new XmlSlurper().parse(outputxmlFile)

		getConfig()

		def attribList  = config.get(new String(propertyName)).tokenize(';')
		for (a in 0 .. attribList.size()-1)
		{
			String[] day  = attribList.get(a).split(",")
			int index = week.indexOf(day[3])
			def input = attribList[a].tokenize('=')
			def inputValues = input[0].tokenize(',')
			def inputTag = inputValues[0]
			def inputAttr = inputValues[1]
			def ChildinputTag = inputValues[2]


			def outputValues2 = input[1].tokenize('=')
			def outputValues = outputValues2[0].tokenize(',')
			def outputTag = outputValues[0]
			def outputAttr = outputValues[1]


			try{
				println("Input Data :")
				inputcust.childNodes().each { child ->
					child.name
					inputkeyValue = readXml1(child, ChildinputTag)

				}

				println "OutPut Data :"
				outputcust.childNodes().each { child ->
					child.name
					outputAttrValue = readXmlAttrs(child, outputTag, outputAttr)

				}
				/*if(!inputkeyValue.equals(outputAttrValue)){
				 match = false;
				 break;
				 }
				 */

				/*outputAttrValue.add(outputAttrValue2)
				 outputAttrValue.add(outputMtagvalue)*/

				match =  inputkeyValue.charAt(index) == '1' ? true : false  == Boolean.parseBoolean(outputAttrValue)
				//match =  inputkeyValue.containsAll(outputAttrValue)
				//match = inputkeyValue.equals(outputAttrValue)
				println "Match : " + inputkeyValue.charAt(index) + " : " + match
			}
			catch(Exception e2)
			{
				println(e2)
			}
		}
		return match
	}



	def static boolean MULcompareXMLsAttrBooleanValuesCheckInOutNew(inputxmlFile, outputxmlFile,propertyName){
		def match = true
		def inputkeyValue, outputkeyValue
		def week = [
			"mon",
			"tue",
			"wed",
			"thu",
			"fri",
			"sat",
			"sun"
		]

		def inputcust = new XmlSlurper().parse(inputxmlFile)
		def outputcust = new XmlSlurper().parse(outputxmlFile)
		getConfig()

		def elementList = config.get(new String(propertyName)).tokenize(';')

		for(e in 0 .. elementList.size()-1) {
			String[] day  = elementList.get(e).split(",")
			int index = week.indexOf(day[1])
			try{
				def tags  = elementList[e].tokenize('=')
				println (tags)
				def inputTag = tags[0]
				println (inputTag)
				def outputValues = tags[1].tokenize(',')
				println (outputValues)
				def outputAttr = outputValues[1]
				println (outputAttr)
				def outputTag = outputValues[0]
				println (outputTag)

				println("Input Data :")
				inputcust.children().children().each { child ->

					child.name
					inputkeyValue = readXml1(child, inputTag)  }
				println "OutPut Data :"
				outputcust.children().children().each { child ->

					child.name
					outputkeyValue = readXmlAttrs(child, outputTag, outputAttr)
				}
				match =  inputkeyValue.charAt(index) == '1' ? true : false  == Boolean.parseBoolean(outputkeyValue)
			}
			catch(Exception e2)
			{
				println(e2)
			}

		}
		//          }

		return match

	}

	//Compare two XMls with respect to dateTime
	def static boolean compareXMLsWithAttributesDateTime(inputxmlFile, outputxmlFile, propertyName){

		def match = true
		def inputkeyValue, outputAttrValue

		def inputcust = new XmlSlurper().parse(inputxmlFile)
		def outputcust = new XmlSlurper().parse(outputxmlFile)

		getConfig()

		def attribList  = config.get(new String(propertyName)).tokenize(';')
		for (a in 0 .. attribList.size()-1)
		{
			def input = attribList[a].tokenize('=')
			def inputTag = input[0]
			def outputValues = input[1].tokenize(',')
			def outputAttr = outputValues[1]
			def outputTag = outputValues[0]


			try{
				println("Input Data :")
				inputcust.childNodes().each { child ->
					child.name
					inputkeyValue = readXml1(child, inputTag)
				}
				println "OutPut Data :"
				outputcust.childNodes().each { child ->
					child.name
					outputAttrValue = readXmlAttrs(child, outputTag, outputAttr)
				}
				outputAttrValue = outputAttrValue.replaceAll("T"," ")
				if(!inputkeyValue.contains(outputAttrValue)){
					match = false
					break
				}

			}
			catch(Exception e2)
			{
				println(e2)
			}
		}
		return match
	}

	//Compare XMls for Restrictions Type
	def static boolean compareXMLsAttrRestrictionsType(inputxmlFile, outputxmlFile,propertyName){
		def match = true
		def inputkeyValue, outputkeyValue

		def inputcust = new XmlSlurper().parse(inputxmlFile)
		def outputcust = new XmlSlurper().parse(outputxmlFile)
		getConfig()

		def elementList = config.get(new String(propertyName)).tokenize(';')

		for(e in 0 .. elementList.size()-1) {

			try{
				def tags  = elementList[e].tokenize('=')
				def inputTag = tags[0]
				def outputValues = tags[1].tokenize(',')
				def outputAttr = outputValues[1]
				def outputTag = outputValues[0]
				println("Input Data :")
				inputcust.childNodes().each { child ->
					child.name
					inputkeyValue = readXml1(child, inputTag)  }
				println "OutPut Data :"
				outputcust.childNodes().each { child ->
					child.name
					outputkeyValue = readXmlAttrs(child, outputTag, outputAttr) }

				if(inputkeyValue == "C"){
					if(outputkeyValue.equals("Closed for Business")){
						match = true
						break
					}

				}else if(inputkeyValue == "A"){
					if(outputkeyValue.equals("Closed for Arrival")){
						match = true
						break
					}
				}else if(inputkeyValue == "D"){
					if(outputkeyValue.equals("Closed for Departure")){
						match = true
						break
					}
				}
			}
			catch(Exception e2)
			{
				println(e2)
			}

		}
		//          }

		return match

	}

	//Compare two XMls with multirecord for dateTime
	//
	def  boolean MULcompareXMLsWithAttributesDateTime(inputxmlFile, outputxmlFile, propertyName){

		def match = false
		def inputkeyValue = [],inputAttrValue = [],outputAttrValue =[]

		def inputcust = new XmlSlurper().parse(inputxmlFile)
		def outputcust = new XmlSlurper().parse(outputxmlFile)

		getConfig()

		def attribList  = config.get(new String(propertyName)).tokenize(';')
		for (a in 0 .. attribList.size()-1)
		{
			def input = attribList[a].tokenize('=')
			def inputValues = input[0].tokenize(',')
			def inputTag = inputValues[0]
			def inputAttr = inputValues[1]
			def ChildinputTag = inputValues[2]
			def outputValues = input[1].tokenize(',')
			def outputTag = outputValues[0]
			def outputAttr = outputValues[1]



			try{
				/*  println("Input Data Entity Type :")
				 inputcust.childNodes().each { child -> child.name
				 inputAttrValue = readXmlAttrs1(child, inputTag, inputAttr)
				 }*/


				println("Input Data :")
				inputcust.childNodes().each { child ->
					child.name
					inputkeyValue = readXml4(child, ChildinputTag, inputAttr)
				}

				println "OutPut Data :"
				outputcust.childNodes().each { child ->
					child.name
					outputAttrValue = readXmlAttrs1(child, outputTag, outputAttr)
				}
				/*if(!inputkeyValue.equals(outputAttrValue)){
				 match = false;
				 break;
				 }
				 */
				for(int i=0;i<outputAttrValue.size();i++){
					outputAttrValue.set(i, outputAttrValue.getAt(i).replaceAll("T"," "))
					match = inputkeyValue.getAt(i).equals(outputAttrValue.getAt(i))
				}
			}
			catch(Exception e2)
			{
				println(e2)
			}
		}
		return match
	}

	//Compare two XMls with multirecord for Restrictions
	def  boolean MULTagcompareXMLsWithAttributesRestrictionType(inputxmlFile, outputxmlFile, propertyName){

		def match = false
		def inputkeyValue = [],inputAttrValue = [],outputAttrValue =[],outputMtagvalue

		def inputcust = new XmlSlurper().parse(inputxmlFile)
		def outputcust = new XmlSlurper().parse(outputxmlFile)

		getConfig()

		def attribList  = config.get(new String(propertyName)).tokenize(';')
		for (a in 0 .. attribList.size()-1)
		{
			def input = attribList[a].tokenize('=')
			def inputValues = input[0].tokenize(',')
			def inputTag = inputValues[0]
			def inputAttr = inputValues[1]
			def ChildinputTag = inputValues[2]
			def outputValues = input[1].tokenize(',')
			def outputTag = outputValues[0]
			def outputAttr = outputValues[1]
			def outputMTag = outputValues[2]



			try{
				/*  println("Input Data Entity Type :")
				 inputcust.childNodes().each { child -> child.name
				 inputAttrValue = readXmlAttrs1(child, inputTag, inputAttr)
				 }*/


				println("Input Data :")
				inputcust.childNodes().each { child ->
					child.name
					inputkeyValue = readXml4(child, ChildinputTag, inputAttr)
				}

				println "OutPut Data :"
				outputcust.childNodes().each { child ->
					child.name
					outputAttrValue = readXmlAttrs1(child, outputTag, outputAttr)
					outputMtagvalue = readXml1(child,outputMTag)
				}
				/*if(!inputkeyValue.equals(outputAttrValue)){
				 match = false;
				 break;
				 }
				 */

				for(int i=0;i<inputkeyValue.size();i++){
					for(int j=0;j<outputAttrValue.size();j++){
						//println inputkeyValue.getAt(i)+" :  "+outputAttrValue.getAt(j)
						if(inputkeyValue.getAt(i) == "C"){
							if(outputAttrValue.getAt(j).equals("Closed for Business")){
								match = true
								break
							}

						}else if(inputkeyValue.getAt(i) == "A"){
							if(outputAttrValue.getAt(j).equals("Closed for Arrival")){
								match = true
								break
							}
						}else if(inputkeyValue.getAt(i) == "D"){
							if(outputAttrValue.getAt(j).equals("Closed for Departure")){
								match = true
								break
							}
						}

					}
				}
			}
			catch(Exception e2)
			{
				println(e2)
			}
		}
		return match
	}



	def static boolean compareXMLsBooleanValuesCB4225(inputxmlFile, outputxmlFile,propertyName){
		def match = true
		def inputkeyValue, outputkeyValue

		def inputcust = new XmlSlurper().parse(inputxmlFile)
		def outputcust = new XmlSlurper().parse(outputxmlFile)
		getConfig()

		def elementList = config.get(new String(propertyName)).tokenize(';')

		for(e in 0 .. elementList.size()-1) {

			try{
				def tags  = elementList[e].tokenize('=')
				println("Input Data :")
				inputcust.childNodes().each { child ->
					child.name
					inputkeyValue = readXml1(child, tags[0])	}
				println "OutPut Data :"
				outputcust.childNodes().each { child ->
					child.name
					outputkeyValue = readXml1(child, tags[1]) }

				if(inputkeyValue == ""){
					if(outputkeyValue.equals("false")){
						match = true
						break
					}

				}


			}
			catch(Exception e2)
			{
				println(e2)
			}

		}
		//			}

		return match

	}

	/**
	 * To verify when an empty tag is passed.
	 * @param inputxmlFile
	 * @param outputxmlFile
	 * @param propertyName
	 * @return
	 */

	def static boolean compareXMLsDifftagsForNull(inputxmlFile, outputxmlFile,propertyName){
		def match = true
		def inputkeyValue, outputkeyValue

		def inputcust = new XmlSlurper().parse(inputxmlFile)
		def outputcust = new XmlSlurper().parse(outputxmlFile)
		getConfig()

		def elementList = config.get(new String(propertyName)).tokenize(';')

		for(e in 0 .. elementList.size()-1) {
			try{
				def tags  = elementList[e].tokenize('=')
				println("Input Data :")
				inputcust.childNodes().each { child ->
					child.name
					if(!readXml1(child)==null){
						inputkeyValue = readXml1(child, tags[0])
					}
				}
				println "OutPut Data :"
				outputcust.childNodes().each { child ->
					child.name
					if(!readXml1(child)==null){
						outputkeyValue = readXml1(child, tags[1])
					}
				}

				if(!inputkeyValue.equals(outputkeyValue))
				{
					match = false
					break
				}
			}


			catch(Exception e2)
			{
				println(e2)
			}


		}

		return match

	}

}
