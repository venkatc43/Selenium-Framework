/*
	This is the Geb configuration file.
	
	See: http://www.gebish.org/manual/current/configuration.html
*/



import org.openqa.selenium.chrome.ChromeDriver
import org.openqa.selenium.firefox.FirefoxBinary
import org.openqa.selenium.firefox.FirefoxDriver
import org.openqa.selenium.firefox.FirefoxProfile

waiting {
	timeout = 2
}

environments {
	FirefoxProfile profile = new FirefoxProfile();
	
	// run via â€œ./gradlew chromeTestâ€�
	// See: http://code.google.com/p/selenium/wiki/ChromeDriver

	
	// run via â€œ./gradlew firefoxTestâ€�
	// See: http://code.google.com/p/selenium/wiki/FirefoxDriver
	firefox {
		//FirefoxProfile firefoxProfile = new FirefoxProfile();
		//firefoxProfile.setPreference("webdriver.reap_profile","false")
		//firefoxProfile.setPreference("webdriver.firefox.useExisting", false)
		/*firefoxProfile.setPreference("privacy.clearOnShutdown.cache","true")
		firefoxProfile.setPreference("privacy.clearOnShutdown.cookies","true")
		firefoxProfile.setPreference("privacy.clearOnShutdown.sessions","true")
		firefoxProfile.setPreference("privacy.clearOnShutdown.history","true")
		firefoxProfile.setPreference("privacy.clearOnShutdown.passwords","true")*/
		//firefoxProfile.setPreference("browser.private.browsing.autostart", true);
		driver = { new FirefoxDriver(firefoxProfile) }
		//driver = { new FirefoxDriver(new FirefoxBinary(new File("/usr/sbin/firefox")), profile) }
		//autoClearCookies = true
		
		
	}
	
	chrome {
		
		System.setProperty("webdriver.chrome.driver","C:\\QAAutomation\\qa_kuoni_automation\\common_qa_automation\\src\\main\\resources\\chromedriver.exe")
		driver = { new ChromeDriver() }
	}

}

// To run the tests with all browsers just run 