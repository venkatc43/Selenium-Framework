package com.moj.rota.admin.stepdefinitions;

import static com.jayway.restassured.RestAssured.given;

import java.util.List;
import java.util.Map;

import com.moj.rota.base.stepdefs.BaseStepDefination;
import com.moj.test.utils.ExcelUtil;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RotaStandardReportsStepDefination extends BaseStepDefination {

	private ExcelUtil excelUtil = null;
	private static String reportType = null;
	private static String location = null;
	private static String endDateForExpected = null;
	private static int transferInrowNumber =0;

	@When("^I sent request with report type \"(.*?)\" ,location \"(.*?)\"$")
	public void i_sent_request_with_report_type_location(String reportTypeVal, String ljaLocation) throws Throwable {

		requestSpec.accept("application/vnd.ms-excel");
		reportType = reportTypeVal;
		switch (reportType) {
		case "BENCHCONTACT":
			response = given().spec(requestSpec).urlEncodingEnabled(true).log().all().when()
					.get("/RotaAdminREST/webresources/reports/standard-report/BENCHCONTACT/"
							+ getDraftLJALocationID(ljaLocation) + "/" + urlSessionId);
			break;
		case "ADDRESSLABELS":
			response = given().spec(requestSpec).urlEncodingEnabled(true).log().all().when()
					.get("/RotaAdminREST/webresources/reports/standard-report/LJA/" + getDraftLJALocationID(ljaLocation)
							+ "/ADDRESSLABELS/" + urlSessionId);
			break;

		case "OUTOFHOURS":
			response = given().spec(requestSpec).urlEncodingEnabled(true).log().all().when()
					.get("/RotaAdminREST/webresources/reports/standard-report/" + getDraftLJALocationID(ljaLocation)
							+ "/OUTOFHOURS/" + urlSessionId);
			break;

		case "PANEL":
			response = given().spec(requestSpec).urlEncodingEnabled(true).log().all().when()
					.get("/RotaAdminREST/webresources/reports/standard-report/LJA/" + getDraftLJALocationID(ljaLocation)
							+ "/PANEL/" + urlSessionId);
			break;
		case "CONTACTLIST":
			response = given().spec(requestSpec).urlEncodingEnabled(true).log().all().when()
			.get("/RotaAdminREST/webresources/reports/standard-report/" + getDraftLJALocationID(ljaLocation)
					+ "/CONTACTLIST/" + urlSessionId);
	break;

		}

	}

	@Then("^Excel Report title should contains \"(.*?)\"$")
	public void excel_Report_title_should_contains(String reportTitle) throws Throwable {
		byte[] responseByteArray = response.asByteArray();
		excelUtil = new ExcelUtil(responseByteArray);
		assertUtil.isEquals(reportTitle, excelUtil.getCellValue(0, 0));
	}

	@Then("^Excel Report headers should consists of:$")
	public void excel_Report_headers_should_consists_of(List<String> reportHeaders) throws Throwable {

		switch (reportType) {
		case "ADDRESSLABELS":
			byte[] responseByteArray = response.asByteArray();
			excelUtil = new ExcelUtil(responseByteArray);
			for (int i = 0; i < reportHeaders.size(); i++) {
				assertUtil.isEquals(reportHeaders.get(i), excelUtil.getCellValue(0, i));
			}
			break;
		case "BENCHCONTACT":
		case "OUTOFHOURS":
			for (int i = 0; i < reportHeaders.size(); i++) {
				assertUtil.isEquals(reportHeaders.get(i), excelUtil.getCellValue(3, i));
			}
			break;
		case "PANEL":
		case "UNBALANCEDBENCH":
		case "MENTOREDSITTING":
			for (int i = 0; i < reportHeaders.size(); i++) {
				assertUtil.isEquals(reportHeaders.get(i), excelUtil.getCellValue(5, i));
			}
			break;
		case "70THBIRTHDAY":
		case "MAGNONAVAILABILITY":
		case "VACATED_SITTINGS":
		case "CANCELLED_SITTINGS":
		case "CONTACTLIST":
			for (int i = 0; i < reportHeaders.size(); i++) {
				assertUtil.isEquals(reportHeaders.get(i), excelUtil.getCellValue(4, i));
			}
			break;
		case "MAGMOVEMENT":
			int rowNumber = 0;
			for (int i = 0; i < reportHeaders.size(); i++) {
				rowNumber = excelUtil.getRowNumberByKeyForReports(reportHeaders.get(i));
				assertUtil.isEquals(reportHeaders.get(i), excelUtil.getCellValue(rowNumber, 0));
				// Title
				assertUtil.isTrue(excelUtil.getCellValue(rowNumber + 1, 0).length() > 0);
				// ForeNames
				assertUtil.isTrue(excelUtil.getCellValue(rowNumber + 1, 1).length() > 0);
				// SurName
				assertUtil.isTrue(excelUtil.getCellValue(rowNumber + 1, 2).length() > 0);
			}
			break;
		case "SITTINGSUMMARY":
			int columCount = 0;
			for (int i = 0; i < reportHeaders.size(); i++) {

				if (reportHeaders.get(i).equals("Youth") || reportHeaders.get(i).equals("Family")
						|| reportHeaders.get(i).equals("Adult Crown Court")) {
					columCount = ++columCount;
				}
				assertUtil.isEquals(reportHeaders.get(i), excelUtil.getCellValue(5, columCount++));
			}
			break;
		case "ROTADATERANGE":
		case "DAILYATTENDANCE":
			if (reportHeaders.get(0).equals("Venue (session)")) {
				assertUtil.isEquals(reportHeaders.get(0), excelUtil.getCellValue(4, 0));
			} else {
				int cellSize = excelUtil.getNumberofCellsByRowNumber(4);
				for (int i = 1; i < cellSize - 1; i++) {
					String data[] = excelUtil.getCellValue(4, i).split(",");
					// checking dayname length -Min length example is Sunday
					assertUtil.isTrue("DayName", data[0].length() >= 5);
					// checking Date length -Min length example is 1 May 2016
					assertUtil.isTrue("Date", data[1].length() >= 9);
				}
			}

			break;
		case "MAGTRANSFERS":
			//transfer out header verification
			assertUtil.isEquals(reportHeaders.get(0), excelUtil.getCellValue(4, 0));
			for (int i = 1; i < reportHeaders.size(); i++) {
				assertUtil.isEquals(reportHeaders.get(i), excelUtil.getCellValue(5, i-1));
			}
			break;

		}

	}

	@Then("^Excel report should display content of \"(.*?)\"$")
	public void excel_report_should_display(String reportName, Map<String, String> reportValue) throws Throwable {
		int rowNumber = 0;
		int courtSessionSplit = 5;
		//Transfer in values will be next row of headers
		transferInrowNumber=++transferInrowNumber;
		if (reportValue.get("Forenames") != null) {
			rowNumber = excelUtil.getRowNumberByKey(reportValue.get("Forenames"),1);
		} else if (reportValue.get("Sitting Magistrate") != null) {
			rowNumber = excelUtil.getRowNumberByKeyForReports(reportValue.get("Sitting Magistrate"));
		} else if (reportValue.get("Contactlist Magistrate") != null) {
			rowNumber = excelUtil.getRowNumberByKeyForReports(reportValue.get("Contactlist Magistrate"));
		}
		
		//need to set row number to increament row number for advisory report
		if(reportType.equals("ADVISORY"))
		{
			rowNumber=5;
		}

		int columnCount = 0;
		for (Map.Entry<String, String> content : reportValue.entrySet()) {
			String contentValue = content.getValue();
			String contentKey = content.getKey();

			switch (contentKey) {
			case "Title":
				assertUtil.isTrue(contentValue, excelUtil.getCellValue(rowNumber, columnCount++).matches(contentValue));
				break;
			case "Postcode":
				assertUtil.isEquals(contentValue, excelUtil.getCellValue(rowNumber, 8));
				break;
			case "Leaving Date":
				assertUtil.isTrue(excelUtil.getCellValue(rowNumber, 10).length() > 8);
				break;
			case "Leaving Reason":
				assertUtil.isEquals(contentValue, excelUtil.getCellValue(rowNumber, 11));
				break;
			case "Unbalanced Date":
				assertUtil.isTrue(excelUtil.getCellValue(6, columnCount++).length() > 8);
				break;
			case "Business Type":
				assertUtil.isTrue(excelUtil.getCellValue(6, columnCount++).length() > 0);
				break;
			case "Count":
				assertUtil.isTrue(Integer.parseInt(excelUtil.getCellValue(6, columnCount++).replace(".0", "")) >= 0);
				break;
			case "DateRange Values":
				assertUtil.isTrue(excelUtil.getCellValue(6, 1).matches(contentValue));
				break;
			case "Magistrate":
				assertUtil.isTrue(excelUtil.getCellValue(6, columnCount++).matches(contentValue));
				break;
			case "Mentor":
				assertUtil.isTrue(excelUtil.getCellValue(6, columnCount++).matches(contentValue));
				break;
			case "Sitting Date":
				assertUtil.isTrue(excelUtil.getCellValue(6, columnCount++).matches(contentValue));
				break;
			case "Sitting Email":
				assertUtil.isTrue(excelUtil.getCellValue(rowNumber, 14).matches(contentValue));
				break;
			case "Total results:":
				assertUtil.isTrue(excelUtil.getCellValue(3, 0).contains(contentKey));
				// checking total number of results value like 0..
				assertUtil.isTrue(excelUtil.getCellValue(3, 0).matches(contentValue));
				break;
			case "Total-Adult,Youth,Family broken rules":
			case "Average":
				if (contentKey.equalsIgnoreCase("Average")) {
					rowNumber = excelUtil.getRowNumberByKeyForReports("Average");
					assertUtil.isEquals(contentKey, excelUtil.getCellValue(rowNumber, 0));
				} else {
					String data[] = contentKey.split("-");
					rowNumber = excelUtil.getRowNumberByKeyForReports(data[0]);
					assertUtil.isEquals(data[0], excelUtil.getCellValue(rowNumber, 0));
				}

				assertUtil.isTrue("All:", Integer.parseInt(excelUtil.getCellValue(rowNumber, 1)) >= 0);
				assertUtil.isTrue("Adult Winger broken rule:",
						Integer.parseInt(excelUtil.getCellValue(rowNumber, 2)) >= 0);
				assertUtil.isTrue("Adult Chair broken rule:",
						Integer.parseInt(excelUtil.getCellValue(rowNumber, 3)) >= 0);
				assertUtil.isTrue("Youth Winger broken rule:",
						Integer.parseInt(excelUtil.getCellValue(rowNumber, 4)) >= 0);
				assertUtil.isTrue("Youth Chair broken rule:",
						Integer.parseInt(excelUtil.getCellValue(rowNumber, 5)) >= 0);
				assertUtil.isTrue("Family Winger broken rule:",
						Integer.parseInt(excelUtil.getCellValue(rowNumber, 6)) >= 0);
				assertUtil.isTrue("Family Chair broken rule:",
						Integer.parseInt(excelUtil.getCellValue(rowNumber, 7)) >= 0);
				assertUtil.isTrue("Adult crown court winger broken rule:",
						Integer.parseInt(excelUtil.getCellValue(rowNumber, 8)) >= 0);
				assertUtil.isTrue("Youth crown court broken rule:",
						Integer.parseInt(excelUtil.getCellValue(rowNumber, 9)) >= 0);

				break;
			default:
				if (reportType.equalsIgnoreCase("70THBIRTHDAY") || reportType.equalsIgnoreCase("MAGNONAVAILABILITY")
						|| reportType.equalsIgnoreCase("VACATED_SITTINGS") || reportType.equalsIgnoreCase("CANCELLED_SITTINGS")) {
					rowNumber = 5;
					assertUtil.isTrue(contentValue,excelUtil.getCellValue(rowNumber, columnCount++).matches(contentValue));
				} else if (reportType.equalsIgnoreCase("COURTSESSIONSPLIT")) {
					rowNumber = courtSessionSplit++;
					if(contentKey.equals("Total"))
					{
						rowNumber = courtSessionSplit++;	
					}
					assertUtil.isEquals(contentKey, excelUtil.getCellValue(rowNumber, 0));
					assertUtil.isTrue(excelUtil.getCellValue(rowNumber, 1).length() > 0);
					//percentage coming as blank
					if (rowNumber <= 6) {
						assertUtil.isTrue(Integer.valueOf(excelUtil.getFormulaCellTypeValue(rowNumber))>0);
					}

				} else if (reportType.equalsIgnoreCase("UNBALANCEDBENCH")) {
					assertUtil.isTrue(contentValue, excelUtil.getCellValue(6, columnCount++).matches(contentValue));
				} else if (reportType.equalsIgnoreCase("ROTADATERANGE")
						|| reportType.equalsIgnoreCase("DAILYATTENDANCE")) {
					assertUtil.isEquals(contentValue, excelUtil.getCellValue(6, columnCount++));

				} else if (reportType.equalsIgnoreCase("MENTOREDSITTING")) {
					assertUtil.isEquals(contentValue, excelUtil.getCellValue(6, columnCount++));

				} else if (reportType.equalsIgnoreCase("ADVISORY")) {
					columnCount=0;
					if (columnCount == 0) {
						contentKey=contentKey.replace("Date", rotaPeriodStartDate.replace("-", "/"));
					} 
					assertUtil.isEquals(contentKey, excelUtil.getCellValue(rowNumber, columnCount++));
					assertUtil.isTrue(contentValue, excelUtil.getCellValue(rowNumber, columnCount).matches(contentValue));
					rowNumber++;

				} else if (reportType.equalsIgnoreCase("MAGTRANSFERS")) {
					//cheking Transfer In values only
					if(contentKey.equals("Total"))
					{
						int totalRowNumber=excelUtil.getRowNumberByKey(contentKey, 2);
						assertUtil.isTrue(contentValue,excelUtil.getCellValue(totalRowNumber, 3).matches(contentValue));
						
					} else {
						assertUtil.isTrue(contentValue,excelUtil.getCellValue(transferInrowNumber, columnCount++).matches(contentValue));
					}
					

				} else if (reportType.equalsIgnoreCase("CONTACTLIST")) {
					String actulaValue = excelUtil.getCellValue(rowNumber, columnCount++);
					if (contentKey.equals("Home,Mobile,Office")) {
						String[] telephoeNumbers = contentKey.split(",");
						String[] telephoeNumbersValues = contentValue.split(",");
						for (int i = 0; i < telephoeNumbers.length; i++) {
							assertUtil.isTrue(telephoeNumbersValues[i], actulaValue.contains(telephoeNumbersValues[i]));
						}
					} else {
						assertUtil.isTrue(contentValue, actulaValue.contains(contentValue));
					}
					
				}else {
					assertUtil.isEquals(contentValue,
							excelUtil.getCellValue(rowNumber, columnCount++).replace(".0", ""));
				}

			}
		}

	}

	@Then("^Excel report should display the panel type \"(.*?)\"$")
	public void excel_report_should_display_the_panel_type(String panelType) throws Throwable {
		assertUtil.isEquals(panelType, excelUtil.getCellValue(3, 0));
	}

	@Then("^panel excel report should contains gender \"(.*?)\" ,Role \"(.*?)\"$")
	public void panel_excel_report_should_contains_gender_Role(String gender, String role,
			Map<String, String> reportValue) throws Throwable {

		int rowNumber = excelUtil.getRowNumberByKey(reportValue.get("Forenames"),1);
		int columnCount = 0;
		for (Map.Entry<String, String> content : reportValue.entrySet()) {
			String contentValue = content.getValue();
			String contentKey = content.getKey();

			switch (contentKey) {
			case "Title":
				assertUtil.isTrue(contentValue, excelUtil.getCellValue(rowNumber, columnCount++).matches(contentValue));
				break;
			default:
				assertUtil.isEquals(contentValue, excelUtil.getCellValue(rowNumber, columnCount++));
			}

		}

		assertUtil.isEquals(role, excelUtil.getCellValue(rowNumber, 4));
		assertUtil.isEquals(gender, excelUtil.getCellValue(rowNumber, 5));
	}

	@When("^I add report type \"(.*?)\" ,location \"(.*?)\" to request$")
	public void i_add_report_type_location_to_request(String reportTypeVal, String locationType) throws Throwable {
		reportType = reportTypeVal;
		location = locationType;
	}

	@When("^I sent request with Rota start date  ,end date: \"(.*?)\"$")
	public void i_sent_request_with_Rota_start_date_end_date(String endDate) throws Throwable {
		if (rotaPeriodStartDate == null) {
			// start date as current date
			rotaPeriodStartDate = getDateForRestRequest();
		}
		switch (reportType) {
		case "70THBIRTHDAY":
			response = given().spec(requestSpec).urlEncodingEnabled(true).log().all().when()
					.get("/RotaAdminREST/webresources/reports/standard-report/" + rotaPeriodStartDate + "/" + endDate
							+ "/" + "LJA/" + getDraftLJALocationID(location) + "/70THBIRTHDAY/" + urlSessionId);
			break;
		case "COURTSESSIONSPLIT":
			// end date as current date plus six months
			rotaPeriodStartDate = rotaPeriodStartDate.replace("/", "-");
			endDateForExpected = getDateForRestRequest(6);
			response = given().spec(requestSpec).urlEncodingEnabled(true).log().all().when()
					.get("/RotaAdminREST/webresources/reports/standard-report/" + rotaPeriodStartDate + "/"
							+ endDateForExpected + "/" + ljaSouthLocationID + "/COURTSESSIONSPLIT/"
							+ publishedUrlSessionId);
			break;

		case "MAGISTRATESINFO":
			endDateForExpected = getDateForRestRequest(6);
			response = given().spec(requestSpec).urlEncodingEnabled(true).log().all().when()
					.get("/RotaAdminREST/webresources/reports/standard-report/MAGISTRATESINFO/" + rotaPeriodStartDate
							+ "/" + endDateForExpected + "/" + getDraftLJALocationID(location) + "/" + urlSessionId);
			break;

		case "MAGMOVEMENT":
			response = given().spec(requestSpec).urlEncodingEnabled(true).log().all().when()
					.get("/RotaAdminREST/webresources/reports/standard-report/" + rotaPeriodStartDate + "/" + endDate
							+ "/LJA/" + getDraftLJALocationID(location) + "/MAGMOVEMENT/" + urlSessionId);
			break;
		case "SITTINGSUMMARY":
			response = given().spec(requestSpec).urlEncodingEnabled(true).log().all().when()
					.get("/RotaAdminREST/webresources/reports/standard-report/" + rotaPeriodStartDate + "/" + endDate
							+ "/LJA/" + getDraftLJALocationID(location) + "/SITTINGSUMMARY/" + urlSessionId);
			break;
		case "UNBALANCEDBENCH":
			response = given().spec(requestSpec).urlEncodingEnabled(true).log().all().when()
					.get("/RotaAdminREST/webresources/reports/standard-report/" + rotaPeriodStartDate + "/" + endDate
							+ "/DFC/" + getDraftLJALocationID(location) + "/UNBALANCEDBENCH/" + urlSessionId);
			break;
		case "ROTADATERANGE":
			endDateForExpected = getDate();
			rotaPeriodStartDate = rotaPeriodStartDate.replace("/", "-");
			endDateForExpected = endDateForExpected.replace("/", "-");
			response = given().spec(requestSpec).urlEncodingEnabled(true).log().all().when()
					.get("/RotaAdminREST/webresources/reports/standard-report/" + rotaPeriodStartDate + "/"
							+ endDateForExpected + "/LJA/" + ljaSouthLocationID + "/" + magCourt1 + "/ROTADATERANGE/"
							+ optimisedUrlSessionId);
			break;
		case "MENTOREDSITTING":
			rotaPeriodStartDate = rotaPeriodStartDate.replace("/", "-");
			endDateForExpected = getDateForRestRequest(12);
			response = given().spec(requestSpec).urlEncodingEnabled(true).log().all().when()
					.get("/RotaAdminREST/webresources/reports/standard-report/" + rotaPeriodStartDate + "/"
							+ endDateForExpected + "/LJA/" + ljaSouthLocationID + "/MENTOREDSITTING/"
							+ optimisedUrlSessionId);
			break;
		case "DAILYATTENDANCE":
			rotaPeriodStartDate = rotaPeriodStartDate.replace("/", "-");
			response = given().spec(requestSpec).urlEncodingEnabled(true).log().all().when()
					.get("/RotaAdminREST/webresources/reports/standard-report/" + rotaPeriodStartDate + "/LJA/"
							+ ljaSouthLocationID + "/" + magCourt1 + "/DAILYATTENDANCE/" + publishedUrlSessionId);
			break;
			
		case "MAGNONAVAILABILITY":
			endDateForExpected = getDateForRestRequest(6);
			response = given().spec(requestSpec).urlEncodingEnabled(true).log().all().when()
					.get("/RotaAdminREST/webresources/reports/standard-report/" + rotaPeriodStartDate + "/" + endDateForExpected
							+ "/" + "LJA/" + getDraftLJALocationID(location) + "/MAGNONAVAILABILITY/" + urlSessionId);
			break;
			
		case "MAGTRANSFERS":
			endDateForExpected = getDateForRestRequest(6);
			response = given().spec(requestSpec).urlEncodingEnabled(true).log().all().when()
					.get("/RotaAdminREST/webresources/reports/standard-report/" + rotaPeriodStartDate + "/" + endDateForExpected
							+ "/" + getDraftLJALocationID(location) + "/MAGTRANSFERS/" + urlSessionId);
			break;
		case "ADVISORY":
			endDateForExpected = getDateForRestRequest(6);
			response = given().spec(requestSpec).urlEncodingEnabled(true).log().all().when()
					.get("/RotaAdminREST/webresources/reports/standard-report/" + rotaPeriodStartDate + "/" + endDateForExpected
							+ "/" + getDraftLJALocationID(location) + "/ADVISORY/" + urlSessionId);
			break;
		case "VACATED_SITTINGS":
		case "CANCELLED_SITTINGS":
			rotaPeriodStartDate = getDateForRestRequest();
			endDateForExpected = getDateForRestRequest(6);
			response = given().spec(requestSpec).urlEncodingEnabled(true).log().all().when()
					.get("/RotaAdminREST/webresources/reports/standard-report/" + rotaPeriodStartDate + "/" + endDateForExpected
							+ "/" + "LJA/" + ljaSouthLocationID + "/"+reportType+"/" + publishedUrlSessionId);
			break;
		}
	}

	@Then("^Excel report should contains the rota start date and end date \"(.*?)\"$")
	public void excel_report_should_contains_the_rota_start_date_and_end_date(String endDate) throws Throwable {
		switch (reportType) {
		case "COURTSESSIONSPLIT":
		case "MAGNONAVAILABILITY":
		case "MAGTRANSFERS":
			assertUtil.isEquals(rotaPeriodStartDate + " to " + endDateForExpected, excelUtil.getCellValue(1, 0));
			break;
		case "MAGISTRATESINFO":
		case "MENTOREDSITTING":
		case "ADVISORY":
			assertUtil.isEquals(rotaPeriodStartDate.replace("-", "/") + " to " + endDateForExpected.replace("-", "/"),
					excelUtil.getCellValue(1, 0));
			break;
		case "MAGMOVEMENT":
			assertUtil.isEquals(rotaPeriodStartDate + " to " + endDate, excelUtil.getCellValue(1, 0));
			break;
		case "SITTINGSUMMARY":
			assertUtil.isEquals(rotaPeriodStartDate.replace("-", "/") + " to " + endDate.replace("-", "/"),
					excelUtil.getCellValue(1, 0));
			break;
		case "VACATED_SITTINGS":
		case "CANCELLED_SITTINGS":
			assertUtil.isEquals(rotaPeriodStartDate + " - " + endDateForExpected, excelUtil.getCellValue(1, 0));
			break;
		default:
			assertUtil.isEquals(rotaPeriodStartDate + " - " + endDate, excelUtil.getCellValue(1, 0));
		}

	}

	@Then("^Excel report contains the magistrate name \"(.*?)\" ,details consists of:$")
	public void excel_report_contains_the_magistrate_name_details_consists_of(String magName,
			List<String> personalDetails) throws Throwable {
		int rowNumber = excelUtil.getRowNumberByKeyForReports(magName);
		assertUtil.isEquals(magName, excelUtil.getCellValue(rowNumber, 0));
		rowNumber = rowNumber + 1;
		for (int i = 0; i < personalDetails.size(); i++) {
			assertUtil.isEquals(personalDetails.get(i), excelUtil.getCellValue(rowNumber + i, 0));
			assertUtil.isTrue(personalDetails.get(i), excelUtil.getCellValue(rowNumber + i, 0).length() > 0);
		}

	}

	@Then("^Report contains other content details:$")
	public void report_contains_other_content_details(List<String> otherReportHeadings) throws Throwable {
		int rowNumber = 0;
		for (int i = 0; i < otherReportHeadings.size(); i++) {
			rowNumber = excelUtil.getRowNumberByKeyForReports(otherReportHeadings.get(i));
			switch (otherReportHeadings.get(i)) {
			case "Panel Membership":
			case "Mentor & Appraiser Authorities":
			case "Sitting Exceptions":
			case "Inactivity Periods":
			case "Non-available Dates":
				assertUtil.isEquals(otherReportHeadings.get(i), excelUtil.getCellValue(rowNumber, 0));
				assertUtil.isTrue(excelUtil.getCellValue(rowNumber + 1, 0).length() > 0);
				break;
			case "Sitting Preferences":
				assertUtil.isEquals(otherReportHeadings.get(i), excelUtil.getCellValue(rowNumber, 0));
				// Sitting frequency:
				assertUtil.isTrue(excelUtil.getCellValue(rowNumber + 1, 0).length() > 0);
				assertUtil.isTrue(excelUtil.getCellValue(rowNumber + 1, 1).length() > 0);
				// Sit on Saturdays:
				assertUtil.isTrue(excelUtil.getCellValue(rowNumber + 2, 0).length() > 0);
				assertUtil.isTrue(excelUtil.getCellValue(rowNumber + 2, 1).length() > 0);
				// Sit on Bank Holidays:
				assertUtil.isTrue(excelUtil.getCellValue(rowNumber + 3, 0).length() > 0);
				assertUtil.isTrue(excelUtil.getCellValue(rowNumber + 3, 1).length() > 0);
				// Available at short notice:
				assertUtil.isTrue(excelUtil.getCellValue(rowNumber + 4, 0).length() > 0);
				assertUtil.isTrue(excelUtil.getCellValue(rowNumber + 4, 1).length() > 0);
				// Sit on consecutive days:
				assertUtil.isTrue(excelUtil.getCellValue(rowNumber + 5, 0).length() > 0);
				assertUtil.isTrue(excelUtil.getCellValue(rowNumber + 5, 1).length() > 0);
				// Sit on Welsh-speaking cases:
				assertUtil.isTrue(excelUtil.getCellValue(rowNumber + 6, 0).length() > 0);
				assertUtil.isTrue(excelUtil.getCellValue(rowNumber + 6, 1).length() > 0);
				// Able to do cross-bench appraisals:
				assertUtil.isTrue(excelUtil.getCellValue(rowNumber + 7, 0).length() > 0);
				assertUtil.isTrue(excelUtil.getCellValue(rowNumber + 7, 1).length() > 0);
				// Able to sit out of hours:
				assertUtil.isTrue(excelUtil.getCellValue(rowNumber + 8, 0).length() > 0);
				assertUtil.isTrue(excelUtil.getCellValue(rowNumber + 8, 1).length() > 0);
				break;

			}

		}
	}

	@Then("^Magistrate movement report should consists of:$")
	public void magistrate_movement_report_should_consists_of(Map<String, String> reportValues) throws Throwable {
		int rowNumber = 0;
		for (Map.Entry<String, String> content : reportValues.entrySet()) {
			rowNumber = 0;
			String contentValue = content.getValue();
			String contentKey = content.getKey();
			switch (contentKey) {
			case "New Appointments-Total":
			case "Transfers In-Total":
			case "Transfers Out-Total":
			case "Retired-Total":
			case "Resigned-Total":

				String[] data = contentKey.split("-");
				rowNumber = excelUtil.getRowNumberByKeyForReports(data[0]);
				// Repet the loop until it will reach to Total column and it
				// will update the row number
				do {
					rowNumber = rowNumber + 1;
				} while (!(excelUtil.getCellValue(rowNumber, 1).equalsIgnoreCase("Total")));

				String totalValue = excelUtil.getCellValue(rowNumber, 2);

				if (totalValue.equals("0.0")) {
					assertUtil.isEquals(data[1], excelUtil.getCellValue(rowNumber, 1));
					assertUtil.isEquals(contentValue, totalValue.replace("0.0", "0"));
				} else {
					assertUtil.isTrue("Title", excelUtil.getCellValue(rowNumber - 1, 0).length() > 0);
					assertUtil.isTrue("Title", excelUtil.getCellValue(rowNumber - 1, 1).length() > 0);
					assertUtil.isTrue("Title", excelUtil.getCellValue(rowNumber - 1, 2).length() > 0);
					assertUtil.isEquals(data[1], excelUtil.getCellValue(rowNumber, 1));
					assertUtil.isTrue(Integer.parseInt(totalValue.replace(".0", "0")) > 0);
				}

				break;
			}

		}
	}
	
	@Then("^Excel Report Transfer in headers should consists of:$")
	public void excel_Report_Transfer_in_headers_should_consists_of(List<String> transferInHeaders) throws Throwable {
		transferInrowNumber = excelUtil.getRowNumberByKey(transferInHeaders.get(0),0);
		//Transfer in  header verification
		assertUtil.isEquals(transferInHeaders.get(0), excelUtil.getCellValue(transferInrowNumber, 0));
		transferInrowNumber=++transferInrowNumber;
		for (int i = 1; i < transferInHeaders.size(); i++) {
			assertUtil.isEquals(transferInHeaders.get(i), excelUtil.getCellValue(transferInrowNumber, i-1));
		}
			    
	}

}
