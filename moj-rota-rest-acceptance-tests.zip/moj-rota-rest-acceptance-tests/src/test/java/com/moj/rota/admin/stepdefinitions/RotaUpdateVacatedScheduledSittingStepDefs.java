package com.moj.rota.admin.stepdefinitions;

import static com.jayway.restassured.RestAssured.given;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.jayway.restassured.path.json.JsonPath;
import com.jayway.restassured.response.Response;
import com.moj.rota.base.stepdefs.BaseStepDefination;
import com.rota.json.JsonAsString;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class RotaUpdateVacatedScheduledSittingStepDefs extends BaseStepDefination {

	private static String operationType = null;
	private static int versionNumber = 0;

	@When("^I request with panel type \"(.*?)\" ,business type \"(.*?)\",\"(.*?)\" , AM or PM \"(.*?)\" ,\"(.*?)\" ,\"(.*?)\",\"(.*?)\",\"(.*?)\",\"(.*?)\"$")
	public void i_sent_request_with_panel_type_business_type_AM_or_PM(String panelType, String businessType,
			String venueID, String sessionType, String date, String operationTypeVal, String day, String vacatedType,
			String location) throws Throwable {

		operationType = operationTypeVal;
		versionNumber = getUpdateVersionNumber(panelType);
		switch (operationType) {
		case "Add":
		case "LAdd":
			String json = JsonAsString.create_session.replace("panelValue", panelType)
					.replace("businessTypeValue", businessType).replace("versionValue", String.valueOf(versionNumber))
					.replace("durationValue", getDuration(operationType)).replace("sessionType", sessionType)
					.replace("sessionDateValue", getDate()).replace("dayValue", String.valueOf(getDayNumber()));

			response = given().spec(requestSpec).urlEncodingEnabled(true).body(json).log().all().when()
					.post("/RotaAdminREST/webresources/rota/session/" + getPublishedVenueID(location) + "/LJA/"
							+ publishedUrlSessionId);
			break;

		case "Update":
		case "LUpdate":
			String updatedjson = JsonAsString.create_session_vacate_update.replace("panelValue", panelType)
					.replace("businessTypeValue", businessType).replace("versionValue", String.valueOf(versionNumber))
					.replace("durationValue", getDuration(operationType)).replace("sessionType", sessionType)
					.replace("sessionDateValue", getDate()).replace("dayValue", String.valueOf(getDayNumber()))
					.replace("idValue", createdSessionID).replace("sessionsIdValue", publishCourtSessionID);

			response = given().spec(requestSpec).urlEncodingEnabled(true).body(updatedjson).log().all().when()
					.put("/RotaAdminREST/webresources/rota/session/" + createdSessionID + "/" + publishedUrlSessionId);

			break;
		case "RemoveLinked":
			versionNumber = 1;
			String removeLinkedjson = JsonAsString.create_session_vacate_update.replace("panelValue", panelType)
					.replace("businessTypeValue", businessType).replace("versionValue", String.valueOf(versionNumber))
					.replace("durationValue", "1").replace("sessionType", sessionType)
					.replace("sessionDateValue", getDate()).replace("dayValue", String.valueOf(getDayNumber()))
					.replace("idValue", createdSessionID).replace("sessionsIdValue", publishCourtSessionID)
					.replace("versionValue", String.valueOf(versionNumber));

			response = given().spec(requestSpec).urlEncodingEnabled(true).body(removeLinkedjson).log().all().when()
					.put("/RotaAdminREST/webresources/rota/session/" + createdSessionID + "/" + publishedUrlSessionId);
			versionNumber = 0;

			break;

		case "MagUIUpdate":

			Response sessionResponse = given().spec(requestSpec).urlEncodingEnabled(true).log().ifValidationFails()
					.when().get("/RotaAdminREST/webresources/rota/venue/LJA/" + ljaSouthLocationID + "/"
							+ getPublishedVenueID(location) + "/" + date + "/" + publishedUrlSessionId);
			sessionResponse.then().spec(getResponseSpecification()).log().ifValidationFails();

			JsonPath sessionsData = new JsonPath(sessionResponse.getBody().asInputStream());
			List<Object> sessiondataList = (ArrayList<Object>) sessionsData.get("sessions");

			Map<String, Object> sessionData = (HashMap<String, Object>) sessiondataList.get(5);

			String sesionID = (String) sessionData.get("id");

			String uiUpdatedjson = JsonAsString.vacate_session_vacate_update.replace("panelValue", panelType)
					.replace("businessTypeValue", businessType).replace("versionValue", String.valueOf(versionNumber))
					.replace("sessionType", sessionType).replace("sessionDateValue", date)
					.replace("dayValue", String.valueOf(getDayNumberByDate(date))).replace("idValue", sesionID)
					.replace("sessionsIdValue", publishCourtSessionID);

			response = given().spec(requestSpec).urlEncodingEnabled(true).body(uiUpdatedjson).log().all().when()
					.put("/RotaAdminREST/webresources/rota/session/" + sesionID + "/" + publishedUrlSessionId);

			break;

		case "Vacate_Scheduled":
		case "LVacate_Scheduled":
			versionNumber = getScheduleVacateVersionNum(panelType);

			String vacatedJson = JsonAsString.vacate_schedule_sittings.replace("idValue", createdSessionID)
					.replace("versionValue", String.valueOf(versionNumber)).replace("vacatedType", vacatedType);

			response = given().spec(requestSpec).urlEncodingEnabled(true).body(vacatedJson).log().all().when()
					.put("/RotaAdminREST/webresources/magistrate/scheduled-sittings/cancel/" + createdSessionID + "/"
							+ publishedUrlSessionId);
			response.then().spec(getResponseSpecification()).log().all();
			break;

		case "Delete":
		case "LDelete":
			response = given().spec(requestSpec).urlEncodingEnabled(true).log().all().when().delete(
					"/RotaAdminREST/webresources/rota/session/" + createdSessionID + "/" + publishedUrlSessionId);
			break;
		case "LinkedDelete":
			response = given().spec(requestSpec).urlEncodingEnabled(true).log().all().when().delete(
					"/RotaAdminREST/webresources/rota/session/" + createdSessionID + "/" + publishedUrlSessionId);
			response.then().spec(getResponseSpecification()).log().all();
			int deleteFirstSessionID = Integer.parseInt(createdSessionID) + 1;
			response = given().spec(requestSpec).urlEncodingEnabled(true).log().all().when().delete(
					"/RotaAdminREST/webresources/rota/session/" + deleteFirstSessionID + "/" + publishedUrlSessionId);
			break;
		default:
		}

	}

	@Then("^get the updated vacated sittings \"(.*?)\" ,\"(.*?)\",\"(.*?)\"$")
	public void get_the_updated_vacated_sittings(String panelType, String businessType, String vacateType)
			throws Throwable {

		if (operationType.equals("Update") || operationType.equals("LUpdate")) {
			response = given().spec(requestSpec).urlEncodingEnabled(true).log().ifValidationFails().when()
					.get("/RotaAdminREST/webresources/rota/session/" + createdSessionID + "/" + publishedUrlSessionId);
			response.then().spec(getResponseSpecification()).log().ifValidationFails();
		}
		JsonPath jsonPath = new JsonPath(response.body().asInputStream());

		if ((!operationType.equals("Delete") && !operationType.equals("Vacate_Scheduled"))
				&& (!operationType.equals("LDelete") && !operationType.equals("LVacate_Scheduled"))) {
			Map<String, Object> listOfData = (HashMap<String, Object>) jsonPath.get();
			versionNumber = (int) listOfData.get("version");
			assertUtil.isEquals(panelType, listOfData.get("panelType"));
			assertUtil.isEquals(businessType, listOfData.get("specialistBusinessType"));
			assertUtil.isEquals(getDuration(operationType), listOfData.get("duration").toString());
			if (operationType.equals("Add") || operationType.equals("LAdd")) {
				createdSessionID = (String) listOfData.get("id");
				assertUtil.isTrue(createdSessionID.length() > 1);
			}

		} else if (operationType.equals("Vacate_Scheduled") || operationType.equals("LVacate_Scheduled")) {
			Map<String, Object> vacatedData = (HashMap<String, Object>) jsonPath.get();
			assertUtil.isEquals(vacateType, vacatedData.get("type"));
			assertUtil.isTrue(vacatedData.get("reason").toString().length() > 0);
		}

	}

	@Then("^I should see the updated linked court sittings$")
	public void i_should_see_the_updated_linked_court_sittings() throws Throwable {

		if (operationType.equals("LAdd")) {
			JsonPath jsonPath = new JsonPath(response.body().asInputStream());

			Map<String, Object> listOfData = (HashMap<String, Object>) jsonPath.get();
			createdSessionID = (String) listOfData.get("id");
			assertUtil.isTrue(createdSessionID.length() > 1);
		}

		// After removing linked court sessions and checking the both the
		// session have scheduled sitting
		if (operationType.equals("RemoveLinked")) {
			// session1
			response = given().spec(requestSpec).urlEncodingEnabled(true).log().ifValidationFails().when()
					.get("/RotaAdminREST/webresources/rota/session/" + createdSessionID + "/" + publishedUrlSessionId);
			response.then().spec(getResponseSpecification()).log().ifValidationFails();

			JsonPath jsonPath = new JsonPath(response.body().asInputStream());
			Map<String, Object> listOfData = (HashMap<String, Object>) jsonPath.get("winger1");
			// Checking scheduled winger1 exist
			assertUtil.isTrue("First session Scheduled sitting not exist", listOfData.size() > 0);
			assertUtil.isTrue(listOfData.get("firstName").toString().length() > 0);

			int sessionID = Integer.parseInt(createdSessionID) + 1;
			// session2
			response = given().spec(requestSpec).urlEncodingEnabled(true).log().ifValidationFails().when()
					.get("/RotaAdminREST/webresources/rota/session/" + sessionID + "/" + publishedUrlSessionId);
			response.then().spec(getResponseSpecification()).log().ifValidationFails();

			JsonPath secondJsonPath = new JsonPath(response.body().asInputStream());
			Map<String, Object> secondSessionWinger1Data = (HashMap<String, Object>) secondJsonPath.get("winger1");

			assertUtil.isTrue("Second session Scheduled sitting not exist", secondSessionWinger1Data.size() > 0);
			assertUtil.isTrue(secondSessionWinger1Data.get("firstName").toString().length() > 0);
		}

	}

	private int getScheduleVacateVersionNum(String panelType) {
		if (panelType.equals("YOUTH")) {
			versionNumber = 3;
		} else if (panelType.equals("FAMILY")) {
			versionNumber = 5;
		} else if (panelType.equals("ADULT")) {
			versionNumber = 1;
		}
		return versionNumber;
	}

	private int getUpdateVersionNumber(String panelType) {
		if (panelType.equals("YOUTH")) {
			versionNumber = 2;
		} else if (panelType.equals("FAMILY")) {
			versionNumber = 4;
		} else if (panelType.equals("ADULT")) {
			versionNumber = 0;
		}
		return versionNumber;
	}

	private String getDuration(String operationTypeVal) {
		String durationValue;
		// defining linked session through duration
		if (operationTypeVal.substring(0).contains("L")) {
			durationValue = "2";
		} else {
			durationValue = "1";
		}
		return durationValue;
	}

}
