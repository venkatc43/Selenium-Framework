package com.moj.rota.admin.stepdefinitions;

import static com.jayway.restassured.RestAssured.given;

import com.jayway.restassured.path.json.JsonPath;
import com.moj.rota.base.stepdefs.BaseStepDefination;
import com.rota.json.JsonAsString;

import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class MagistrateAdvanceSearch extends BaseStepDefination {

	@When("^I sent request to service$")
	public void i_sent_request_to_service() throws Throwable {

		response = given().spec(requestSpec).urlEncodingEnabled(true).body(JsonAsString.magAdhocSearch).log().all()
				.when().post("/RotaAdminREST/webresources/magistrate/multi-search");
	}

	@When("^I sent request to service with location \"(.*?)\" , panel type \"(.*?)\" ,Adhoc \"(.*?)\" and lja location \"(.*?)\"$")
	public void i_sent_request_to_service_with_location_panel_type_Adhoc_and_lja_location(String location, String panel,
			String adhoc, String ljaLocation) throws Throwable {

		String json = JsonAsString.magAdhocSearch.replace("ljaValue", getDraftLJALocationID(ljaLocation))
				.replace("panelValue", panel).replace("adhocValue", adhoc)
				.replace("locationValue", getDraftRotaLocationID(location)).replace("specialAuthValue", "");

		response = given().spec(requestSpec).urlEncodingEnabled(true).body(json).log().all().when()
				.post("/RotaAdminREST/webresources/magistrate/multi-search");
	}

	@When("^I sent request to service with location \"(.*?)\" , panel type \"(.*?)\" ,Special Authority \"(.*?)\" and lja location \"(.*?)\"$")
	public void i_sent_request_to_service_with_location_panel_type_Special_Authority_and_lja_location(String location,
			String panel, String specialAuthority, String ljaLocation) throws Throwable {

		String json = JsonAsString.magAdhocSearch.replace("ljaValue", getDraftLJALocationID(ljaLocation))
				.replace("panelValue", panel).replace("adhocValue", "null")
				.replace("locationValue", getDraftRotaLocationID(location))
				.replace("specialAuthValue", specialAuthority);

		response = given().spec(requestSpec).urlEncodingEnabled(true).body(json).log().all().when()
				.post("/RotaAdminREST/webresources/magistrate/multi-search");

	}

	@Then("^I should see the service search results \"(.*?)\"$")
	public void i_should_see_the_service_search_results(String results) throws Throwable {
		response.then().spec(getResponseSpecification()).log().all();
		JsonPath jsonPath = new JsonPath(response.getBody().asInputStream());
		int resultsSize = jsonPath.getList("resultsList").size();
		if (results.equals("Results Not Found")) {
			assertUtil.isTrue("Magistrates not found with adhoc", resultsSize >= 0);
		} else {
			assertUtil.isTrue("Magistrates not found with adhoc", resultsSize > 0);
		}
	}

}
