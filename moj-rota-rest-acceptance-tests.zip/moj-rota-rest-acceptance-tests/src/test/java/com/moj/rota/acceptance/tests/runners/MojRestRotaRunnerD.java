package com.moj.rota.acceptance.tests.runners;

import cucumber.api.junit.Cucumber;
import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(
        features = {
                "target/test-classes"
                
        },
        		plugin = {
        		        "pretty", "html:target/cucumber-report/Reports",
        		        "json:target/cucumber-report/MOJREST/cucumber.json",
        		        "rerun:target/cucumber-report/moj/rerun.txt"},
        tags = {"@Rest-Session"},
        glue = {"com/moj/rota/"})
public class MojRestRotaRunnerD {
}
